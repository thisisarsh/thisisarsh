unit uTaxJul24;

interface

uses uTaxJan24, NCIniMod, Utils, uNCCLAIM, SysUtils, Math;

type
  TTaxJul24 = class(TTaxJan24)

  private

  protected
      procedure Set_ncbcschd(nc_bc_ann_sal: currency; nc_calc_type: char;
                          nc_calc_descr: shortstring; var w: recConst);override;
      function Calculate_CPP2(annual_salary:currency): currency;
      function Set_ncldtxtb(r: recNCCLAIM; AccidentDate: TDateTime; nc_tax_year, nc_acc_year: integer;
                            nc_max_adjustment: currency): boolean;Override;
      function Calculate_Fed_NRTC: currency;Override;
      function Calculate_Man_NRTC: currency;Override;
      procedure Calculate_A(var r: recNCCLAIM; Var w: recConst);Override;
      procedure Calculate_B(var r: recNCCLAIM; Var w: recConst);Override;
      procedure Calculate_C(var r: recNCCLAIM; Var w: recConst);Override;
end;

implementation

procedure TTaxJul24.Calculate_A(var r: recNCCLAIM; Var w: recConst);
begin
  //PrintDisplay('TTaxBase.Calculate_A(var r: recNCCLAIM; var w: recConst)');
  nc_ann_income := r.WKLY_SAL_A * 52;
  if (nc_ann_income > nc_max_ann_sal) then
     begin
     nc_prorate := nc_max_ann_sal / nc_ann_income;
     w.Work_nc_prorate := nc_prorate;
     nc_bc_pro_deductions := nc_bc_deductions * nc_prorate;
     end
  else
     begin
     nc_prorate := 1;
     w.Work_nc_prorate := nc_prorate;
     nc_bc_pro_deductions := nc_bc_deductions;
     end;

  Set_ncbcschd(nc_ann_income,'A','actual annual income',w);
  r.CPP_Prem := nc_bc_cpp;
  r.CPP2_Prem := nc_bc_cpp2;
  r.EI_Prem  := nc_bc_uic;

  if ( nc_bc_fedtax >= 0 ) then
     r.Inc_Tax_Fed := nc_bc_fedtax
  else
     r.Inc_Tax_Fed := 0;

  if ( nc_bc_mb_tax >= 0 ) then
     r.Inc_Tax_Man:= nc_bc_mb_tax
  else
     r.Inc_Tax_Man := 0;

  if ( nc_bc_td >= 0 ) then
     r.Total_Deds_A := nc_bc_td
  else
     r.Total_Deds_A := 0;
end;

procedure TTaxJul24.Calculate_B(var r: recNCCLAIM; Var w: recConst);
begin
  //PrintDisplay('TTaxBase.Calculate_B(var r: recNCCLAIM; var w: recConst)');
  if nc_ann_income > nc_max_ann_sal then
     begin
     Set_ncbcschd(nc_max_ann_sal,'B',inttostr(nc_tax_year)+ ' maximum annual income',w);
     r.WKLY_SAL := (nc_max_ann_sal / 52);
     r.CPP_Prem := nc_bc_cpp;
     r.CPP2_Prem := nc_bc_cpp2;
     r.EI_Prem := nc_bc_uic;

     if nc_bc_fedtax >= 0 then
        r.Inc_Tax_Fed := nc_bc_fedtax
     else
        r.Inc_Tax_Fed := 0;

     if nc_bc_mb_tax >= 0 then
        r.Inc_Tax_Man := nc_bc_mb_tax
     else
        r.Inc_Tax_Man := 0;

     if nc_bc_td >= 0 then
        r.Total_Deds := nc_bc_td
     else
        r.Total_Deds := 0;
     end
  else
     begin
     r.WKLY_SAL := r.WKLY_SAL_A;
     r.Total_Deds := r.Total_Deds_A;
     end;
end;

procedure TTaxJul24.Calculate_C(var r: recNCCLAIM; Var w: recConst);
begin
  if nc_max_ann_sal > nc_ann_income then
     begin
     nc_shelter_income := nc_ann_income  * 0.75;
     nc_shelter_base   := nc_ann_income;
     end
  else
     begin
     nc_shelter_income := nc_max_ann_sal * 0.75;
     nc_shelter_base   := nc_max_ann_sal;
     end;

  Set_ncbcschd(nc_shelter_income,'C','annual shelter income',w);
  r.CPP_Prem_S := nc_bc_cpp;
  r.CPP2_Prem_S := nc_bc_cpp2;
  r.EI_Prem_S := nc_bc_uic;

  if nc_bc_fedtax >= 0 then
     r.Inc_Tax_Fed_S := nc_bc_fedtax
  else
     r.Inc_Tax_Fed_S := 0;

  if nc_bc_mb_tax >= 0 then
     r.Inc_Tax_Man_S := nc_bc_mb_tax
  else
     r.Inc_Tax_Man_S := 0;

  if nc_bc_td >= 0 then
     r.Total_Deds_S := nc_bc_td
  else
     r.Total_Deds_S := 0;
end;


function TTaxJul24.Calculate_Fed_NRTC: currency;
begin
  //PrintDisplay('TTaxBase.Calculate_Fed_NRTC: currency');
  //result := PDoxRound((nc_bc_cpp + nc_bc_uic + nc_tax_exmp + nc_federalCanadaEmploymentCredit) * nc_fed_tax_rate_i, 2);
  result := PDoxRound((nc_bc_cpp + nc_bc_cpp2 + nc_bc_uic + nc_tax_exmp) * nc_fed_tax_rate_i, 2);
end;

function TTaxJul24.Calculate_Man_NRTC: currency;
var
  a : double;
begin
  //PrintDisplay('TTaxJan09.Calculate_Man_NRTC: currency');
  a := PDoxRound( ( nc_bc_cpp + nc_bc_cpp2 + nc_bc_uic + nc_mb_tax_exmp + nc_mbFamilyTaxBenefitAmt ) * nc_mb_tax_rate_i, 2 );
  result := a;
end;

function TTaxJul24.Calculate_CPP2(annual_salary:currency): currency;
var
   CPP2BaseSalary:Currency;
begin
  if (nc_cpp_exempt = 'Y') then
     begin
     result := 0;
     end
  else
     begin
     CPP2BaseSalary := nc_cpp_basic_exmp + (nc_cpp_max_ann_contrib / nc_cpp_crate);
     if (annual_salary > CPP2BaseSalary) then
        begin
        result := PDoxRound((annual_salary - CPP2BaseSalary) * nc_cpp2_crate, 2);
        end
     else
        begin
        result := 0;
        end;


     if result > nc_cpp2_max_ann_contrib then
        result := nc_cpp2_max_ann_contrib;
     end;
end;


procedure TTaxJul24.Set_ncbcschd(nc_bc_ann_sal: currency; nc_calc_type: char;
      nc_calc_descr: shortstring; var w: recConst);
begin
  //PrintDisplay('TTaxJan09.Set_ncbcschd(nc_bc_ann_sal: currency;');
  nc_bc_cpp := Calculate_CPP(nc_bc_ann_sal);
  nc_bc_cpp2 := Calculate_CPP2(nc_bc_ann_sal);
  nc_bc_uic := Calculate_UIC(nc_bc_ann_sal);
  //nc_federalCanadaEmploymentCredit := Calculate_federalCanadaEmploymentCredit(nc_bc_ann_sal);
  nc_bc_ann_sal_net := Calculate_Net_Income(nc_bc_ann_sal);
  nc_bc_nrtc := Calculate_Fed_NRTC;
  nc_mbFamilyTaxBenefitAmt := Calculate_mbFamilyTaxBenefitAmt();
  nc_bc_mb_nrtc := Calculate_Man_NRTC;
  nc_bc_fedtax := Calculate_Fed_Tax(w);
  nc_bc_mb_tax := Calculate_Man_Tax(w);
  //
  // Changed Nov 2003 by D. Madill
  // Changed to eliminate rounding error on tax calculations.
  //
  nc_bc_cpp := PdoxRound(nc_bc_cpp, 2);
  nc_bc_cpp2 := PdoxRound(nc_bc_cpp2, 2);
  nc_bc_uic := PDoxRound(nc_bc_uic, 2);
  //nc_federalCanadaEmploymentCredit := PDoxRound( nc_federalCanadaEmploymentCredit, 2 );
  nc_bc_fedtax := PDoxRound(nc_bc_fedtax, 2);
  nc_bc_mb_tax := PDoxRound(nc_bc_mb_tax, 2);
  nc_bc_ann_sal := PDoxRound(nc_bc_ann_sal, 2);
  nc_bc_ann_sal_net := PDoxRound(nc_bc_ann_sal_net, 2);
  nc_bc_nrtc := PDoxRound(nc_bc_nrtc, 2);
  nc_bc_mb_nrtc := PDoxRound(nc_bc_mb_nrtc, 2);
  nc_bc_bft := PDoxRound(nc_bc_bft, 2);
  nc_bc_fst := PDoxRound(nc_bc_fst, 2);
  nc_bc_mbt := PDoxRound(nc_bc_mbt, 2);
  //
  //nc_bc_td := nc_bc_cpp + nc_bc_uic + nc_bc_fedtax + nc_bc_mb_tax;
  nc_bc_td := nc_bc_cpp + nc_bc_cpp2 + nc_bc_uic + nc_bc_fedtax + nc_bc_mbt;
  nc_bc_netinc := nc_bc_ann_sal - nc_bc_td;
  Case nc_calc_type of
    'A': begin
           w.Work_nc_bc_cpp_a := nc_bc_cpp;
           w.work_nc_bc_cpp2_a := nc_bc_cpp2;
           w.Work_nc_bc_uic_a := nc_bc_uic;
           //w.Work_federalCanadaEmploymentCredit_a := nc_federalCanadaEmploymentCredit;
           w.Work_actualNoOfDependants := actualNoOfDependants;
           w.Work_nc_bc_ann_sal_net_a := nc_bc_ann_sal_net;
           w.Work_nc_bc_nrtc_a := nc_bc_nrtc;
           w.Work_nc_bc_mb_nrtc_a := nc_bc_mb_nrtc;
           w.Work_nc_bc_mb_tax_a := nc_bc_mb_tax;
           w.Work_nc_bc_td_a := nc_bc_td;
           w.Work_nc_bc_netinc_a := nc_bc_netinc;
           w.Work_nc_bc_bft_a := nc_bc_bft;
           w.Work_nc_bc_mbt_a := nc_bc_mbt;
           w.Work_mbFamilyTaxBenefitRate_a := nc_mbFamilyTaxBenefitAmt;
         end;
    'B': begin
           w.Work_nc_bc_cpp_b := nc_bc_cpp;
           w.Work_nc_bc_cpp2_b := nc_bc_cpp2;
           w.Work_nc_bc_uic_b := nc_bc_uic;
           //w.Work_federalCanadaEmploymentCredit_b := nc_federalCanadaEmploymentCredit;
           w.Work_nc_bc_ann_sal_net_b := nc_bc_ann_sal_net;
           w.Work_nc_bc_nrtc_b := nc_bc_nrtc;
           w.Work_nc_bc_mb_nrtc_b := nc_bc_mb_nrtc;
           w.Work_nc_bc_mb_tax_b := nc_bc_mb_tax;
           w.Work_nc_bc_td_b := nc_bc_td;
           w.Work_nc_bc_netinc_b := nc_bc_netinc;
           w.Work_nc_bc_bft_b := nc_bc_bft;
           w.Work_nc_bc_mbt_b := nc_bc_mbt;
           w.Work_mbFamilyTaxBenefitRate_b := nc_mbFamilyTaxBenefitAmt;
         end;
    'C': begin
           w.Work_nc_bc_cpp_c := nc_bc_cpp;
           w.Work_nc_bc_cpp2_c := nc_bc_cpp2;
           w.Work_nc_bc_uic_c := nc_bc_uic;
           //w.Work_federalCanadaEmploymentCredit_c := nc_federalCanadaEmploymentCredit;
           w.Work_nc_bc_ann_sal_net_c := nc_bc_ann_sal_net;
           w.Work_nc_bc_nrtc_c := nc_bc_nrtc;
           w.Work_nc_bc_mb_nrtc_c := nc_bc_mb_nrtc;
           w.Work_nc_bc_mb_tax_c := nc_bc_mb_tax;
           w.Work_nc_bc_td_c := nc_bc_td;
           w.Work_nc_bc_netinc_c := nc_bc_netinc;
           w.Work_nc_bc_bft_c := nc_bc_bft;
           w.Work_nc_bc_mbt_c := nc_bc_mbt;
           w.Work_mbFamilyTaxBenefitRate_c := nc_mbFamilyTaxBenefitAmt;
         end;
    'D': begin
           w.Work_nc_bc_cpp_d := nc_bc_cpp;
           w.Work_nc_bc_cpp2_d := nc_bc_cpp2;
           w.Work_nc_bc_uic_d := nc_bc_uic;
           //w.Work_federalCanadaEmploymentCredit_d := nc_federalCanadaEmploymentCredit;
           w.Work_nc_bc_ann_sal_net_d := nc_bc_ann_sal_net;
           w.Work_nc_bc_nrtc_d := nc_bc_nrtc;
           w.Work_nc_bc_mb_nrtc_d := nc_bc_mb_nrtc;
           w.Work_nc_bc_mb_tax_d := nc_bc_mb_tax;
           w.Work_nc_bc_td_d := nc_bc_td;
           w.Work_nc_bc_netinc_d := nc_bc_netinc;
           w.Work_nc_bc_bft_d := nc_bc_bft;
           w.Work_nc_bc_mbt_d := nc_bc_mbt;
           w.Work_mbFamilyTaxBenefitRate_d := nc_mbFamilyTaxBenefitAmt;
         end;
    'E': begin
           w.Work_nc_bc_cpp_e := nc_bc_cpp;
           w.Work_nc_bc_cpp2_e := nc_bc_cpp2;
           w.Work_nc_bc_uic_e := nc_bc_uic;
           //w.Work_federalCanadaEmploymentCredit_e := nc_federalCanadaEmploymentCredit;
           w.Work_nc_bc_ann_sal_net_e := nc_bc_ann_sal_net;
           w.Work_nc_bc_nrtc_e := nc_bc_nrtc;
           w.Work_nc_bc_mb_nrtc_e := nc_bc_mb_nrtc;
           w.Work_nc_bc_mb_tax_e := nc_bc_mb_tax;
           w.Work_nc_bc_td_e := nc_bc_td;
           w.Work_nc_bc_netinc_e := nc_bc_netinc;
           w.Work_nc_bc_bft_e := nc_bc_bft;
           w.Work_nc_bc_mbt_e := nc_bc_mbt;
           w.Work_mbFamilyTaxBenefitRate_e := nc_mbFamilyTaxBenefitAmt;
         end;
    'M': begin
           w.Work_nc_bc_cpp_m := nc_bc_cpp;
           w.Work_nc_bc_cpp2_m := nc_bc_cpp2;
           w.Work_nc_bc_uic_m := nc_bc_uic;
           //w.Work_federalCanadaEmploymentCredit_m := nc_federalCanadaEmploymentCredit;
           w.Work_nc_bc_ann_sal_net_m := nc_bc_ann_sal_net;
           w.Work_nc_bc_nrtc_m := nc_bc_nrtc;
           w.Work_nc_bc_mb_nrtc_m := nc_bc_mb_nrtc;
           w.Work_nc_bc_mb_tax_m := nc_bc_mb_tax;
           w.Work_nc_bc_td_m := nc_bc_td;
           w.Work_nc_bc_netinc_m := nc_bc_netinc;
           w.Work_nc_bc_bft_m := nc_bc_bft;
           w.Work_nc_bc_mbt_m := nc_bc_mbt;
           w.Work_mbFamilyTaxBenefitRate_m := nc_mbFamilyTaxBenefitAmt;
         end;
    'S': begin
           w.Work_nc_bc_cpp_s := nc_bc_cpp;
           w.Work_nc_bc_cpp2_s := nc_bc_cpp2;
           w.Work_nc_bc_uic_s := nc_bc_uic;
           //w.Work_federalCanadaEmploymentCredit_s := nc_federalCanadaEmploymentCredit;
           w.Work_nc_bc_ann_sal_net_s := nc_bc_ann_sal_net;
           w.Work_nc_bc_nrtc_s:= nc_bc_nrtc;
           w.Work_nc_bc_mb_nrtc_s := nc_bc_mb_nrtc;
           w.Work_nc_bc_mb_tax_s := nc_bc_mb_tax;
           w.Work_nc_bc_td_s:= nc_bc_td;
           w.Work_nc_bc_netinc_s := nc_bc_netinc;
           w.Work_nc_bc_bft_s := nc_bc_bft;
           w.Work_nc_bc_mbt_s := nc_bc_mbt;
           w.Work_mbFamilyTaxBenefitRate_s := nc_mbFamilyTaxBenefitAmt;
         end;
    end;
end;

function TTaxJul24.Set_ncldtxtb(r: recNCCLAIM; AccidentDate: TDateTime; nc_tax_year, nc_acc_year: integer;
  nc_max_adjustment: currency): boolean;
var
   Test_Accident_Date:TDateTime;
   Acc_Year, Acc_Month, Acc_Day, Test_Tax_Year:Word;
begin
  //PrintDisplay('TTaxCalculator.Set_ncldtxtb(nc_tax_year, nc_acc_year: integer;');
  result:=false;

  Test_Tax_Year := nc_tax_year;

  //
  // LRC Bill 18
  //
  DecodeDate(r.Accident_Date, Acc_Year, Acc_Month, Acc_Day);
  Test_Tax_Year := Max(Year(r.Accident_Date), r.Indexation_Year);
  if nc_max_adjustment <> 0 then
     begin
     nc_max_ann_sal := nc_max_adjustment;
     end
  else
     begin
     if (Acc_Year >= 2006) AND (Acc_Year <= 2021)  then
        begin
        nc_max_ann_sal := r.WKLY_SAL_A * 52;
        end
     else
        begin
        nc_max_ann_sal := getAnnualMaximum(r.Accident_Date, nc_acc_year, Acc_Month, nc_tax_year);
        end;
     end;

  with arrayNCTAXRAT[FindindexNCTAXRAT(AccidentDate, nc_tax_year)] do
    begin
    nc_uic_prate               := UIC_premium_rate;
    nc_max_ins_earn            := UIC_max_insured_earnings;
    nc_uic_max_ann_prem        := UIC_max_annual_premium;
    nc_cpp_basic_exmp          := CPP_basic_exemption;
    nc_cpp_crate               := CPP_contrib_rate;
    nc_cpp_max_ann_contrib     := CPP_max_annual_contrib;
    nc_cpp2_crate              := CPP2_contrib_rate;
    nc_cpp2_max_ann_contrib    := CPP2_max_annual_contrib;
    nc_fed_inclvl_i            := FED_income_level_i;
    nc_fed_inclvl_ii           := FED_income_level_ii;
    nc_fed_inclvl_iii          := FED_income_level_iii;
    nc_fed_inclvl_iiii         := FED_income_level_iiii;
    nc_fed_tax_amt_i           := FED_tax_amt_i;
    nc_fed_tax_amt_ii          := FED_tax_amt_ii;
    nc_fed_tax_amt_iii         := FED_tax_amt_iii;
    nc_fed_tax_amt_iiii        := FED_tax_amt_iiii;
    nc_fed_tax_rate_i          := FED_tax_rate_i;
    nc_fed_tax_rate_ii         := FED_tax_rate_ii;
    nc_fed_tax_rate_iii        := FED_tax_rate_iii;
    nc_fed_tax_rate_iiii       := FED_tax_rate_iiii;
    nc_fed_tax_rate_iiiii      := FED_tax_rate_iiiii;
    nc_fed_surtax_rate_i       := FED_surtax_rate_i;
    nc_fed_surtax_rate_ii      := FED_surtax_rate_ii;
    nc_fed_surtax_lim_ii       := FED_surtax_limit_ii;
    nc_mb_tax_rate             := MB_tax_rate;
    nc_mb_tax_rate_i           := MB_tax_rate_i;
    nc_mb_tax_rate_ii          := MB_tax_rate_ii;
    nc_mb_tax_rate_iii         := MB_tax_rate_iii;
    nc_mb_inclvl_i             := MB_income_level_i;
    nc_mb_inclvl_ii            := MB_income_level_ii;
    nc_mb_tax_amt_i            := MB_tax_amt_i;
    nc_mb_tax_amt_ii           := MB_tax_amt_ii;
    nc_mb_net_rate             := MB_net_tax_rate;
    nc_mbFamilyTaxBenefitRate  := mbFamilyTaxBenefitRate;
    //nc_maxfederalCanadaEmploymentCredit := federalCanadaEmploymentCredit;
    end;

  if (Acc_Year < 2006) or (Acc_Year > 2021) then
     begin
     if (FindindexNCANNMAX(r.Accident_Date, nc_acc_year, nc_tax_year) > -1)   or
        (FindindexNCTAXRAT(AccidentDate, nc_tax_year) > -1) then
        result := true;
     end
  else
     begin
     result := true;
     end;

end;

end.
