(*****************************************************************)
(*  Wageloss System                                              *)
(*                                                               *)
(*  Initialization Module                                        *)
(*                                                               *)
(*  This module stores global data records and arrays. Some of   *)
(*  the arrays are populated at startup from WLTABLES.DLL.       *)
(*                                                               *)
(*  Author: Brad Trupp  / Capella Systems Group, Inc.            *)
(*  Date:   July 1997                                            *)
(*****************************************************************)

unit NCIniMod;

interface

uses Windows, Registry, NCRecdef, QuickRpt, SysUtils, Printers;

const

  UW_RegKeyRoot: string = '\Software\WCB\WagelossSystem';

var
  arrayNCANNMAX: array[1..140] of recNCANNMAX;
  arrayNCCHQMSG: array[1..39] of recNCCHQMSG;
  arrayNCCODEXP: array[1..39] of recNCCODEXP;
  arrayNCCODTAX: array[1..39] of recNCCODTAX;
  arrayNCEXMAMT: array[1..39] of recNCEXMAMT;
  arrayNCINDEXF: array[1..39] of recNCINDEXF;
  arrayNCTAXRAT: array[1..39] of recNCTAXRAT;
  arrayNC_CFIO:  array[1..39] of recNC_CFIO;

  indexNCANNMAX: integer;
  indexNCCHQMSG: integer;
  indexNCCODEXP: integer;
  indexNCCODTAX: integer;
  indexNCEXMAMT: integer;
  indexNCINDEXF: integer;
  indexNCTAXRAT: integer;
  indexNC_CFIO: integer;

  dataClaim: recNCCLAIM;
  dataForm: recNCFORM;
  dataLogin: recNCLOGIN;

  QRPrinterDefault, QRBinDefault: integer;
  QRPrinterDefaultName: string;

  function  GetCurrentTaxYear: integer; stdcall; external 'WLTABLES.DLL';
  procedure GetNCANNMAX(var tb: array of recNCANNMAX); stdcall; external 'WLTABLES.DLL';
  procedure GetNCCHQMSG(var tb: array of recNCCHQMSG); stdcall; external 'WLTABLES.DLL';
  procedure GetNCCODEXP(var tb: array of recNCCODEXP); stdcall; external 'WLTABLES.DLL';
  procedure GetNCCODTAX(var tb: array of recNCCODTAX); stdcall; external 'WLTABLES.DLL';
  procedure GetNCEXMAMT(var tb: array of recNCEXMAMT); stdcall; external 'WLTABLES.DLL';
  procedure GetNCINDEXF(var tb: array of recNCINDEXF); stdcall; external 'WLTABLES.DLL';
  procedure GetNCTAXRAT(var tb: array of recNCTAXRAT); stdcall; external 'WLTABLES.DLL';
  procedure GetNC_CFIO(var tb: array of recNC_CFIO);   stdcall; external 'WLTABLES.DLL';
  procedure GetWagelossRegistryData;
  procedure PutWagelossRegistryData;
  procedure PrintDisplay(s : string);

implementation

(******************************************************************************)
(*                                                                            *)
(*                                                                            *)
(*                                                                            *)
(******************************************************************************)
procedure GetWagelossRegistryData;
var
  reg: TRegistry;
begin
  reg := TRegistry.Create;
  try
    reg.RootKey := HKEY_CURRENT_USER;
    if reg.OpenKey( UW_RegKeyRoot, true ) then
    begin
      if reg.ValueExists( 'QRPrinterDefault' ) then
        QRPrinterDefault := reg.ReadInteger( 'QRPrinterDefault' );
      if reg.ValueExists( 'QRPrinterDefaultName' ) then
        QRPrinterDefaultName := reg.ReadString( 'QRPrinterDefaultName' );
      if reg.ValueExists( 'QRBinDefault' ) then
        QRBinDefault := reg.ReadInteger( 'QRBinDefault' );

      reg.CloseKey;
    end;

  finally
    reg.Free;
end;
end;

(******************************************************************************)
(*                                                                            *)
(*                                                                            *)
(*                                                                            *)
(******************************************************************************)
procedure PutWagelossRegistryData;
var
  reg: TRegistry;
begin
  reg := TRegistry.Create;
  try
    reg.RootKey := HKEY_CURRENT_USER;
    if reg.OpenKey( UW_RegKeyRoot, true ) then
      begin
      reg.WriteInteger( 'QRPrinterDefault', QRPrinterDefault);
      reg.WriteString( 'QRPrinterDefaultName', QRPrinterDefaultName);
      reg.WriteInteger( 'QRBinDefault', QRBinDefault);
      reg.CloseKey;
      end;
  finally
    reg.Free;
    end;
end;


procedure PrintDisplay(s : string);
var
  f: textfile;
begin
  // For debugging the dll
  AssignFile(f, 'C:\WCB Projects\Development\Wageloss\bin\atemp.txt');
  append(f);
  writeln(f, s);
  close(f);
end;

(******************************************************************************)
(*                                                                            *)
(*  At startup / initialization the in-memory arrays will be loaded from      *)
(*  the WLTABLES DLL.                                                         *)
(*                                                                            *)
(******************************************************************************)
Initialization
begin
  {$IFDEF DEBUG}
  ShowDebugLine( 'WLINIT00 started.');
  {$ENDIF}
  GetNCANNMAX(arrayNCANNMAX);
  GetNCCHQMSG(arrayNCCHQMSG);
  GetNCCODEXP(arrayNCCODEXP);
  GetNCCODTAX(arrayNCCODTAX);
  GetNCEXMAMT(arrayNCEXMAMT);
  GetNCINDEXF(arrayNCINDEXF);
  GetNCTAXRAT(arrayNCTAXRAT);
  GetNC_CFIO(arrayNC_CFIO);
  indexNCANNMAX:= -1;
  indexNCCHQMSG:= -1;
  indexNCCODEXP:= -1;
  indexNCCODTAX:= -1;
  indexNCEXMAMT:= -1;
  indexNCINDEXF:= -1;
  indexNCTAXRAT:= -1;
  indexNC_CFIO:= -1;
  ClearNCCLAIM( dataClaim );
  QRPrinterDefault:= -1;
  QRPrinterDefaultName:='';
  QRBinDefault:= -1;
  GetWagelossRegistryData;
  {$IFDEF DEBUG}
  ShowDebugLine( 'WLINIT00 complete.');
  {$ENDIF}
end;

end.
