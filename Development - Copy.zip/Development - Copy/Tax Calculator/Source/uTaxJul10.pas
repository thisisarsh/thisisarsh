unit uTaxJul10;

interface
uses uTaxJan10, NCIniMod, Utils, uNCCLAIM;

type
  TTaxJul10 = class(TTaxJan10)
end;

implementation

{ TTaxJul10}

end.
