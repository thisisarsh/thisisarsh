unit uTaxJul22;

interface

uses uTaxJan22, NCIniMod, Utils, uNCCLAIM;

type
  TTaxJul22 = class(TTaxJan22)
end;

implementation

  { TTaxJul21}

end.
