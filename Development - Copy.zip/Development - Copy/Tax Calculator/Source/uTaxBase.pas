unit uTaxBase;

interface

uses
  SysUtils, Math, NCIniMod, Utils, uNCCLAIM, Dialogs, Variants;

type
  ECalcError = class(Exception);
type
  TTaxBase = class

  private
    FVersion: Double;
    procedure SetUserName(const Value: string);

  protected
    FUserName: string;
    nc_uic_prate                :currency;
    nc_max_ins_earn             :currency;
    nc_uic_max_ann_prem         :currency;
    nc_cpp_basic_exmp           :currency;
    nc_cpp_crate                :double; //currency;
    nc_cpp_max_ann_contrib      :currency;
    nc_cpp2_max_ann_contrib     :currency;
    nc_cpp2_crate               :Currency;
    nc_fed_inclvl_i             :currency;
    nc_fed_inclvl_ii            :currency;
    nc_fed_tax_amt_i            :currency;
    nc_fed_tax_amt_ii           :currency;
    nc_fed_tax_rate_i           :currency;
    nc_fed_tax_rate_ii          :currency;
    nc_fed_tax_rate_iii         :currency;
    nc_fed_surtax_rate_i        :currency;
    nc_fed_surtax_rate_ii       :currency;
    nc_fed_surtax_lim_ii        :currency;
    nc_mb_tax_rate              :currency;
    nc_mb_tax_rate_i            :currency;
    nc_mb_tax_rate_ii           :currency;
    nc_mb_tax_rate_iii          :currency;
    nc_mb_inclvl_i              :currency;
    nc_mb_inclvl_ii             :currency;
    nc_mb_tax_amt_i             :currency;
    nc_mb_tax_amt_ii            :currency;
    nc_mb_net_rate              :currency;
    NC_SPOUSE                   :currency;
    NC_Prov_SPOUSE              :Currency; // Added mid year 2003
    NC_II_SPOUSE                :currency;
    NC_III_SPOUSE               :currency;
    NC_CHILDSPOUSE              :currency;
    NC_Prov_CHILDSPOUSE         :Currency; // Added Midyear 2003
    NC_II_CHILDSPOUSE           :currency;
    NC_III_CHILDSPOUSE          :currency;
    nc_1st_dep                  :currency;
    NC_Prov_1st_Dep             :Currency; // Added mid year 2003
    nc_II_dep                   :currency;
    NC_III_DEP                  :currency;
    nc_3rd_dep                  :currency;
    NC_Prov_3rd_Dep             :Currency; // Added midyear 2003
    nc_tax_year                 :integer;
    nc_accident_year            :integer;
    nc_no_of_dep                :integer;
    nc_no_infirm                :integer;
    personal                    :currency;
    Prov_Personal               :Currency; // Added midyear 2003
    II_Personal                 :currency;
    III_Personal                :currency;
    nc_base_dep                 :currency;
    nc_add_dep                  :currency;
    infirm                      :currency;
    Prov_Infirm                 :Currency; // Added midyear 2003
    NC_Prov_Infirm              :Currency; // Added midyear 2003
    nc_II_infirm                :currency;
    NC_III_INFIRM               :currency;
    NC_EXEMPT_AMOUNT            :currency;
    NC_MB_EXEMPT_AMOUNT         :Currency; // Added midyear 2003
    nc_ii_credit                :currency;
    nc_iii_credit               :currency;
    nc_tax_exmp                 :currency;
    nc_mb_tax_exmp              :currency; // added mid year 2003
    nc_uic_exempt               :string;
    nc_cpp_exempt               :string;
    nc_tax_exempt               :string;
    selfEmployed                :string;
    nc_ann_income               :currency;
    nc_bc_ann_sal_net           :currency;
    nc_bc_cpp, nc_bc_cpp2, nc_bc_uic : currency;
    nc_bc_deductions            : currency;
    nc_bc_pro_deductions        : currency;
    nc_cben_income              : currency; //added for 2006 leg review
    nc_minwage_income           : currency;
    nc_minwage_shelter_income   : currency;
    nc_prorate                  : double;
    nc_bc_fedtax, nc_bc_mb_tax, nc_bc_td: currency;
    nc_max_ann_sal              : currency;
    nc_shelter_income, nc_shelter_base: currency;
    nc_postinj_earn, nc_cben_pinj_inc, nc_cben_pinj_ann :currency;
    nc_colben_tax               : currency;
    nc_bc_netinc                : currency;
    nc_bc_cpp_sal               : currency;
    nc_bc_nrtc, nc_bc_bft, nc_bc_fst: currency;
    nc_bc_mb_nrtc, nc_bc_mbt, nc_bc_mnt, nc_bc_mst, nc_bc_mtr: currency;
    NC_DAYS_PER_WK              : currency;
    MAXIMUM_WK_BENEFIT_90       : currency;
    WKLY_TAX_SHELTER            : currency;
    WEEKLY_NET_S                : currency;
    WEEKLY_90                   : currency;
    WEEKLY_80                   : currency;
    WEEKLY_90_S                 : currency;
    WEEKLY_80_S                 : currency;
    EXCESS_90                   : currency;
    EXCESS_80                   : currency;
    EXCESS_90_S                 : currency;
    EXCESS_80_S                 : currency;
    TheTaxYear			            : Integer;
    federalChildTaxCredit       : currency; // added mid year 2007
    //nc_maxfederalCanadaEmploymentCredit : currency; //added mid year 2007
    //nc_federalCanadaEmploymentCredit : Currency; // added mid year 2007
    actualNoOfDependants        : integer;  // added mid year 2007
    nc_mbFamilyTaxBenefitRate   : Currency; //added mid year 2008
    nc_mbFamilyTaxBenefitAmt    : Currency; //added mid year 2008    
    function Calculate_CPP(annual_salary:currency): currency;dynamic;
    function Calculate_UIC(annual_salary:currency): currency;dynamic;
    //function Calculate_federalCanadaEmploymentCredit(annual_salary:currency): currency;dynamic;
    function Calculate_Net_Income(annual_salary:currency):currency;dynamic;
    function Calculate_Fed_NRTC:currency;dynamic;
    function Calculate_Man_NRTC:currency;dynamic;
    function Calculate_Fed_Tax(var w: recConst):currency;dynamic;
    function Calculate_Fed_Surtax:currency;dynamic;
    function Calculate_Fed_Tax_2:currency;dynamic;
    function Calculate_Man_Tax(var w: recConst):currency;dynamic;
    function Calculate_Man_mbt:currency;dynamic;
    function Calculate_Man_mnt:currency;dynamic;
    function Calculate_Man_mst:currency;dynamic;
    function Calculate_Man_mtr:currency;dynamic;
    procedure SetPersonal(AccidentDate: TDateTime; year:integer; var w: recConst);dynamic;
    procedure SetMarital(AccidentDate: TDateTime; year:integer;
      status, spouse_working:shortstring; ClaimSpouseForTaxPurposes:string; var w: recConst);dynamic;
    function FindindexNCEXMAMT(AccidentDate:TDateTime; year:integer):integer;dynamic;
    procedure SetExemptForDependants(AccidentDate: TDateTime; year:integer);dynamic;
    procedure SetDependantAmounts(AccidentDate: TDateTime; year:integer; var w: recConst);dynamic;
    function Calculate_Exempt_Amount:currency;dynamic;
    function Calculate_Section_II:currency;dynamic;
    function Calculate_Section_III:currency;dynamic;
    function SetTaxCode(AccidentDate: TDateTime; year:integer):ShortString;dynamic;
//    function FindindexNCCODTAX(AccidentDate: TDateTime; year:integer):integer;dynamic;
    function FindindexNCANNMAX(iAccident_Date:TDateTime; accident_year, tax_year:integer):integer;dynamic;
    function getAnnualMaximum(iAccident_Date:TdateTime; accident_year, accident_month, tax_year: integer): Currency;dynamic;
    function FindindexNCTAXRAT(AccidentDate: TDateTime; year:integer):integer;dynamic;
    function Calc_nc_bc_deductions(var r: recNCCLAIM):currency;dynamic;
    procedure Calculate_A(var r: recNCCLAIM; Var w: recConst);dynamic;
    procedure Calculate_B(var r: recNCCLAIM; Var w: recConst);dynamic;
    procedure Calculate_C(var r: recNCCLAIM; Var w: recConst);dynamic;
    procedure Calculate_E(var r: recNCCLAIM; Var w: recConst);dynamic;
    procedure Calculate_M(var r: recNCCLAIM; Var w: recConst);dynamic;
    procedure Calculate_D(var r: recNCCLAIM; Var w: recConst);dynamic;
    procedure Calculate_S(var r: recNCCLAIM; Var w: recConst);dynamic;
    procedure Set_ncexmcal(var AccidentDate: TDateTime; var r: recNCCLAIM; Var w: recConst);dynamic;
    function Set_ncldtxtb(r: recNCCLAIM; AccidentDate: TDateTime; nc_tax_year, nc_acc_year: integer;
      nc_max_adjustment: currency): boolean;dynamic;
    procedure Set_nccanty( var r: recNCCLAIM );dynamic;
    procedure Set_nctaxcal(var r: recNCCLAIM; Var w: recConst);dynamic;
    procedure Set_ncbcschd(nc_bc_ann_sal: currency; nc_calc_type: char;
      nc_calc_descr: shortstring; var w: recConst);dynamic;
    procedure Set_ncbencal(var r: recNCCLAIM; Var w: recConst);dynamic;
    function Set_isSelfAssurer( firmNo: shortstring ): boolean;dynamic;
    function Set_Firm_Name(firmNo: shortstring):string;dynamic;
    procedure SetTaxYear(TaxYear:Integer);Overload;
    procedure SetTaxYear(AccidentDate: tdatetime; TaxYear: Integer);overload;
    function GetTaxYear():Integer;
  public
    procedure uTax_ncbencal(var r: recNCCLAIM; Var w: recConst);
    procedure uTax_nccanty(var r: recNCCLAIM );
    function uTax_isSelfAssurer( firmNo: shortstring ): boolean;
    function uTax_Find_Firm_Name( firmNo: shortstring): string;
    constructor Create(AOwner: TObject);
    destructor Destroy; override;
  published
    property Version:Double read FVersion;
    property UserName:string read FUserName write SetUserName;
end;

implementation

{TTaxBase}

function TTaxBase.Calculate_CPP(annual_salary:currency): currency;
begin
  //PrintDisplay('TTaxBase.Calculate_CPP(annual_salary:currency): currency');
  if (annual_salary > nc_cpp_basic_exmp) and (nc_cpp_exempt <> 'Y') then
    nc_bc_cpp_sal := annual_salary - nc_cpp_basic_exmp
  else
    nc_bc_cpp_sal := 0;

  result := nc_bc_cpp_sal * nc_cpp_crate;
  result := PDoxRound(result, 2);

  if result > nc_cpp_max_ann_contrib then
    result := nc_cpp_max_ann_contrib;
end;

function TTaxBase.Calculate_Fed_NRTC: currency;
begin
  //PrintDisplay('TTaxBase.Calculate_Fed_NRTC: currency');
  //result := PDoxRound((nc_bc_cpp + nc_bc_uic + nc_tax_exmp + nc_federalCanadaEmploymentCredit) * nc_fed_tax_rate_i, 2);
  result := PDoxRound((nc_bc_cpp + nc_bc_uic + nc_tax_exmp) * nc_fed_tax_rate_i, 2);
end;

function TTaxBase.Calculate_Fed_Surtax: currency;
begin
  //PrintDisplay('TTaxBase.Calculate_Fed_Surtax: currency');
  if (nc_tax_exempt <> 'Y') and (nc_tax_exempt <> 'N') then
    raise ECalcError.create('Tax Exempt must be Y or N.');
  if nc_tax_exempt = 'Y' then
    begin
    result := 0;
    end
  else
    begin
    if nc_bc_bft > nc_fed_surtax_lim_ii then
      result := ((nc_bc_bft - nc_fed_surtax_lim_ii) * nc_fed_surtax_rate_ii) +
                (nc_bc_bft * nc_fed_surtax_rate_i)
    else
      result := (nc_bc_bft * nc_fed_surtax_rate_i)
    end;  // else

  result := PDoxRound(result, 2);
end;

function TTaxBase.Calculate_Fed_Tax(var w: recConst): currency;
begin
  //PrintDisplay('TTaxBase.Calculate_Fed_Tax(var w: recConst): currency');
  nc_bc_bft := Calculate_Fed_Tax_2;
  nc_bc_fst := Calculate_Fed_Surtax;
  result := PDoxRound(nc_bc_bft + nc_bc_fst, 2);
end;

function TTaxBase.Calculate_Fed_Tax_2: currency;
var
  const1, const2 : currency;
begin
  //PrintDisplay('TTaxBase.Calculate_Fed_Tax_2: currency');
  const1 := Round(nc_fed_inclvl_i * (nc_fed_tax_rate_ii - nc_fed_tax_rate_i));
  const2 := Round(nc_fed_inclvl_ii * (nc_fed_tax_rate_iii - nc_fed_tax_rate_ii));
  const2 := Round(const2 + const1);

  if nc_tax_exempt = 'Y' then
    begin
    result := 0;
    end
  else
    begin
    if nc_bc_ann_sal_net > nc_fed_inclvl_ii then
      result := (nc_bc_ann_sal_net *  nc_fed_tax_rate_iii) - const2
    else if nc_bc_ann_sal_net > nc_fed_inclvl_i then
      result := (nc_bc_ann_sal_net *  nc_fed_tax_rate_ii) - const1
    else
      result := (nc_bc_ann_sal_net * nc_fed_tax_rate_i);

    result := result - nc_bc_nrtc;

    result := PDoxRound(result, 2);
    if result < 0 then
      result := 0;
    end;
end;

function TTaxBase.Calculate_Man_mbt: currency;
begin
  //PrintDisplay('TTaxBase.Calculate_Man_mbt: currency');
  if nc_tax_exempt = 'Y' then
    begin
    result := 0;
    end
  else
    begin
    result := nc_bc_bft * nc_mb_tax_rate;
    end;

  result := PDoxRound(result, 2);  
end;

function TTaxBase.Calculate_Man_mnt: currency;
begin
  //PrintDisplay('TTaxBase.Calculate_Man_mnt: currency');
  if nc_tax_exempt = 'Y' then
    begin
    result := 0;
    end
  else
    begin
    result := nc_bc_ann_sal_net * nc_mb_net_rate;
    end;

  result := PDoxRound(result, 2);
end;

function TTaxBase.Calculate_Man_mst: currency;
begin
  //PrintDisplay('TTaxBase.Calculate_Man_mst: currency');
  if nc_tax_exempt = 'Y' then
    begin
    result := 0;
    end
  else
    begin
    if nc_bc_mnt > nc_ii_credit then
      result := nc_bc_mnt - nc_ii_credit
    else
      result := 0;
    end;

  result := PDoxRound(result, 2);
end;

function TTaxBase.Calculate_Man_mtr: currency;
begin
  //PrintDisplay('TTaxBase.Calculate_Man_mtr: currency;');
  if nc_tax_exempt = 'Y' then
    begin
    result := 0;
    end
  else
    begin
    if nc_iii_credit > nc_bc_mnt then
      result := nc_iii_credit - nc_bc_mnt
    else
      result := 0;
    end;

  result := PDoxRound(result, 2);  
end;

function TTaxBase.Calculate_Man_NRTC: currency;
begin
  //PrintDisplay('TTaxBase.Calculate_Man_NRTC: currency');
  result := 0;
end;

function TTaxBase.Calculate_Man_Tax(var w: recConst): currency;
begin
  //PrintDisplay('TTaxBase.Calculate_Man_Tax(var w: recConst): currency');
  nc_bc_mbt := Calculate_Man_mbt;
  nc_bc_mnt := Calculate_Man_mnt;
  nc_bc_mst := Calculate_Man_mst;
  nc_bc_mtr := Calculate_Man_mtr;
  result := nc_bc_mbt + nc_bc_mnt + nc_bc_mst - nc_bc_mtr; // jdyck

  if result < 0 then
    result := 0;
end;

function TTaxBase.Calculate_Net_Income(annual_salary: currency): currency;
begin
  //PrintDisplay('TTaxBase.Calculate_Net_Income');
  result := annual_salary;
  if result < 0 then
    result := 0;
end;

function TTaxBase.Calculate_UIC(annual_salary: currency): currency;
begin
  //PrintDisplay('TTaxBase.Calculate_UIC(annual_salary: currency): currency');
  if nc_uic_exempt = 'Y' then
    result := 0
  else
    begin
    result := annual_salary * nc_uic_prate;

    result := PDoxRound(result, 2);
    if result > nc_uic_max_ann_prem then
      result := nc_uic_max_ann_prem;
    end;
end;
{
function TTaxBase.Calculate_federalCanadaEmploymentCredit(annual_salary:currency): currency;
begin
  if selfEmployed = 'Y' then
    result := 0
  else
  begin
    result := annual_salary;

    result := PDoxRound( result, 2 );

    if result > nc_maxfederalCanadaEmploymentCredit then
      result := nc_maxfederalCanadaEmploymentCredit;
  end;
end;
}
constructor TTaxBase.Create(AOwner: TObject);
begin
  //PrintDisplay('TTaxBase.Create(AOwner: TObject)');
  Fversion:=1.0;
end;

destructor TTaxBase.Destroy;
begin
  //PrintDisplay('TTaxBase.Destroy');
//
end;

function TTaxBase.FindindexNCEXMAMT(AccidentDate:TDateTime; year: integer): integer;
var
  iii: integer;
begin
  //ShowMessage('TTaxBase.FindindexNCEXMAMT(year: integer): integer');
  result:=-1;
  SetTaxYear(AccidentDate, year);
  for iii := low(arrayNCEXMAMT) to high(arrayNCEXMAMT) do
  begin
    if ( arrayNCEXMAMT[iii].Tax_Year > 1900 ) and
       ( arrayNCEXMAMT[iii].Tax_Year = GetTaxYear ) then
       begin
         result:=iii;
         break;
       end
  end;
  if ( result < 0 ) then
    begin
    uNCCLaim.msgReturn_Message := '*Invalid Tax Year.';
    raise ECalcError.create('Tax year not found in Table NCEXMAMT.');
    end;
end;

procedure TTaxBase.SetMarital(AccidentDate: TDateTime; year: integer; status,
  spouse_working: shortstring; ClaimSpouseForTaxPurposes:string; var w: recConst);
begin
  //PrintDisplay('TTaxBase.SetMarital(year: integer; status,');
  if ( status = 'MARRIED' ) OR ( status = 'COMMON-LAW' )
    OR ( status = 'M' ) OR ( status = 'C' ) then
  begin
    if ( spouse_working = 'N' ) AND (ClaimSpouseForTaxPurposes = 'Y') Then
    begin
      NC_SPOUSE     := arrayNCEXMAMT[FindindexNCEXMAMT(AccidentDate, year)].Spouse;
      w.Work_NC_SPOUSE := NC_SPOUSE;
      NC_II_SPOUSE  := arrayNCEXMAMT[FindindexNCEXMAMT(AccidentDate, year)].II_Spouse;
      w.Work_NC_II_SPOUSE := NC_II_SPOUSE;
      NC_III_SPOUSE := arrayNCEXMAMT[FindindexNCEXMAMT(AccidentDate, year)].III_Spouse;
      w.Work_NC_III_SPOUSE := NC_III_SPOUSE;
    end;
  end
  ELSE
  begin
    IF(nc_no_of_dep > 0) Then
    begin
      NC_CHILDSPOUSE     := arrayNCEXMAMT[FindindexNCEXMAMT(AccidentDate, year)].ChildSpouse;
      w.Work_NC_CHILDSPOUSE := NC_CHILDSPOUSE;
      NC_II_CHILDSPOUSE  := arrayNCEXMAMT[FindindexNCEXMAMT(AccidentDate, year)].II_ChildSpouse;
      w.Work_NC_II_CHILDSPOUSE    := NC_II_CHILDSPOUSE;
      NC_III_CHILDSPOUSE := arrayNCEXMAMT[FindindexNCEXMAMT(AccidentDate, year)].III_ChildSpouse;
      w.Work_NC_III_CHILDSPOUSE := NC_III_CHILDSPOUSE;
      nc_no_of_dep   := nc_no_of_dep - 1;
      w.Work_nc_no_of_dep := nc_no_of_dep;
    end
    ELSE
    begin
      IF(nc_no_infirm > 0) Then
      begin
        NC_CHILDSPOUSE     := arrayNCEXMAMT[FindindexNCEXMAMT(AccidentDate, year)].ChildSpouse;
        w.Work_NC_CHILDSPOUSE := NC_CHILDSPOUSE;
        NC_II_CHILDSPOUSE  := arrayNCEXMAMT[FindindexNCEXMAMT(AccidentDate, year)].II_ChildSpouse;
        w.Work_NC_II_CHILDSPOUSE := NC_II_CHILDSPOUSE;
        NC_III_CHILDSPOUSE := arrayNCEXMAMT[FindindexNCEXMAMT(AccidentDate, year)].III_ChildSpouse;
        w.Work_NC_III_CHILDSPOUSE := NC_III_CHILDSPOUSE;
        nc_no_infirm := nc_no_infirm - 1;
        w.Work_nc_no_infirm := nc_no_infirm;
      end;
    end;
  end;
end;

procedure TTaxBase.SetPersonal(AccidentDate: TDateTime; year: integer; var w: recConst);
begin
  //PrintDisplay('TTaxBase.SetPersonal(year: integer; var w: recConst)');
  personal     := arrayNCEXMAMT[FindindexNCEXMAMT(AccidentDate, year)].Personal;
  w.Work_personal := personal;
  II_Personal  := arrayNCEXMAMT[FindindexNCEXMAMT(AccidentDate, year)].II_Personal;
  w.Work_II_Personal := II_Personal;
  III_Personal := arrayNCEXMAMT[FindindexNCEXMAMT(AccidentDate, year)].III_Personal;
  w.Work_III_Personal := III_Personal;

end;

procedure TTaxBase.SetExemptForDependants(AccidentDate: TDateTime; year: integer);
begin
  //PrintDisplay('TTaxBase.SetExemptForDependants(year: integer)');
  if ( nc_no_of_dep <= 2 ) then
  begin
    nc_1st_dep := nc_no_of_dep * arrayNCEXMAMT[FindindexNCEXMAMT(AccidentDate, year)].Dep_1st;
    nc_base_dep := nc_no_of_dep;
    nc_add_dep  := 0;
  end
  ELSE
  begin
    nc_1st_dep := 2 * arrayNCEXMAMT[FindindexNCEXMAMT(AccidentDate, year)].Dep_1st;
    nc_3rd_dep := (nc_no_of_dep - 2) * arrayNCEXMAMT[FindindexNCEXMAMT(accidentDate, year)].Dep_3rd;
    nc_base_dep := 2;
    nc_add_dep  := nc_no_of_dep - 2;
  end;
end;

procedure TTaxBase.SetDependantAmounts(AccidentDate: TDateTime; year: integer; var w: recConst);
begin
  //PrintDisplay('TTaxBase.SetDependantAmounts(year: integer; var w: recConst)');
  nc_II_dep  := nc_no_of_dep * arrayNCEXMAMT[FindindexNCEXMAMT(AccidentDate, year)].II_Dep;
  w.Work_nc_II_dep := nc_II_dep;
  NC_III_DEP := nc_no_of_dep * arrayNCEXMAMT[FindindexNCEXMAMT(AccidentDate, year)].III_Dep;
  w.Work_NC_III_DEP := NC_III_DEP;

  federalChildTaxCredit := actualNoOfDependants * arrayNCEXMAMT[ FindindexNCEXMAMT( AccidentDate, year ) ].federalChildTaxCredit;
  w.Work_federalChildTaxCredit := federalChildTaxCredit;

  infirm        := nc_no_infirm * arrayNCEXMAMT[FindindexNCEXMAMT(AccidentDate, year)].Infirm_Dep;
  w.Work_infirm := infirm;
  nc_II_infirm  := nc_no_infirm * arrayNCEXMAMT[FindindexNCEXMAMT(AccidentDate, year)].II_Infirm_Dep;
  w.Work_nc_II_infirm := nc_II_infirm;
  NC_III_INFIRM := nc_no_infirm * arrayNCEXMAMT[FindindexNCEXMAMT(AccidentDate, year)].III_Infirm_Dep;
  w.Work_NC_III_INFIRM := NC_III_INFIRM;
end;

function TTaxBase.Calculate_Exempt_Amount: currency;
begin
  //PrintDisplay('TTaxBase.Calculate_Exempt_Amount: currency');
  result := personal
         + NC_SPOUSE
         + NC_CHILDSPOUSE
         + nc_1st_dep
         + nc_3rd_dep
         + infirm
         + federalChildTaxCredit;
end;

function TTaxBase.Calculate_Section_II: currency;
begin
  //PrintDisplay('TTaxBase.Calculate_Section_II: currency');
  result     := II_Personal
             + NC_II_SPOUSE
             + NC_II_CHILDSPOUSE
             + nc_II_dep
             + nc_II_infirm;
end;

function TTaxBase.Calculate_Section_III: currency;
begin
  //PrintDisplay('TTaxBase.Calculate_Section_III: currency');
  result    := III_Personal
            + NC_III_SPOUSE
            + NC_III_CHILDSPOUSE
            + NC_III_DEP
            + NC_III_INFIRM;
end;

function TTaxBase.SetTaxCode(AccidentDate: TDateTime; year:integer): ShortString;
begin
  //PrintDisplay('TTaxBase.SetTaxCode(year:integer): ShortString');
//  if ( NC_EXEMPT_AMOUNT > arrayNCCODTAX[FindindexNCCODTAX(AccidentDate, year)].Code_10 ) then result := 'X' else
//  if ( NC_EXEMPT_AMOUNT > arrayNCCODTAX[FindindexNCCODTAX(AccidentDate, year)].Code_9 ) then result := '10' else
//  if ( NC_EXEMPT_AMOUNT > arrayNCCODTAX[FindindexNCCODTAX(AccidentDate, year)].Code_8 ) then result := '9' else
//  if ( NC_EXEMPT_AMOUNT > arrayNCCODTAX[FindindexNCCODTAX(AccidentDate, year)].Code_7 ) then result := '8' else
//  if ( NC_EXEMPT_AMOUNT > arrayNCCODTAX[FindindexNCCODTAX(AccidentDate, year)].Code_6 ) then result := '7' else
//  if ( NC_EXEMPT_AMOUNT > arrayNCCODTAX[FindindexNCCODTAX(AccidentDate, year)].Code_5 ) then result := '6' else
//  if ( NC_EXEMPT_AMOUNT > arrayNCCODTAX[FindindexNCCODTAX(AccidentDate, year)].Code_4 ) then result := '5' else
//  if ( NC_EXEMPT_AMOUNT > arrayNCCODTAX[FindindexNCCODTAX(AccidentDate, year)].Code_3 ) then result := '4' else
//  if ( NC_EXEMPT_AMOUNT > arrayNCCODTAX[FindindexNCCODTAX(AccidentDate, year)].Code_2 ) then result := '3' else
//  if ( NC_EXEMPT_AMOUNT > arrayNCCODTAX[FindindexNCCODTAX(AccidentDate, year)].Code_1 ) then result := '2' else
//  result := '1';

    // NCCODTAX (Tax Codes) - Removed April 24, 2026 - AGhuman
    // Setting Tax Code to blank to store in database table 'WageLossCalcFactor'
    result:='';
end;

//function TTaxBase.FindindexNCCODTAX(AccidentDate: TDateTime; year: integer): integer;
//var
//  iii: integer;
//begin
//  //ShowMessage('TTaxBase.FindindexNCCODTAX(year: integer): integer');
//  result:=-1;
//  SetTaxYear(AccidentDate, year);
//  for iii := low(arrayNCCODTAX) to high(arrayNCCODTAX) do
//  begin
//    if ( arrayNCCODTAX[iii].Tax_Year > 1900 ) and
//       ( arrayNCCODTAX[iii].Tax_Year = GetTaxYear ) then
//       begin
//         result:=iii;
//         break;
//       end
//  end;
//  if ( result < 0 ) then
//  begin
//    uNCCLaim.msgReturn_Message := '*Invalid Tax Year.';
//    raise ECalcError.create('Tax year not found in Table NCCODTAX.');
//  end;
//end;


//
// Added Nov 4, 2021 by D. Madill
//
// Added to accommodate the Bill 18 maximum's in addition to the Bill 59 Maximum's
// which have diverged as a result of Bill 18.
//
function TTaxBase.getAnnualMaximum(iAccident_Date:TDateTime; accident_year, accident_month, tax_year: integer): Currency;
var
  iii:Integer;
begin
  result := -1;

  if Year(iAccident_Date) < 2006 then
     begin
     for iii := low(arrayNCANNMAX) to high(arrayNCANNMAX) do
        begin
        if (arrayNCANNMAX[iii].Accident_Year > 1900)          and
           (arrayNCANNMAX[iii].Accident_Year = accident_year) and
           (arrayNCANNMAX[iii].Tax_Year = tax_year)           then
           begin
           result:=iii;
           break;
           end
        end;
     if (result < 0) then
        begin
        accident_year := nc_tax_year;
        for iii := low(arrayNCANNMAX) to high(arrayNCANNMAX) do
           begin
           if (arrayNCANNMAX[iii].Accident_Year > 1900)          and
              (arrayNCANNMAX[iii].Accident_Year = accident_year) and
              (arrayNCANNMAX[iii].Tax_Year = tax_year)           then
              begin
              result:=iii;
              break;
              end
           end;
        end;

     if accident_month = 12 then // December
        result := arrayNCANNMAX[iii].Annual_Maximum_Dec
     else
        result := arrayNCANNMAX[iii].Annual_Maximum;
     end
  else if Year(iAccident_Date) > 2021 then
     begin
     for iii := low(arrayNCANNMAXB18) to high(arrayNCANNMAXB18) do
        begin
        if (arrayNCANNMAXB18[iii].Accident_Year > 1900)          and
           (arrayNCANNMAXB18[iii].Accident_Year = accident_year) and
           (arrayNCANNMAXB18[iii].Tax_Year = tax_year)           then
           begin
           result:=iii;
           break;
           end
        end;
     if (result < 0) then
        begin
        accident_year := nc_tax_year;
        for iii := low(arrayNCANNMAXB18) to high(arrayNCANNMAXB18) do
           begin
           if (arrayNCANNMAXB18[iii].Accident_Year > 1900)          and
              (arrayNCANNMAXB18[iii].Accident_Year = accident_year) and
              (arrayNCANNMAXB18[iii].Tax_Year = tax_year)           then
              begin
              result:=iii;
              break;
              end
           end;
        end;

     if accident_month = 12 then // December
        result := arrayNCANNMAXB18[iii].Annual_Maximum_Dec
     else
        result := arrayNCANNMAXB18[iii].Annual_Maximum;
     end;


//
// The annual max was not found in the tax tables. Here we abort and set a message
// to indicate a failure.
//
  if ( result < 0 ) then
     begin
     uNCCLaim.msgReturn_Message := '*Invalid Tax Year.';
     raise ECalcError.create('Tax year not found in Table NCANNMAX/NCANNMAXB18.');
     end;
end;

//
// Modified March 5, 2003 by D. Madill
//
// Modified to fail if the tax year and accident date is not found in the
// tax table.
//
// Modified to use the Recurrence date forward indexing for claims with a
// Recurrence after Jan 1, 2001
//
function TTaxBase.FindindexNCANNMAX(iAccident_Date:TDateTime; accident_year, tax_year: integer): integer;
var
  iii:Integer;
begin
  //PrintDisplay('TTaxBase.FindindexNCANNMAX(accident_year,');
  result := -1;

  if year(iAccident_Date) < 2006 then
     begin
     for iii := low(arrayNCANNMAX) to high(arrayNCANNMAX) do
        begin
        if (arrayNCANNMAX[iii].Accident_Year > 1900)          and
           (arrayNCANNMAX[iii].Accident_Year = accident_year) and
           (arrayNCANNMAX[iii].Tax_Year = tax_year)           then
           begin
           result:=iii;
           break;
           end
        end;

     if ( result < 0 ) then
        begin
        accident_year := nc_tax_year;
        for iii := low(arrayNCANNMAX) to high(arrayNCANNMAX) do
           begin
           if (arrayNCANNMAX[iii].Accident_Year > 1900)          and
              (arrayNCANNMAX[iii].Accident_Year = accident_year) and
              (arrayNCANNMAX[iii].Tax_Year = tax_year)           then
              begin
              result:=iii;
              break;
              end
           end;
        end;
     end
  else if Year(iAccident_Date) > 2021 then
     begin
     for iii := low(arrayNCANNMAXB18) to high(arrayNCANNMAXB18) do
        begin
        if (arrayNCANNMAXB18[iii].Accident_Year > 1900)          and
           (arrayNCANNMAXB18[iii].Accident_Year = accident_year) and
           (arrayNCANNMAXB18[iii].Tax_Year = tax_year)           then
           begin
           result:=iii;
           break;
           end
        end;
     if (result < 0) then
        begin
        accident_year := nc_tax_year;
        for iii := low(arrayNCANNMAXB18) to high(arrayNCANNMAXB18) do
           begin
           if (arrayNCANNMAXB18[iii].Accident_Year > 1900)          and
              (arrayNCANNMAXB18[iii].Accident_Year = accident_year) and
              (arrayNCANNMAXB18[iii].Tax_Year = tax_year)           then
              begin
              result:=iii;
              break;
              end
           end;
        end;
     end;


//
// The annual max was not found in the tax tables. Here we abort and set a message
// to indicate a failure.
//
  if ( result < 0 ) then
     begin
     uNCCLaim.msgReturn_Message := '*Invalid Tax Year.';
     raise ECalcError.create('Tax year not found in Table NCANNMAX/NCANNMAXB18.');
     end;
end;

function TTaxBase.FindindexNCTAXRAT(AccidentDate: TDateTime; year: integer): integer;
var
  iii:integer;
begin
  //ShowMessage('TTaxBase.FindindexNCTAXRAT(year: integer): integer');
  result:=-1;
  //showmessage('6, ' + FormatDateTime('c', AccidentDate));
  SetTaxYear(AccidentDate, year);
  for iii := low(arrayNCTAXRAT) to high(arrayNCTAXRAT) do
  begin
    if ( arrayNCTAXRAT[iii].Tax_Year > 1900 ) and
       ( arrayNCTAXRAT[iii].Tax_Year = GetTaxYear ) then
       begin
         result:=iii;
         break;
       end
  end;
//
// The Tax Rate was not found in the tax tables. Here we abort and set a message
// to indicate a failure.
//
  if ( result < 0 ) then
     begin
     uNCCLaim.msgReturn_Message := '*Invalid Tax Year.';
     raise ECalcError.create('Tax year not found in Table NCTAXRAT.');
     exit;
     end;
end;

function TTaxBase.Calc_nc_bc_deductions(var r: recNCCLAIM):currency;
begin
  //PrintDisplay('TTaxBase.Calc_nc_bc_deductions(var r: recNCCLAIM):currency');
  result := (r.Child_Care_Exp + r.Spousal_Support) * 52;
end;

procedure TTaxBase.Calculate_A(var r: recNCCLAIM; Var w: recConst);
begin
  //PrintDisplay('TTaxBase.Calculate_A(var r: recNCCLAIM; var w: recConst)');
  nc_ann_income := r.WKLY_SAL_A * 52;
  if (nc_ann_income > nc_max_ann_sal) then
  begin
    nc_prorate := nc_max_ann_sal / nc_ann_income;
    w.Work_nc_prorate := nc_prorate;
    nc_bc_pro_deductions := nc_bc_deductions * nc_prorate;
  end
  else
  begin
    nc_prorate := 1;
    w.Work_nc_prorate := nc_prorate;
    nc_bc_pro_deductions := nc_bc_deductions;
  end;
  Set_ncbcschd(nc_ann_income,'A','actual annual income',w);
  r.CPP_Prem := nc_bc_cpp;
  r.EI_Prem  := nc_bc_uic;
  if ( nc_bc_fedtax >= 0 ) then r.Inc_Tax_Fed := nc_bc_fedtax else  r.Inc_Tax_Fed := 0;
  if ( nc_bc_mb_tax >= 0 ) then r.Inc_Tax_Man:= nc_bc_mb_tax else r.Inc_Tax_Man := 0;
  if ( nc_bc_td >= 0 ) then r.Total_Deds_A := nc_bc_td else r.Total_Deds_A := 0;
end;

procedure TTaxBase.Calculate_M(var r: recNCCLAIM; Var w: recConst);
begin
  //PrintDisplay('TTaxBase.Calculate_A(var r: recNCCLAIM; var w: recConst)');
  nc_minwage_income := r.Minimum_wage;
  Set_ncbcschd(nc_minwage_income,'M','minimum annual income',w);
end;

procedure TTaxBase.Calculate_S(var r: recNCCLAIM; Var w: recConst);
begin
  //PrintDisplay('TTaxBase.Calculate_A(var r: recNCCLAIM; var w: recConst)');
  nc_minwage_shelter_income := r.Minimum_wage * 0.75;
  Set_ncbcschd(nc_minwage_shelter_income,'S','sheltered minimum annual income',w);
end;

procedure TTaxBase.Calculate_D(var r: recNCCLAIM; Var w: recConst);
begin
  //PrintDisplay('TTaxBase.Calculate_A(var r: recNCCLAIM; var w: recConst)');
  nc_cben_income := r.Collateral_Ben_Tax * 52;
  Set_ncbcschd(nc_cben_income,'D','collateral benefit only',w);
end;

procedure TTaxBase.Calculate_B(var r: recNCCLAIM; Var w: recConst);
begin
  //PrintDisplay('TTaxBase.Calculate_B(var r: recNCCLAIM; var w: recConst)');
  if nc_ann_income > nc_max_ann_sal then
  begin
    Set_ncbcschd(nc_max_ann_sal,'B',inttostr(nc_tax_year)+ ' maximum annual income',w);
    r.WKLY_SAL := (nc_max_ann_sal / 52);
    r.CPP_Prem := nc_bc_cpp;
    r.EI_Prem := nc_bc_uic;
    if nc_bc_fedtax >= 0 then r.Inc_Tax_Fed := nc_bc_fedtax else r.Inc_Tax_Fed := 0;
    if nc_bc_mb_tax >= 0 then r.Inc_Tax_Man := nc_bc_mb_tax else r.Inc_Tax_Man := 0;
    if nc_bc_td >= 0 then r.Total_Deds := nc_bc_td else r.Total_Deds := 0;
  end
  else
  begin
    r.WKLY_SAL := r.WKLY_SAL_A;
    r.Total_Deds := r.Total_Deds_A;
  end;
end;

procedure TTaxBase.Calculate_C(var r: recNCCLAIM; Var w: recConst);
begin
  //PrintDisplay('TTaxBase.Calculate_C(var r: recNCCLAIM; var w: recConst)');
  if nc_max_ann_sal > nc_ann_income then
  begin
    nc_shelter_income := nc_ann_income  * 0.75;
    nc_shelter_base   := nc_ann_income;
  end
  else
  begin
    nc_shelter_income := nc_max_ann_sal * 0.75;
    nc_shelter_base   := nc_max_ann_sal;
  end;
  Set_ncbcschd(nc_shelter_income,'C','annual shelter income',w);
  r.CPP_Prem_S := nc_bc_cpp;
  r.EI_Prem_S := nc_bc_uic;
  if nc_bc_fedtax >= 0 then r.Inc_Tax_Fed_S := nc_bc_fedtax else r.Inc_Tax_Fed_S := 0;
  if nc_bc_mb_tax >= 0 then r.Inc_Tax_Man_S := nc_bc_mb_tax else r.Inc_Tax_Man_S := 0;
  if nc_bc_td >= 0 then r.Total_Deds_S := nc_bc_td else r.Total_Deds_S := 0;
end;

procedure TTaxBase.Calculate_E(var r: recNCCLAIM; Var w: recConst);
begin
  //PrintDisplay('TTaxBase.Calculate_E(var r: recNCCLAIM; var w: recConst)');
  nc_colben_tax   := r.COLLATERAL_BEN_TAX;
  nc_postinj_earn := r.POST_INJURY_EARN;
  nc_cben_pinj_inc := nc_colben_tax  + nc_postinj_earn;
  nc_cben_pinj_ann := nc_cben_pinj_inc * 52;
  if nc_cben_pinj_ann > 0 then
  begin
    Set_ncbcschd(nc_cben_pinj_ann,'E','annual bnfts + earnings',w);
    r.Coll_Ben_Tax_Net := (nc_bc_netinc / 52) *
                          (nc_colben_tax / nc_cben_pinj_inc);
    r.Post_Injury_Earn_Net  := (nc_bc_netinc / 52) *
                              (Nc_postinj_earn / nc_cben_pinj_inc);
  end
  else
  begin
    r.Coll_Ben_Tax_Net      := 0;
    r.Post_Injury_Earn_Net  := 0;
  end;
end;

procedure TTaxBase.SetUserName(const Value: string);
begin
  //PrintDisplay('TTaxBase.SetUserName(const Value: string)');
  FUserName := Value;
end;

function TTaxBase.Set_isSelfAssurer(firmNo: shortstring): boolean;
var
  iii: integer;
  ws: shortstring;
begin
  //PrintDisplay('TTaxBase.Set_isSelfAssurer(firmNo: shortstring): boolean');
  ws:=copy( firmNo,1,7);
  indexNC_CFIO:=-1;
  for iii := low(arrayNC_CFIO) to high(arrayNC_CFIO) do
  begin
    if ( arrayNC_CFIO[iii].PRIME_FIRM_NO = ws ) then
       begin
         indexNC_CFIO:=iii;
         break;
       end
  end;
  if ( indexNC_CFIO < 0 ) then
  begin
    result:=false;
    exit;
  end;
  result:=true;
end;

procedure TTaxBase.Set_ncbcschd(nc_bc_ann_sal: currency; nc_calc_type: char;
      nc_calc_descr: shortstring; var w: recConst);
begin
  //PrintDisplay('TTaxBase.Set_ncbcschd(nc_bc_ann_sal: currency;');
  nc_bc_cpp := Calculate_CPP(nc_bc_ann_sal);
  nc_bc_uic := Calculate_UIC(nc_bc_ann_sal);
  //nc_federalCanadaEmploymentCredit := Calculate_federalCanadaEmploymentCredit(nc_bc_ann_sal);
  nc_bc_ann_sal_net := Calculate_Net_Income(nc_bc_ann_sal);
  nc_bc_nrtc := Calculate_Fed_NRTC;
  nc_bc_mb_nrtc := Calculate_Man_NRTC;
  nc_bc_fedtax := Calculate_Fed_Tax(w);
  nc_bc_mb_tax := Calculate_Man_Tax(w);
  //
  // Changed Nov 2003 by D. Madill
  // Changed to eliminate rounding error on tax calculations.
  //
  nc_bc_cpp := PdoxRound(nc_bc_cpp, 2);
  nc_bc_uic := PDoxRound(nc_bc_uic, 2);
  //nc_federalCanadaEmploymentCredit := PDoxRound( nc_federalCanadaEmploymentCredit, 2 );
  nc_bc_fedtax := PDoxRound(nc_bc_fedtax, 2);
  nc_bc_mb_tax := PDoxRound(nc_bc_mb_tax, 2);
  nc_bc_ann_sal := PDoxRound(nc_bc_ann_sal, 2);
  nc_bc_ann_sal_net := PDoxRound(nc_bc_ann_sal_net, 2);
  nc_bc_nrtc := PDoxRound(nc_bc_nrtc, 2);
  nc_bc_mb_nrtc := PDoxRound(nc_bc_mb_nrtc, 2);
  nc_bc_bft := PDoxRound(nc_bc_bft, 2);
  nc_bc_fst := PDoxRound(nc_bc_fst, 2);
  nc_bc_mbt := PDoxRound(nc_bc_mbt, 2);
  //
  nc_bc_td := nc_bc_cpp + nc_bc_uic + nc_bc_fedtax + nc_bc_mb_tax;
  //nc_bc_td := nc_bc_cpp + nc_bc_uic + nc_bc_fedtax + nc_bc_mbt;
  nc_bc_netinc := nc_bc_ann_sal - nc_bc_td;
  Case nc_calc_type of
    'A': begin
           w.Work_nc_bc_cpp_a := nc_bc_cpp;
           w.Work_nc_bc_uic_a := nc_bc_uic;
           //w.Work_federalCanadaEmploymentCredit_a := nc_federalCanadaEmploymentCredit;
           w.Work_actualNoOfDependants := actualNoOfDependants;
           w.Work_nc_bc_ann_sal_net_a := nc_bc_ann_sal_net;
           w.Work_nc_bc_nrtc_a := nc_bc_nrtc;
           w.Work_nc_bc_mb_nrtc_a := nc_bc_mb_nrtc;
           w.Work_nc_bc_mb_tax_a := nc_bc_mb_tax;
           w.Work_nc_bc_td_a := nc_bc_td;
           w.Work_nc_bc_netinc_a := nc_bc_netinc;
           w.Work_nc_bc_bft_a := nc_bc_bft;
           w.Work_nc_bc_fst_a := nc_bc_fst;
           w.Work_nc_bc_mbt_a := nc_bc_mbt;
           w.Work_mbFamilyTaxBenefitRate_a := nc_mbFamilyTaxBenefitAmt;
         end;
    'B': begin
           w.Work_nc_bc_cpp_b := nc_bc_cpp;
           w.Work_nc_bc_uic_b := nc_bc_uic;
           //w.Work_federalCanadaEmploymentCredit_b := nc_federalCanadaEmploymentCredit;
           w.Work_nc_bc_ann_sal_net_b := nc_bc_ann_sal_net;
           w.Work_nc_bc_nrtc_b := nc_bc_nrtc;
           w.Work_nc_bc_mb_nrtc_b := nc_bc_mb_nrtc;
           w.Work_nc_bc_mb_tax_b := nc_bc_mb_tax;
           w.Work_nc_bc_td_b := nc_bc_td;
           w.Work_nc_bc_netinc_b := nc_bc_netinc;
           w.Work_nc_bc_bft_b := nc_bc_bft;
           w.Work_nc_bc_fst_b := nc_bc_fst;
           w.Work_nc_bc_mbt_b := nc_bc_mbt;
           w.Work_mbFamilyTaxBenefitRate_b := nc_mbFamilyTaxBenefitAmt;
         end;
    'C': begin
           w.Work_nc_bc_cpp_c := nc_bc_cpp;
           w.Work_nc_bc_uic_c := nc_bc_uic;
           //w.Work_federalCanadaEmploymentCredit_c := nc_federalCanadaEmploymentCredit;
           w.Work_nc_bc_ann_sal_net_c := nc_bc_ann_sal_net;
           w.Work_nc_bc_nrtc_c := nc_bc_nrtc;
           w.Work_nc_bc_mb_nrtc_c := nc_bc_mb_nrtc;
           w.Work_nc_bc_mb_tax_c := nc_bc_mb_tax;
           w.Work_nc_bc_td_c := nc_bc_td;
           w.Work_nc_bc_netinc_c := nc_bc_netinc;
           w.Work_nc_bc_bft_c := nc_bc_bft;
           w.Work_nc_bc_fst_c := nc_bc_fst;
           w.Work_nc_bc_mbt_c := nc_bc_mbt;
           w.Work_mbFamilyTaxBenefitRate_c := nc_mbFamilyTaxBenefitAmt;
         end;
    'D': begin
           w.Work_nc_bc_cpp_d := nc_bc_cpp;
           w.Work_nc_bc_uic_d := nc_bc_uic;
           //w.Work_federalCanadaEmploymentCredit_d := nc_federalCanadaEmploymentCredit;
           w.Work_nc_bc_ann_sal_net_d := nc_bc_ann_sal_net;
           w.Work_nc_bc_nrtc_d := nc_bc_nrtc;
           w.Work_nc_bc_mb_nrtc_d := nc_bc_mb_nrtc;
           w.Work_nc_bc_mb_tax_d := nc_bc_mb_tax;
           w.Work_nc_bc_td_d := nc_bc_td;
           w.Work_nc_bc_netinc_d := nc_bc_netinc;
           w.Work_nc_bc_bft_d := nc_bc_bft;
           w.Work_nc_bc_fst_d := nc_bc_fst;
           w.Work_nc_bc_mbt_d := nc_bc_mbt;
           w.Work_mbFamilyTaxBenefitRate_d := nc_mbFamilyTaxBenefitAmt;
         end;
    'E': begin
           w.Work_nc_bc_cpp_e := nc_bc_cpp;
           w.Work_nc_bc_uic_e := nc_bc_uic;
           //w.Work_federalCanadaEmploymentCredit_e := nc_federalCanadaEmploymentCredit;
           w.Work_nc_bc_ann_sal_net_e := nc_bc_ann_sal_net;
           w.Work_nc_bc_nrtc_e := nc_bc_nrtc;
           w.Work_nc_bc_mb_nrtc_e := nc_bc_mb_nrtc;
           w.Work_nc_bc_mb_tax_e := nc_bc_mb_tax;
           w.Work_nc_bc_td_e := nc_bc_td;
           w.Work_nc_bc_netinc_e := nc_bc_netinc;
           w.Work_nc_bc_bft_e := nc_bc_bft;
           w.Work_nc_bc_fst_e := nc_bc_fst;
           w.Work_nc_bc_mbt_e := nc_bc_mbt;
           w.Work_mbFamilyTaxBenefitRate_e := nc_mbFamilyTaxBenefitAmt;
         end;
    end;
end;

procedure TTaxBase.Set_ncbencal(var r: recNCCLAIM; Var w: recConst);
begin
  //PrintDisplay('TTaxBase.Set_ncbencal(var r: recNCCLAIM; var w: recConst)');
  r.Calc_Date              := date;
  r.Calc_Username          := FUserName;
  NC_DAYS_PER_WK           := r.Days_Worked_per_Week;
  r.Annual_Gross           := r.WKLY_SAL    * 52;
  r.Annual_Gross_A         := r.Wkly_Sal_A  * 52;
  r.Annual_Net             := r.Annual_Gross
                                     - r.Total_Deds;
  r.Annual_Net_A           := r.Annual_Gross_A
                                     - r.Total_Deds_A;
  r.WEEKLY_NET             := PdoxRound(r.Annual_Net /52,2)
                                     - r.Post_Injury_Earn_Net;
  r.Weekly_Net_A           := PdoxRound(r.Annual_Net_A /52,2)
                                     - r.Post_Injury_Earn_Net;
  MAXIMUM_WK_BENEFIT_90              := PdoxRound(r.Weekly_Net_A *0.90,2);


  //Modified - Jan 07 - bcooper - NR64337
  //original:
  //WKLY_TAX_SHELTER      := PdoxRound((r.Total_Deds *0.75 - r.Total_Deds_S )/52,2);
  //new:
  if ( ( ( r.Total_Deds *0.75 - r.Total_Deds_S )/52 ) < 0 ) then
    WKLY_TAX_SHELTER      := 0
  else
    WKLY_TAX_SHELTER      := PdoxRound((r.Total_Deds *0.75 - r.Total_Deds_S )/52,2);

  WEEKLY_NET_S                       := r.WEEKLY_NET
                                     - WKLY_TAX_SHELTER;
  WEEKLY_90                          := PdoxRound(r.WEEKLY_NET *0.90,2);
  WEEKLY_80                          := PdoxRound(r.WEEKLY_NET *0.80,2);
  WEEKLY_90_S                        := PdoxRound((WEEKLY_NET_S * 0.90),2);
  WEEKLY_80_S                        := PdoxRound((WEEKLY_NET_S * 0.80),2);
  EXCESS_90                          := PdoxRound(PdoxMax(0,WEEKLY_90
                                     + r.Coll_Ben_Tax_Net
                                     + r.Collateral_Ben_Non_Tax
                                     - MAXIMUM_WK_BENEFIT_90),2);
  EXCESS_80                          := PdoxRound(PdoxMax(0,WEEKLY_80
                                     + r.Coll_Ben_Tax_Net
                                     + r.Collateral_Ben_Non_Tax
                                     - MAXIMUM_WK_BENEFIT_90),2);
  EXCESS_90_S                        := PdoxRound(PdoxMax(0,WEEKLY_90_S
                                     + r.Coll_Ben_Tax_Net
                                     + r.Collateral_Ben_Non_Tax
                                     - MAXIMUM_WK_BENEFIT_90),2);
  EXCESS_80_S                        := PdoxRound(PdoxMax(0,WEEKLY_80_S
                                     + r.Coll_Ben_Tax_Net
                                     + r.Collateral_Ben_Non_Tax
                                     - MAXIMUM_WK_BENEFIT_90),2);
  r.WEEKLY_90              := PdoxMax(0,WEEKLY_90   - EXCESS_90);
  r.WEEKLY_80              := PdoxMax(0,WEEKLY_80   - EXCESS_80);
  r.WEEKLY_90_S            := PdoxMax(0,WEEKLY_90_S - EXCESS_90_S);
  r.WEEKLY_80_S            := PdoxMax(0,WEEKLY_80_S - EXCESS_80_S);

  if (r.Weekly_90 < 0) Then
    r.Weekly_90 := 0;
  if (r.Weekly_90_S < 0) then
    r.Weekly_90_S := 0;
  if (r.Weekly_80 < 0) Then
    r.Weekly_80 := 0;
  if (r.Weekly_80_S < 0) then
    r.Weekly_80_S := 0;

  r.Annual_80              := r.WEEKLY_80    * 52;
  r.Annual_80_S            := r.WEEKLY_80_S  * 52;
  r.Annual_90              := r.WEEKLY_90    * 52;
  r.Annual_90_S            := r.WEEKLY_90_S  * 52;
end;

procedure TTaxBase.Set_nccanty(var r: recNCCLAIM);
var
  nc_actual_wcb_contrib: currency;
begin
  //PrintDisplay('TTaxBase.Set_nccanty(var r: recNCCLAIM)');
  nc_actual_wcb_contrib      := 5.00 - r.nc_104_Wk_WCB_p_Contrib_Red;
  r.nc_104_Wk_WCB_p_Contrib    := 5.00;
  r.WKLY_WCB_ANTY_CON_AMT      := PdoxRound((nc_actual_wcb_contrib * r.WEEKLY_80)   / 100 ,2);
  r.WKLY_WCB_ANTY_CON_AMT_S    := PdoxRound((nc_actual_wcb_contrib * r.WEEKLY_80_S) / 100 ,2);
  r.WKLY_CLMT_ANTY_CON_AMT     := PdoxRound(( r.nc_104_WK_CLMT_p_CONTRIB * r.WEEKLY_80) / 100 ,2);
  r.WKLY_CLMT_ANTY_CON_AMT_S   := PdoxRound(( r.nc_104_WK_CLMT_p_CONTRIB * r.WEEKLY_80_S ) / 100 ,2);
end;

procedure TTaxBase.Set_ncexmcal(var AccidentDate: TDateTime; var r: recNCCLAIM; Var w: recConst);
begin
  //PrintDisplay('TTaxBase.Set_ncexmcal(var AccidentDate: TDateTime; var r: recNCCLAIM; w: recConst)');
  NC_SPOUSE             := 0;
  NC_II_SPOUSE          := 0;
  NC_III_SPOUSE         := 0;
  NC_CHILDSPOUSE        := 0;
  NC_II_CHILDSPOUSE     := 0;
  NC_III_CHILDSPOUSE    := 0;
  nc_1st_dep            := 0;
  nc_II_dep             := 0;
  NC_III_DEP            := 0;
  nc_3rd_dep            := 0;
  w.Work_NC_SPOUSE      := 0;
  w.Work_NC_II_SPOUSE   := 0;
  w.Work_NC_III_SPOUSE  := 0;
  w.Work_NC_CHILDSPOUSE := 0;
  w.Work_NC_II_CHILDSPOUSE := 0;
  w.Work_NC_III_CHILDSPOUSE := 0;
  w.Work_nc_II_dep      := 0;
  w.Work_NC_III_DEP     := 0;
  nc_tax_year           := r.Tax_Year;
  w.Work_nc_tax_year    := nc_tax_year;
  nc_accident_year      := year( AccidentDate );
  if AccidentDate = 0 then
    nc_accident_year := r.Tax_Year;
  nc_no_of_dep          := r.No_of_Dependnts;
  w.Work_nc_no_of_dep   := nc_no_of_dep;
  actualNoOfDependants  := r.No_of_Dependnts;
  w.Work_actualNoOfDependants := actualNoOfDependants;
  nc_no_infirm          := r.No_Infirm;
  w.Work_nc_no_infirm   := nc_no_infirm;
  SetPersonal(AccidentDate, nc_tax_year,w);
  SetMarital(AccidentDate, nc_tax_year,r.MARITAL_STATUS,r.Spouse_Working, r.ClaimSpouseForTaxPurposes, w);
  SetExemptForDependants(AccidentDate, nc_tax_year);
  SetDependantAmounts(AccidentDate, nc_tax_year,w);
  NC_EXEMPT_AMOUNT := Calculate_Exempt_Amount;
  w.Work_NC_EXEMPT_AMOUNT := NC_EXEMPT_AMOUNT;
  nc_ii_credit     := Calculate_Section_II;
  w.Work_nc_ii_credit := nc_ii_credit;
  r.II_CREDIT      := nc_ii_credit;
  nc_iii_credit    := Calculate_Section_III;
  w.Work_nc_iii_credit := nc_iii_credit;
  r.III_CREDIT     := nc_iii_credit;
  r.Tax_Exemption   := NC_EXEMPT_AMOUNT;
  nc_tax_exmp  := nc_exempt_amount;
  w.Work_nc_tax_exmp := nc_tax_exmp;
  r.Tax_Code := SetTaxCode(AccidentDate, nc_tax_year);
end;

function TTaxBase.Set_ncldtxtb(r: recNCCLAIM; AccidentDate: TDateTime; nc_tax_year, nc_acc_year: integer;
  nc_max_adjustment: currency): boolean;
var
   Test_Accident_Date:TDateTime;
   Acc_Year, Acc_Month, Acc_Day, Test_Tax_Year:Word;
begin
  result:=false;

  //
  // LRC Bill 18
  //

  if nc_max_adjustment <> 0 then
     begin
     nc_max_ann_sal := nc_max_adjustment;
     end
  else
     begin
     nc_max_ann_sal := getAnnualMaximum(r.Accident_Date, nc_acc_year, Acc_Month, nc_tax_year);
     end;

  with arrayNCTAXRAT[FindindexNCTAXRAT(AccidentDate, nc_tax_year)] do
    begin
    nc_uic_prate               := UIC_premium_rate;
    nc_max_ins_earn            := UIC_max_insured_earnings;
    nc_uic_max_ann_prem        := UIC_max_annual_premium;
    nc_cpp_basic_exmp          := CPP_basic_exemption;
    nc_cpp_crate               := CPP_contrib_rate;
    nc_cpp_max_ann_contrib     := CPP_max_annual_contrib;
    nc_fed_inclvl_i            := FED_income_level_i;
    nc_fed_inclvl_ii           := FED_income_level_ii;
    nc_fed_tax_amt_i           := FED_tax_amt_i;
    nc_fed_tax_amt_ii          := FED_tax_amt_ii;
    nc_fed_tax_rate_i          := FED_tax_rate_i;
    nc_fed_tax_rate_ii         := FED_tax_rate_ii;
    nc_fed_tax_rate_iii        := FED_tax_rate_iii;
    nc_fed_surtax_rate_i       := FED_surtax_rate_i;
    nc_fed_surtax_rate_ii      := FED_surtax_rate_ii;
    nc_fed_surtax_lim_ii       := FED_surtax_limit_ii;
    nc_mb_tax_rate             := MB_tax_rate;
    nc_mb_tax_rate_i           := MB_tax_rate_i;
    nc_mb_tax_rate_ii          := MB_tax_rate_ii;
    nc_mb_tax_rate_iii         := MB_tax_rate_iii;
    nc_mb_inclvl_i             := MB_income_level_i;
    nc_mb_inclvl_ii            := MB_income_level_ii;
    nc_mb_tax_amt_i            := MB_tax_amt_i;
    nc_mb_tax_amt_ii           := MB_tax_amt_ii;
    nc_mb_net_rate             := MB_net_tax_rate;
    nc_mbFamilyTaxBenefitRate  := mbFamilyTaxBenefitRate;
    //nc_maxfederalCanadaEmploymentCredit := federalCanadaEmploymentCredit;
    end;

  if (Acc_Year < 2006) or (Acc_Year > 2021) then
     begin
     if (FindindexNCANNMAX(r.Accident_Date, nc_acc_year, nc_tax_year) > -1)   or
        (FindindexNCTAXRAT(AccidentDate, nc_tax_year) > -1) then
        result := true;
     end
  else
     begin
     result := true;
     end;
end;

procedure TTaxBase.Set_nctaxcal(var r: recNCCLAIM; Var w: recConst);
begin
  //PrintDisplay('TTaxBase.Set_nctaxcal(var r: recNCCLAIM; var w: recConst)');
  nc_bc_deductions := Calc_nc_bc_deductions(r);
  w.Work_nc_bc_deductions := nc_bc_deductions;
  nc_bc_cpp2 := 0;
  r.CPP2_Prem := 0;
  r.CPP2_Prem_S := 0;
  nc_uic_exempt := r.EI_Exempt;
  nc_cpp_exempt := r.CPP_Exempt;
  nc_tax_exempt := r.Tax_Exempt;
  selfEmployed := r.Self_Employed;
  Calculate_A(r,w);
  Calculate_B(r,w);
  Calculate_C(r,w);
  Calculate_D(r,w);
  Calculate_E(r,w);
end;

function TTaxBase.uTax_isSelfAssurer(firmNo: shortstring): boolean;
begin
  //PrintDisplay('TTaxBase.uTax_isSelfAssurer(firmNo: shortstring): boolean');
  result := Set_isSelfAssurer(firmNo);
end;
//  
// Modified by D. Madill
// March 5, 2003
// Modified to check the Recurrence flag to ensure we will not be processing with
// an improper recurrence date
//
procedure TTaxBase.uTax_ncbencal(var r: recNCCLAIM; Var w: recConst);
var
  WorkDate: TdateTime;
  Month, Acc_Year, Acc_Month, Acc_Day:Word;
begin
  //PrintDisplay('TTaxBase.uTax_ncbencal(var r: recNCCLAIM; w: recConst)');
  //
  // Modified by D. Madill
  // Modified April 2003 to conform to Mid year changes point 2 & 3
  //
  DecodeDate(r.Accident_Date, Acc_Year, Acc_Month, Acc_Day);
  if ((r.Indexation_Year > 0) AND (r.Tax_Year <> Acc_Year)) Then
    Month := Max(((Acc_Month+1) Mod 13),1)
  else
    Month := Acc_Month;
  WorkDate := Max(r.RecurrenceDate, EncodeDate(Min(Max(r.Indexation_Year,Acc_Year), r.Tax_Year), Month, 1));

  if Set_ncldtxtb(r, WorkDate, r.tax_year, StrToInt(FormatDateTime('yyyy', WorkDate)), r.Max_Adjustment ) then
  begin
    Set_ncexmcal(WorkDate, r,w);
    Set_nctaxcal(r,w);
    Set_ncbencal(r,w);
    Set_nccanty(r);
  end;
end;

procedure TTaxBase.uTax_nccanty(var r: recNCCLAIM);
begin
  //PrintDisplay('TTaxBase.uTax_nccanty(var r: recNCCLAIM)');
  Set_nccanty(r);
end;

function TTaxBase.uTax_Find_Firm_Name(firmNo: shortstring): string;
begin
  //PrintDisplay('TTaxBase.uTax_Find_Firm_Name(firmNo: shortstring): string');
  result := Set_Firm_Name(firmNo);
end;

function TTaxBase.Set_Firm_Name(firmNo: shortstring): string;
begin
  //PrintDisplay('TTaxBase.Set_Firm_Name(firmNo: shortstring): string');
  if Set_isSelfAssurer(firmNo) then
    result:=arrayNC_CFIO[indexNC_CFIO].Firm_Name;
end;

function TTaxBase.GetTaxYear: Integer;
begin
  If (TheTaxYear = null) then
  	Result := 0
  else
    Result := TheTaxYear;
end;

procedure TTaxBase.SetTaxYear(TaxYear: Integer);
begin
  If(TaxYear = null) then
    TheTaxYear := 0
  else
    TheTaxYear := TaxYear;
end;

//
// Modified March 5, 2003 by D. Madill
//
// Modified to default to set the latest Tax Year if the date is in excess of the
// latest tax year available.
//
procedure TTaxBase.SetTaxYear(AccidentDate: tdatetime; TaxYear: Integer);
var
  Year, Month, Day: Word;
begin
     DecodeDate(AccidentDate, Year, Month, Day);

     if TaxYear < 2000 then
          begin
          TheTaxYear := TaxYear;
          end
     else if TaxYear = 2000 then
          begin
          TheTaxYear := 2000;
          end
     else if TaxYear = 2001 then
          begin
	        TheTaxYear := 2001;
	        end
     else if (TaxYear = 2002) and (month < 7) then
          begin
	        TheTaxYear := 2002;
  	      end
     else if ((TaxYear = 2002) and (month > 6)) or
             ((TaxYear = 2003) and (month < 7)) then
          begin
	        TheTaxYear := 2003;
  	      end
     else if ((TaxYear = 2003) and (month > 6)) or
             ((TaxYear = 2004) and (month < 7)) then
          begin
	        TheTaxYear := 2004;
  	      end
     else if ((TaxYear = 2004) and (month > 6)) or
             ((TaxYear = 2005) and (month < 7)) then
          begin
	        TheTaxYear := 2005;
  	      end
     else if ((TaxYear = 2005) and (month > 6)) or
             ((TaxYear = 2006) and (month < 7)) then
          begin
	        TheTaxYear := 2006;
          End
     else if ((TaxYear = 2006) and (month > 6)) or
             ((TaxYear = 2007) and (month < 7)) then
          begin
	        TheTaxYear := 2007;
          End
     else if ((TaxYear = 2007) and (month > 6)) or
             ((TaxYear = 2008) and (month < 7)) then
          begin
	        TheTaxYear := 2008;
          End
     else if ((TaxYear = 2008) and (month > 6)) or
             ((TaxYear = 2009) and (month < 7)) then
          begin
	        TheTaxYear := 2009;
          End
     else if ((TaxYear = 2009) and (month > 6)) or
             ((TaxYear = 2010) and (month < 7)) then
          begin
	        TheTaxYear := 2010;
          End
     else if ((TaxYear = 2010) and (month > 6)) or
             ((TaxYear = 2011) and (month < 7)) then
          begin
	        TheTaxYear := 2011;
          End
     else if ((TaxYear = 2011) and (month > 6)) or
             ((TaxYear = 2012) and (month < 7)) then
          begin
	        TheTaxYear := 2012;
          End
     else if ((TaxYear = 2012) and (month > 6)) or
             ((TaxYear = 2013) and (month < 7)) then
          begin
	        TheTaxYear := 2013;
          End
     else if ((TaxYear = 2013) and (month > 6)) or
             ((TaxYear = 2014) and (month < 7)) then
          begin
	        TheTaxYear := 2014;
          End
     else if ((TaxYear = 2014) and (month > 6)) or
             ((TaxYear = 2015) and (month < 7)) then
          begin
	        TheTaxYear := 2015;
          End
     else if ((TaxYear = 2015) and (month > 6)) or
             ((TaxYear = 2016) and (month < 7)) then
          begin
	        TheTaxYear := 2016;
          end
     else if ((TaxYear = 2016) and (month > 6)) or
             ((TaxYear = 2017) and (month < 7)) then
          begin
	        TheTaxYear := 2017;
          end
     else if ((TaxYear = 2017) and (month > 6)) or
             ((TaxYear = 2018) and (month < 7)) then
          begin
	        TheTaxYear := 2018;
          end
     else if ((TaxYear = 2018) and (month > 6)) or
             ((TaxYear = 2019) and (month < 7)) then
          begin
	        TheTaxYear := 2019;
          end
     else if ((TaxYear = 2019) and (month > 6)) or
             ((TaxYear = 2020) and (month < 7)) then
          begin
	        TheTaxYear := 2020;
          end
     else if ((TaxYear = 2020) and (month > 6)) or
             ((TaxYear = 2021) and (month < 7)) then
          begin
	        TheTaxYear := 2021;
          end
     else if ((TaxYear = 2021) and (month > 6)) or
             ((TaxYear = 2022) and (month < 7)) then
          begin
	        TheTaxYear := 2022;
          end
     else if ((TaxYear = 2022) and (month > 6)) or
             ((TaxYear = 2023) and (month < 7)) then
          begin
	        TheTaxYear := 2023;
          end
     else if ((TaxYear = 2023) and (month > 6)) or
             ((TaxYear = 2024) and (month < 7)) then
          begin
	        TheTaxYear := 2024;
          end
     else if ((TaxYear = 2024) and (month > 6)) or
             ((TaxYear = 2025) and (month < 7)) then
          begin
	        TheTaxYear := 2025;
          end
     else if ((TaxYear = 2025) and (month > 6)) or
             ((TaxYear = 2026) and (month < 7)) then
          begin
	        TheTaxYear := 2026;
          end
     else if ((TaxYear = 2026) and (month > 6)) or
             ((TaxYear = 2027) and (month < 7)) then
          begin
	        TheTaxYear := 2027;
          end;;
end;

end.
