unit uTaxJul06;

interface
uses uTaxJan06, NCIniMod, Utils, uNCCLAIM;

type
  TTaxJul06 = class(TTaxJan06)
end;

implementation

{ TTaxJul06 }

end.

