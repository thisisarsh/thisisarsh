library TaxCalculator;

{ Important note about DLL memory management: ShareMem must be the
  first unit in your library's USES clause AND your project's (select
  Project-View Source) USES clause if your DLL exports any procedures or
  functions that pass strings as parameters or function results. This
  applies to all strings passed to and from your DLL--even those that
  are nested in records and classes. ShareMem is the interface unit to
  the BORLNDMM.DLL shared memory manager, which must be deployed along
  with your DLL. To avoid using BORLNDMM.DLL, pass string information
  using PChar or ShortString parameters. }



uses
  Forms,
  SysUtils,
  Classes,
  uTaxCalc in 'uTaxCalc.pas',
  Utils in '..\..\Repository\Delphi\Utils.pas',
  uTaxCalculator in 'uTaxCalculator.pas',
  uNCCLAIM in 'uNCCLAIM.pas',
  uTax2000 in 'uTax2000.pas',
  uTaxJan01 in 'uTaxJan01.pas',
  uTaxJan02 in 'uTaxJan02.pas',
  uTaxBase in 'uTaxBase.pas',
  uTaxJul02 in 'uTaxJul02.pas',
  uTaxJan04 in 'uTaxJan04.pas',
  uTaxJul04 in 'uTaxJul04.pas',
  uTaxJul05 in 'uTaxJul05.pas',
  uTaxJan06 in 'uTaxJan06.pas',
  uTaxJul06 in 'uTaxJul06.pas',
  uTaxJan07 in 'uTaxJan07.pas',
  uTaxJul07 in 'uTaxJul07.pas',
  uTaxJan08 in 'uTaxJan08.pas',
  NCRECDEF in '..\..\Wageloss\SOURCE\NCRECDEF.PAS',
  NCIniMod in '..\..\Wageloss\SOURCE\NCIniMod.pas',
  uTaxJul08 in 'uTaxJul08.pas',
  uTaxJan09 in 'uTaxJan09.pas',
  uTaxJul09 in 'uTaxJul09.pas',
  uTaxJan10 in 'uTaxJan10.pas',
  uTaxJul10 in 'uTaxJul10.pas',
  uTaxJan11 in 'uTaxJan11.pas',
  uTaxJul11 in 'uTaxJul11.pas',
  uTaxJan12 in 'uTaxJan12.pas',
  uTaxJul12 in 'uTaxJul12.pas',
  uTaxJan13 in 'uTaxJan13.pas',
  uTaxJul13 in 'uTaxJul13.pas',
  uTaxJan14 in 'uTaxJan14.pas',
  uTaxJul14 in 'uTaxJul14.pas',
  uTaxJan15 in 'uTaxJan15.pas',
  uTaxJul15 in 'uTaxJul15.pas',
  uTaxJan16 in 'uTaxJan16.pas',
  uTaxJul16 in 'uTaxJul16.pas',
  uTaxJan17 in 'uTaxJan17.pas',
  uTaxJul17 in 'uTaxJul17.pas',
  uTaxJan18 in 'uTaxJan18.pas',
  uTaxJul18 in 'uTaxJul18.pas',
  uTaxJan19 in 'uTaxJan19.pas',
  uTaxJul19 in 'uTaxJul19.pas',
  uTaxJan20 in 'uTaxJan20.pas',
  uTaxJul20 in 'uTaxJul20.pas',
  uTaxJan21 in 'uTaxJan21.pas',
  uTaxJul21 in 'uTaxJul21.pas',
  uTaxJan22 in 'uTaxJan22.pas',
  uTaxJul22 in 'uTaxJul22.pas',
  uTaxJan23 in 'uTaxJan23.pas',
  uTaxJul23 in 'uTaxJul23.pas',
  uTaxJan24 in 'uTaxJan24.pas',
  uTaxJul24 in 'uTaxJul24.pas',
  uTaxJan25 in 'uTaxJan25.pas',
  uTaxJul25 in 'uTaxJul25.pas',
  uTaxJan26 in 'uTaxJan26.pas',
  uTaxJul26 in 'uTaxJul26.pas';

{$E dll}

exports
  ncbencal index 1 name 'Calc_Ben',
  isSelfAssurer index 2 name 'Check_Self_Assurer',
  nccanty index 3 name 'Calc_Annuity',
  findFirmName index 4 name 'Find_Firm_Name';
end.
