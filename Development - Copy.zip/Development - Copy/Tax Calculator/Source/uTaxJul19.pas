unit uTaxJul19;

interface
uses uTaxJan19, NCIniMod, Utils, uNCCLAIM;

type
  TTaxJul19 = class(TTaxJan19)
end;

implementation

  { TTaxJan19}

end.
