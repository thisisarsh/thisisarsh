unit uTaxJul14;

interface
uses uTaxJan14, NCIniMod, Utils, uNCCLAIM;

type
  TTaxJul14 = class(TTaxJan14)
end;

implementation

  { TTaxJul14}

end.


