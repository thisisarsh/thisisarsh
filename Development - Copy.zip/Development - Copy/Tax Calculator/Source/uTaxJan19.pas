unit uTaxJan19;

interface
uses uTaxJul18, NCIniMod, Utils, uNCCLAIM;

type
  TTaxJan19 = class(TTaxJul18)
end;

implementation

  { TTaxJan19}

end.
