unit uTaxJul04;

interface
uses uTaxJan04, NCIniMod, Utils, uNCCLAIM;

type
  TTaxJul04=class(TTaxJan04)
end;

implementation

{ TTaxJul04 }

end.
 