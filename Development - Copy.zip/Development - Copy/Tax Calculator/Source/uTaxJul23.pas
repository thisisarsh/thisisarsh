unit uTaxJul23;

interface

uses uTaxJan23, NCIniMod, Utils, uNCCLAIM;

type
  TTaxJul23 = class(TTaxJan23)
end;

implementation

end.
