unit uTaxJul02;

interface
uses uTaxJan02, NCIniMod, Utils, uNCCLAIM;

type
  TTaxJul02=class(TTaxJan02)
end;

implementation

{ TTaxJul02 }

end.






