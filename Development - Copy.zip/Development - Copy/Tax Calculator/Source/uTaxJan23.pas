unit uTaxJan23;

interface

uses uTaxJul22, NCIniMod, Utils, uNCCLAIM;

type
  TTaxJan23 = class(TTaxJul22)
end;

implementation

end.
