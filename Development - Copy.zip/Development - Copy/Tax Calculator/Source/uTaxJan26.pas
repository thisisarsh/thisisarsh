unit uTaxJan26;

interface

uses uTaxJul25, NCIniMod, Utils, uNCCLAIM;

type
  TTaxJan26 = class(TTaxJul25)

  end;

implementation

end.
