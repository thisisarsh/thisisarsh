unit uTaxJan16;

interface
uses uTaxJul15, NCIniMod, Utils, uNCCLAIM;

type
  TTaxJan16 = class(TTaxJul15)
end;

implementation

  { TTaxJan16}

end.
