unit uTaxJan13;

interface
uses uTaxJul12, NCIniMod, Utils, uNCCLAIM;

type
  TTaxJan13 = class(TTaxJul12)
end;

implementation

{ TTaxJan13}

end.
