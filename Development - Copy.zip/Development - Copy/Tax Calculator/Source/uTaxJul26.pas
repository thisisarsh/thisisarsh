unit uTaxJul26;

interface

uses uTaxJan26, NCIniMod, Utils, uNCCLAIM;

type
  TTaxJul26 = class(TTaxJan26)

  end;

implementation

end.
