unit uTax2000;

interface
uses uTaxCalculator, NCIniMod;

type
  TTax2000=class(TTaxCalculator)
  private
  protected
    function Calculate_Fed_Surtax:currency;override;
  public
  published
end;

implementation

{ TTax2000 }

function TTax2000.Calculate_Fed_Surtax: currency;
var
   t, tr1, tr2, ta:Currency;
begin
  if nc_tax_exempt = 'Y' then
  begin
    t := 0;
    tr1 := 0;
    tr2 := 0;
    ta := 0;
  end
  else
  begin
    t := Round((Nc_Bc_Bft * nc_fed_surtax_rate_i)* 100) / 100;
    if nc_bc_bft > nc_fed_surtax_lim_ii then
    begin
       tr2 := 0;
       ta := ((nc_bc_bft - nc_fed_surtax_lim_ii) * nc_fed_surtax_rate_ii);
    end
    else if nc_bc_bft > 8333.00 then
    begin
       tr2 := 250.00 - ((Nc_Bc_Bft - 8333.00) * 0.06);
       ta := 0;
    end
    else
    begin
       t := 0.00;
       tr2 := 0;
       ta := 0;
    end;

    tr1 := Round((t - tr2) * 0.5 * 100) / 100;
  end;  //else

  Result := t - tr1 - tr2 + ta;
end;

end.
