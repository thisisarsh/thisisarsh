unit uTaxJul15;

interface
uses uTaxJan15, NCIniMod, Utils, uNCCLAIM;

type
  TTaxJul15 = class(TTaxJan15)
end;

implementation

  { TTaxJul15}

end.

