unit uTaxJan14;

interface
uses uTaxJul13, NCIniMod, Utils, uNCCLAIM;

type
  TTaxJan14 = class(TTaxJul13)
end;

implementation

  { TTaxJan14}

end.


