unit uTaxJan01;

interface
uses uTax2000, NCIniMod, Utils;

type
  TTaxJan01=class(TTax2000)
  private
  protected
    function Calculate_Fed_Surtax:currency;override;
    function Calculate_Man_mbt:currency;override;
    function Calculate_Man_NRTC:currency;override;
    function Calculate_Net_Income(annual_salary:currency):currency;override;
  public
  published
end;
implementation

{ TTaxJan01 }

function TTaxJan01.Calculate_Fed_Surtax: currency;
begin
  //PrintDisplay('TTaxJan01.Calculate_Fed_Surtax: currency');
  if nc_tax_exempt = 'Y' then
    begin
    result := 0;
    end
  else
    begin
    if nc_bc_bft > nc_fed_surtax_lim_ii then
      result := (nc_bc_bft - nc_fed_surtax_lim_ii) * nc_fed_surtax_rate_ii
    else
      result := 0.00;
    end;
  result := PDoxRound(result, 2);
end;

function TTaxJan01.Calculate_Man_mbt: currency;
var
  const1, const2 : Currency;
begin
  //PrintDisplay('TTaxJan01.Calculate_Man_mbt: currency');
  const1 := Round((nc_mb_inclvl_i * (nc_mb_tax_rate_ii - nc_mb_tax_rate_i)) * 100)/ 100;
  const2 := Round((nc_mb_inclvl_ii * (nc_mb_tax_rate_iii - nc_mb_tax_rate_ii) + const1) * 100)/ 100;
  if nc_tax_exempt = 'Y' then
    begin
    result := 0;
    end
  else
    begin
    if nc_bc_ann_sal_net > nc_mb_inclvl_ii then
      result := (nc_bc_ann_sal_net * nc_mb_tax_rate_iii) - const2
    else if nc_bc_ann_sal_net > nc_mb_inclvl_i then
      result := (nc_bc_ann_sal_net * nc_mb_tax_rate_ii) - const1
    else
      result := (nc_bc_ann_sal_net * nc_mb_tax_rate_i);

    result := PDoxRound(result, 2);
    result := result - nc_bc_mb_nrtc;

    if result < 0 then
      result := 0;
    end;
end;

function TTaxJan01.Calculate_Man_NRTC: currency;
begin
  //PrintDisplay('TTaxJan01.Calculate_Man_NRTC: currency');
  result := PDoxRound((nc_bc_cpp + nc_bc_uic + nc_tax_exmp) * nc_mb_tax_rate_i, 2);
end;

function TTaxJan01.Calculate_Net_Income(annual_salary: currency): currency;
begin
  //PrintDisplay('TTaxJan01.Calculate_Net_Income(annual_salary: currency): currency');
  if ((nc_ann_income > nc_max_ann_sal) and (annual_salary <> nc_ann_income)) AND
     (NOT (((annual_salary = nc_minwage_income) AND (nc_minwage_income > 0)) AND (nc_ann_income > nc_max_ann_sal))) then
    result := annual_salary - nc_bc_pro_deductions
  else
    result := annual_salary - nc_bc_deductions;

  result := PDoxRound(result, 2);
  if result < 0 then
    result := 0;
end;

end.
