unit uTaxJan07;

interface
uses uTaxJul06, NCIniMod, Utils, uNCCLAIM;

type
  TTaxJan07 = class(TTaxJul06)
end;

implementation

{ TTaxJan07}

end.

