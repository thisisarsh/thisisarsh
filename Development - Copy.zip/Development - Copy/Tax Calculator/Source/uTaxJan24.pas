unit uTaxJan24;

interface


uses uTaxJul23, NCIniMod, Utils, uNCCLAIM;

type
  TTaxJan24 = class(TTaxJul23)
end;

implementation

end.
