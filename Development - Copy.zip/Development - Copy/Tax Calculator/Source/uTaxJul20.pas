unit uTaxJul20;

interface

uses uTaxJan20, NCIniMod, Utils, uNCCLAIM;

type
  TTaxJul20 = class(TTaxJan20)
end;

implementation

  { TTaxJul20}

end.
