unit uTaxJul25;

interface

uses uTaxJan25, NCIniMod, Utils, uNCCLAIM;

type
  TTaxJul25 = class(TTaxJan25)

  end;

implementation

end.
