unit uTaxJan08;

interface
uses uTaxJul07, NCIniMod, Utils, uNCCLAIM;

type
  TTaxJan08 = class(TTaxJul07)
end;

implementation

{ TTaxJan08}

end.

