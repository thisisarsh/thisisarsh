unit uTaxJan22;

interface

uses uTaxJul21, NCIniMod, Utils, uNCCLAIM;

type
  TTaxJan22 = class(TTaxJul21)
end;

implementation

  { TTaxJan22}

end.
