unit uTaxJan17;

interface
uses uTaxJul16, NCIniMod, Utils, uNCCLAIM;

type
  TTaxJan17 = class(TTaxJul16)
end;

implementation

  { TTaxJan17}

end.
