unit uTaxJan02;

interface
uses SysUtils, uTaxJan01, NCIniMod, Utils, Math, uNCCLAIM;

type
  TTaxJan02=class(TTaxJan01)
  private
  protected
    nc_fed_tax_amt_iii           :currency;
    nc_fed_tax_rate_iiii         :currency;
    nc_fed_inclvl_iii            :currency;
    procedure Set_ncexmcal(var AccidentDate: TDateTime; var r: recNCCLAIM; Var w: recConst);Override;
    procedure SetMarital(AccidentDate: TDateTime; year:integer;
      status, spouse_working:shortstring; ClaimSpouseForTaxPurposes:string; var w: recConst);Override;
    procedure SetPersonal(AccidentDate: TDateTime; year:integer; var w: recConst);Override;
    procedure SetDependantAmounts(AccidentDate: TDateTime; year:integer; var w: recConst);Override;
    function Calculate_Fed_Tax_2:currency;Override;
    function Set_ncldtxtb(r: recNCCLAIM; AccidentDate: TDateTime; nc_tax_year, nc_acc_year: integer;
      nc_max_adjustment: currency): boolean;Override;
    function Calculate_Man_Tax(var w: recConst):currency;Override;
    function Calculate_Fed_Tax(var w: recConst):currency;Override;
    procedure Set_ncbcschd(nc_bc_ann_sal: currency; nc_calc_type: char;
      nc_calc_descr: shortstring; var w: recConst);Override;
    function Calculate_Man_mbt: currency; Override;
  public
  published
end;
implementation

procedure TTaxJan02.Set_ncexmcal(var AccidentDate: TDateTime; var r: recNCCLAIM; Var w: recConst);
begin
  //PrintDisplay('TTaxCalculator.Set_ncexmcal(var AccidentDate: TDateTime; var r: recNCCLAIM; w: recConst)');
  NC_SPOUSE             := 0;
  NC_III_SPOUSE         := 0;
  NC_CHILDSPOUSE        := 0;
  NC_III_CHILDSPOUSE    := 0;
  nc_1st_dep            := 0;
  NC_III_DEP            := 0;
  nc_3rd_dep            := 0;
  w.Work_NC_SPOUSE      := 0;
  w.Work_NC_III_SPOUSE  := 0;
  w.Work_NC_CHILDSPOUSE := 0;
  w.Work_NC_III_CHILDSPOUSE := 0;
  w.Work_NC_III_DEP     := 0;
  nc_tax_year           := r.Tax_Year;
  w.Work_nc_tax_year    := nc_tax_year;
  nc_accident_year      := year( AccidentDate );
  if AccidentDate = 0 then
    nc_accident_year := r.Tax_Year;
  nc_no_of_dep          := r.No_of_Dependnts;
  w.Work_nc_no_of_dep   := nc_no_of_dep;
  nc_no_infirm          := r.No_Infirm;
  w.Work_nc_no_infirm   := nc_no_infirm;
  actualNoOfDependants  := r.No_of_Dependnts;
  w.Work_actualNoOfDependants := actualNoOfDependants;
  SetPersonal(AccidentDate, nc_tax_year,w);
  SetMarital(AccidentDate, nc_tax_year,r.MARITAL_STATUS,r.Spouse_Working, r.ClaimSpouseForTaxPurposes, w);
  SetExemptForDependants(AccidentDate, nc_tax_year);
  SetDependantAmounts(AccidentDate, nc_tax_year,w);
  NC_EXEMPT_AMOUNT := Calculate_Exempt_Amount;
  w.Work_NC_EXEMPT_AMOUNT := NC_EXEMPT_AMOUNT;
  nc_iii_credit    := Calculate_Section_III;
  w.Work_nc_iii_credit := nc_iii_credit;
  r.III_CREDIT     := nc_iii_credit;
  r.Tax_Exemption   := NC_EXEMPT_AMOUNT;
  nc_tax_exmp  := nc_exempt_amount;
  w.Work_nc_tax_exmp := nc_tax_exmp;
  r.Tax_Code := SetTaxCode(AccidentDate, nc_tax_year);
end;

procedure TTaxJan02.SetMarital(AccidentDate: TDateTime; year: integer; status,
  spouse_working: shortstring; ClaimSpouseForTaxPurposes:string; var w: recConst);
begin
  //PrintDisplay('TTaxCalculator.SetMarital(year: integer; status,');
  if ( status = 'MARRIED' ) OR ( status = 'COMMON-LAW' )
    OR ( status = 'M' ) OR ( status = 'C' ) then
  begin
    if ( spouse_working = 'N' ) And (ClaimSpouseForTaxPurposes = 'Y') Then
    begin
      NC_SPOUSE     := arrayNCEXMAMT[FindindexNCEXMAMT(AccidentDate, year)].Spouse;
      w.Work_NC_SPOUSE := NC_SPOUSE;
      NC_III_SPOUSE := arrayNCEXMAMT[FindindexNCEXMAMT(AccidentDate, year)].III_Spouse;
      w.Work_NC_III_SPOUSE := NC_III_SPOUSE;
    end;
  end
  ELSE
  begin
    IF(nc_no_of_dep > 0) Then
    begin
      NC_CHILDSPOUSE     := arrayNCEXMAMT[FindindexNCEXMAMT(AccidentDate, year)].ChildSpouse;
      w.Work_NC_CHILDSPOUSE := NC_CHILDSPOUSE;
      NC_III_CHILDSPOUSE := arrayNCEXMAMT[FindindexNCEXMAMT(AccidentDate, year)].III_ChildSpouse;
      w.Work_NC_III_CHILDSPOUSE := NC_III_CHILDSPOUSE;
      nc_no_of_dep   := nc_no_of_dep - 1;
      w.Work_nc_no_of_dep := nc_no_of_dep;
    end
    ELSE
    begin
      IF(nc_no_infirm > 0) Then
      begin
        NC_CHILDSPOUSE     := arrayNCEXMAMT[FindindexNCEXMAMT(AccidentDate, year)].ChildSpouse;
        w.Work_NC_CHILDSPOUSE := NC_CHILDSPOUSE;
        NC_III_CHILDSPOUSE := arrayNCEXMAMT[FindindexNCEXMAMT(AccidentDate, year)].III_ChildSpouse;
        w.Work_NC_III_CHILDSPOUSE := NC_III_CHILDSPOUSE;
        nc_no_infirm := nc_no_infirm - 1;
        w.Work_nc_no_infirm := nc_no_infirm;
      end;
    end;
  end;
end;

procedure TTaxJan02.SetPersonal(AccidentDate: TDateTime; year: integer; var w: recConst);
begin
  //PrintDisplay('TTaxCalculator.SetPersonal(year: integer; var w: recConst)');
  personal     := arrayNCEXMAMT[FindindexNCEXMAMT(AccidentDate, year)].Personal;
  w.Work_personal := personal;
  III_Personal := arrayNCEXMAMT[FindindexNCEXMAMT(AccidentDate, year)].III_Personal;
  w.Work_III_Personal := III_Personal;
end;

procedure TTaxJan02.SetDependantAmounts(AccidentDate: TDateTime; year: integer; var w: recConst);
begin
  //PrintDisplay('TTaxCalculator.SetDependantAmounts(year: integer; var w: recConst)');
  NC_III_DEP := nc_no_of_dep * arrayNCEXMAMT[FindindexNCEXMAMT(AccidentDate, year)].III_Dep;
  w.Work_NC_III_DEP := NC_III_DEP;

  federalChildTaxCredit := actualNoOfDependants * arrayNCEXMAMT[ FindindexNCEXMAMT( AccidentDate, year ) ].federalChildTaxCredit;
  w.Work_federalChildTaxCredit := federalChildTaxCredit;

  infirm        := nc_no_infirm * arrayNCEXMAMT[FindindexNCEXMAMT(AccidentDate, year)].Infirm_Dep;
  w.Work_infirm := infirm;
  NC_III_INFIRM := nc_no_infirm * arrayNCEXMAMT[FindindexNCEXMAMT(AccidentDate, year)].III_Infirm_Dep;
  w.Work_NC_III_INFIRM := NC_III_INFIRM;
end;

function TTaxJan02.Calculate_Fed_Tax_2: currency;
var
  const1, const2, const3: Currency;
begin
  //PrintDisplay('TTaxCalculator.Calculate_Fed_Tax_2: currency');
  const1 := nc_fed_inclvl_i * (nc_fed_tax_rate_ii - nc_fed_tax_rate_i);
  const2 := (nc_fed_inclvl_ii * (nc_fed_tax_rate_iii - nc_fed_tax_rate_ii)) + const1;
  const3 := (nc_fed_inclvl_iii * (nc_fed_tax_rate_iiii - nc_fed_tax_rate_iii)) + const2;

  const1 := Round(const1);
  const2 := Round(const2);
  const3 := Round(const3);
  if nc_tax_exempt = 'Y' then
    begin
    result := 0;
    end
  else
    begin
    if nc_bc_ann_sal_net > nc_fed_inclvl_iii then
      result := (nc_bc_ann_sal_net *  nc_fed_tax_rate_iiii) - const3
    else if nc_bc_ann_sal_net > nc_fed_inclvl_ii then
      result := (nc_bc_ann_sal_net *  nc_fed_tax_rate_iii) - const2
    else if nc_bc_ann_sal_net > nc_fed_inclvl_i then
      result := (nc_bc_ann_sal_net *  nc_fed_tax_rate_ii) - const1
    else
      result := (nc_bc_ann_sal_net * nc_fed_tax_rate_i);

    result := PDoxRound(result, 2);
    result := result - nc_bc_nrtc;
    if result < 0 then
      result := 0;
  end;
end;

function TTaxJan02.Set_ncldtxtb(r: recNCCLAIM; AccidentDate: TDateTime; nc_tax_year, nc_acc_year: integer;
  nc_max_adjustment: currency): boolean;
var
   Test_Accident_Date:TDateTime;
   Acc_Year, Acc_Month, Acc_Day, Test_Tax_Year:Word;
begin
  //PrintDisplay('TTaxCalculator.Set_ncldtxtb(nc_tax_year, nc_acc_year: integer;');
  result:=false;

  //
  // ********* Start of modification *********
  //
  // Determine the Test_Axccident_Date to use
  //
  Test_Tax_Year := nc_tax_year;

//  if ((r.Recurrence <> 'Y')) then
//     Begin
//     Test_Accident_Date := r.Accident_Date;
//     DecodeDate(Test_Accident_Date, Acc_Year, Acc_Month, Acc_Day);
//     Test_Tax_Year := Min(Max(r.Indexation_Year , Acc_Year), Test_Tax_Year);
//     End
//  else
//     Begin
//     if (r.RecurrenceDate >= EncodeDate(2001, 01, 01)) Then
//        Begin
//        //
//        // Accident date for the calc of the max is actually the
//        // recurrence date. However we must test the tax year to ensure
//        // that the tax year is not within 2 years of the recurrence date
//        // for the test
//        //
//        Test_Accident_Date := r.RecurrenceDate;
//        DecodeDate(Test_Accident_Date, Acc_Year, Acc_Month, Acc_Day);
//        If ((Test_Tax_Year - Acc_Year) < 2) Then
//           Begin
//           Test_Tax_Year := Acc_Year;
//           End;
//           //
//           // Set the accident date if we meet the policy for recurrences after
//           // 2006 with an accident date after 2001 and less than 2006
//           //
////           if ((Year(r.RecurrenceDate) >= 2006)  and
////              (Year(r.Accident_Date) < 2006))      Then
////            begin
////              Test_Accident_Date := EncodeDate(2005, Acc_Month, Acc_Day);
////            end;
//           //
//           //
//        End
//     Else
//        Begin
//        Test_Accident_Date := r.Accident_Date;
//        DecodeDate(Test_Accident_Date, Acc_Year, Acc_Month, Acc_Day);
//        Test_Tax_Year := Min(Max(r.Indexation_Year , Acc_Year), Test_Tax_Year);
//        End;
//     End;
//  DecodeDate(Test_Accident_Date, Acc_Year, Acc_Month, Acc_Day);
//
// ********* End of modification *********
//

    //
    // LRC Bill 18
    //
    Acc_Year := Year(r.Accident_Date);
    Test_Tax_Year := Max(Year(r.Accident_Date), r.Indexation_Year);
    //
    // *****
    //

  //TODO: have to add in some date checking routine that will allow for bill 25 claims to not have a max
  if nc_max_adjustment <> 0 then
     begin
     nc_max_ann_sal := nc_max_adjustment;
     end
  else
     begin
     if ((Acc_Year >= 2006) AND (Acc_Year <= 2021)) then
        begin
        nc_max_ann_sal := r.WKLY_SAL_A * 52;
        end
     else
        begin
        nc_max_ann_sal := getAnnualMaximum(r.Accident_Date, nc_acc_year, Acc_Month, nc_tax_year);
//        if Acc_Month = 12 Then
//           nc_max_ann_sal := arrayNCANNMAX[FindindexNCANNMAX(Acc_Year, Test_Tax_Year)].Annual_Maximum_Dec
//        else
//           nc_max_ann_sal := arrayNCANNMAX[FindindexNCANNMAX(Acc_Year, Test_Tax_Year)].Annual_Maximum;
        end;
     end;

  with arrayNCTAXRAT[FindindexNCTAXRAT(AccidentDate, nc_tax_year)] do
     begin
     nc_uic_prate               := UIC_premium_rate;
     nc_max_ins_earn            := UIC_max_insured_earnings;
     nc_uic_max_ann_prem        := UIC_max_annual_premium;
     nc_cpp_basic_exmp          := CPP_basic_exemption;
     nc_cpp_crate               := CPP_contrib_rate;
     nc_cpp_max_ann_contrib     := CPP_max_annual_contrib;
     nc_fed_inclvl_i            := FED_income_level_i;
     nc_fed_inclvl_ii           := FED_income_level_ii;
     nc_fed_inclvl_iii          := FED_income_level_iii;
     nc_fed_tax_amt_i           := FED_tax_amt_i;
     nc_fed_tax_amt_ii          := FED_tax_amt_ii;
     nc_fed_tax_amt_iii         := FED_tax_amt_iii;
     nc_fed_tax_rate_i          := FED_tax_rate_i;
     nc_fed_tax_rate_ii         := FED_tax_rate_ii;
     nc_fed_tax_rate_iii        := FED_tax_rate_iii;
     nc_fed_tax_rate_iiii       := FED_tax_rate_iiii;
     nc_fed_surtax_rate_i       := FED_surtax_rate_i;
     nc_fed_surtax_rate_ii      := FED_surtax_rate_ii;
     nc_fed_surtax_lim_ii       := FED_surtax_limit_ii;
     nc_mb_tax_rate             := MB_tax_rate;
     nc_mb_tax_rate_i           := MB_tax_rate_i;
     nc_mb_tax_rate_ii          := MB_tax_rate_ii;
     nc_mb_tax_rate_iii         := MB_tax_rate_iii;
     nc_mb_inclvl_i             := MB_income_level_i;
     nc_mb_inclvl_ii            := MB_income_level_ii;
     nc_mb_tax_amt_i            := MB_tax_amt_i;
     nc_mb_tax_amt_ii           := MB_tax_amt_ii;
     nc_mb_net_rate             := MB_net_tax_rate;
     nc_mbFamilyTaxBenefitRate  := mbFamilyTaxBenefitRate;
     //nc_maxfederalCanadaEmploymentCredit := federalCanadaEmploymentCredit;
     end;

  if (Acc_Year < 2006) or (Acc_Year > 2021) then
     begin
     if (FindindexNCANNMAX(r.Accident_Date, nc_acc_year, nc_tax_year) > -1)   or
        (FindindexNCTAXRAT(AccidentDate, nc_tax_year) > -1) then
        result := true;
     end
  else
     begin
     result := true;
     end;

end;

function TTaxJan02.Calculate_Man_Tax(var w: recConst): currency;
begin
  //PrintDisplay('TTaxCalculator.Calculate_Man_Tax(var w: recConst): currency');
  nc_bc_mbt := Calculate_Man_mbt;
  nc_bc_mnt := Calculate_Man_mnt;
  nc_bc_mtr := Calculate_Man_mtr;
  result := nc_bc_mbt - nc_bc_mtr; // jdyck

  result := PDoxRound(result, 2);
  if result < 0 then
    result := 0;
end;

function TTaxJan02.Calculate_Fed_Tax(var w: recConst): currency;
begin
  //PrintDisplay('TTaxCalculator.Calculate_Fed_Tax(var w: recConst): currency');
  result := Calculate_Fed_Tax_2;
end;

procedure TTaxJan02.Set_ncbcschd(nc_bc_ann_sal: currency; nc_calc_type: char;
      nc_calc_descr: shortstring; var w: recConst);
begin
  //PrintDisplay('TTaxCalculator.Set_ncbcschd(nc_bc_ann_sal: currency;');
  nc_bc_cpp := Calculate_CPP(nc_bc_ann_sal);
  nc_bc_uic := Calculate_UIC(nc_bc_ann_sal);
  //nc_federalCanadaEmploymentCredit := Calculate_federalCanadaEmploymentCredit(nc_bc_ann_sal);
  nc_bc_ann_sal_net := Calculate_Net_Income(nc_bc_ann_sal);
  nc_bc_nrtc := Calculate_Fed_NRTC;
  nc_bc_mb_nrtc := Calculate_Man_NRTC;
  nc_bc_fedtax := Calculate_Fed_Tax(w);
  nc_bc_mb_tax := Calculate_Man_Tax(w);
  //
  // Changed Nov 2003 by D. Madill
  // Changed to eliminate rounding error on tax calculations.
  //
  nc_bc_cpp := PdoxRound(nc_bc_cpp, 2);
  nc_bc_uic := PDoxRound(nc_bc_uic, 2);
  //nc_federalCanadaEmploymentCredit :=  PDoxRound( nc_federalCanadaEmploymentCredit, 2 );
  nc_bc_fedtax := PDoxRound(nc_bc_fedtax, 2);
  nc_bc_mb_tax := PDoxRound(nc_bc_mb_tax, 2);
  nc_bc_ann_sal := PDoxRound(nc_bc_ann_sal, 2);
  nc_bc_ann_sal_net := PDoxRound(nc_bc_ann_sal_net, 2);
  nc_bc_nrtc := PDoxRound(nc_bc_nrtc, 2);
  nc_bc_mb_nrtc := PDoxRound(nc_bc_mb_nrtc, 2);
  nc_bc_bft := PDoxRound(nc_bc_bft, 2);
  nc_bc_fst := PDoxRound(nc_bc_fst, 2);
  nc_bc_mbt := PDoxRound(nc_bc_mbt, 2);
  //
  nc_bc_td := nc_bc_cpp + nc_bc_uic + nc_bc_fedtax + nc_bc_mb_tax;
  //nc_bc_td := nc_bc_cpp + nc_bc_uic + nc_bc_fedtax + nc_bc_mbt;
  nc_bc_netinc := nc_bc_ann_sal - nc_bc_td;
  Case nc_calc_type of
    'A': begin
           w.Work_nc_bc_cpp_a := nc_bc_cpp;
           w.Work_nc_bc_uic_a := nc_bc_uic;
           //w.Work_federalCanadaEmploymentCredit_a := nc_federalCanadaEmploymentCredit;
           w.Work_actualNoOfDependants := actualNoOfDependants;
           w.Work_nc_bc_ann_sal_net_a := nc_bc_ann_sal_net;
           w.Work_nc_bc_nrtc_a := nc_bc_nrtc;
           w.Work_nc_bc_mb_nrtc_a := nc_bc_mb_nrtc;
           w.Work_nc_bc_mb_tax_a := nc_bc_mb_tax;
           w.Work_nc_bc_td_a := nc_bc_td;
           w.Work_nc_bc_netinc_a := nc_bc_netinc;
           w.Work_nc_bc_bft_a := nc_bc_bft;
           w.Work_nc_bc_mbt_a := nc_bc_mbt;
           w.Work_mbFamilyTaxBenefitRate_a := nc_mbFamilyTaxBenefitAmt;
         end;
    'B': begin
           w.Work_nc_bc_cpp_b := nc_bc_cpp;
           w.Work_nc_bc_uic_b := nc_bc_uic;
           //w.Work_federalCanadaEmploymentCredit_b := nc_federalCanadaEmploymentCredit;
           w.Work_nc_bc_ann_sal_net_b := nc_bc_ann_sal_net;
           w.Work_nc_bc_nrtc_b := nc_bc_nrtc;
           w.Work_nc_bc_mb_nrtc_b := nc_bc_mb_nrtc;
           w.Work_nc_bc_mb_tax_b := nc_bc_mb_tax;
           w.Work_nc_bc_td_b := nc_bc_td;
           w.Work_nc_bc_netinc_b := nc_bc_netinc;
           w.Work_nc_bc_bft_b := nc_bc_bft;
           w.Work_nc_bc_mbt_b := nc_bc_mbt;
           w.Work_mbFamilyTaxBenefitRate_b := nc_mbFamilyTaxBenefitAmt;
         end;
    'C': begin
           w.Work_nc_bc_cpp_c := nc_bc_cpp;
           w.Work_nc_bc_uic_c := nc_bc_uic;
           //w.Work_federalCanadaEmploymentCredit_c := nc_federalCanadaEmploymentCredit;
           w.Work_nc_bc_ann_sal_net_c := nc_bc_ann_sal_net;
           w.Work_nc_bc_nrtc_c := nc_bc_nrtc;
           w.Work_nc_bc_mb_nrtc_c := nc_bc_mb_nrtc;
           w.Work_nc_bc_mb_tax_c := nc_bc_mb_tax;
           w.Work_nc_bc_td_c := nc_bc_td;
           w.Work_nc_bc_netinc_c := nc_bc_netinc;
           w.Work_nc_bc_bft_c := nc_bc_bft;
           w.Work_nc_bc_mbt_c := nc_bc_mbt;
           w.Work_mbFamilyTaxBenefitRate_c := nc_mbFamilyTaxBenefitAmt;
         end;
    'D': begin
           w.Work_nc_bc_cpp_d := nc_bc_cpp;
           w.Work_nc_bc_uic_d := nc_bc_uic;
           //w.Work_federalCanadaEmploymentCredit_d := nc_federalCanadaEmploymentCredit;
           w.Work_nc_bc_ann_sal_net_d := nc_bc_ann_sal_net;
           w.Work_nc_bc_nrtc_d := nc_bc_nrtc;
           w.Work_nc_bc_mb_nrtc_d := nc_bc_mb_nrtc;
           w.Work_nc_bc_mb_tax_d := nc_bc_mb_tax;
           w.Work_nc_bc_td_d := nc_bc_td;
           w.Work_nc_bc_netinc_d := nc_bc_netinc;
           w.Work_nc_bc_bft_d := nc_bc_bft;
           w.Work_nc_bc_mbt_d := nc_bc_mbt;
           w.Work_mbFamilyTaxBenefitRate_d := nc_mbFamilyTaxBenefitAmt;
         end;
    'E': begin
           w.Work_nc_bc_cpp_e := nc_bc_cpp;
           w.Work_nc_bc_uic_e := nc_bc_uic;
           //w.Work_federalCanadaEmploymentCredit_e := nc_federalCanadaEmploymentCredit;
           w.Work_nc_bc_ann_sal_net_e := nc_bc_ann_sal_net;
           w.Work_nc_bc_nrtc_e := nc_bc_nrtc;
           w.Work_nc_bc_mb_nrtc_e := nc_bc_mb_nrtc;
           w.Work_nc_bc_mb_tax_e := nc_bc_mb_tax;
           w.Work_nc_bc_td_e := nc_bc_td;
           w.Work_nc_bc_netinc_e := nc_bc_netinc;
           w.Work_nc_bc_bft_e := nc_bc_bft;
           w.Work_nc_bc_mbt_e := nc_bc_mbt;
           w.Work_mbFamilyTaxBenefitRate_e := nc_mbFamilyTaxBenefitAmt;
         end;
    end;
end;

function TTaxJan02.Calculate_Man_mbt: currency;
var
  const1, const2 : integer;
begin
  //PrintDisplay('TTaxJan01.Calculate_Man_mbt: currency');
  const1 := Round(nc_mb_inclvl_i * (nc_mb_tax_rate_ii - nc_mb_tax_rate_i));
  const2 := Round(nc_mb_inclvl_ii * (nc_mb_tax_rate_iii - nc_mb_tax_rate_ii) + const1);
  if nc_tax_exempt = 'Y' then
    begin
    result := 0;
    end
  else
    begin
    if nc_bc_ann_sal_net > nc_mb_inclvl_ii then
      result := (nc_bc_ann_sal_net * nc_mb_tax_rate_iii) - const2
    else if nc_bc_ann_sal_net > nc_mb_inclvl_i then
      result := PDoxRound((nc_bc_ann_sal_net * nc_mb_tax_rate_ii), 2) - const1
    else
      result := (nc_bc_ann_sal_net * nc_mb_tax_rate_i);

    result := PDoxRound(result, 2);
    result := result - nc_bc_mb_nrtc;

    if result < 0 then
      result := 0;
    end;
end;

end.
