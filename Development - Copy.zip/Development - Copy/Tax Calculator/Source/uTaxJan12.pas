unit uTaxJan12;

interface
uses uTaxJul11, NCIniMod, Utils, uNCCLAIM;

type
  TTaxJan12 = class(TTaxJul11)
end;

implementation

{ TTaxJul11}

end.
