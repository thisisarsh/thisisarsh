unit uTaxJul13;

interface
uses uTaxJan13, NCIniMod, Utils, uNCCLAIM;

type
  TTaxJul13 = class(TTaxJan13)
end;

implementation

{ TTaxJul13}

end.
