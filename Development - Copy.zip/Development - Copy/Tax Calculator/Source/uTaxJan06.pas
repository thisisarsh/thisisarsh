unit uTaxJan06;

interface
uses SysUtils, uTaxJul05, NCIniMod, Utils, uNCCLAIM, Dialogs, Math;

type
  TTaxJan06=class(TTaxJul05)

  private

  protected
     procedure Set_ncbencal(var r: recNCCLAIM; Var w: recConst);override;
     procedure Set_nctaxcal(var r: recNCCLAIM; Var w: recConst);override;
     procedure Calculate_E(var r: recNCCLAIM; Var w: recConst);override;
     procedure Set_ncbcschd(nc_bc_ann_sal: currency; nc_calc_type: char;
      nc_calc_descr: shortstring; var w: recConst);override;
     procedure Set_nccanty(var r: recNCCLAIM);override;

  public

  published
end;

implementation

{ TTaxJan06 }

procedure TTaxJan06.Set_ncbencal(var r: recNCCLAIM; Var w: recConst);
var
   NetPostInjury:Currency;
begin
  //PrintDisplay('TTaxJan06.Set_ncbencal(var r: recNCCLAIM; var w: recConst)'); 
  r.Calc_Date           := Date;
  r.Calc_Username       := FUserName;
  NC_DAYS_PER_WK        := r.Days_Worked_per_Week;
  r.Annual_Gross        := r.WKLY_SAL    * 52;
  r.Annual_Gross_A      := r.Wkly_Sal_A  * 52;
  r.Annual_Net          := r.Annual_Gross - r.Total_Deds;
  r.Annual_Net_A        := r.Annual_Gross_A - r.Total_Deds_A;

  if Year(r.Accident_Date) >= 2006 Then
  begin
    if (r.Annual_Gross <= (r.Minimum_wage + 0.00005)) Then
      NetPostInjury := PdoxRound( r.Post_Injury_Earn_Net, 2 )
    else
      NetPostInjury := PdoxRound( PdoxRound( r.Post_Injury_Earn_Net, 2 ) * 0.90,2);
  end
  else
    NetPostInjury := PdoxRound( r.Post_Injury_Earn_Net, 2 );

  if Year(r.Accident_Date) >= 2006 Then
  begin
    if (r.Annual_Gross <= (r.Minimum_wage + 0.00005)) Then
    begin
      r.WEEKLY_NET          := PdoxRound(r.Annual_Net /52,2);
      r.Weekly_Net_A        := PdoxRound(r.Annual_Net_A /52,2);
    end
    else
    begin
      r.WEEKLY_NET          := PdoxRound( PdoxRound( (r.Annual_Net /52), 2 ) * 0.90,2);
      r.Weekly_Net_A        := PdoxRound((r.Annual_Net_A /52) * 0.90,2);
    end
  end
  else
  begin
     r.WEEKLY_NET          := PdoxRound(r.Annual_Net /52,2) - r.Post_Injury_Earn_Net;
     r.Weekly_Net_A        := PdoxRound(r.Annual_Net_A /52,2) - r.Post_Injury_Earn_Net;
  end;

  // Leg review changes for Jan 1, 2006
  if Year(r.Accident_Date) >= 2006 Then
  begin
    MAXIMUM_WK_BENEFIT_90 := PdoxRound(r.Annual_Net_A /52,2)
  end
  else
  begin
     MAXIMUM_WK_BENEFIT_90 := PdoxRound(r.Weekly_Net_A *0.90,2);
  end;
  //

  if (Year(r.Accident_Date) >= 2006) Then
  begin
    if (r.Annual_Gross <= (r.Minimum_wage + 0.00005)) Then
    begin
      if ( ( ( r.Total_Deds * 0.75 - r.Total_Deds_S )/52 ) < 0 ) then
        WKLY_TAX_SHELTER      := 0
      else
        WKLY_TAX_SHELTER      := PdoxRound( ( r.Total_Deds *0.75 - r.Total_Deds_S )/52,2);

      WEEKLY_NET_S          := r.WEEKLY_NET - WKLY_TAX_SHELTER;
    end
    else
    begin
      if ( ( ( r.Total_Deds *0.75 - r.Total_Deds_S )/52 ) < 0 ) then
        WKLY_TAX_SHELTER      := 0
      else
        WKLY_TAX_SHELTER      := PdoxRound((r.Total_Deds * 0.75 - r.Total_Deds_S )/52,2);

      WKLY_TAX_SHELTER      := PdoxRound(WKLY_TAX_SHELTER * 0.90, 2);
      WEEKLY_NET_S          := r.WEEKLY_NET - WKLY_TAX_SHELTER;
    end;

    WEEKLY_90             := PdoxRound(r.WEEKLY_NET,2);
    WEEKLY_80             := PdoxRound(r.WEEKLY_NET,2);  //*** Needs change
    WEEKLY_90_S           := PdoxRound((WEEKLY_NET_S),2);
    WEEKLY_80_S           := PdoxRound((WEEKLY_NET_S),2); //*** Needs change
  end
  else if (Year(r.Accident_Date) < 2006) Then
  begin
    WKLY_TAX_SHELTER      := PdoxRound((r.Total_Deds *0.75 - r.Total_Deds_S )/52,2);
    WEEKLY_NET_S          := r.WEEKLY_NET - WKLY_TAX_SHELTER;
    WEEKLY_90             := PdoxRound(r.WEEKLY_NET *0.90,2);
    WEEKLY_80             := PdoxRound(r.WEEKLY_NET *0.80,2);
    WEEKLY_90_S           := PdoxRound((WEEKLY_NET_S * 0.90),2);
    WEEKLY_80_S           := PdoxRound((WEEKLY_NET_S * 0.80),2);
  end;
  //
  // Leg review changes for Jan 1, 2006
  // The Collateral benefit no longer will affect the excess calculation
  //
  EXCESS_90             := PdoxRound(PdoxMax(0,WEEKLY_90
                              + r.Coll_Ben_Tax_Net
                              + r.Collateral_Ben_Non_Tax
                              - MAXIMUM_WK_BENEFIT_90),2);
  EXCESS_80             := PdoxRound(PdoxMax(0,WEEKLY_80
                              + r.Coll_Ben_Tax_Net
                              + r.Collateral_Ben_Non_Tax
                              - MAXIMUM_WK_BENEFIT_90),2);
  EXCESS_90_S           := PdoxRound(PdoxMax(0,WEEKLY_90_S
                              + r.Coll_Ben_Tax_Net
                              + r.Collateral_Ben_Non_Tax
                              - MAXIMUM_WK_BENEFIT_90),2);
  EXCESS_80_S           := PdoxRound(PdoxMax(0,WEEKLY_80_S
                              + r.Coll_Ben_Tax_Net
                              + r.Collateral_Ben_Non_Tax
                              - MAXIMUM_WK_BENEFIT_90),2);

  r.WEEKLY_90           := PdoxMax(0,Weekly_90   - EXCESS_90);
  r.WEEKLY_80           := PdoxMax(0,WEEKLY_80   - EXCESS_80);
  r.WEEKLY_90_S         := PdoxMax(0,WEEKLY_90_S - EXCESS_90_S);
  r.WEEKLY_80_S         := PdoxMax(0,WEEKLY_80_S - EXCESS_80_S);

  if Year(r.Accident_Date) >= 2006 then
  begin
    r.Weekly_90         := r.Weekly_90 - NetPostInjury;
    r.Weekly_90_S       := r.Weekly_90_S - NetPostInjury;
    r.Weekly_80         := r.Weekly_80 - NetPostInjury;
    r.Weekly_80_S       := r.Weekly_80_S - NetPostInjury;
  end;

  if (Year(r.Accident_Date) >= 2006) Then begin
    r.WEEKLY_NET        := PdoxRound(r.Annual_Net /52,2);
    r.Weekly_Net_A      := PdoxRound(r.Annual_Net_A /52,2);
  end;
  //
  //

  r.Annual_80           := r.WEEKLY_80    * 52;
  r.Annual_80_S         := r.WEEKLY_80_S  * 52;
  r.Annual_90           := r.WEEKLY_90    * 52;
  r.Annual_90_S         := r.WEEKLY_90_S  * 52;
end;

procedure TTaxJan06.Calculate_E(var r: recNCCLAIM; Var w: recConst);
begin
  //PrintDisplay('TTaxJan06.Calculate_E(var r: recNCCLAIM; var w: recConst)');
  nc_colben_tax     := r.COLLATERAL_BEN_TAX;
  nc_postinj_earn   := r.POST_INJURY_EARN;
  nc_cben_pinj_inc  := nc_colben_tax  + nc_postinj_earn;
  nc_cben_pinj_ann := nc_cben_pinj_inc * 52;

  if nc_cben_pinj_ann > 0 then
  begin
    Set_ncbcschd(nc_cben_pinj_ann,'E','annual bnfts + earnings',w);
    r.Coll_Ben_Tax_Net := (nc_bc_netinc / 52) *
                          (nc_colben_tax / nc_cben_pinj_inc);
    r.Post_Injury_Earn_Net  := (nc_bc_netinc / 52) *
                              (Nc_postinj_earn / nc_cben_pinj_inc);
  end
  else
  begin
    r.Coll_Ben_Tax_Net      := 0;
    r.Post_Injury_Earn_Net  := 0;
  end;
end;

procedure TTaxJan06.Set_nctaxcal(var r: recNCCLAIM; Var w: recConst);
begin
  //PrintDisplay('TTaxBase.Set_nctaxcal(var r: recNCCLAIM; var w: recConst)');
  nc_bc_deductions := Calc_nc_bc_deductions(r);
  w.Work_nc_bc_deductions := nc_bc_deductions;
  nc_bc_cpp2 := 0;
  r.CPP2_Prem := 0;
  r.CPP2_Prem_S := 0;
  nc_uic_exempt := r.EI_Exempt;
  nc_cpp_exempt := r.CPP_Exempt;
  nc_tax_exempt := r.Tax_Exempt;
  selfEmployed := r.Self_Employed;
  Calculate_A(r,w);
  Calculate_B(r,w);
  Calculate_C(r,w);
  Calculate_D(r,w);
  Calculate_E(r,w);
  Calculate_M(r,w);
  Calculate_S(r,w);
end;

procedure TTaxJan06.Set_ncbcschd(nc_bc_ann_sal: currency; nc_calc_type: char;
      nc_calc_descr: shortstring; var w: recConst);
begin
  //PrintDisplay('TTaxCalculator.Set_ncbcschd(nc_bc_ann_sal: currency;');
  nc_bc_cpp := Calculate_CPP(nc_bc_ann_sal);
  nc_bc_uic := Calculate_UIC(nc_bc_ann_sal);
  //nc_federalCanadaEmploymentCredit := Calculate_federalCanadaEmploymentCredit(nc_bc_ann_sal);
  nc_bc_ann_sal_net := Calculate_Net_Income(nc_bc_ann_sal);
  nc_bc_nrtc := Calculate_Fed_NRTC;
  nc_bc_mb_nrtc := Calculate_Man_NRTC;
  nc_bc_fedtax := Calculate_Fed_Tax(w);
  nc_bc_mb_tax := Calculate_Man_Tax(w);
  //
  // Changed Nov 2003 by D. Madill
  // Changed to eliminate rounding error on tax calculations.
  //
  nc_bc_cpp := PdoxRound(nc_bc_cpp, 2);
  nc_bc_uic := PDoxRound(nc_bc_uic, 2);
  //nc_federalCanadaEmploymentCredit := PDoxRound( nc_federalCanadaEmploymentCredit, 2 );
  nc_bc_fedtax := PDoxRound(nc_bc_fedtax, 2);
  nc_bc_mb_tax := PDoxRound(nc_bc_mb_tax, 2);
  nc_bc_ann_sal := PDoxRound(nc_bc_ann_sal, 2);
  nc_bc_ann_sal_net := PDoxRound(nc_bc_ann_sal_net, 2);
  nc_bc_nrtc := PDoxRound(nc_bc_nrtc, 2);
  nc_bc_mb_nrtc := PDoxRound(nc_bc_mb_nrtc, 2);
  nc_bc_bft := PDoxRound(nc_bc_bft, 2);
  nc_bc_fst := PDoxRound(nc_bc_fst, 2);
  nc_bc_mbt := PDoxRound(nc_bc_mbt, 2);
  //
  nc_bc_td := nc_bc_cpp + nc_bc_uic + nc_bc_fedtax + nc_bc_mb_tax;
  //nc_bc_td := nc_bc_cpp + nc_bc_uic + nc_bc_fedtax + nc_bc_mbt;
  nc_bc_netinc := nc_bc_ann_sal - nc_bc_td;
  Case nc_calc_type of
    'A': begin
           w.Work_nc_bc_cpp_a := nc_bc_cpp;
           w.Work_nc_bc_uic_a := nc_bc_uic;
           //w.Work_federalCanadaEmploymentCredit_a := nc_federalCanadaEmploymentCredit;
           w.Work_actualNoOfDependants := actualNoOfDependants;
           w.Work_nc_bc_ann_sal_net_a := nc_bc_ann_sal_net;
           w.Work_nc_bc_nrtc_a := nc_bc_nrtc;
           w.Work_nc_bc_mb_nrtc_a := nc_bc_mb_nrtc;
           w.Work_nc_bc_mb_tax_a := nc_bc_mb_tax;
           w.Work_nc_bc_td_a := nc_bc_td;
           w.Work_nc_bc_netinc_a := nc_bc_netinc;
           w.Work_nc_bc_bft_a := nc_bc_bft;
           w.Work_nc_bc_mbt_a := nc_bc_mbt;
           w.Work_mbFamilyTaxBenefitRate_a := nc_mbFamilyTaxBenefitAmt;
         end;
    'B': begin
           w.Work_nc_bc_cpp_b := nc_bc_cpp;
           w.Work_nc_bc_uic_b := nc_bc_uic;
           //w.Work_federalCanadaEmploymentCredit_b := nc_federalCanadaEmploymentCredit;
           w.Work_nc_bc_ann_sal_net_b := nc_bc_ann_sal_net;
           w.Work_nc_bc_nrtc_b := nc_bc_nrtc;
           w.Work_nc_bc_mb_nrtc_b := nc_bc_mb_nrtc;
           w.Work_nc_bc_mb_tax_b := nc_bc_mb_tax;
           w.Work_nc_bc_td_b := nc_bc_td;
           w.Work_nc_bc_netinc_b := nc_bc_netinc;
           w.Work_nc_bc_bft_b := nc_bc_bft;
           w.Work_nc_bc_mbt_b := nc_bc_mbt;
           w.Work_mbFamilyTaxBenefitRate_b := nc_mbFamilyTaxBenefitAmt;
         end;
    'C': begin
           w.Work_nc_bc_cpp_c := nc_bc_cpp;
           w.Work_nc_bc_uic_c := nc_bc_uic;
           //w.Work_federalCanadaEmploymentCredit_c := nc_federalCanadaEmploymentCredit;
           w.Work_nc_bc_ann_sal_net_c := nc_bc_ann_sal_net;
           w.Work_nc_bc_nrtc_c := nc_bc_nrtc;
           w.Work_nc_bc_mb_nrtc_c := nc_bc_mb_nrtc;
           w.Work_nc_bc_mb_tax_c := nc_bc_mb_tax;
           w.Work_nc_bc_td_c := nc_bc_td;
           w.Work_nc_bc_netinc_c := nc_bc_netinc;
           w.Work_nc_bc_bft_c := nc_bc_bft;
           w.Work_nc_bc_mbt_c := nc_bc_mbt;
           w.Work_mbFamilyTaxBenefitRate_c := nc_mbFamilyTaxBenefitAmt;
         end;
    'D': begin
           w.Work_nc_bc_cpp_d := nc_bc_cpp;
           w.Work_nc_bc_uic_d := nc_bc_uic;
           //w.Work_federalCanadaEmploymentCredit_d := nc_federalCanadaEmploymentCredit;
           w.Work_nc_bc_ann_sal_net_d := nc_bc_ann_sal_net;
           w.Work_nc_bc_nrtc_d := nc_bc_nrtc;
           w.Work_nc_bc_mb_nrtc_d := nc_bc_mb_nrtc;
           w.Work_nc_bc_mb_tax_d := nc_bc_mb_tax;
           w.Work_nc_bc_td_d := nc_bc_td;
           w.Work_nc_bc_netinc_d := nc_bc_netinc;
           w.Work_nc_bc_bft_d := nc_bc_bft;
           w.Work_nc_bc_mbt_d := nc_bc_mbt;
           w.Work_mbFamilyTaxBenefitRate_d := nc_mbFamilyTaxBenefitAmt;
         end;
    'E': begin
           w.Work_nc_bc_cpp_e := nc_bc_cpp;
           w.Work_nc_bc_uic_e := nc_bc_uic;
           //w.Work_federalCanadaEmploymentCredit_e := nc_federalCanadaEmploymentCredit;
           w.Work_nc_bc_ann_sal_net_e := nc_bc_ann_sal_net;
           w.Work_nc_bc_nrtc_e := nc_bc_nrtc;
           w.Work_nc_bc_mb_nrtc_e := nc_bc_mb_nrtc;
           w.Work_nc_bc_mb_tax_e := nc_bc_mb_tax;
           w.Work_nc_bc_td_e := nc_bc_td;
           w.Work_nc_bc_netinc_e := nc_bc_netinc;
           w.Work_nc_bc_bft_e := nc_bc_bft;
           w.Work_nc_bc_mbt_e := nc_bc_mbt;
           w.Work_mbFamilyTaxBenefitRate_e := nc_mbFamilyTaxBenefitAmt;
         end;
    'M': begin
           w.Work_nc_bc_cpp_m := nc_bc_cpp;
           w.Work_nc_bc_uic_m := nc_bc_uic;
           //w.Work_federalCanadaEmploymentCredit_m := nc_federalCanadaEmploymentCredit;
           w.Work_nc_bc_ann_sal_net_m := nc_bc_ann_sal_net;
           w.Work_nc_bc_nrtc_m := nc_bc_nrtc;
           w.Work_nc_bc_mb_nrtc_m := nc_bc_mb_nrtc;
           w.Work_nc_bc_mb_tax_m := nc_bc_mb_tax;
           w.Work_nc_bc_td_m := nc_bc_td;
           w.Work_nc_bc_netinc_m := nc_bc_netinc;
           w.Work_nc_bc_bft_m := nc_bc_bft;
           w.Work_nc_bc_mbt_m := nc_bc_mbt;
           w.Work_mbFamilyTaxBenefitRate_m := nc_mbFamilyTaxBenefitAmt;
         end;
    'S': begin
           w.Work_nc_bc_cpp_s := nc_bc_cpp;
           w.Work_nc_bc_uic_s := nc_bc_uic;
           //w.Work_federalCanadaEmploymentCredit_s := nc_federalCanadaEmploymentCredit;
           w.Work_nc_bc_ann_sal_net_s := nc_bc_ann_sal_net;
           w.Work_nc_bc_nrtc_s:= nc_bc_nrtc;
           w.Work_nc_bc_mb_nrtc_s := nc_bc_mb_nrtc;
           w.Work_nc_bc_mb_tax_s := nc_bc_mb_tax;
           w.Work_nc_bc_td_s:= nc_bc_td;
           w.Work_nc_bc_netinc_s := nc_bc_netinc;
           w.Work_nc_bc_bft_s := nc_bc_bft;
           w.Work_nc_bc_mbt_s := nc_bc_mbt;
           w.Work_mbFamilyTaxBenefitRate_s := nc_mbFamilyTaxBenefitAmt;
         end;
    end;
end;

procedure TTaxJan06.Set_nccanty(var r: recNCCLAIM);
var
  nc_actual_wcb_contrib: currency;
begin
  //PrintDisplay('TTaxBase.Set_nccanty(var r: recNCCLAIM)');
  nc_actual_wcb_contrib      := r.nc_104_Wk_WCB_p_Contrib;

  if Year(r.Accident_Date) >= 2006 then
  begin
    if ( ( Weekly_90 - Weekly_90_S ) < 0 ) then
      r.WKLY_WCB_ANTY_CON_AMT      := PdoxRound((nc_actual_wcb_contrib * r.WEEKLY_90)   / 100 ,2)
    else
      r.WKLY_WCB_ANTY_CON_AMT      := PdoxRound((nc_actual_wcb_contrib * r.WEEKLY_90_S)   / 100 ,2);

    r.WKLY_CLMT_ANTY_CON_AMT     := PdoxRound(( r.nc_104_WK_CLMT_p_CONTRIB * r.WEEKLY_90_S) / 100 ,2);
  end
  else
  begin
    r.WKLY_WCB_ANTY_CON_AMT    := PdoxRound((nc_actual_wcb_contrib * r.WEEKLY_80) / 100 ,2);
    r.WKLY_CLMT_ANTY_CON_AMT   := PdoxRound(( r.nc_104_WK_CLMT_p_CONTRIB * r.WEEKLY_80 ) / 100 ,2);
  end;

end;

end.
 