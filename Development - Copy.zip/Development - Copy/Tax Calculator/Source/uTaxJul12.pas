unit uTaxJul12;

interface
uses uTaxJan12, NCIniMod, Utils, uNCCLAIM;

type
  TTaxJul12 = class(TTaxJan12)
end;

implementation

{ TTaxJan12}

end.
