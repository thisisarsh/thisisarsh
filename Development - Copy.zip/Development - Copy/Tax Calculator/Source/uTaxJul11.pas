unit uTaxJul11;

interface
uses uTaxJan11, NCIniMod, Utils, uNCCLAIM;

type
  TTaxJul11 = class(TTaxJan11)
end;

implementation

{ TTaxJan11}

end.
