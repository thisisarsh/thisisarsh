unit uTaxJan20;

interface

uses uTaxJul19, NCIniMod, Utils, uNCCLAIM;

type
  TTaxJan20 = class(TTaxJul19)
end;

implementation

  { TTaxJan19}

end.



