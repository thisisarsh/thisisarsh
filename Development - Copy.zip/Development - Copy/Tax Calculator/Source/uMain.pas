unit uMain;

interface

uses
  Windows, Messages, SysUtils, Classes, Graphics, Controls, Forms, Dialogs,
  StdCtrls, NCRecdef;

type
  ECalcError = class(Exception);

  TForm1 = class(TForm)
    Button1: TButton;
    procedure Button1Click(Sender: TObject);
  private
    { Private declarations }
  public
    { Public declarations }
        //fClaim : recNCCLAIM;
  end;

var
  Form1: TForm1;

procedure ncptxcal( var r: recNCCLAIM ); stdcall; external 'TaxCalculator.DLL';
procedure Exempt_Calc( var r: recNCCLAIM ); stdcall; external 'TaxCalculator.DLL';
function Load_Tax_Table(tax_year, acc_year: integer; max_adjustment: currency): boolean;
  stdcall; external 'TaxCalculator.DLL';
procedure nccanty( var r: recNCCLAIM ); stdcall; external 'TaxCalculator.DLL';
procedure nctaxcal( var r: recNCCLAIM ); stdcall; external 'TaxCalculator.DLL';
procedure ncbcschd(nc_bc_ann_sal: currency; nc_calc_type: char; nc_calc_descr: shortstring );
   stdcall; external 'TaxCalculator.DLL';
procedure Calc_Ben( var r: recNCCLAIM ); stdcall; external 'TaxCalculator.DLL';
function Check_Self_Assurer(  var r: recNCCLAIM ): boolean; stdcall; external 'TaxCalculator.DLL';

implementation

{$R *.DFM}

{ TForm1 }


procedure TForm1.Button1Click(Sender: TObject);
var
  a,b:boolean;
  s:recNCCLAIM;
  d : currency;
begin
  b:= false;
  try
    NCRecdef.ClearNCCLAIM( s );
    b:=Load_Tax_Table(2001, 2001, 0);
    a:=b;
  except
    on E: ECalcError do
       Application.ShowException(E)
  end;
  //
end;

end.
 