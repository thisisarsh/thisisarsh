unit uTaxCalculator;

interface

uses
  uTaxBase;

type
  TTaxCalculator = class(TTaxBase);

implementation

{ TaxCalculator }

end.

