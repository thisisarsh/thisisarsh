unit uTaxJan25;

interface

uses uTaxJul24, NCIniMod, Utils, uNCCLAIM;

type
  TTaxJan25 = class(TTaxJul24)

  end;

implementation

end.
