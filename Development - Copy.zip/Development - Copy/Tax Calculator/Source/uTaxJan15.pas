unit uTaxJan15;

interface
uses uTaxJul14, NCIniMod, Utils, uNCCLAIM;

type
  TTaxJan15 = class(TTaxJul14)
end;

implementation

  { TTaxJan15}

end.

