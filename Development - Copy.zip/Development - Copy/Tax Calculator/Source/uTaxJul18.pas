unit uTaxJul18;

interface
uses uTaxJan18, NCIniMod, Utils, uNCCLAIM;

type
  TTaxJul18 = class(TTaxJan18)
end;

implementation

  { TTaxJan18}

end.
