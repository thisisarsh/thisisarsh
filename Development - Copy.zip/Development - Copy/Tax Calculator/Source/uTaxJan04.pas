unit uTaxJan04;

interface
uses uTaxJul02, NCIniMod, Utils, uNCCLAIM;

type
  TTaxJan04=class(TTaxJul02)
  private
  protected
    function Calculate_Man_NRTC:currency;override;
    function Calculate_MB_Exempt_Amount: currency; Dynamic;
    procedure Set_ncexmcal(var AccidentDate: TDateTime; var r: recNCCLAIM; Var w: recConst); Override;
    procedure SetPersonal(AccidentDate: TDateTime; year: integer; var w: recConst); Override;
    procedure SetMarital(AccidentDate: TDateTime; year: integer; status,
              spouse_working: shortstring; ClaimSpouseForTaxPurposes:string; var w: recConst); Override;
    procedure SetDependantAmounts(AccidentDate: TDateTime; year: integer; var w: recConst); Override;
    procedure SetExemptForDependants(AccidentDate: TDateTime; year: integer); Override;
  public
  published
end;

implementation

{ TTaxJan04 }

function TTaxJan04.Calculate_Man_NRTC: currency;
begin
  //PrintDisplay('TTaxJan01.Calculate_Man_NRTC: currency');
  result := PDoxRound((nc_bc_cpp + nc_bc_uic + nc_mb_tax_exmp) * nc_mb_tax_rate_i, 2);
end;

procedure TTaxJan04.Set_ncexmcal(var AccidentDate: TDateTime; var r: recNCCLAIM; Var w: recConst);
begin
  //PrintDisplay('TTaxBase.Set_ncexmcal(var AccidentDate: TDateTime; var r: recNCCLAIM; w: recConst)');
  NC_SPOUSE             := 0;
  NC_Prov_Spouse        := 0; // Added Midyear 2003
  NC_II_SPOUSE          := 0;
  NC_III_SPOUSE         := 0;
  NC_CHILDSPOUSE        := 0;
  NC_Prov_ChildSpouse   := 0; // Added Midyear 2003
  NC_II_CHILDSPOUSE     := 0;
  NC_III_CHILDSPOUSE    := 0;
  nc_1st_dep            := 0;
  nc_II_dep             := 0;
  NC_III_DEP            := 0;
  nc_3rd_dep            := 0;
  w.Work_NC_SPOUSE      := 0;
  w.Work_NC_Prov_Spouse := 0; // Added Midyear 2003
  w.Work_NC_II_SPOUSE   := 0;
  w.Work_NC_III_SPOUSE  := 0;
  w.Work_NC_CHILDSPOUSE := 0;
  w.Work_NC_Prov_ChildSpouse := 0; // Added Midyear 2003
  w.Work_NC_II_CHILDSPOUSE := 0;
  w.Work_NC_III_CHILDSPOUSE := 0;
  w.Work_nc_II_dep      := 0;
  w.Work_NC_III_DEP     := 0;
  nc_tax_year           := r.Tax_Year;
  w.Work_nc_tax_year    := nc_tax_year;
  nc_accident_year      := year( AccidentDate );
  if AccidentDate = 0 then
    nc_accident_year := r.Tax_Year;
  nc_no_of_dep          := r.No_of_Dependnts;
  w.Work_nc_no_of_dep   := nc_no_of_dep;
  nc_no_infirm          := r.No_Infirm;
  w.Work_nc_no_infirm   := nc_no_infirm;
  actualNoOfDependants  := r.No_of_Dependnts;
  w.Work_actualNoOfDependants := actualNoOfDependants;
  SetPersonal(AccidentDate, nc_tax_year,w);
  SetMarital(AccidentDate, nc_tax_year,r.MARITAL_STATUS,r.Spouse_Working, r.ClaimSpouseForTaxPurposes, w);
  SetExemptForDependants(AccidentDate, nc_tax_year);
  SetDependantAmounts(AccidentDate, nc_tax_year,w);
  NC_EXEMPT_AMOUNT := Calculate_Exempt_Amount;
  w.Work_NC_EXEMPT_AMOUNT := NC_EXEMPT_AMOUNT;
  NC_MB_EXEMPT_AMOUNT := Calculate_MB_Exempt_Amount; // Added Midyear 2003
  w.Work_NC_MB_EXEMPT_Amount := NC_MB_EXEMPT_AMOUNT; // Added Midyear 2003
  nc_ii_credit     := Calculate_Section_II;
  w.Work_nc_ii_credit := nc_ii_credit;
  r.II_CREDIT      := nc_ii_credit;
  nc_iii_credit    := Calculate_Section_III;
  w.Work_nc_iii_credit := nc_iii_credit;
  r.III_CREDIT     := nc_iii_credit;
  r.Tax_Exemption   := NC_EXEMPT_AMOUNT;
  nc_tax_exmp  := nc_exempt_amount;
  r.MB_Tax_Exemption := NC_MB_EXEMPT_AMOUNT; // Added Midyear 2003
  nc_mb_Tax_exmp := NC_MB_EXEMPT_AMOUNT; // Added Midyear 2003
  w.Work_nc_tax_exmp := nc_tax_exmp;
  w.Work_NC_MB_Tax_Exmp := nc_mb_tax_exmp; // Added Midyear 2003
  r.Tax_Code := SetTaxCode(AccidentDate, nc_tax_year);
end;

function TTaxJan04.Calculate_MB_Exempt_Amount: currency;
begin
  //PrintDisplay('TTaxBase.Calculate_Exempt_Amount: currency');
  result := Prov_personal
            + NC_Prov_SPOUSE
            + NC_Prov_CHILDSPOUSE
            + NC_Prov_1st_Dep
            + NC_Prov_3rd_Dep
            + Prov_Infirm;
end;

procedure TTaxJan04.SetPersonal(AccidentDate: TDateTime; year: integer; var w: recConst);
begin
  //PrintDisplay('TTaxCalculator.SetPersonal(year: integer; var w: recConst)');
  personal     := arrayNCEXMAMT[FindindexNCEXMAMT(AccidentDate, year)].Personal;
  w.Work_personal := personal;
  III_Personal := arrayNCEXMAMT[FindindexNCEXMAMT(AccidentDate, year)].III_Personal;
  w.Work_III_Personal := III_Personal;

  Prov_Personal     := arrayNCEXMAMT[FindindexNCEXMAMT(AccidentDate, year)].Prov_Personal;
  w.Work_Prov_personal := Prov_personal;
end;

procedure TTaxJan04.SetMarital(AccidentDate: TDateTime; year: integer; status,
          spouse_working: shortstring; ClaimSpouseForTaxPurposes:string; var w: recConst);
begin
  //PrintDisplay('TTaxBase.SetMarital(year: integer; status,');
  if ( status = 'MARRIED' ) OR ( status = 'COMMON-LAW' )
    OR ( status = 'M' ) OR ( status = 'C' ) then
  begin
    if ( spouse_working = 'N' ) And (ClaimSpouseForTaxPurposes = 'Y') Then
    begin
      NC_SPOUSE     := arrayNCEXMAMT[FindindexNCEXMAMT(AccidentDate, year)].Spouse;
      w.Work_NC_SPOUSE := NC_SPOUSE;
      NC_II_SPOUSE  := arrayNCEXMAMT[FindindexNCEXMAMT(AccidentDate, year)].II_Spouse;
      w.Work_NC_II_SPOUSE := NC_II_SPOUSE;
      NC_III_SPOUSE := arrayNCEXMAMT[FindindexNCEXMAMT(AccidentDate, year)].III_Spouse;
      w.Work_NC_III_SPOUSE := NC_III_SPOUSE;

      //
      // Aded Midyear 2003
      //
      NC_Prov_SPOUSE := arrayNCEXMAMT[FindindexNCEXMAMT(AccidentDate, year)].Prov_Spouse;
      w.Work_NC_Prov_SPOUSE := NC_Prov_SPOUSE;
    end;
  end
  ELSE
  begin
    IF(nc_no_of_dep > 0) Then
    begin
      NC_CHILDSPOUSE     := arrayNCEXMAMT[FindindexNCEXMAMT(AccidentDate, year)].ChildSpouse;
      w.Work_NC_CHILDSPOUSE := NC_CHILDSPOUSE;
      NC_II_CHILDSPOUSE  := arrayNCEXMAMT[FindindexNCEXMAMT(AccidentDate, year)].II_ChildSpouse;
      w.Work_NC_II_CHILDSPOUSE    := NC_II_CHILDSPOUSE;
      NC_III_CHILDSPOUSE := arrayNCEXMAMT[FindindexNCEXMAMT(AccidentDate, year)].III_ChildSpouse;
      w.Work_NC_III_CHILDSPOUSE := NC_III_CHILDSPOUSE;
      nc_no_of_dep   := nc_no_of_dep - 1;
      w.Work_nc_no_of_dep := nc_no_of_dep;

      //
      // Added midyear 2003
      //
      NC_Prov_CHILDSPOUSE := arrayNCEXMAMT[FindindexNCEXMAMT(AccidentDate, year)].Prov_ChildSpouse;
      w.Work_NC_Prov_CHILDSPOUSE := NC_Prov_CHILDSPOUSE;
    end
    ELSE
    begin
      IF(nc_no_infirm > 0) Then
      begin
        NC_CHILDSPOUSE     := arrayNCEXMAMT[FindindexNCEXMAMT(AccidentDate, year)].ChildSpouse;
        w.Work_NC_CHILDSPOUSE := NC_CHILDSPOUSE;
        NC_II_CHILDSPOUSE  := arrayNCEXMAMT[FindindexNCEXMAMT(AccidentDate, year)].II_ChildSpouse;
        w.Work_NC_II_CHILDSPOUSE := NC_II_CHILDSPOUSE;
        NC_III_CHILDSPOUSE := arrayNCEXMAMT[FindindexNCEXMAMT(AccidentDate, year)].III_ChildSpouse;
        w.Work_NC_III_CHILDSPOUSE := NC_III_CHILDSPOUSE;
        nc_no_infirm := nc_no_infirm - 1;
        w.Work_nc_no_infirm := nc_no_infirm;
      //
      // Added midyear 2003
      //
      NC_Prov_CHILDSPOUSE := arrayNCEXMAMT[FindindexNCEXMAMT(AccidentDate, year)].Prov_ChildSpouse;
      w.Work_NC_Prov_CHILDSPOUSE := NC_Prov_CHILDSPOUSE;
      end;
    end;
  end;
end;

procedure TTaxJan04.SetDependantAmounts(AccidentDate: TDateTime; year: integer; var w: recConst);
begin
  //PrintDisplay('TTaxBase.SetDependantAmounts(year: integer; var w: recConst)');
  nc_II_dep  := nc_no_of_dep * arrayNCEXMAMT[FindindexNCEXMAMT(AccidentDate, year)].II_Dep;
  w.Work_nc_II_dep := nc_II_dep;
  NC_III_DEP := nc_no_of_dep * arrayNCEXMAMT[FindindexNCEXMAMT(AccidentDate, year)].III_Dep;
  w.Work_NC_III_DEP := NC_III_DEP;

  federalChildTaxCredit := w.Work_actualNoOfDependants * arrayNCEXMAMT[ FindindexNCEXMAMT( AccidentDate, year ) ].federalChildTaxCredit;
  w.Work_federalChildTaxCredit := federalChildTaxCredit;

  infirm        := nc_no_infirm * arrayNCEXMAMT[FindindexNCEXMAMT(AccidentDate, year)].Infirm_Dep;
  w.Work_infirm := infirm;
  nc_II_infirm  := nc_no_infirm * arrayNCEXMAMT[FindindexNCEXMAMT(AccidentDate, year)].II_Infirm_Dep;
  w.Work_nc_II_infirm := nc_II_infirm;
  NC_III_INFIRM := nc_no_infirm * arrayNCEXMAMT[FindindexNCEXMAMT(AccidentDate, year)].III_Infirm_Dep;
  w.Work_NC_III_INFIRM := NC_III_INFIRM;
  //
  // Added midyear 2003
  //
  Prov_Infirm := nc_no_infirm * arrayNCEXMAMT[FindindexNCEXMAMT(AccidentDate, year)].Prov_Infirm_Dep;
  w.Work_Prov_infirm := Prov_Infirm;
end;

procedure TTaxJan04.SetExemptForDependants(AccidentDate: TDateTime; year: integer);
begin
  //PrintDisplay('TTaxBase.SetExemptForDependants(year: integer)');
  if ( nc_no_of_dep <= 2 ) then
  begin
    nc_1st_dep := nc_no_of_dep * arrayNCEXMAMT[FindindexNCEXMAMT(AccidentDate, year)].Dep_1st;
    nc_base_dep := nc_no_of_dep;
    nc_add_dep  := 0;
  end
  ELSE
  begin
    nc_1st_dep := 2 * arrayNCEXMAMT[FindindexNCEXMAMT(AccidentDate, year)].Dep_1st;
    nc_3rd_dep := (nc_no_of_dep - 2) * arrayNCEXMAMT[FindindexNCEXMAMT(accidentDate, year)].Dep_3rd;
    nc_base_dep := 2;
    nc_add_dep  := nc_no_of_dep - 2;
  end;
end;


end.
 