unit uTaxCalc;

interface
uses uTaxCalculator, uTax2000, uTaxJan01, uTaxJan02, uTaxJul04,
    Forms, SysUtils, uNCCLAIM, NCIniMod, Dialogs, uTaxBase, Math;

    procedure nccanty(var r: recNCCLAIM);
    function findFirmName(var firmNo: shortstring): string;
    procedure NCBenCal(var r: recNCCLAIM; Var w: recConst);
    function isSelfAssurer( var firmNo:shortstring): boolean;
    function CheckDate(var r: recNCCLAIM):boolean;
    function getCalculator(Year, Month: integer): TTaxBase;


Const
     cnst_Max_Tax_Year           = 2027;
     cnst_Max_Tax_Month          = 06;     //Never change this number

var
  TaxCalc : TTaxBase;

implementation

uses utils, uTaxJul02, uTaxJan04, uTaxJul05, uTaxJan06,
    uTaxJul06, uTaxJan07, uTaxJul07, uTaxJan08, uTaxJul08, uTaxJan09,
    uTaxJul09, uTaxJan10, uTaxJul10, uTaxJan11, uTaxJul11, uTaxJan12,
    uTaxJul12, uTaxJan13, uTaxJul13, uTaxJan14, uTaxJul14, uTaxJan15,
    uTaxJul15, uTaxJan16, uTaxJul16, uTaxJan17, uTaxJul17, uTaxJan18,
    uTaxJul18, uTaxJan19, uTaxJul19, uTaxJan20, uTaxJul20, uTaxJan21,
    uTaxJul21, uTaxJan22, uTaxJul22, uTaxJan23, uTaxJul23, uTaxJan24,
    uTaxJul24, uTaxJan25, uTaxJul25, uTaxJan26, uTaxJul26;

function findFirmName( var firmNo: shortstring):string;
begin
   try
      TaxCalc := getCalculator(1999, 1);
      result := TaxCalc.uTax_Find_Firm_Name(firmNo);
      TaxCalc := nil;
   except
      on e:Exception do
         begin
         raise;
         end;
   end;
end;

function isSelfAssurer( var firmNo: shortstring): boolean;
begin
   try
      TaxCalc := getCalculator(1999, 1);
      result := TaxCalc.uTax_isSelfAssurer(firmNo);
      taxCalc := nil;
   except
      on e:Exception do
         begin
         raise;
         end;
   end;
end;

//
// Modified March 5, 2003 by D. Madill
//
// Modified to return and error code if the tax calculator does not complete
//
procedure NCBenCal( var r: recNCCLAIM; Var w: recConst);
begin
//
// First Set the return code to True -> Assume success
//
  try
     r.ReturnCode := True;
     if CheckDate(r) then
        begin
        if TaxCalc <> nil then
           TaxCalc.uTax_ncbencal(r,w);
           TaxCalc := nil;
        end;
  except
     on Exception do
        Begin
        r.ReturnCode := False;
        TaxCalc := nil;
        if uNCClaim.msgReturn_Message <> '' Then
           Begin
           r.ReturnMessage := uNCClaim.msgReturn_Message;
           End
        else if r.ReturnMessage = '' Then
            Begin
            r.ReturnMessage := '*Unknown error in Benefit Calculator.';
            End;
        End;
  end;

end;

procedure nccanty( var r: recNCCLAIM);
begin
//
// First Set the return code to True -> Assume success
//
  try
     r.ReturnCode := True;
     if CheckDate(r) then
        begin
        if TaxCalc <> nil then
           TaxCalc.uTax_nccanty(r);
        TaxCalc := nil;
        end;
  except
     on Exception do
        Begin
        r.ReturnCode := False;
        if uNCClaim.msgReturn_Message <> '' Then
           Begin
           r.ReturnMessage := uNCClaim.msgReturn_Message;
           End
        else
            Begin
            r.ReturnMessage := '*Unknown error in Benefit Calculator.';
            End;
        End;
  end;
end;
//
// Modified March 5, 2003 by D. Madill
//
// Modified to set a warning message if the date is in excess of the max date.
// Also modified to allow for error handling within the NCBenCalc routine
//
function CheckDate( var r: recNCCLAIM ):boolean;
var
   WorkDate: TDateTime;
   Year, Month, Day, Acc_Year, Acc_Month, Acc_Day: Word;
begin
  //result := false;
  DecodeDate(r.Accident_Date, Acc_Year, Acc_Month, Acc_Day);
  if ((r.Indexation_Year > 0) AND (r.Tax_Year <> Acc_Year)) Then
    Month := Max(((Acc_Month+1) Mod 13),1)
  else
    Month := Acc_Month;
  if (r.Tax_Year <> 0) Then
  Begin
    WorkDate := Max(r.RecurrenceDate, EncodeDate(Min(Max(r.Indexation_Year,Acc_Year), r.Tax_Year), Month, 1));
    DecodeDate(WorkDate, Year, Month, Day);
    TaxCalc := getCalculator(r.tax_Year, Month);
    result := True;
  end
  else
  Begin
    r.ReturnMessage := '*Please enter a valid Tax Year.';
    Result := False;
    exit;
  End;

  // Check to see if we are greater than the max tax year. Use the tax calculator date
  if ((r.tax_Year = cnst_Max_Tax_Year) And (Month > cnst_Max_Tax_Month)) OR
      (r.tax_Year > cnst_Max_Tax_Year)                                    Then
  Begin
    r.ReturnMessage := '*Future Tax Calculator Date not allowed.';
  End;
end;


// Modified to default to latest Tax Calulator if the date is in excess of the
// latest calculator available.
//
Function getCalculator(Year, Month: integer): TTaxBase;
begin
  if Year < 2000 then
  begin
    if TaxCalc = nil then
      TaxCalc := TTaxCalculator.Create(application);
  end
  else if Year = 2000 then
  begin
    if TaxCalc = nil then
      TaxCalc := TTax2000.Create(application);
  end
  else if Year = 2001 then
  begin
    if TaxCalc = nil then
        TaxCalc := TTaxJan01.Create(application);
  end
  else if (Year = 2002) and (month <= 6) then
  begin
    if TaxCalc = nil then
        TaxCalc := TTaxJan02.Create(application);
  end
  else if ((Year = 2002) and (Month > 6))  Or
    ((Year = 2003) and (Month <= 6)) then
  begin
    if TaxCalc = nil then
        TaxCalc := TTaxJul02.Create(application);
  end
  else if ((Year = 2003) and (Month > 6))  Or
          ((Year = 2004) and (Month <= 6)) then
  begin
    if TaxCalc = nil then
        TaxCalc := TTaxJan04.Create(application);
  end
  else if ((Year = 2004) And (Month > 6))  OR
          ((Year = 2005) And (Month <= 6)) Then
  Begin
    TaxCalc := TTaxJul04.Create(application);
  End
  else if ((Year = 2005) And (Month > 6))   AND
          ((Year = 2005) And (Month <= 12)) Then
  Begin
    TaxCalc := TTaxJul05.Create(application);
  End
  else if ((Year = 2006) And (Month >= 1))  AND
          ((Year = 2006) And (Month <= 6))  Then
  Begin
    TaxCalc := TTaxJan06.Create(application);
  End
  else if ((Year = 2006) And (Month > 6))  AND
          ((Year = 2006) And (Month <= 12))  Then
  Begin
    TaxCalc := TTaxJul06.Create(application);
    End
  else if ((Year = 2007) And (Month >= 1))  AND
          ((Year = 2007) And (Month <= 6))  Then
  Begin
    TaxCalc := TTaxJan07.Create(application);
  End
  else if ((Year = 2007) And (Month > 6))  AND
          ((Year = 2007) And (Month <= 12))  Then
  Begin
    TaxCalc := TTaxJul07.Create(application);
  End
  else if ((Year = 2008) And (Month >= 1))  AND
          ((Year = 2008) And (Month <= 6))  Then
  Begin
    TaxCalc := TTaxJan08.Create(application);
  End
  else if ((Year = 2008) And (Month > 6))  AND
          ((Year = 2008) And (Month <= 12))  Then
  Begin
    TaxCalc := TTaxJul08.Create(application);
  End
  else if ((Year = 2009) And (Month >= 1))  AND
          ((Year = 2009) And (Month <= 6))  Then
  Begin
    TaxCalc := TTaxJan09.Create(application);
  End
  else if ((Year = 2009) And (Month > 6))  AND
          ((Year = 2009) And (Month <= 12))  Then
  Begin
    TaxCalc := TTaxJul09.Create(application);
  End
  else if ((Year = 2010) And (Month >= 1))  AND
          ((Year = 2010) And (Month <= 6))  Then
  Begin
    TaxCalc := TTaxJan10.Create(application);
  End
  else if ((Year = 2010) And (Month > 6))  AND
          ((Year = 2010) And (Month <= 12))  Then
  Begin
    TaxCalc := TTaxJul10.Create(application);
  End
  else if ((Year = 2011) And (Month >= 1))  AND
          ((Year = 2011) And (Month <= 6))  Then
  Begin
    TaxCalc := TTaxJan11.Create(application);
  End
  else if ((Year = 2011) And (Month > 6))  AND
          ((Year = 2011) And (Month <= 12))  Then
  Begin
    TaxCalc := TTaxJul11.Create(application);
  End
  else if ((Year = 2012) And (Month >= 1))  AND
          ((Year = 2012) And (Month <= 6))  Then
  Begin
    TaxCalc := TTaxJan12.Create(application);
  End
  else if ((Year = 2012) And (Month > 6))  AND
          ((Year = 2012) And (Month <= 12))  Then
  Begin
    TaxCalc := TTaxJul12.Create(application);
  End
  else if ((Year = 2013) And (Month >= 1))  AND
          ((Year = 2013) And (Month <= 6))  Then
  Begin
    TaxCalc := TTaxJan13.Create(application);
  End
  else if ((Year = 2013) And (Month > 6))  AND
          ((Year = 2013) And (Month <= 12))  Then
  Begin
    TaxCalc := TTaxJul13.Create(application);
  End
  else if ((Year = 2014) And (Month >= 1))  AND
          ((Year = 2014) And (Month <= 6))  Then
  Begin
    TaxCalc := TTaxJan14.Create(application);
  End
  else if ((Year = 2014) And (Month > 6))  AND
          ((Year = 2014) And (Month <= 12))  Then
  Begin
    TaxCalc := TTaxJul14.Create(application);
  End
  else if ((Year = 2015) And (Month >= 1))  AND
          ((Year = 2015) And (Month <= 6))  Then
  Begin
    TaxCalc := TTaxJan15.Create(application);
  End
  else if ((Year = 2015) And (Month > 6))  AND
          ((Year = 2015) And (Month <= 12))  Then
     begin
     TaxCalc := TTaxJul15.Create(application);
     end
  else if ((Year = 2016) And (Month >= 1))  AND
          ((Year = 2016) And (Month <= 6))  Then
     begin
     TaxCalc := TTaxJan16.Create(application);
     end
  else if ((Year = 2016) And (Month > 6))  AND
          ((Year = 2016) And (Month <= 12))  Then
     begin
     TaxCalc := TTaxJul16.Create(application);
     end
  else if ((Year = 2017) And (Month >= 1))  AND
          ((Year = 2017) And (Month <= 6))  Then
     begin
     TaxCalc := TTaxJan17.Create(application);
     end
  else if ((Year = 2017) And (Month > 6))  AND
          ((Year = 2017) And (Month <= 12))  Then
     begin
     TaxCalc := TTaxJul17.Create(application);
     end
  else if ((Year = 2018) And (Month >= 1))  AND
          ((Year = 2018) And (Month <= 6))  Then
     begin
     TaxCalc := TTaxJan18.Create(application);
     end
  else if ((Year = 2018) And (Month > 6))  AND
          ((Year = 2018) And (Month <= 12))  Then
     begin
     TaxCalc := TTaxJul18.Create(application);
     end
  else if ((Year = 2019) And (Month >= 1))  AND
          ((Year = 2019) And (Month <= 6))  Then
     begin
     TaxCalc := TTaxJan19.Create(application);
     end
  else if ((Year = 2019) And (Month > 6))  AND
          ((Year = 2019) And (Month <= 12))  Then
     begin
     TaxCalc := TTaxJul19.Create(application);
     end
  else if ((Year = 2020) And (Month >= 1))  AND
          ((Year = 2020) And (Month <= 6))  Then
     begin
     TaxCalc := TTaxJan20.Create(application);
     end
  else if ((Year = 2020) And (Month > 6))  AND
          ((Year = 2020) And (Month <= 12))  Then
     begin
     TaxCalc := TTaxJul20.Create(application);
     end
  else if ((Year = 2021) And (Month >= 1))  AND
          ((Year = 2021) And (Month <= 6))  Then
     begin
     TaxCalc := TTaxJan21.Create(application);
     end
  else if ((Year = 2021) And (Month > 6))  AND
          ((Year = 2021) And (Month <= 12))  Then
     begin
     TaxCalc := TTaxJul21.Create(application);
     end
  else if ((Year = 2022) And (Month >= 1))  AND
          ((Year = 2022) And (Month <= 6))  Then
     begin
     TaxCalc := TTaxJan22.Create(application);
     end
  else if ((Year = 2022) And (Month > 6))  AND
          ((Year = 2022) And (Month <= 12))  Then
     begin
     TaxCalc := TTaxJul22.Create(application);
     end
  else if ((Year = 2023) And (Month >= 1))  AND
          ((Year = 2023) And (Month <= 6))  Then
     begin
     TaxCalc := TTaxJan23.Create(application);
     end
  else if ((Year = 2023) And (Month > 6))  AND
          ((Year = 2023) And (Month <= 12))  Then
     begin
     TaxCalc := TTaxJul23.Create(application);
     end
  else if ((Year = 2024) And (Month >= 1))  AND
          ((Year = 2024) And (Month <= 6))  Then
     begin
     TaxCalc := TTaxJan24.Create(application);
     end
  else if ((Year = 2024) And (Month > 6))  AND
          ((Year = 2024) And (Month <= 12))  Then
     begin
     TaxCalc := TTaxJul24.Create(application);
     end
  else if ((Year = 2025) And (Month >= 1))  AND
          ((Year = 2025) And (Month <= 6))  Then
     begin
     TaxCalc := TTaxJan25.Create(application);
     end
  else if ((Year = 2025) And (Month > 6))  AND
          ((Year = 2025) And (Month <= 12))  Then
     begin
     TaxCalc := TTaxJul25.Create(application);
     end
  else if ((Year = 2026) And (Month >= 1))  AND
          ((Year = 2026) And (Month <= 6))  Then
     begin
     TaxCalc := TTaxJan26.Create(application);
     end
  else if ((Year = 2026) And (Month > 6))  AND
          ((Year = 2026) And (Month <= 12))  Then
     begin
     TaxCalc := TTaxJul26.Create(application);
     end;

  result := TaxCalc;
end;

end.
