unit uTaxJul17;

interface
uses uTaxJan17, NCIniMod, Utils, uNCCLAIM;

type
  TTaxJul17 = class(TTaxJan17)
end;

implementation

  { TTaxJul17}

end.
