unit uTaxJul16;

interface
uses uTaxJan16, NCIniMod, Utils, uNCCLAIM, SysUtils, Math;

type
  TTaxJul16 = class(TTaxJan16)
  protected
  nc_fed_tax_amt_iiii           :currency;
  nc_fed_tax_rate_iiiii         :currency;
  nc_fed_inclvl_iiii            :currency;
  function Calculate_Fed_Tax_2:currency;Override;
  function Set_ncldtxtb(r: recNCCLAIM; AccidentDate: TDateTime; nc_tax_year, nc_acc_year: integer;
    nc_max_adjustment: currency): boolean;Override;
end;

implementation

function TTaxJul16.Calculate_Fed_Tax_2: currency;
var
  const1, const2, const3, const4: Currency;
begin
  //PrintDisplay('TTaxCalculator.Calculate_Fed_Tax_2: currency');
  const1 := nc_fed_inclvl_i * (nc_fed_tax_rate_ii - nc_fed_tax_rate_i);
  const2 := (nc_fed_inclvl_ii * (nc_fed_tax_rate_iii - nc_fed_tax_rate_ii)) + const1;
  const3 := (nc_fed_inclvl_iii * (nc_fed_tax_rate_iiii - nc_fed_tax_rate_iii)) + const2;
  const4 := (nc_fed_inclvl_iiii * (nc_fed_tax_rate_iiiii - nc_fed_tax_rate_iiii)) + const3;

  const1 := Round(const1);
  const2 := Round(const2);
  const3 := Round(const3);
  const4 := Round(const4);
  if nc_tax_exempt = 'Y' then
    begin
    result := 0;
    end
  else
    begin
    if nc_bc_ann_sal_net > nc_fed_inclvl_iiii then
      result := (nc_bc_ann_sal_net *  nc_fed_tax_rate_iiiii) - const4
    else if nc_bc_ann_sal_net > nc_fed_inclvl_iii then
      result := (nc_bc_ann_sal_net *  nc_fed_tax_rate_iiii) - const3
    else if nc_bc_ann_sal_net > nc_fed_inclvl_ii then
      result := (nc_bc_ann_sal_net *  nc_fed_tax_rate_iii) - const2
    else if nc_bc_ann_sal_net > nc_fed_inclvl_i then
      result := (nc_bc_ann_sal_net *  nc_fed_tax_rate_ii) - const1
    else
      result := (nc_bc_ann_sal_net * nc_fed_tax_rate_i);

    result := PDoxRound(result, 2);
    result := result - nc_bc_nrtc;
    if result < 0 then
      result := 0;
  end;
end;


function TTaxJul16.Set_ncldtxtb(r: recNCCLAIM; AccidentDate: TDateTime; nc_tax_year, nc_acc_year: integer;
  nc_max_adjustment: currency): boolean;
var
   Test_Accident_Date:TDateTime;
   Acc_Year, Acc_Month, Acc_Day, Test_Tax_Year:Word;
begin
  //PrintDisplay('TTaxCalculator.Set_ncldtxtb(nc_tax_year, nc_acc_year: integer;');
  result:=false;

  Test_Tax_Year := nc_tax_year;

  //
  // LRC Bill 18
  //
  DecodeDate(r.Accident_Date, Acc_Year, Acc_Month, Acc_Day);
  Test_Tax_Year := Max(Year(r.Accident_Date), r.Indexation_Year);
  if nc_max_adjustment <> 0 then
     begin
     nc_max_ann_sal := nc_max_adjustment;
     end
  else
     begin
     if (Acc_Year >= 2006) AND (Acc_Year <= 2021)  then
        begin
        nc_max_ann_sal := r.WKLY_SAL_A * 52;
        end
     else
        begin
        nc_max_ann_sal := getAnnualMaximum(r.Accident_Date, nc_acc_year, Acc_Month, nc_tax_year);
        end;
     end;

  with arrayNCTAXRAT[FindindexNCTAXRAT(AccidentDate, nc_tax_year)] do
    begin
    nc_uic_prate               := UIC_premium_rate;
    nc_max_ins_earn            := UIC_max_insured_earnings;
    nc_uic_max_ann_prem        := UIC_max_annual_premium;
    nc_cpp_basic_exmp          := CPP_basic_exemption;
    nc_cpp_crate               := CPP_contrib_rate;
    nc_cpp_max_ann_contrib     := CPP_max_annual_contrib;
    nc_fed_inclvl_i            := FED_income_level_i;
    nc_fed_inclvl_ii           := FED_income_level_ii;
    nc_fed_inclvl_iii          := FED_income_level_iii;
    nc_fed_inclvl_iiii         := FED_income_level_iiii;
    nc_fed_tax_amt_i           := FED_tax_amt_i;
    nc_fed_tax_amt_ii          := FED_tax_amt_ii;
    nc_fed_tax_amt_iii         := FED_tax_amt_iii;
    nc_fed_tax_amt_iiii         := FED_tax_amt_iiii;
    nc_fed_tax_rate_i          := FED_tax_rate_i;
    nc_fed_tax_rate_ii         := FED_tax_rate_ii;
    nc_fed_tax_rate_iii        := FED_tax_rate_iii;
    nc_fed_tax_rate_iiii       := FED_tax_rate_iiii;
    nc_fed_tax_rate_iiiii      := FED_tax_rate_iiiii;
    nc_fed_surtax_rate_i       := FED_surtax_rate_i;
    nc_fed_surtax_rate_ii      := FED_surtax_rate_ii;
    nc_fed_surtax_lim_ii       := FED_surtax_limit_ii;
    nc_mb_tax_rate             := MB_tax_rate;
    nc_mb_tax_rate_i           := MB_tax_rate_i;
    nc_mb_tax_rate_ii          := MB_tax_rate_ii;
    nc_mb_tax_rate_iii         := MB_tax_rate_iii;
    nc_mb_inclvl_i             := MB_income_level_i;
    nc_mb_inclvl_ii            := MB_income_level_ii;
    nc_mb_tax_amt_i            := MB_tax_amt_i;
    nc_mb_tax_amt_ii           := MB_tax_amt_ii;
    nc_mb_net_rate             := MB_net_tax_rate;
    nc_mbFamilyTaxBenefitRate  := mbFamilyTaxBenefitRate;
    //nc_maxfederalCanadaEmploymentCredit := federalCanadaEmploymentCredit;
    end;

  if (Acc_Year < 2006) or (Acc_Year > 2021) then
     begin
     if (FindindexNCANNMAX(r.Accident_Date, nc_acc_year, nc_tax_year) > -1)   or
        (FindindexNCTAXRAT(AccidentDate, nc_tax_year) > -1) then
        result := true;
     end
  else
     begin
     result := true;
     end;

end;

end.
