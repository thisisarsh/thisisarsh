unit uTaxJul07;

interface
uses uTaxJan07, NCIniMod, Utils, uNCCLAIM;

type
  TTaxJul07 = class(TTaxJan07)
end;

implementation

{ TTaxJul07}

end.

