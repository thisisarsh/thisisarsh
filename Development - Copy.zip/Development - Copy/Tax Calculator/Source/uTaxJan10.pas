unit uTaxJan10;

interface
uses uTaxJul09, NCIniMod, Utils, uNCCLAIM;

type
  TTaxJan10 = class(TTaxJul09)
end;

implementation

{ TTaxJan10}

end.
