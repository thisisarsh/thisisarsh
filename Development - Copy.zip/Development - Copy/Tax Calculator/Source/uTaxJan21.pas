unit uTaxJan21;

interface

uses uTaxJul20, NCIniMod, Utils, uNCCLAIM;

type
  TTaxJan21 = class(TTaxJul20)
end;

implementation

  { TTaxJan19}

end.
