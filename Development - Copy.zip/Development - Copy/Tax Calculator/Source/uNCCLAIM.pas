unit uNCCLAIM;

interface
type
  {$include Working.INC}
  {$include NCCLAIM.inc}


var
  msgReturn_Message:ShortString;

implementation

end.
