(*****************************************************************)
(*  Wageloss System                                              *)
(*                                                               *)
(*  Record Definations and record utility functions              *)
(*                                                               *)
(*                                                               *)
(*  Author: Brad Trupp  / Capella Systems Group, Inc.            *)
(*  Date:   August 1997                                          *)
(*                                                               *)
(*  October 1998 - add shelter rebate fields                     *)
(*  October 2000 - add fields to accomodate policy changes       *)
(*                                                               *)
(*****************************************************************)

unit NCRecdef;

interface
uses
  SysUtils;
type

  {$include NCANNMAX.inc}
  {$include NCCHQMSG.inc}
  {$include NCCODEXP.inc}
  {$include NCCODTAX.inc}
  {$include NCEXMAMT.inc}
  {$include NCINDEXF.inc}
  {$include NCTAXRAT.inc}
  {$include NC_CFIO.inc}

  {$include NCCLAIM.inc}
  {$include NCFORM.inc}
  {$include NCLOGIN.inc}
  {$include WLREBDTL.inc}

  procedure ClearNCCLAIM( var r: recNCCLAIM );
  procedure CopyNCCLAIM( var a, b: recNCCLAIM );
  procedure ClearWLREBDTL( var r: recWLREBDTL );

implementation

(******************************************************************************)
(*                                                                            *)
(*  Clear all fields for a recNCClaim record.                                 *)
(*                                                                            *)
(******************************************************************************)
procedure ClearNCCLAIM( var r: recNCCLAIM );
begin
  with r do
    begin
      isClaimCurrent:=false;
      Claim_No := '';
      Claim_Suffix := '';
      Prime_Firm_No := '';
      Firm_Name := '';
      SIN := '';
      Clmnts_Surname := '';
      Clmnts_1st_Name := '';
      Clmnts_Add_No_1 := '';
      Clmnts_Add_No_2 := '';
      Clmnts_Add_No_3 := '';
      Clmnts_Post_Code := '';
      Clmnts_Home_Phone := '';
      Clmnts_Work_Phone := '';
      Alt_Mail_Add_code := '';
      Birth_Date := 0;
      Tax_Year := 0;
      Tax_Code := '';
      Marital_Status := '';
      Spouse_Working := '';
      Days_Worked_per_Week := 0;
      Tot_Comp_Pd_To_Date := 0;
      No_Days_Of_Comp_Bnfts := 0;
      No_Weeks_of_Comp_Bnfts := 0;
      Comp_Wks_Pd_to_63 := 0;
      Comp_Wks_Pd_to_63_Flag := '';
      Days_Bnft_Pd_On_Last_Comp := 0;
      Curr_Case_Type := '';
      Accident_Date := 0;
      Last_Review_Date := 0;
      Calc_Date := 0;
      Calc_Username := '';
      No_Of_Dependnts := 0;
      No_Infirm := 0;
      Tax_Exemption := 0;
      II_Credit := 0;
      III_Credit := 0;
      Collateral_Ben_Tax := 0;
      Collateral_Ben_Non_Tax := 0;
      Post_Injury_Earn := 0;
      Deemed_Earnings := '';
      Coll_Ben_Tax_Net := 0;
      Coll_Ben_Non_Tax_Net := 0;
      Post_Injury_Earn_Net := 0;
      Wkly_Sal := 0;
      Wkly_Sal_A := 0;
      Weekly_Net := 0;
      Weekly_Net_S := 0;
      Weekly_Net_A := 0;
      Weekly_90 := 0;
      Weekly_90_S := 0;
      Weekly_80 := 0;
      Weekly_80_S := 0;
      Annual_Gross := 0;
      Annual_Gross_A := 0;
      Annual_Net := 0;
      Annual_Net_A := 0;
      Annual_90 := 0;
      Annual_90_S := 0;
      Annual_80 := 0;
      Annual_80_S := 0;
      Inc_Tax_Fed := 0;
      Inc_Tax_Fed_S := 0;
      Inc_Tax_Man := 0;
      Inc_Tax_Man_S := 0;
      CPP_Prem := 0;
      CPP_Prem_S := 0;
      EI_Exempt := '';
      EI_Prem := 0;
      EI_Prem_S := 0;
      Total_Deds := 0;
      Total_Deds_S := 0;
      Total_Deds_A := 0;
      Formula_Code := '';
      Hash_Total := 0;
      Weekly_Benefit := 0;
      CFIO := '';
      Payee_Code := '';
      Payment_Type_Code := '';
      Date_Pd_From_Cheq := 0;
      Date_Pd_To_Cheq := 0;
      First_Pay_Date := 0;
      Num_of_Payments := 0;
      Claim_Exp_Code := '';
      Amount_Paid := 0;
      Loss_Earn_Date := 0;
      Pay_Frequency := '';
      No_Days_Paid := 0;
      No_Weeks_Paid := 0;
      Message_Code_A := '';
      Message_Code_B := '';
      Message_Code_C := '';
      Benefit_Type_Code := '';
      Benefit_Type := '';
      Original_Wkly_Sal := 0;
      Wkly_Sal_Index_Flag := '';
      Pre_1992_Wkly_Sal := 0;
      Tot_WCB_Anty_Elig_Earn := 0;
      Tot_WCB_Anty_Contib_Amt := 0;
      Tot_Clmt_Anty_Elig_Earn := 0;
      Tot_Clmt_Anty_Contrib_Amt := 0;
      nc_104_Wk_Clmt_Reply_Date := 0;
      nc_104_Wk_Effective_Date := 0;
      nc_104_Wk_WCB_p_Contrib := 0;
      nc_104_Wk_WCB_p_Contrib_Red := 0;
      nc_104_Wk_WCB_p_Eff_Date := 0;
      nc_104_Wk_Clmt_p_Contrib := 0;
      nc_104_Wk_Clmt_p_Eff_Date := 0;
      Wkly_WCB_Anty_Con_Amt := 0;
      Wkly_WCB_Anty_Con_Amt_S := 0;
      Wkly_Clmt_Anty_Con_Amt := 0;
      Wkly_Clmt_Anty_Con_Amt_S := 0;
      Indexation_Calc_Date := 0;
      Indexation_Year := 0;
      Index_to_Year := 0;
      Indexed_Amount := 0;
      Payment_Anty_Earn := 0;
      Payment_WCB_Contrib := 0;
      Payment_Clmt_Contrib := 0;
      OK_to_Process := '';
      Mf_Null := '';
      Employer_Top_Up_Flag := '';
      CI_04_Wkly_NET_Sal := 0;
      PHIN := '';
      CI05_Balance := 0;
      CI05_Rate := 0;
      CI05_Status := '';
      CI05_Trlrcnt := 0;
      Mf_Cics_Status := 0;
      Mf_Cics_Msg := '';
      AverageEarningsBasedOn := '';
      overPaymentBal := 0;
      overPaymentBalDate := 0;
      // New fields for 2000 policy changes
      Self_Employed := '';
      Recurrence := '';
      CPP_Exempt := '';
      Tax_Exempt := '';
      Child_Care_Exp := 0;
      Spousal_Support := 0;
      Child_Support := 0;
      Max_Adjustment := 0;
    end;
end;

(******************************************************************************)
(*                                                                            *)
(*  Clone all fields in a recNCClaim record to another.                       *)
(*                                                                            *)
(******************************************************************************)
procedure copyNCCLAIM( var a, b: recNCCLAIM );
begin
  b.isClaimCurrent :=               a.isClaimCurrent;
  b.Claim_No :=                     a.Claim_No;
  b.Claim_Suffix :=                 a.Claim_Suffix;
  b.Prime_Firm_No :=                a.Prime_Firm_No;
  b.Firm_Name :=                    a.Firm_Name;
  b.SIN :=                          a.SIN;
  b.Clmnts_Surname :=               a.Clmnts_Surname;
  b.Clmnts_1st_Name :=              a.Clmnts_1st_Name;
  b.Clmnts_Add_No_1 :=              a.Clmnts_Add_No_1;
  b.Clmnts_Add_No_2 :=              a.Clmnts_Add_No_2;
  b.Clmnts_Add_No_3 :=              a.Clmnts_Add_No_3;
  b.Clmnts_Post_Code :=             a.Clmnts_Post_Code;
  b.Clmnts_Home_Phone :=            a.Clmnts_Home_Phone;
  b.Clmnts_Work_Phone :=            a.Clmnts_Work_Phone;
  b.Alt_Mail_Add_code :=            a.Alt_Mail_Add_code;
  b.Birth_Date :=                   a.Birth_Date;
  b.Tax_Year :=                     a.Tax_Year;
  b.Tax_Code :=                     a.Tax_Code;
  b.Marital_Status :=               a.Marital_Status;
  b.Spouse_Working :=               a.Spouse_Working;
  b.Days_Worked_per_Week :=         a.Days_Worked_per_Week;
  b.Tot_Comp_Pd_To_Date :=          a.Tot_Comp_Pd_To_Date;
  b.No_Days_Of_Comp_Bnfts :=        a.No_Days_Of_Comp_Bnfts;
  b.No_Weeks_of_Comp_Bnfts :=       a.No_Weeks_of_Comp_Bnfts;
  b.Comp_Wks_Pd_to_63 :=            a.Comp_Wks_Pd_to_63;
  b.Comp_Wks_Pd_to_63_Flag :=       a.Comp_Wks_Pd_to_63_Flag;
  b.Days_Bnft_Pd_On_Last_Comp :=    a.Days_Bnft_Pd_On_Last_Comp;
  b.Curr_Case_Type :=               a.Curr_Case_Type;
  b.Accident_Date :=                a.Accident_Date;
  b.Last_Review_Date :=             a.Last_Review_Date;
  b.Calc_Date :=                    a.Calc_Date;
  b.Calc_Username :=                a.Calc_Username;
  b.No_Of_Dependnts :=              a.No_Of_Dependnts;
  b.No_Infirm :=                    a.No_Infirm;
  b.Tax_Exemption :=                a.Tax_Exemption;
  b.II_Credit :=                    a.II_Credit;
  b.III_Credit :=                   a.III_Credit;
  b.Collateral_Ben_Tax :=           a.Collateral_Ben_Tax;
  b.Collateral_Ben_Non_Tax :=       a.Collateral_Ben_Non_Tax;
  b.Post_Injury_Earn :=             a.Post_Injury_Earn;
  b.Deemed_Earnings :=              a.Deemed_Earnings;
  b.Coll_Ben_Tax_Net :=             a.Coll_Ben_Tax_Net;
  b.Coll_Ben_Non_Tax_Net :=         a.Coll_Ben_Non_Tax_Net;
  b.Post_Injury_Earn_Net :=         a.Post_Injury_Earn_Net;
  b.Wkly_Sal :=                     a.Wkly_Sal;
  b.Wkly_Sal_A :=                   a.Wkly_Sal_A;
  b.Weekly_Net :=                   a.Weekly_Net;
  b.Weekly_Net_S :=                 a.Weekly_Net_S;
  b.Weekly_Net_A :=                 a.Weekly_Net_A;
  b.Weekly_90 :=                    a.Weekly_90;
  b.Weekly_90_S :=                  a.Weekly_90_S;
  b.Weekly_80 :=                    a.Weekly_80;
  b.Weekly_80_S :=                  a.Weekly_80_S;
  b.Annual_Gross :=                 a.Annual_Gross;
  b.Annual_Gross_A :=               a.Annual_Gross_A;
  b.Annual_Net :=                   a.Annual_Net;
  b.Annual_Net_A :=                 a.Annual_Net_A;
  b.Annual_90 :=                    a.Annual_90;
  b.Annual_90_S :=                  a.Annual_90_S;
  b.Annual_80 :=                    a.Annual_80;
  b.Annual_80_S :=                  a.Annual_80_S;
  b.Inc_Tax_Fed :=                  a.Inc_Tax_Fed;
  b.Inc_Tax_Fed_S :=                a.Inc_Tax_Fed_S;
  b.Inc_Tax_Man :=                  a.Inc_Tax_Man;
  b.Inc_Tax_Man_S :=                a.Inc_Tax_Man_S;
  b.CPP_Prem :=                     a.CPP_Prem;
  b.CPP_Prem_S :=                   a.CPP_Prem_S;
  b.EI_Exempt :=                    a.EI_Exempt;
  b.EI_Prem :=                      a.EI_Prem;
  b.EI_Prem_S :=                    a.EI_Prem_S;
  b.Total_Deds :=                   a.Total_Deds;
  b.Total_Deds_S :=                 a.Total_Deds_S;
  b.Total_Deds_A :=                 a.Total_Deds_A;
  b.Formula_Code :=                 a.Formula_Code;
  b.Hash_Total :=                   a.Hash_Total;
  b.Weekly_Benefit :=               a.Weekly_Benefit;
  b.CFIO :=                         a.CFIO;
  b.Payee_Code :=                   a.Payee_Code;
  b.Payment_Type_Code :=            a.Payment_Type_Code;
  b.Date_Pd_From_Cheq :=            a.Date_Pd_From_Cheq;
  b.Date_Pd_To_Cheq :=              a.Date_Pd_To_Cheq;
  b.First_Pay_Date :=               a.First_Pay_Date;
  b.Num_of_Payments :=              a.Num_of_Payments;
  b.Claim_Exp_Code :=               a.Claim_Exp_Code;
  b.Amount_Paid :=                  a.Amount_Paid;
  b.Loss_Earn_Date :=               a.Loss_Earn_Date;
  b.Pay_Frequency :=                a.Pay_Frequency;
  b.No_Days_Paid :=                 a.No_Days_Paid;
  b.No_Weeks_Paid :=                a.No_Weeks_Paid;
  b.Message_Code_A  :=              a.Message_Code_A;
  b.Message_Code_B  :=              a.Message_Code_B;
  b.Message_Code_C  :=              a.Message_Code_C;
  b.Benefit_Type_Code :=            a.Benefit_Type_Code;
  b.Benefit_Type :=                 a.Benefit_Type;
  b.Original_Wkly_Sal :=            a.Original_Wkly_Sal;
  b.Wkly_Sal_Index_Flag :=          a.Wkly_Sal_Index_Flag;
  b.Pre_1992_Wkly_Sal :=            a.Pre_1992_Wkly_Sal;
  b.Tot_WCB_Anty_Elig_Earn :=       a.Tot_WCB_Anty_Elig_Earn;
  b.Tot_WCB_Anty_Contib_Amt :=      a.Tot_WCB_Anty_Contib_Amt;
  b.Tot_Clmt_Anty_Elig_Earn :=      a.Tot_Clmt_Anty_Elig_Earn;
  b.Tot_Clmt_Anty_Contrib_Amt :=    a.Tot_Clmt_Anty_Contrib_Amt;
  b.nc_104_Wk_Clmt_Reply_Date :=    a.nc_104_Wk_Clmt_Reply_Date;
  b.nc_104_Wk_Effective_Date :=     a.nc_104_Wk_Effective_Date;
  b.nc_104_Wk_WCB_p_Contrib :=      a.nc_104_Wk_WCB_p_Contrib;
  b.nc_104_Wk_WCB_p_Contrib_Red :=  a.nc_104_Wk_WCB_p_Contrib_Red;
  b.nc_104_Wk_WCB_p_Eff_Date :=     a.nc_104_Wk_WCB_p_Eff_Date;
  b.nc_104_Wk_Clmt_p_Contrib :=     a.nc_104_Wk_Clmt_p_Contrib;
  b.nc_104_Wk_Clmt_p_Eff_Date :=    a.nc_104_Wk_Clmt_p_Eff_Date;
  b.Wkly_WCB_Anty_Con_Amt :=        a.Wkly_WCB_Anty_Con_Amt;
  b.Wkly_WCB_Anty_Con_Amt_S :=      a.Wkly_WCB_Anty_Con_Amt_S;
  b.Wkly_Clmt_Anty_Con_Amt :=       a.Wkly_Clmt_Anty_Con_Amt;
  b.Wkly_Clmt_Anty_Con_Amt_S :=     a.Wkly_Clmt_Anty_Con_Amt_S;
  b.Indexation_Calc_Date :=         a.Indexation_Calc_Date;
  b.Indexation_Year :=              a.Indexation_Year;
  b.Index_to_Year :=                a.Index_to_Year;
  b.Indexed_Amount :=               a.Indexed_Amount;
  b.Payment_Anty_Earn :=            a.Payment_Anty_Earn;
  b.Payment_WCB_Contrib :=          a.Payment_WCB_Contrib;
  b.Payment_Clmt_Contrib :=         a.Payment_Clmt_Contrib;
  b.OK_to_Process :=                a.OK_to_Process;
  b.Mf_Null :=                      a.Mf_Null;
  b.Employer_Top_Up_Flag :=         a.Employer_Top_Up_Flag;
  b.CI_04_Wkly_NET_Sal :=           a.CI_04_Wkly_NET_Sal;
  b.PHIN :=                         a.PHIN;
  b.CI05_Balance :=                 a.CI05_Balance;
  b.CI05_Rate :=                    a.CI05_Rate;
  b.CI05_Status :=                  a.CI05_Status;
  b.CI05_Trlrcnt :=                 a.CI05_Trlrcnt;
  b.Mf_Cics_Status :=               a.Mf_Cics_Status;
  b.Mf_Cics_Msg :=                  a.Mf_Cics_Msg;
  b.AverageEarningsBasedOn :=       a.AverageEarningsBasedOn;
  b.overPaymentBal :=               a.overPaymentBal;
  b.overPaymentBalDate :=           a.overPaymentBalDate;
  // New fields for 2000 policy changes
  b.Self_Employed :=                a.Self_Employed;
  b.Recurrence :=                   a.Recurrence;
  b.CPP_Exempt :=                   a.CPP_Exempt;
  b.Tax_Exempt :=                   a.Tax_Exempt;
  b.Child_Care_Exp :=               a.Child_Care_Exp;
  b.Spousal_Support :=              a.Spousal_Support;
  b.Child_Support :=                a.Child_Support;
  b.Max_Adjustment :=               a.Max_Adjustment;
end;

procedure ClearWLREBDTL( var r: recWLREBDTL );
begin
  with r do
    begin
      Claim_No := '';
      Claim_Suffix := '';
      Clmt_Name_Initials := '';
      Tax_Year := 0;
      Marital_Status := '';
      Spouse_Working := '';
      Nbr_Of_Dependants := 0;
      Nbr_Of_Infirm_Deps := 0;
      Uic_Exempt := '';
      Accum_Wks_Yr_PdCst := 0;
      Accum_Wks_Yr_90Net := 0;
      Wkly_Sal := 0;
      Wkly_Net := 0;
      Wkly_90 := 0;
      Wkly_90_S := 0;
      Wkly_80 := 0;
      Annual_Gross := 0;
      Annual_Net := 0;
      Annual_90 := 0;
      Annual_90_S := 0;
      Annual_80 := 0;
      Tax_Exemption := 0;
      Inc_Tax_Fed := 0;
      Inc_Tax_Prov := 0;
      Cpp_Prem := 0;
      Uic_Prem := 0;
      Total_Deds := 0;
      Wkly_Sal_A := 0;
      Annual_Gross_A := 0;
      Annual_Net_A := 0;
      Tax_Exemption_A := 0;
      Inc_Tax_Fed_A := 0;
      Inc_Tax_Prov_A := 0;
      Cpp_Prem_A := 0;
      Uic_Prem_A := 0;
      Tax_Shelter_Bnft := 0;
      Tax_Shelter_Deduct := 0;
      Rebate_Amount := 0;
      Weeks_Worked := 0;
      Wkly_Tax_S := 0;
      Total_Deds_A := 0;
      Total_Tax_S := 0;
      Total_Deds_P_A := 0;
      Shelter_Rebate_Year := 0;
      Prime_Firm_No := '';
      Payment_Issued_Flag := false;
      Logical_Delete_Flag := false;
      // New fields for 2000 policy changes
      Self_Employed := '';
      Recurrence := '';
      CPP_Exempt := '';
      Tax_Exempt := '';
      Child_Care_Exp := 0;
      Spousal_Support := 0;
      Child_Support := 0;
      Max_Adjustment := 0;
    end;
end;

end.
