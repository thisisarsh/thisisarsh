unit uTaxJan11;

interface
uses uTaxJul10, NCIniMod, Utils, uNCCLAIM;

type
  TTaxJan11 = class(TTaxJul10)
end;

implementation

{ TTaxJul10}

end.
