unit uTaxJul21;

interface

uses uTaxJan21, NCIniMod, Utils, uNCCLAIM;

type
  TTaxJul21 = class(TTaxJan21)
end;

implementation

  { TTaxJul21}

end.
