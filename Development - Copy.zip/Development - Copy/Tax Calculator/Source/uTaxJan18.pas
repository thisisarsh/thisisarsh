unit uTaxJan18;

interface
uses uTaxJul17, NCIniMod, Utils, uNCCLAIM;

type
  TTaxJan18 = class(TTaxJul17)
end;

implementation

  { TTaxJan18}

end.
