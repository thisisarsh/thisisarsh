unit uTaxJul05;

interface
uses uTaxJul04, NCIniMod, Utils, uNCCLAIM;

type
  TTaxJul05=class(TTaxJul04)
end;

implementation

{ TTaxJul05 }

end.
 