unit TaxCalcTestRunner;

interface
uses
  DUnitX.TestFramework, SysUtils, ADODB, Variants, Data.DB;

type

  [TestFixture]
  TaxCalcUnitTest = class(TObject) 
  public
    [Setup]
    procedure Setup;
    [TearDown]
    procedure TearDown;
    //
    // This suite of tests are for Jan 1, 1992 thru Dec 31, 2005
    // Note: MARRIED must be in upper case or it will not calculate correctly
    //
    [Test]
//    [TestCase('Test-Simp-A-1992','01/01/1992,500.00,5,1992,0,01/01/1992,N,01/01/1900,N,01/01/1900,N,N,SINGLE,N,0,0,N,N,N,02/01/1992,0.00,AVERAGE EARNINGS,0.00,0.00,0.00,0.00,0.00,N,0.00,0.00,0.00,3295.65,2152.13,529.00,728.00,6704.78,371.06,333.95,325.79,65.16,296.85,59.37')]
//    [TestCase('Test-Simp-B-1992','30/06/1992,500.00,5,1992,0,01/01/1992,N,01/01/1900,N,01/01/1900,N,N,SINGLE,N,0,0,N,N,N,01/07/1992,0.00,AVERAGE EARNINGS,0.00,0.00,0.00,0.00,0.00,N,0.00,0.00,0.00,3295.65,2152.13,529.00,728.00,6704.78,371.06,333.95,325.79,65.16,296.85,59.37')]
//    [TestCase('Test-Simp-C-1992','01/07/1992,500.00,5,1992,0,01/01/1992,N,01/01/1900,N,01/01/1900,N,N,SINGLE,N,0,0,N,N,N,02/07/1992,0.00,AVERAGE EARNINGS,0.00,0.00,0.00,0.00,0.00,N,0.00,0.00,0.00,3295.65,2152.13,529.00,728.00,6704.78,371.06,333.95,325.79,65.16,296.85,59.37')]
//    [TestCase('Test-Simp-D-1992','31/12/1992,500.00,5,1992,0,01/01/1992,N,01/01/1900,N,01/01/1900,N,N,SINGLE,N,0,0,N,N,N,01/01/1993,0.00,AVERAGE EARNINGS,0.00,0.00,0.00,0.00,0.00,N,0.00,0.00,0.00,3295.65,2152.13,529.00,728.00,6704.78,371.06,333.95,325.79,65.16,296.85,59.37')]
//    // Married with Dependants 01/01
//    [TestCase('Test-Mar-Dep-A-1992','01/01/1992,1000.00,5,1992,0,01/01/1992,N,01/01/1900,N,01/01/1900,N,N,MARRIED,Y,1,0,N,N,N,02/01/1992,0.00,AVERAGE EARNINGS,0.00,0.00,0.00,0.00,0.00,N,0.00,0.00,0.00,8217.87,5264.80,632.50,990.08,15105.25,584.51,588.14,502.74,100.55,467.61,93.52')]
//    [TestCase('Test-Mar-Dep-B-1992','01/01/1992,1000.00,5,1992,0,01/01/1992,N,01/01/1900,N,01/01/1900,N,N,MARRIED,Y,2,0,N,N,N,02/01/1992,0.00,AVERAGE EARNINGS,0.00,0.00,0.00,0.00,0.00,N,0.00,0.00,0.00,8145.40,5183.91,632.50,990.08,14951.89,587.46,590.45,500.80,100.16,469.97,93.99')]
//    [TestCase('Test-Mar--IDep-C-1992','01/01/1992,1000.00,5,1992,0,01/01/1992,N,01/01/1900,N,01/01/1900,N,N,MARRIED,Y,0,1,N,N,N,02/01/1992,0.00,AVERAGE EARNINGS,0.00,0.00,0.00,0.00,0.00,N,0.00,0.00,0.00,8015.45,5149.56,632.50,990.08,14787.59,590.62,593.64,506.86,101.37,472.50,94.50')]
//    [TestCase('Test-Mar-D-IDep-D-1992','01/01/1992,1000.00,5,1992,0,01/01/1992,N,01/01/1900,N,01/01/1900,N,N,MARRIED,Y,0,2,N,N,N,02/01/1992,0.00,AVERAGE EARNINGS,0.00,0.00,0.00,0.00,0.00,N,0.00,0.00,0.00,7740.56,4953.42,632.50,990.08,14316.56,599.68,601.44,509.04,101.81,479.74,95.95')]
//    // Married with Dependants 30/06
//    [TestCase('Test-Mar-Dep-A-1992','30/06/1992,1000.00,5,1992,0,01/01/1992,N,01/01/1900,N,01/01/1900,N,N,MARRIED,Y,1,0,N,N,N,01/07/1992,0.00,AVERAGE EARNINGS,0.00,0.00,0.00,0.00,0.00,N,0.00,0.00,0.00,8217.87,5264.80,632.50,990.08,15105.25,584.51,588.14,502.74,100.55,467.61,93.52')]
//    [TestCase('Test-Mar-Dep-B-1992','30/06/1992,1000.00,5,1992,0,01/01/1992,N,01/01/1900,N,01/01/1900,N,N,MARRIED,Y,2,0,N,N,N,01/07/1992,0.00,AVERAGE EARNINGS,0.00,0.00,0.00,0.00,0.00,N,0.00,0.00,0.00,8145.40,5183.91,632.50,990.08,14951.89,587.46,590.45,500.80,100.16,469.97,93.99')]
//    [TestCase('Test-Mar--IDep-C-1992','30/06/1992,1000.00,5,1992,0,01/01/1992,N,01/01/1900,N,01/01/1900,N,N,MARRIED,Y,0,1,N,N,N,01/07/1992,0.00,AVERAGE EARNINGS,0.00,0.00,0.00,0.00,0.00,N,0.00,0.00,0.00,8015.45,5149.56,632.50,990.08,14787.59,590.62,593.64,506.86,101.37,472.50,94.50')]
//    [TestCase('Test-Mar-D-IDep-D-1992','30/06/1992,1000.00,5,1992,0,01/01/1992,N,01/01/1900,N,01/01/1900,N,N,MARRIED,Y,0,2,N,N,N,01/07/1992,0.00,AVERAGE EARNINGS,0.00,0.00,0.00,0.00,0.00,N,0.00,0.00,0.00,7740.56,4953.42,632.50,990.08,14316.56,599.68,601.44,509.04,101.81,479.74,95.95')]
//    // Married with Dependants 01/07
//    [TestCase('Test-Mar-Dep-A-1992','01/07/1992,1000.00,5,1992,0,01/01/1992,N,01/01/1900,N,01/01/1900,N,N,MARRIED,Y,1,0,N,N,N,02/07/1992,0.00,AVERAGE EARNINGS,0.00,0.00,0.00,0.00,0.00,N,0.00,0.00,0.00,8217.87,5264.80,632.50,990.08,15105.25,584.51,588.14,502.74,100.55,467.61,93.52')]
//    [TestCase('Test-Mar-Dep-B-1992','01/07/1992,1000.00,5,1992,0,01/01/1992,N,01/01/1900,N,01/01/1900,N,N,MARRIED,Y,2,0,N,N,N,02/07/1992,0.00,AVERAGE EARNINGS,0.00,0.00,0.00,0.00,0.00,N,0.00,0.00,0.00,8145.40,5183.91,632.50,990.08,14951.89,587.46,590.45,500.80,100.16,469.97,93.99')]
//    [TestCase('Test-Mar--IDep-C-1992','01/07/1992,1000.00,5,1992,0,01/01/1992,N,01/01/1900,N,01/01/1900,N,N,MARRIED,Y,0,1,N,N,N,02/07/1992,0.00,AVERAGE EARNINGS,0.00,0.00,0.00,0.00,0.00,N,0.00,0.00,0.00,8015.45,5149.56,632.50,990.08,14787.59,590.62,593.64,506.86,101.37,472.50,94.50')]
//    [TestCase('Test-Mar-D-IDep-D-1992','01/07/1992,1000.00,5,1992,0,01/01/1992,N,01/01/1900,N,01/01/1900,N,N,MARRIED,Y,0,2,N,N,N,02/07/1992,0.00,AVERAGE EARNINGS,0.00,0.00,0.00,0.00,0.00,N,0.00,0.00,0.00,7740.56,4953.42,632.50,990.08,14316.56,599.68,601.44,509.04,101.81,479.74,95.95')]
//    // Married with Dependants 31/12
//    [TestCase('Test-Mar-Dep-A-1992','31/12/1992,1000.00,5,1992,0,01/01/1992,N,01/01/1900,N,01/01/1900,N,N,MARRIED,Y,1,0,N,N,N,01/01/1993,0.00,AVERAGE EARNINGS,0.00,0.00,0.00,0.00,0.00,N,0.00,0.00,0.00,8217.87,5264.80,632.50,990.08,15105.25,584.51,588.14,502.74,100.55,467.61,93.52')]
//    [TestCase('Test-Mar-Dep-B-1992','31/12/1992,1000.00,5,1992,0,01/01/1992,N,01/01/1900,N,01/01/1900,N,N,MARRIED,Y,2,0,N,N,N,01/01/1993,0.00,AVERAGE EARNINGS,0.00,0.00,0.00,0.00,0.00,N,0.00,0.00,0.00,8145.40,5183.91,632.50,990.08,14951.89,587.46,590.45,500.80,100.16,469.97,93.99')]
//    [TestCase('Test-Mar--IDep-C-1992','31/12/1992,1000.00,5,1992,0,01/01/1992,N,01/01/1900,N,01/01/1900,N,N,MARRIED,Y,0,1,N,N,N,01/01/1993,0.00,AVERAGE EARNINGS,0.00,0.00,0.00,0.00,0.00,N,0.00,0.00,0.00,8015.45,5149.56,632.50,990.08,14787.59,590.62,593.64,506.86,101.37,472.50,94.50')]
//    [TestCase('Test-Mar-D-IDep-D-1992','31/12/1992,1000.00,5,1992,0,01/01/1992,N,01/01/1900,N,01/01/1900,N,N,MARRIED,Y,0,2,N,N,N,01/01/1993,0.00,AVERAGE EARNINGS,0.00,0.00,0.00,0.00,0.00,N,0.00,0.00,0.00,7740.56,4953.42,632.50,990.08,14316.56,599.68,601.44,509.04,101.81,479.74,95.95')]
//    // Married, Dependants, no tax, no cpp, no ei
//    [TestCase('Test-Mar-D-IDep-D-1992','01/01/1992,1000.00,5,1992,0,01/01/1992,N,01/01/1900,N,01/01/1900,N,N,MARRIED,Y,2,2,Y,Y,Y,02/01/1992,0.00,AVERAGE EARNINGS,0.00,0.00,0.00,0.00,0.00,N,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,875.00,900.00,787.50,157.50,700.00,140.00')]
//    //
//    [TestCase('TestA-1993','01/01/1993,500.00,5.00,1993,0,01/01/1993,N,01/01/1900,N,01/01/1900,N,N,SINGLE,N,0,0,N,N,N,02/01/1993,0.00,AVERAGE EARNINGS,0.00,0.00,0.00,0.00,0.00,N,0.00,0.00,0.00,3236.22,2130.37,547.20,780.00,6693.79,371.27,334.14,325.77,65.15,297.02,59.40')]
//    [TestCase('TestB-1993','30/06/1993,500.00,5.00,1993,0,01/01/1993,N,01/01/1900,N,01/01/1900,N,N,SINGLE,N,0,0,N,N,N,01/07/1993,0.00,AVERAGE EARNINGS,0.00,0.00,0.00,0.00,0.00,N,0.00,0.00,0.00,3236.22,2130.37,547.20,780.00,6693.79,371.27,334.14,325.77,65.15,297.02,59.40')]
//    [TestCase('TestC-1993','01/07/1993,500.00,5.00,1993,0,01/01/1993,N,01/01/1900,N,01/01/1900,N,N,SINGLE,N,0,0,N,N,N,02/07/1993,0.00,AVERAGE EARNINGS,0.00,0.00,0.00,0.00,0.00,N,0.00,0.00,0.00,3236.22,2130.37,547.20,780.00,6693.79,371.27,334.14,325.77,65.15,297.02,59.40')]
//    [TestCase('TestD-1993','31/12/1993,500.00,5.00,1993,0,01/01/1993,N,01/01/1900,N,01/01/1900,N,N,SINGLE,N,0,0,N,N,N,01/01/1994,0.00,AVERAGE EARNINGS,0.00,0.00,0.00,0.00,0.00,N,0.00,0.00,0.00,3236.22,2130.37,547.20,780.00,6693.79,371.27,334.14,325.77,65.15,297.02,59.40')]
//    [TestCase('TestA-1994','01/01/1994,500.00,5.00,1994,0,01/01/1994,N,01/01/1900,N,01/01/1900,N,N,SINGLE,N,0,0,N,N,N,02/01/1994,0.00,AVERAGE EARNINGS,0.00,0.00,0.00,0.00,0.00,N,0.00,0.00,0.00,3186.20,2128.57,567.50,780.00,6662.27,371.88,334.69,326.38,65.28,297.50,59.50')]
//    [TestCase('TestB-1994','30/06/1994,500.00,5.00,1994,0,01/01/1994,N,01/01/1900,N,01/01/1900,N,N,SINGLE,N,0,0,N,N,N,01/07/1994,0.00,AVERAGE EARNINGS,0.00,0.00,0.00,0.00,0.00,N,0.00,0.00,0.00,3186.20,2128.57,567.50,780.00,6662.27,371.88,334.69,326.38,65.28,297.50,59.50')]
//    [TestCase('TestC-1994','01/07/1994,500.00,5.00,1994,0,01/01/1994,N,01/01/1900,N,01/01/1900,N,N,SINGLE,N,0,0,N,N,N,02/07/1994,0.00,AVERAGE EARNINGS,0.00,0.00,0.00,0.00,0.00,N,0.00,0.00,0.00,3186.20,2128.57,567.50,780.00,6662.27,371.88,334.69,326.38,65.28,297.50,59.50')]
//    [TestCase('TestD-1994','31/12/1994,500.00,5.00,1994,0,01/01/1994,N,01/01/1900,N,01/01/1900,N,N,SINGLE,N,0,0,N,N,N,01/01/1995,0.00,AVERAGE EARNINGS,0.00,0.00,0.00,0.00,0.00,N,0.00,0.00,0.00,3186.20,2128.57,567.50,780.00,6662.27,371.88,334.69,326.38,65.28,297.50,59.50')]
//    [TestCase('TestA-2003','01/01/2003,500.00,5.00,2003,0,01/01/2003,N,01/01/1900,N,01/01/1900,N,N,SINGLE,N,0,0,N,N,N,02/01/2003,0.00,AVERAGE EARNINGS,0.00,0.00,0.00,0.00,0.00,N,0.00,0.00,0.00,2677.84,1824.28,1057.50,572.00,6131.62,382.08,343.87,333.95,66.79,305.66,61.13')]
//    [TestCase('TestA-2005','01/01/2005,500.00,5.00,2005,0,01/01/2005,N,01/01/1900,N,01/01/1900,N,N,SINGLE,N,0,0,N,N,N,02/01/2005,0.00,AVERAGE EARNINGS,0.00,0.00,0.00,0.00,0.00,N,0.00,0.00,0.00,2617.51,1824.38,1113.75,514.80,6070.44,383.26,344.93,334.72,66.94,306.61,61.32')]
//    // Test case generated from QAData
//    [TestCase('Test-1-1992-Y','01/01/1992,550.00,5.00,1992,0,01/01/1992,N,01/01/1900,N,01/01/1900,N,N,MARRIED,Y,5,1,N,N,N,02/01/1992,0.00,Average Earnings,25.00,50.00,0.00,0.00,0.00,N,0.00,0.00,0.00,2881.42,640.99,588.80,800.80,4912.01,455.54,409.99,361.39,72.28,361.39,72.28')]
//    [TestCase('Test-2-1992-Y','01/01/1992,900.00,5.00,1992,0,01/01/1992,N,01/01/1900,N,01/01/1900,N,N,MARRIED,Y,5,1,N,N,N,02/01/1992,0.00,Average Earnings,150.00,100.00,0.00,0.00,0.00,N,0.00,0.00,0.00,7435.68,3717.43,632.50,990.08,12775.69,629.31,578.35,482.12,96.42,482.12,96.42')]
    [TestCase('Test-3-1992-Y','01/01/1992,1200.00,5.00,1992,0,01/01/1992,N,01/01/1900,N,01/01/1900,N,N,MARRIED,Y,5,1,N,N,N,02/01/1992,0.00,Average Earnings,125.00,200.00,0.00,0.00,0.00,N,0.00,0.00,0.00,7435.68,3717.43,632.50,990.08,12775.69,629.31,717.99,526.86,105.37,503.45,100.69')]
    [TestCase('Test-4-1992-N','01/01/1992,500.00,5.00,1992,0,01/01/1992,N,01/01/1900,N,01/01/1900,N,N,MARRIED,N,2,0,N,N,N,02/01/1992,0.00,Average Earnings,50.00,100.00,0.00,0.00,0.00,N,0.00,0.00,0.00,2216.61,837.75,529.00,728.00,4311.36,417.09,375.38,279.15,55.83,279.15,55.83')]
    [TestCase('Test-5-1992-N','01/03/1992,885.00,5.00,1992,0,01/03/1992,N,01/01/1900,N,01/01/1900,N,Y,COMMON-LAW,N,5,0,Y,N,N,02/03/1992,0.00,Average Earnings,75.00,200.00,0.00,0.00,0.00,N,0.00,0.00,0.00,0.00,0.00,242.14,0.00,242.14,255.50,603.91,229.65,45.93,204.40,40.88')]
    procedure TaxTestBase92To05(const InjuryDate:String;const WeeklyWage,DaysPerWeek:Currency;
                          const TaxYear,YearIndexed:Integer;
                          const IndexedDate:String;
                          const Recurrence:String;
                          const RecurrenceDate:String;
                          const YouthfulWorker:String;
                          const LossOfEarningsDate:String;
                          const Apprentice,SelfEmployed,MaritalStatus,SpouseWorking:String;
                          const Dependants, InfirmDependants:Integer;
                          const EIExempt, CPPExempt,IncomeTaxExempt:String;
                          const EffectiveDate:String;
                          const MaxAdjustment:Currency;
                          const EarningsBasedOn:String;
                          const PostInjuryEarningsWkGross, CollateralTaxable:Currency; // CollateralCPP, CollateralEI, CollateralDisability, CollateralOther
                          const CollateralNonTaxable, PostInjuryEmployerTopUp, PostInjuryPrivateInsurance:Currency;
                          const DeemedEarnings:String;
                          const ChildCareExpense,ChildSupport,SpousalSupport:Currency;
                          const EFederalTax, EManitobaTax, ECPP, EEI, ETotalDeductions, ENetLossOfEarn, EWeekly90Net:Currency;
                          const EWeekly90Sheltered, EDaily90CompRate, E80WeeklyNet, EDaily80CompRate:Currency);
    //
    // These are for test cases Jan 1, 2006 thru present
    // The major change for these is the use of the minimum wage calculations
    //
    //[TestCase('TestA-2018','01/01/2018,500.00,5,2018,0,N,N,N,N,SINGLE,N,0,0,N,N,N,02/01/2018,0.00,AVERAGE EARNINGS,0.00,0.00,0.00,0.00,0.00,0.00,0.00,N,0.00,0.00,0.00,1530.63,1357.37,974.75,378.03,4240.78,364.45,364.45,349.59,69.92,349.59,69.92')]
    procedure TaxTestBase06To(const InjuryDate:String;const WeeklyWage,DaysPerWeek:Currency;
                          const TaxYear,YearIndexed:Integer;
                          const Recurrence,YouthfulWorker,Apprentice,SelfEmployed,MaritalStatus,SpouseWorking:String;
                          const Dependants, InfirmDependants:Integer;
                          const EIExempt, CPPExempt,IncomeTaxExempt:String;
                          const EffectiveDate:String;
                          const MaxAdjustment:Currency;
                          const EarningsBasedOn:String;
                          const PostInjuryEarningsWkGross, CollateralCPP, CollateralEI, CollateralDisability, CollateralOther:Currency;
                          const PostInjuryEmployerTopUp, PostInjuryPrivateInsurance:Currency;
                          const DeemedEarnings:String;
                          const ChildCareExpense,ChildSupport,SpousalSupport:Currency;
                          const EFederalTax, EManitobaTax, ECPP, EEI, ETotalDeductions, ENetLossOfEarn, EWeekly90Net:Currency;
                          const EWeekly90Sheltered, EDaily90CompRate, E80WeeklyNet, EDaily80CompRate:Currency);
  end;

implementation

uses
   uNCClaim, uTaxBase, Utils, uTaxCalc, NCRecdef, uGlobal;

procedure TaxCalcUnitTest.Setup;
begin
end;

procedure TaxCalcUnitTest.TearDown;
begin
end;

function CreateConnection(DBServer, DBDataBaseName, UserID, Password:String):TADOConnection;
var
   oConnection:TADOConnection;
begin
   oConnection := TADOConnection.Create(nil);
   oConnection.ConnectionString := 'Provider=SQLOLEDB.1;Persist Security Info=True;' +
                                   'User ID=' +  UserID + ';' +
                                   'Password=' + Password + ';' +
                                   'Initial Catalog=' + DBDataBaseName + ';' +
                                   'Data Source=' + DBServer + ';';
   oConnection.LoginPrompt := false;
   oConnection.Open;

   result := oConnection;
end;

function CreateStoredProc(oConnection:TADOConnection; ProcName:String;
                          oParameterName:String; oParamType:TFieldType;oParamDirection:TParameterDirection;
                          oParamLength:Integer):TADOStoredProc;
var
   oStoredProc:TADOStoredProc;
   //oParm:TParam;
begin
   oStoredProc := TADOStoredProc.Create(nil);
   oStoredProc.Connection := oConnection;
   oStoredProc.ProcedureName := ProcName;
   oStoredProc.Parameters.CreateParameter('@RETURN_VLAUE',ftInteger,pdReturnValue,0,null);
   oStoredProc.Parameters.CreateParameter(oParameterName, oParamType, oParamDirection, oParamLength, null);
   oStoredProc.Prepared := true;

   result := oStoredProc;
end;


//
// The next two routines copyNCCLAIM and ClearNCCLAIM have been created locally since the
// types used for the Claim (recNCClaim) are defined different in wageloss and taxCalculator. This
// Causes issues when mixing and matching the units used in the test and will cause type mismatch errors
// when attempting to pass them via reference (ie var parm). Thus I have copied this functionality here.
// If changes are made to the actual routines they will need to be updated here.
//
procedure copyNCCLAIM( var a, b: uNCClaim.recNCCLAIM );
begin
  b.isClaimCurrent :=               a.isClaimCurrent;
  b.Claim_No :=                     a.Claim_No;
  b.Claim_Suffix :=                 a.Claim_Suffix;
  b.Prime_Firm_No :=                a.Prime_Firm_No;
  b.Firm_Name :=                    a.Firm_Name;
  b.SIN :=                          a.SIN;
  b.Clmnts_Surname :=               a.Clmnts_Surname;
  b.Clmnts_1st_Name :=              a.Clmnts_1st_Name;
  b.Clmnts_Add_No_1 :=              a.Clmnts_Add_No_1;
  b.Clmnts_Add_No_2 :=              a.Clmnts_Add_No_2;
  b.Clmnts_Add_No_3 :=              a.Clmnts_Add_No_3;
  b.Clmnts_Post_Code :=             a.Clmnts_Post_Code;
  b.Clmnts_Home_Phone :=            a.Clmnts_Home_Phone;
  b.Clmnts_Work_Phone :=            a.Clmnts_Work_Phone;
  b.Alt_Mail_Add_code :=            a.Alt_Mail_Add_code;
  b.Birth_Date :=                   a.Birth_Date;
  b.Tax_Year :=                     a.Tax_Year;
  b.Tax_Code :=                     a.Tax_Code;
  b.Marital_Status :=               a.Marital_Status;
  b.Spouse_Working :=               a.Spouse_Working;
  b.Days_Worked_per_Week :=         a.Days_Worked_per_Week;
  b.Tot_Comp_Pd_To_Date :=          a.Tot_Comp_Pd_To_Date;
  b.No_Days_Of_Comp_Bnfts :=        a.No_Days_Of_Comp_Bnfts;
  b.No_Weeks_of_Comp_Bnfts :=       a.No_Weeks_of_Comp_Bnfts;
  b.Comp_Wks_Pd_to_63 :=            a.Comp_Wks_Pd_to_63;
  b.Comp_Wks_Pd_to_63_Flag :=       a.Comp_Wks_Pd_to_63_Flag;
  b.Days_Bnft_Pd_On_Last_Comp :=    a.Days_Bnft_Pd_On_Last_Comp;
  b.Curr_Case_Type :=               a.Curr_Case_Type;
  b.Accident_Date :=                a.Accident_Date;
  b.Last_Review_Date :=             a.Last_Review_Date;
  b.Calc_Date :=                    a.Calc_Date;
  b.Calc_Username :=                a.Calc_Username;
  b.No_Of_Dependnts :=              a.No_Of_Dependnts;
  b.No_Infirm :=                    a.No_Infirm;
  b.Tax_Exemption :=                a.Tax_Exemption;
  b.II_Credit :=                    a.II_Credit;
  b.III_Credit :=                   a.III_Credit;
  b.Collateral_Ben_Tax :=           a.Collateral_Ben_Tax;
  b.Collateral_Ben_Non_Tax :=       a.Collateral_Ben_Non_Tax;
  b.Post_Injury_Earn :=             a.Post_Injury_Earn;
  b.Deemed_Earnings :=              a.Deemed_Earnings;
  b.Coll_Ben_Tax_Net :=             a.Coll_Ben_Tax_Net;
  b.Coll_Ben_Non_Tax_Net :=         a.Coll_Ben_Non_Tax_Net;
  b.Post_Injury_Earn_Net :=         a.Post_Injury_Earn_Net;
  b.Wkly_Sal :=                     a.Wkly_Sal;
  b.Wkly_Sal_A :=                   a.Wkly_Sal_A;
  b.Weekly_Net :=                   a.Weekly_Net;
  b.Weekly_Net_S :=                 a.Weekly_Net_S;
  b.Weekly_Net_A :=                 a.Weekly_Net_A;
  b.Weekly_90 :=                    a.Weekly_90;
  b.Weekly_90_S :=                  a.Weekly_90_S;
  b.Weekly_80 :=                    a.Weekly_80;
  b.Weekly_80_S :=                  a.Weekly_80_S;
  b.Annual_Gross :=                 a.Annual_Gross;
  b.Annual_Gross_A :=               a.Annual_Gross_A;
  b.Annual_Net :=                   a.Annual_Net;
  b.Annual_Net_A :=                 a.Annual_Net_A;
  b.Annual_90 :=                    a.Annual_90;
  b.Annual_90_S :=                  a.Annual_90_S;
  b.Annual_80 :=                    a.Annual_80;
  b.Annual_80_S :=                  a.Annual_80_S;
  b.Inc_Tax_Fed :=                  a.Inc_Tax_Fed;
  b.Inc_Tax_Fed_S :=                a.Inc_Tax_Fed_S;
  b.Inc_Tax_Man :=                  a.Inc_Tax_Man;
  b.Inc_Tax_Man_S :=                a.Inc_Tax_Man_S;
  b.CPP_Prem :=                     a.CPP_Prem;
  b.CPP_Prem_S :=                   a.CPP_Prem_S;
  b.EI_Exempt :=                    a.EI_Exempt;
  b.EI_Prem :=                      a.EI_Prem;
  b.EI_Prem_S :=                    a.EI_Prem_S;
  b.Total_Deds :=                   a.Total_Deds;
  b.Total_Deds_S :=                 a.Total_Deds_S;
  b.Total_Deds_A :=                 a.Total_Deds_A;
  b.Formula_Code :=                 a.Formula_Code;
  b.Hash_Total :=                   a.Hash_Total;
  b.Weekly_Benefit :=               a.Weekly_Benefit;
  b.CFIO :=                         a.CFIO;
  b.Payee_Code :=                   a.Payee_Code;
  b.Payment_Type_Code :=            a.Payment_Type_Code;
  b.Date_Pd_From_Cheq :=            a.Date_Pd_From_Cheq;
  b.Date_Pd_To_Cheq :=              a.Date_Pd_To_Cheq;
  b.First_Pay_Date :=               a.First_Pay_Date;
  b.Num_of_Payments :=              a.Num_of_Payments;
  b.Claim_Exp_Code :=               a.Claim_Exp_Code;
  b.Amount_Paid :=                  a.Amount_Paid;
  b.Loss_Earn_Date :=               a.Loss_Earn_Date;
  b.Pay_Frequency :=                a.Pay_Frequency;
  b.No_Days_Paid :=                 a.No_Days_Paid;
  b.No_Weeks_Paid :=                a.No_Weeks_Paid;
  b.Message_Code_A  :=              a.Message_Code_A;
  b.Message_Code_B  :=              a.Message_Code_B;
  b.Message_Code_C  :=              a.Message_Code_C;
  b.Benefit_Type_Code :=            a.Benefit_Type_Code;
  b.Benefit_Type :=                 a.Benefit_Type;
  b.Original_Wkly_Sal :=            a.Original_Wkly_Sal;
  b.Wkly_Sal_Index_Flag :=          a.Wkly_Sal_Index_Flag;
  b.Pre_1992_Wkly_Sal :=            a.Pre_1992_Wkly_Sal;
  b.Tot_WCB_Anty_Elig_Earn :=       a.Tot_WCB_Anty_Elig_Earn;
  b.Tot_WCB_Anty_Contib_Amt :=      a.Tot_WCB_Anty_Contib_Amt;
  b.Tot_Clmt_Anty_Elig_Earn :=      a.Tot_Clmt_Anty_Elig_Earn;
  b.Tot_Clmt_Anty_Contrib_Amt :=    a.Tot_Clmt_Anty_Contrib_Amt;
  b.nc_104_Wk_Clmt_Reply_Date :=    a.nc_104_Wk_Clmt_Reply_Date;
  b.nc_104_Wk_Effective_Date :=     a.nc_104_Wk_Effective_Date;
  b.nc_104_Wk_WCB_p_Contrib :=      a.nc_104_Wk_WCB_p_Contrib;
  b.nc_104_Wk_WCB_p_Contrib_Red :=  a.nc_104_Wk_WCB_p_Contrib_Red;
  b.nc_104_Wk_WCB_p_Eff_Date :=     a.nc_104_Wk_WCB_p_Eff_Date;
  b.nc_104_Wk_Clmt_p_Contrib :=     a.nc_104_Wk_Clmt_p_Contrib;
  b.nc_104_Wk_Clmt_p_Eff_Date :=    a.nc_104_Wk_Clmt_p_Eff_Date;
  b.Wkly_WCB_Anty_Con_Amt :=        a.Wkly_WCB_Anty_Con_Amt;
  b.Wkly_WCB_Anty_Con_Amt_S :=      a.Wkly_WCB_Anty_Con_Amt_S;
  b.Wkly_Clmt_Anty_Con_Amt :=       a.Wkly_Clmt_Anty_Con_Amt;
  b.Wkly_Clmt_Anty_Con_Amt_S :=     a.Wkly_Clmt_Anty_Con_Amt_S;
  b.Indexation_Calc_Date :=         a.Indexation_Calc_Date;
  b.Indexation_Year :=              a.Indexation_Year;
  b.Index_to_Year :=                a.Index_to_Year;
  b.Indexed_Amount :=               a.Indexed_Amount;
  b.Payment_Anty_Earn :=            a.Payment_Anty_Earn;
  b.Payment_WCB_Contrib :=          a.Payment_WCB_Contrib;
  b.Payment_Clmt_Contrib :=         a.Payment_Clmt_Contrib;
  b.OK_to_Process :=                a.OK_to_Process;
  b.Mf_Null :=                      a.Mf_Null;
  b.Employer_Top_Up_Flag :=         a.Employer_Top_Up_Flag;
  b.CI_04_Wkly_NET_Sal :=           a.CI_04_Wkly_NET_Sal;
  b.PHIN :=                         a.PHIN;
  b.CI05_Balance :=                 a.CI05_Balance;
  b.CI05_Rate :=                    a.CI05_Rate;
  b.CI05_Status :=                  a.CI05_Status;
  b.CI05_Trlrcnt :=                 a.CI05_Trlrcnt;
  b.Mf_Cics_Status :=               a.Mf_Cics_Status;
  b.Mf_Cics_Msg :=                  a.Mf_Cics_Msg;
  b.AverageEarningsBasedOn :=       a.AverageEarningsBasedOn;
  b.overPaymentBal :=               a.overPaymentBal;
  b.overPaymentBalDate :=           a.overPaymentBalDate;
  b.Self_Employed :=                a.Self_Employed;
  b.Recurrence :=                   a.Recurrence;
  b.CPP_Exempt :=                   a.CPP_Exempt;
  b.Tax_Exempt :=                   a.Tax_Exempt;
  b.Child_Care_Exp :=               a.Child_Care_Exp;
  b.Spousal_Support :=              a.Spousal_Support;
  b.Child_Support :=                a.Child_Support;
  b.Max_Adjustment :=               a.Max_Adjustment;
  b.RecurrenceDate:=		            a.RecurrenceDate;
  b.Youthful_Worker :=              a.Youthful_Worker;
  b.Apprentice :=                   a.Apprentice;
  b.Deemed_Earnings :=              a.Deemed_Earnings;
  b.TaxCollBen_CPPQPP :=            a.TaxCollBen_CPPQPP;
  b.TaxCollBen_EI :=                a.TaxCollBen_EI;
  b.TaxCollBen_DisabilityIns :=     a.TaxCollBen_DisabilityIns;
  b.TaxCollBen_EmpTopUp :=          a.TaxCollBen_EmpTopUp;
  b.TaxCollBen_Combination :=       a.TaxCollBen_Combination;
  b.NonTaxCollBen_EmpTopUp :=       a.NonTaxCollBen_EmpTopUp;
  b.NonTaxCollBen_PrivateIns :=     a.NonTaxCollBen_PrivateIns;
  b.Minimum_wage_Flag :=            a.Minimum_wage_Flag;
  b.Minimum_wage :=                 a.Minimum_wage;
  b.Min_Wage_Annual_Net_A :=        a.Min_Wage_Annual_Net_A;
  b.Tax_Coll_Ben_Only :=            a.Tax_Coll_Ben_Only;
  b.Min_Wage_Total_Deds :=          a.Min_Wage_Total_Deds;
  b.Weekly_Shelter_Ben_Amount :=    a.Weekly_Shelter_Ben_Amount;
  b.Pay_At_100_Flag :=              a.Pay_At_100_Flag;
  b.Weekly_Shelter_Ben_Amount_90 := a.Weekly_Shelter_Ben_Amount_90;
  b.Minimum_Wage_Flag_Partial :=    a.Minimum_Wage_Flag_Partial;
  b.Pay_At_100_Flag_Partial :=      a.Pay_At_100_Flag_Partial;
  b.Uniqueness :=                   a.Uniqueness;
  b.DeathBenefit := 								a.DeathBenefit;
  b.effectiveDate :=                a.effectiveDate;
  b.net80DailyCompensationRateAmt := a.net80DailyCompensationRateAmt;
  b.partial80AfterClmtContribAmt := a.partial80AfterClmtContribAmt;
  b.week104StatusType :=            a.week104StatusType;
  b.commentText :=                  a.commentText;
  b.reducedNoDaysToPay :=           a.reducedNoDaysToPay;
  b.reducedNoWeeksToPay :=          a.reducedNoWeeksToPay;
  b.Accum_Wks_Yr_90Net_Post :=      a.Accum_Wks_Yr_90Net_Post;
  b.workerAnnuityContributionPercent := a.workerAnnuityContributionPercent;
  b.wcbAnnuityContributionPercent := a.wcbAnnuityContributionPercent;
  b.reportType :=                   a.reportType;
  b.collateralTaxableAmt :=         a.collateralTaxableAmt;
  b.collateralNonTaxableAmt :=      a.collateralNonTaxableAmt;
  b.sumWeeksPaidQty :=              a.sumWeeksPaidQty;
  b.paidOver52WeeksFlag :=          a.paidOver52WeeksFlag;
  b.rejectionReasonDesc :=          a.rejectionReasonDesc;
  b.actualWeeksPaidQty :=           a.actualWeeksPaidQty;
  b.doNotBatchProcessFlag :=        a.doNotBatchProcessFlag;
end;

procedure ClearNCCLAIM( var r: uNCClaim.recNCCLAIM );
begin
  with r do
    begin
      isClaimCurrent := false;
      Claim_No := '';
      Claim_Suffix := '';
      Prime_Firm_No := '';
      Firm_Name := '';
      SIN := '';
      Clmnts_Surname := '';
      Clmnts_1st_Name := '';
      Clmnts_Add_No_1 := '';
      Clmnts_Add_No_2 := '';
      Clmnts_Add_No_3 := '';
      Clmnts_Post_Code := '';
      Clmnts_Home_Phone := '';
      Clmnts_Work_Phone := '';
      Alt_Mail_Add_code := '';
      Birth_Date := 0;
      Tax_Year := 0;
      Tax_Code := '';
      Marital_Status := '';
      Spouse_Working := '';
      Days_Worked_per_Week := 0;
      Tot_Comp_Pd_To_Date := 0;
      No_Days_Of_Comp_Bnfts := 0;
      No_Weeks_of_Comp_Bnfts := 0;
      Comp_Wks_Pd_to_63 := 0;
      Comp_Wks_Pd_to_63_Flag := '';
      Days_Bnft_Pd_On_Last_Comp := 0;
      Curr_Case_Type := '';
      Accident_Date := 0;
      Last_Review_Date := 0;
      Calc_Date := 0;
      Calc_Username := '';
      No_Of_Dependnts := 0;
      No_Infirm := 0;
      Tax_Exemption := 0;
      II_Credit := 0;
      III_Credit := 0;
      Collateral_Ben_Tax := 0;
      Collateral_Ben_Non_Tax := 0;
      Post_Injury_Earn := 0;
      Deemed_Earnings := '';
      Coll_Ben_Tax_Net := 0;
      Coll_Ben_Non_Tax_Net := 0;
      Post_Injury_Earn_Net := 0;
      Wkly_Sal := 0;
      Wkly_Sal_A := 0;
      Weekly_Net := 0;
      Weekly_Net_S := 0;
      Weekly_Net_A := 0;
      Weekly_90 := 0;
      Weekly_90_S := 0;
      Weekly_80 := 0;
      Weekly_80_S := 0;
      Annual_Gross := 0;
      Annual_Gross_A := 0;
      Annual_Net := 0;
      Annual_Net_A := 0;
      Annual_90 := 0;
      Annual_90_S := 0;
      Annual_80 := 0;
      Annual_80_S := 0;
      Inc_Tax_Fed := 0;
      Inc_Tax_Fed_S := 0;
      Inc_Tax_Man := 0;
      Inc_Tax_Man_S := 0;
      CPP_Prem := 0;
      CPP_Prem_S := 0;
      EI_Exempt := '';
      EI_Prem := 0;
      EI_Prem_S := 0;
      Total_Deds := 0;
      Total_Deds_S := 0;
      Total_Deds_A := 0;
      Formula_Code := '';
      Hash_Total := 0;
      Weekly_Benefit := 0;
      CFIO := '';
      Payee_Code := '';
      Payment_Type_Code := '';
      Date_Pd_From_Cheq := 0;
      Date_Pd_To_Cheq := 0;
      First_Pay_Date := 0;
      Num_of_Payments := 0;
      Claim_Exp_Code := '';
      Amount_Paid := 0;
      Loss_Earn_Date := 0;
      Pay_Frequency := '';
      No_Days_Paid := 0;
      No_Weeks_Paid := 0;
      Message_Code_A := '';
      Message_Code_B := '';
      Message_Code_C := '';
      Benefit_Type_Code := '';
      Benefit_Type := '';
      Original_Wkly_Sal := 0;
      Wkly_Sal_Index_Flag := '';
      Pre_1992_Wkly_Sal := 0;
      Tot_WCB_Anty_Elig_Earn := 0;
      Tot_WCB_Anty_Contib_Amt := 0;
      Tot_Clmt_Anty_Elig_Earn := 0;
      Tot_Clmt_Anty_Contrib_Amt := 0;
      nc_104_Wk_Clmt_Reply_Date := 0;
      nc_104_Wk_Effective_Date := 0;
      nc_104_Wk_WCB_p_Contrib := 0;
      nc_104_Wk_WCB_p_Contrib_Red := 0;
      nc_104_Wk_WCB_p_Eff_Date := 0;
      nc_104_Wk_Clmt_p_Contrib := 0;
      nc_104_Wk_Clmt_p_Eff_Date := 0;
      Wkly_WCB_Anty_Con_Amt := 0;
      Wkly_WCB_Anty_Con_Amt_S := 0;
      Wkly_Clmt_Anty_Con_Amt := 0;
      Wkly_Clmt_Anty_Con_Amt_S := 0;
      Indexation_Calc_Date := 0;
      Indexation_Year := 0;
      Index_to_Year := 0;
      Indexed_Amount := 0;
      Payment_Anty_Earn := 0;
      Payment_WCB_Contrib := 0;
      Payment_Clmt_Contrib := 0;
      OK_to_Process := '';
      Mf_Null := '';
      Employer_Top_Up_Flag := '';
      CI_04_Wkly_NET_Sal := 0;
      PHIN := '';
      CI05_Balance := 0;
      CI05_Rate := 0;
      CI05_Status := '';
      CI05_Trlrcnt := 0;
      Mf_Cics_Status := 0;
      Mf_Cics_Msg := '';
      AverageEarningsBasedOn := '';
      overPaymentBal := 0;
      overPaymentBalDate := 0;
      Self_Employed := '';
      Recurrence := '';
      CPP_Exempt := '';
      Tax_Exempt := '';
      Child_Care_Exp := 0;
      Spousal_Support := 0;
      Child_Support := 0;
      Max_Adjustment := 0;
      RecurrenceDate := 0;
      Youthful_Worker := '';
      Apprentice := '';
      TaxCollBen_CPPQPP := 0;
      TaxCollBen_EI := 0;
      TaxCollBen_DisabilityIns := 0;
      TaxCollBen_EmpTopUp := 0;
      TaxCollBen_Combination := 0;
      NonTaxCollBen_EmpTopUp := 0;
      NonTaxCollBen_PrivateIns := 0;
      Min_Wage_Annual_Net_A := 0;
      Min_Wage_Total_Deds := 0;
      Minimum_wage := 0;
      Tax_Coll_Ben_Only := 0;
      Minimum_wage_Flag := false;
      Weekly_Shelter_Ben_Amount := 0;
      Pay_At_100_Flag := false;
      Weekly_Shelter_Ben_Amount_90 := 0;
      Minimum_Wage_Flag_Partial := false;
      Pay_At_100_Flag_Partial := false;
      DeathBenefit := 'N';
      effectiveDate := 0;
      net80DailyCompensationRateAmt := 0;
      partial80AfterClmtContribAmt := 0;
      week104StatusType := '';
      reducedNoDaysToPay := 0;
      reducedNoWeeksToPay := 0;
      Accum_Wks_Yr_90Net_Post := 0;
      workerAnnuityContributionPercent := 0;
      wcbAnnuityContributionPercent := 0;
      reportType := '';
      collateralTaxableAmt := 0;
      collateralNonTaxableAmt := 0;
      sumWeeksPaidQty := 0;
      paidOver52WeeksFlag := '';
      rejectionReasonDesc	:= '';
      actualWeeksPaidQty := 0;
      doNotBatchProcessFlag := '';
      payeeId := 0;
    end;
end;

function getMinimumWage (var recurrence: shortString; recurrenceDate, accidentDate: TDatetime): currency;
var
  lngReturn : Integer;
  testDate : String;
  oConnection:TADOConnection;
  oStoredProc:TADOStoredProc;
begin
  result := 0;

  oConnection := CreateConnection('core_sql_t','wageloss_db','wageloss_test','hello123');
  oStoredProc := CreateStoredProc(oConnection,'usp_Get_Minimum_Wage;1','@accidentdate',ftString,pdInput,10);

  try
    if recurrence = 'Y' Then
       begin
       testDate := FormatDateTime('mm/dd/yyyy',recurrenceDate);
       end
    else
       begin
       testDate := FormatDateTime('mm/dd/yyyy',accidentDate);
       end;

    oStoredProc.Parameters.ParamByName('@accidentDate').Value := testDate;
    oStoredProc.Open;

    if Not oStoredProc.Eof Then
       begin
       result := oStoredProc.FieldByName( 'minWage' ).Value;
       end;
    oStoredProc.Close;
  except
     on e:Exception do
        begin
        Result := 0;
        oStoredProc.Close;
        end;
  end;

  oStoredProc.Free;
  oConnection.Free;
end;

procedure minWageCalculation(var aCalcFullClaim, aCalcFullMinWageClaim, aCalcPartClaim: uNCClaim.recNCCLAIM; aDeathBenefitCalc: boolean);
var
  nc_index_amt: currency;
  nc_cnt, accidentYear: integer;
  wklyMinWage, yrlyMinWage: currency;
  fFullMinWage: uNCClaim.recConst;
begin
  //first copy info to minWage record
  CopyNCCLAIM( aCalcFullClaim, aCalcFullMinWageClaim );

  //get the yearly min wage and divide by 52 to weekly rate
  yrlyMinWage := getMinimumWage(aCalcFullClaim.Recurrence, aCalcFullClaim.RecurrenceDate, aCalcFullClaim.Accident_Date);
  wklyMinWage := yrlyMinWage / 52;

  if month( aCalcFullMinWageClaim.Accident_Date ) < 12 then
    accidentYear := year( aCalcFullMinWageClaim.Accident_Date ) + 2
  else
    accidentYear := year( aCalcFullMinWageClaim.Accident_Date ) + 3;

  nc_index_amt := wklyMinWage;

  for nc_cnt := accidentYear to aCalcFullMinWageClaim.Indexation_year do
  begin
    nc_index_amt := nc_index_amt * valueNCINDEXF( nc_cnt )
  end;

  //put the weekly and yearly minimum wage into CalcFullMinWageClaim
  aCalcFullMinWageClaim.Wkly_Sal_A := nc_index_amt;
  aCalcFullMinWageClaim.Minimum_wage := nc_index_amt * 52 ;
  aCalcFullClaim.Minimum_wage := nc_index_amt * 52;
  aCalcPartClaim.Minimum_wage := nc_index_amt * 52;

  //send to calculator
  NCBenCal(aCalcFullMinWageClaim, fFullMinWage);

  aCalcFullMinWageClaim.Min_Wage_Annual_Net_A := aCalcFullMinWageClaim.Annual_Net;
end;

procedure TaxCalcUnitTest.TaxTestBase92To05(const InjuryDate:String;const WeeklyWage,DaysPerWeek:Currency;
                          const TaxYear,YearIndexed:Integer;
                          const IndexedDate:String;
                          const Recurrence:String;
                          const RecurrenceDate:String;
                          const YouthfulWorker:String;
                          const LossOfEarningsDate:String;
                          const Apprentice,SelfEmployed,MaritalStatus,SpouseWorking:String;
                          const Dependants, InfirmDependants:Integer;
                          const EIExempt, CPPExempt,IncomeTaxExempt:String;
                          const EffectiveDate:String;
                          const MaxAdjustment:Currency;
                          const EarningsBasedOn:String;
                          const PostInjuryEarningsWkGross, CollateralTaxable:Currency; // CollateralCPP, CollateralEI, CollateralDisability, CollateralOther
                          const CollateralNonTaxable, PostInjuryEmployerTopUp, PostInjuryPrivateInsurance:Currency;
                          const DeemedEarnings:String;
                          const ChildCareExpense,ChildSupport,SpousalSupport:Currency;
                          const EFederalTax, EManitobaTax, ECPP, EEI, ETotalDeductions, ENetLossOfEarn, EWeekly90Net:Currency;
                          const EWeekly90Sheltered, EDaily90CompRate, E80WeeklyNet, EDaily80CompRate:Currency);
var
   Claim, PartialClaim:uNCClaim.recNCCLAIM;
   WorkingResult:uNCClaim.recConst;
   CurrentTaxCalculator:TTaxBase;
   AccidentMonth:Integer;
   Temp, savePost_Injury_Earn, WeeklyNet90A:Currency;
   ReturnMessage:string;
   ReturnCode:boolean;
begin
  //
  // Clear the claim records prior to populating
  //
  ClearNCCLAIM(Claim);
  ClearNCCLAIM(PartialClaim);
  //
  // Set the values of the claim record from the test input
  //
  Claim.Accident_Date := StrToDate(InjuryDate);
  Claim.Wkly_Sal := WeeklyWage;
  Claim.Wkly_Sal_A := WeeklyWage;
  Claim.Days_Worked_per_Week := DaysPerWeek;
  Claim.Tax_Year := TaxYear;
  Claim.Indexation_Year := YearIndexed;
  Claim.Recurrence := Recurrence;
  Claim.Youthful_Worker := YouthfulWorker;
  Claim.Apprentice := Apprentice;
  Claim.Self_Employed := SelfEmployed;
  Claim.Marital_Status := MaritalStatus;
  Claim.Spouse_Working := SpouseWorking;
  Claim.No_Of_Dependnts := Dependants;
  Claim.No_Infirm := InfirmDependants;
  Claim.EI_Exempt := EIExempt;
  Claim.CPP_Exempt := CPPExempt;
  Claim.Tax_Exempt := IncomeTaxExempt;
  Claim.effectiveDate := StrToDate(EffectiveDate);
  Claim.Max_Adjustment := MaxAdjustment;
  Claim.AverageEarningsBasedOn := EarningsBasedOn;
  Claim.Child_Care_Exp := ChildCareExpense;
  Claim.Child_Support := ChildSupport;
  Claim.Spousal_Support := SpousalSupport;
  Claim.Post_Injury_Earn := PostInjuryEarningsWkGross;
  Claim.Collateral_Ben_Tax := CollateralTaxable;
  Claim.collateralTaxableAmt := CollateralTaxable;
  Claim.TaxCollBen_CPPQPP := CollateralTaxable;
  Claim.TaxCollBen_EI := 0;
  Claim.TaxCollBen_DisabilityIns := 0;
  Claim.TaxCollBen_Combination := 0;
  //Claim.TaxCollBen_CPPQPP := CollateralCpp;
  //Claim.TaxCollBen_EI := CollateralEI;
  //Claim.TaxCollBen_DisabilityIns := CollateralDisability;
  //Claim.TaxCollBen_Combination := CollateralOther;
  Claim.NonTaxCollBen_EmpTopUp := PostInjuryEmployerTopUp;
  Claim.NonTaxCollBen_PrivateIns := PostInjuryPrivateInsurance;
  Claim.Deemed_Earnings := DeemedEarnings;
  //
  // Copy into the partial claim record if we have a partial wageloss
  //
  copyNCCLAIM( Claim, PartialClaim );
  
  savePost_Injury_Earn := Claim.Post_Injury_Earn;
  Claim.Post_Injury_Earn := 0.0;

  try
     NCBenCal(Claim, WorkingResult);
  finally
     ReturnMessage := Claim.ReturnMessage;
     ReturnCode := Claim.ReturnCode;
  end;

  if ReturnCode Then
     begin
     try
        NCBenCal(PartialClaim, WorkingResult);
        PartialClaim.Weekly_Net := PartialClaim.Weekly_Net + PartialClaim.Post_Injury_Earn_Net;
     finally
        ReturnMessage := Claim.ReturnMessage;
        ReturnCode := Claim.ReturnCode;
     end;

     if ReturnMessage = '' Then
        begin
        ReturnMessage := PartialClaim.ReturnMessage;
        end;

     if Claim.ReturnCode Then
        begin
        Claim.Post_Injury_Earn := savePost_Injury_Earn;
        end;
     end; //ReturnCode





  assert.AreEqual(EFederalTax, Claim.Inc_Tax_Fed,'Federal Tax MisMatch' +
                  ' Expected = ' + FloatToStr(EFederalTax) +
                  ' Actual = ' + FloatToStr(Claim.Inc_Tax_Fed));

  assert.AreEqual(EManitobaTax, Claim.Inc_Tax_Man,'Manitoba Tax MisMatch' +
                  ' Expected = ' + FloatToStr(EManitobaTax) +
                  ' Actual = ' + FloatToStr(Claim.Inc_Tax_Man));
  assert.AreEqual(ECPP, Claim.CPP_Prem,'CPP MisMatch' +
                  ' Expected = ' + FloatToStr(ECPP) +
                  ' Actual = ' + FloatToStr(Claim.CPP_Prem));
  assert.AreEqual(EEI, Claim.EI_Prem,'EI MisMatch' +
                  ' Expected = ' + FloatToStr(EEI) +
                  ' Actual = ' + FloatToStr(Claim.EI_Prem));
  assert.AreEqual(ETotalDeductions, Claim.Total_Deds,'Total Deductions MisMatch' +
                  ' Expected = ' + FloatToStr(EManitobaTax) +
                  ' Actual = ' + FloatToStr(Claim.Inc_Tax_Man));
  assert.AreEqual(ENetLossOfEarn, Claim.Weekly_Net,'Net Loss of Earnings MisMatch' +
                  ' Expected = ' + FloatToStr(ENetLossOfEarn) +
                  ' Actual = ' + FloatToStr(Claim.Weekly_Net_A));
  WeeklyNet90A := PDoxRound(Claim.Weekly_Net_A * 0.9,2);
  assert.AreEqual(EWeekly90Net, WeeklyNet90A,'Weekly 90 Net Actual MisMatch' +
                  ' Expected = ' + FloatToStr(EWeekly90Net) +
                  ' Actual = ' + FloatToStr(WeeklyNet90A));
  //assert.AreEqual(EWeekly90Net, Claim.Weekly_90,'Weekly 90 Net MisMatch' +
  //                ' Expected = ' + FloatToStr(EWeekly90Net) +
  //                ' Actual = ' + FloatToStr(Claim.Weekly_90));

  assert.AreEqual(EWeekly90Sheltered, Claim.Weekly_90_S,'Weekly 90 Sheltered MisMatch' +
                  ' Expected = ' + FloatToStr(EWeekly90Sheltered) +
                  ' Actual = ' + FloatToStr(Claim.Weekly_90_S));
  Temp := PDoxRound(Claim.Weekly_90_S/Claim.Days_Worked_per_Week,2);
  assert.AreEqual(EDaily90CompRate, Temp,'Daily 90 Comp Rate MisMatch' +
                  ' Expected = ' + FloatToStr(EDaily90CompRate) +
                  ' Actual = ' + FloatToStr(Round(Claim.Weekly_90_S/Claim.Days_Worked_per_Week)));
  assert.AreEqual(E80WeeklyNet, Claim.Weekly_80,'Weekly 80 Net MisMatch' +
                  ' Expected = ' + FloatToStr(E80WeeklyNet) +
                  ' Actual = ' + FloatToStr(Claim.Weekly_80));
  Temp := PDoxRound(Claim.Weekly_80/Claim.Days_Worked_per_Week,2);
  assert.AreEqual(EDaily80CompRate, Temp,'Daily 80 Comp Rate MisMatch' +
                  ' Expected = ' + FloatToStr(EDaily80CompRate) +
                  ' Actual = ' + FloatToStr(Round(Claim.Weekly_80/Claim.Days_Worked_per_Week)));
end;

procedure TaxCalcUnitTest.TaxTestBase06To(const InjuryDate:String;const WeeklyWage,DaysPerWeek:Currency;
                          const TaxYear,YearIndexed:Integer;
                          const Recurrence,YouthfulWorker,Apprentice,SelfEmployed,MaritalStatus,SpouseWorking:String;
                          const Dependants, InfirmDependants:Integer;
                          const EIExempt, CPPExempt,IncomeTaxExempt:String;
                          const EffectiveDate:String;
                          const MaxAdjustment:Currency;
                          const EarningsBasedOn:String;
                          const PostInjuryEarningsWkGross, CollateralCPP, CollateralEI, CollateralDisability, CollateralOther:Currency;
                          const PostInjuryEmployerTopUp, PostInjuryPrivateInsurance:Currency;
                          const DeemedEarnings:String;
                          const ChildCareExpense,ChildSupport,SpousalSupport:Currency;
                          const EFederalTax, EManitobaTax, ECPP, EEI, ETotalDeductions, ENetLossOfEarn, EWeekly90Net:Currency;
                          const EWeekly90Sheltered, EDaily90CompRate, E80WeeklyNet, EDaily80CompRate:Currency);
var
   Claim, PartialClaim, ClaimMinWage:uNCClaim.recNCCLAIM;
   WorkingResult:uNCClaim.recConst;
   CurrentTaxCalculator:TTaxBase;
   accidentMonth, accidentYear:Integer;
   Temp, yearlyMinWage, wklyMinWage:Currency;
   yearlyWageLessThenMin, yearlyWageLessThenMinPartial, ReturnCode:boolean;
   ReturnMessage:string;
begin
  //
  // Clear the claim records prior to populating
  //
  ClearNCCLAIM(Claim);
  ClearNCCLAIM(PartialClaim);
  Claim.Post_Injury_Earn := 0.0;
  yearlyWageLessThenMin := false;
  yearlyWageLessThenMinPartial := false;
  Claim.Pay_At_100_Flag := False;
  Claim.Pay_At_100_Flag_Partial := False;
  //
  // Set the values of the claim record from the test input
  //
  Claim.Accident_Date := StrToDate(InjuryDate);
  Claim.Wkly_Sal := WeeklyWage;
  Claim.Wkly_Sal_A := WeeklyWage;
  Claim.Days_Worked_per_Week := DaysPerWeek;
  Claim.Tax_Year := TaxYear;
  Claim.Indexation_Year := YearIndexed;
  Claim.Recurrence := Recurrence;
  Claim.Youthful_Worker := YouthfulWorker;
  Claim.Apprentice := Apprentice;
  Claim.Self_Employed := SelfEmployed;
  Claim.Marital_Status := MaritalStatus;
  Claim.Spouse_Working := SpouseWorking;
  Claim.No_Of_Dependnts := Dependants;
  Claim.No_Infirm := InfirmDependants;
  Claim.EI_Exempt := EIExempt;
  Claim.CPP_Exempt := CPPExempt;
  Claim.Tax_Exempt := IncomeTaxExempt;
  Claim.effectiveDate := StrToDate(EffectiveDate);
  Claim.Max_Adjustment := MaxAdjustment;
  Claim.AverageEarningsBasedOn := EarningsBasedOn;
  Claim.Child_Care_Exp := ChildCareExpense;
  Claim.Child_Support := ChildSupport;
  Claim.Spousal_Support := SpousalSupport;
  Claim.Post_Injury_Earn := PostInjuryEarningsWkGross;
  Claim.TaxCollBen_CPPQPP := CollateralCpp;
  Claim.TaxCollBen_EI := CollateralEI;
  Claim.TaxCollBen_DisabilityIns := CollateralDisability;
  Claim.TaxCollBen_Combination := CollateralOther;
  Claim.NonTaxCollBen_EmpTopUp := PostInjuryEmployerTopUp;
  Claim.NonTaxCollBen_PrivateIns := PostInjuryPrivateInsurance;
  Claim.Deemed_Earnings := DeemedEarnings;
  //
  // Copy into the partial claim record if we have a partial wageloss
  //
  copyNCCLAIM( Claim, PartialClaim );
  yearlyMinWage := getMinimumWage(Claim.Recurrence, Claim.RecurrenceDate, Claim.Accident_Date);

  wklyMinWage := yearlyMinWage / 52;


  //
  // We aren't testing indexing yet so this can be commented out now
  //

//  if month( Claim.Accident_Date ) < 12 then
//     accidentYear := year(Claim.Accident_Date) + 2
//  else
//     accidentYear := year(Claim.Accident_Date) + 3;

//  nc_index_amt := wklyMinWage;
//
//  for nc_cnt := accidentYear to Claim.Indexation_year do
//     begin
//     nc_index_amt := nc_index_amt * valueNCINDEXF( nc_cnt )
//     end;
//
//  Claim.Minimum_wage := nc_index_amt * 52;

  Claim.Minimum_wage := wklyMinWage;

  try
     //calc_ben( aCalcFullClaim, fWorking );
     NCBenCal(Claim, WorkingResult);
  finally
     ReturnMessage := Claim.ReturnMessage;
     ReturnCode := Claim.ReturnCode;
  end;

  if ReturnCode then
     begin
     minWageCalculation(Claim, ClaimMinWage, PartialClaim, false);
     end;

  //if gross earnings less then min then we pay at 100%; factor back up
  if Claim.Annual_Gross_A <= (ClaimMinWage.Minimum_wage + 0.00005 ) then
     begin
     //set flags
     yearlyWageLessThenMin := true;
     Claim.Pay_At_100_Flag := true;
     PartialClaim.Pay_At_100_Flag := true;
     end;



  //NCBenCal(Claim, WorkingResult);

  assert.AreEqual(EFederalTax, ClaimMinWage.Inc_Tax_Fed,'Federal Tax MisMatch' +
                  ' Expected = ' + FloatToStr(EFederalTax) +
                  ' Actual = ' + FloatToStr(ClaimMinWage.Inc_Tax_Fed));
  assert.AreEqual(EManitobaTax, ClaimMinWage.Inc_Tax_Man,'Manitoba Tax MisMatch' +
                  ' Expected = ' + FloatToStr(EManitobaTax) +
                  ' Actual = ' + FloatToStr(ClaimMinWage.Inc_Tax_Man));
  assert.AreEqual(ECPP, ClaimMinWage.CPP_Prem,'CPP MisMatch' +
                  ' Expected = ' + FloatToStr(ECPP) +
                  ' Actual = ' + FloatToStr(ClaimMinWage.CPP_Prem));
  assert.AreEqual(EEI, ClaimMinWage.EI_Prem,'EI MisMatch' +
                  ' Expected = ' + FloatToStr(EEI) +
                  ' Actual = ' + FloatToStr(ClaimMinWage.EI_Prem));
  assert.AreEqual(ETotalDeductions, ClaimMinWage.Total_Deds,'Total Deductions MisMatch' +
                  ' Expected = ' + FloatToStr(EManitobaTax) +
                  ' Actual = ' + FloatToStr(ClaimMinWage.Inc_Tax_Man));
  assert.AreEqual(ENetLossOfEarn, ClaimMinWage.Weekly_Net_A,'Net Loss of Earnings MisMatch' +
                  ' Expected = ' + FloatToStr(ENetLossOfEarn) +
                  ' Actual = ' + FloatToStr(ClaimMinWage.Weekly_Net_A));
  assert.AreEqual(EWeekly90Net, ClaimMinWage.Weekly_90,'Weekly 90 Net MisMatch' +
                  ' Expected = ' + FloatToStr(EWeekly90Net) +
                  ' Actual = ' + FloatToStr(ClaimMinWage.Weekly_90));

  assert.AreEqual(EWeekly90Sheltered, ClaimMinWage.Weekly_90_S,'Weekly 90 Sheltered MisMatch' +
                  ' Expected = ' + FloatToStr(EWeekly90Sheltered) +
                  ' Actual = ' + FloatToStr(ClaimMinWage.Weekly_90_S));
  Temp := PDoxRound(ClaimMinWage.Weekly_90_S/ClaimMinWage.Days_Worked_per_Week,2);
  assert.AreEqual(EDaily90CompRate, Temp,'Daily 90 Comp Rate MisMatch' +
                  ' Expected = ' + FloatToStr(EDaily90CompRate) +
                  ' Actual = ' + FloatToStr(Round(ClaimMinWage.Weekly_90_S/ClaimMinWage.Days_Worked_per_Week)));
  assert.AreEqual(E80WeeklyNet, ClaimMinWage.Weekly_80_S,'Weekly 80 Net MisMatch' +
                  ' Expected = ' + FloatToStr(E80WeeklyNet) +
                  ' Actual = ' + FloatToStr(ClaimMinWage.Weekly_80_S));
  Temp := PDoxRound(ClaimMinWage.Weekly_80_S/ClaimMinWage.Days_Worked_per_Week,2);
  assert.AreEqual(EDaily80CompRate, Temp,'Daily 80 Comp Rate MisMatch' +
                  ' Expected = ' + FloatToStr(EDaily80CompRate) +
                  ' Actual = ' + FloatToStr(Round(ClaimMinWage.Weekly_80_S/ClaimMinWage.Days_Worked_per_Week)));
end;

initialization
  TDUnitX.RegisterTestFixture(TaxCalcUnitTest);
end.
