//
// Modified March 5, 2003
// Modified by D. Madill
// modified to add return code checking from the TaxCalculator.dll
// and to display a Return Message if there is an error from the
// dll
//
Function RecalcBen(var aCalcFullClaim, aCalcPartClaim: recNCCLAIM; aDeathBenefitCalc: boolean): boolean;
var
  ReturnMessage : ShortString;
  yearlyMinWage, wklyMinWage, nc_index_amt, savePost_Injury_Earn : currency;
  nc_cnt, accidentYear : integer;
  ReturnCode, yearlyWageLessThenMin, yearlyWageLessThenMinPartial : Boolean;
  aCalcFullMinWageClaim, aCalcPartMinWageClaim: recNCCLAIM;
  fWorking: recConst;
begin
  if Year( aCalcFullClaim.Accident_Date ) >= 2006 Then // This is the 2006+ Calculation
  begin
    copyNCCLAIM( aCalcFullClaim, aCalcPartClaim );
    savePost_Injury_Earn := aCalcFullClaim.Post_Injury_Earn;
    aCalcFullClaim.Post_Injury_Earn := 0.0;
    yearlyWageLessThenMin := false;
    yearlyWageLessThenMinPartial := false;
    aCalcPartClaim.Pay_At_100_Flag := False;
    aCalcFullClaim.Pay_At_100_Flag := False;
    aCalcPartClaim.Pay_At_100_Flag_Partial := False;
    aCalcFullClaim.Pay_At_100_Flag_Partial := False;

    //first get min wage and set it in CalcFullClaim...need this to set fWorking properly
    yearlyMinWage := getMinimumWage(aCalcFullClaim.Recurrence, aCalcFullClaim.RecurrenceDate, aCalcFullClaim.Accident_Date, aDeathBenefitCalc );

    //original
    //CalcFullClaim.Minimum_wage := yearlyMinWage;
    //*********************************************************************//
    // Added Oct, 2006 - bcooper                                           //
    //*********************************************************************//
    wklyMinWage := yearlyMinWage / 52;

    if month( aCalcFullClaim.Accident_Date ) < 12 then
      accidentYear := year( aCalcFullClaim.Accident_Date ) + 2
    else
      accidentYear := year( aCalcFullClaim.Accident_Date ) + 3;

    nc_index_amt := wklyMinWage;

    for nc_cnt := accidentYear to aCalcFullClaim.Indexation_year do
    begin
      nc_index_amt := nc_index_amt * valueNCINDEXF( nc_cnt )
    end;

    aCalcFullClaim.Minimum_wage := nc_index_amt * 52;
    //*********************************************************************//

    try
       calc_ben( aCalcFullClaim, fWorking );
    Finally
      ReturnMessage := aCalcFullClaim.ReturnMessage;
      ReturnCode := aCalcFullClaim.ReturnCode;
    end;

    if ReturnCode then
    begin
      minWageCalculation(aCalcFullClaim, aCalcFullMinWageClaim, aCalcPartClaim, aDeathBenefitCalc);
    end;

     //if gross earnings less then min then we pay at 100%; factor back up
    if aCalcFullClaim.Annual_Gross_A <= ( aCalcFullMinWageClaim.Minimum_wage + 0.00005 ) then
    begin
      //set flags
      yearlyWageLessThenMin := true;
      aCalcFullClaim.Pay_At_100_Flag := true;
      aCalcPartClaim.Pay_At_100_Flag := true;
    end;

    //set some fields in full and part claim now that min calculation is done
    aCalcFullClaim.Min_Wage_Annual_Net_A := aCalcFullMinWageClaim.Min_Wage_Annual_Net_A;
    aCalcFullClaim.Tax_Coll_Ben_Only := aCalcFullClaim.Coll_Ben_Tax_Net;
    aCalcFullClaim.Min_Wage_Total_Deds := aCalcFullMinWageClaim.Total_Deds;

    //get sheltered amounts
    aCalcFullClaim.Weekly_Shelter_Ben_Amount_90 := getFullShelteredAmount( aCalcFullClaim );
    aCalcFullClaim.Weekly_Shelter_Ben_Amount := getMinShelteredAmount( aCalcFullMinWageClaim );

    aCalcPartClaim.Minimum_wage := aCalcFullMinWageClaim.Minimum_wage;
    aCalcPartClaim.Min_Wage_Annual_Net_A := aCalcFullMinWageClaim.Min_Wage_Annual_Net_A;
    aCalcPartClaim.Tax_Coll_Ben_Only := aCalcFullClaim.Coll_Ben_Tax_Net;
    aCalcPartClaim.Min_Wage_Total_Deds := aCalcFullMinWageClaim.Total_Deds;

    if ReturnCode Then
    Begin
      try
        calc_ben( aCalcpartClaim, fWorking );
      Finally
        ReturnMessage := aCalcFullClaim.ReturnMessage;
        ReturnCode := aCalcFullClaim.ReturnCode;

        if aCalcPartClaim.Annual_Gross_A <= ( aCalcFullMinWageClaim.Minimum_wage + 0.00005 ) then
        begin
          //set flags
          yearlyWageLessThenMinPartial := true;
          aCalcPartClaim.Pay_At_100_Flag_Partial := true;
          aCalcFullClaim.Pay_At_100_Flag_Partial := true;
        end;

        //set some fields in full and part claim now that min calculation is done
        aCalcPartClaim.Minimum_wage := aCalcFullMinWageClaim.Minimum_wage;
        aCalcPartClaim.Min_Wage_Annual_Net_A := aCalcFullMinWageClaim.Min_Wage_Annual_Net_A;
        aCalcPartClaim.Tax_Coll_Ben_Only := aCalcFullClaim.Coll_Ben_Tax_Net;
        aCalcPartClaim.Min_Wage_Total_Deds := aCalcFullMinWageClaim.Total_Deds;
        aCalcPartClaim.Weekly_Shelter_Ben_Amount := aCalcFullClaim.Weekly_Shelter_Ben_Amount;
        aCalcPartClaim.Weekly_Shelter_Ben_Amount_90 := aCalcFullClaim.Weekly_Shelter_Ben_Amount_90;
        //********************************************************************
      end; // end of try Finally

      if ReturnMessage = '' Then
      Begin
        ReturnMessage := aCalcpartClaim.ReturnMessage;
      End;

      if aCalcFullClaim.ReturnCode Then
      Begin
        aCalcFullClaim.Post_Injury_Earn := savePost_Injury_Earn;
      End;
    End; //if ReturnCode

    //check to see if their actual weekly rate is less then the min wage weekly rate
    //going to go after their Annual_Net + CollateralBenefits; this is their weekly max benefit for FULL
    //
    if ( aCalcFullClaim.Weekly_90_S < aCalcFullMinWageClaim.Weekly_90_S )
      and ( not yearlyWageLessThenMin ) then
    begin
      CopyMinWageClaim( aCalcFullClaim, aCalcFullMinWageClaim );
    end;

    //do calc for a partial claim as well
    if ReturnCode then
    begin
      minWagePartCalculation(aCalcFullClaim, aCalcPartClaim, aCalcFullMinWageClaim, aCalcPartMinWageClaim, aDeathBenefitCalc);
    end;

    //check partial wage against min as well
    if ( aCalcPartClaim.Weekly_90_S < aCalcPartMinWageClaim.Weekly_90_S )
      and ( not yearlyWageLessThenMinPartial ) then
    begin
      CopyMinWageClaim( aCalcPartClaim, aCalcPartMinWageClaim );
      aCalcPartClaim.Minimum_Wage_Flag_Partial := true;
    end;

    if ( Not ReturnCode ) OR ( ReturnMessage <> '' ) Then
    Begin
      // set on opening for the first time
      //if not ( self.ActiveControl.Name = edWkly_Sal_A.Name ) then
      //  WagelossMainForm.ShowInfoLine2( CalcFullClaim.ReturnMessage )
      //else
      //  ResetInfoLine2;
    End;
  end
  else  // 2005 and below rebalc
  begin
    copyNCCLAIM( aCalcFullClaim, aCalcPartClaim );
    savePost_Injury_Earn := aCalcFullClaim.Post_Injury_Earn;
    aCalcFullClaim.Post_Injury_Earn := 0.0;

    try
      calc_ben( aCalcFullClaim, fWorking );
    Finally
      ReturnMessage := aCalcFullClaim.ReturnMessage;
      ReturnCode := aCalcFullClaim.ReturnCode;
    end;

    if ReturnCode Then
    Begin
      try
        calc_ben( aCalcpartClaim, fWorking );
        aCalcPartClaim.Weekly_Net := aCalcPartClaim.Weekly_Net + aCalcPartClaim.Post_Injury_Earn_Net;
      Finally
         ReturnMessage := aCalcFullClaim.ReturnMessage;
         ReturnCode := aCalcFullClaim.ReturnCode;
      end;

      if ReturnMessage = '' Then
      Begin
        ReturnMessage := aCalcpartClaim.ReturnMessage;
      End;

      if aCalcFullClaim.ReturnCode Then
      Begin
        aCalcFullClaim.Post_Injury_Earn := savePost_Injury_Earn;
      End;
    End; //ReturnCode

    if ( Not ReturnCode ) OR ( ReturnMessage <> '' ) Then
    Begin
      // set on opening for the first time
      //if not ( self.ActiveControl.Name = edWkly_Sal_A.Name ) then
      //   WagelossMainForm.ShowInfoLine2( CalcFullClaim.ReturnMessage )
      //else
      //   ResetInfoLine2;
    end;
  end;
  result := true;
end;
