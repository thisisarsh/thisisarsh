insert into selfEmployedMax
(
 maxSelfEmployed
,effectiveDate
,userid
,dateTimeStamp
,minSelfEmployed
)
Values
(513990.00
,'1 jan 2020'
,1
,GETDATE()
,25290.00
)
