insert into minimumWage
(
 minWage
,effectiveDate
,userid
,dateTimeStamp
)
Values
(23192.00
,'1 jan 2018'
,1
,GETDATE()
)