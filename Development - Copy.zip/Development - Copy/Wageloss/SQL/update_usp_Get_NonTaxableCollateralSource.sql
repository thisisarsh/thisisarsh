ALTER PROCEDURE usp_Get_NonTaxableCollateralSource
	@Claim_No	CHAR(8)
AS

SELECT	
	Claim_No,
	EmpTopUp,
	PrivateIns,
	EmpTopUp + PrivateIns As TotalNonTaxableCollateral
FROM	
	tbl_NonTaxableCollateralSource
WHERE
	Claim_No	= @Claim_No AND	
	Modification_Date =  	
		(
			SELECT TOP 1 Modification_Date
			FROM tbl_NonTaxableCollateralSource
			WHERE Claim_No	= @Claim_No
			ORDER BY Modification_Date DESC
		)

GO
