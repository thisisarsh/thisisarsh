/*
   Date: 10/04/2006
   User: BCOOPER
   Server: WCBAP12
   Database: wageloss_db
*/

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[usp_Get_NonTaxableCollateralSource]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[usp_Get_NonTaxableCollateralSource]
GO


CREATE PROCEDURE usp_Get_NonTaxableCollateralSource
	@Claim_No	Char(8)
AS

SELECT	Claim_No,
	EmpTopUp,
	PrivateIns,
	EmpTopUp + PrivateIns As TotalNonTaxableCollateral
FROM	tbl_NonTaxableCollateralSource
WHERE	Claim_No	= @Claim_No
And	Modification_Date	in 	
				(
				Select 	Max(Modification_Date)
				From 	tbl_NonTaxableCollateralSource
				Where	Claim_No	= @Claim_No
				)

GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

GRANT  EXECUTE  ON [dbo].[usp_Get_NonTaxableCollateralSource]  TO [wageloss_adm]
GO