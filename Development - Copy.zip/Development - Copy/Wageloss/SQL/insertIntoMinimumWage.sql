use wageloss_db

INSERT INTO wageloss_db..minimumWage
           (minWage, effectiveDate, userid, dateTimeStamp)
VALUES     (18370, '01-Jan-09', 1, GETDATE())
