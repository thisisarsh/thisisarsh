ALTER PROCEDURE usp_Save_NonTaxableCollateralSource
	@Claim_No CHAR(8),
	@EmpTopUp	MONEY,
	@PrivateIns MONEY,
	@Current_User VARCHAR(50)
AS

IF NOT EXISTS	
	(
		SELECT 1
		FROM 
			tbl_NonTaxableCollateralSource
		WHERE 
			Claim_No = @Claim_No AND	
			EmpTopUp = @EmpTopUp AND
			PrivateIns = @PrivateIns AND 
			Modification_Date = 
				(
					SELECT TOP 1 Modification_Date
					FROM tbl_NonTaxableCollateralSource
					WHERE Claim_No	= @Claim_No
					ORDER BY Modification_Date DESC
				) 
	)
	BEGIN
	INSERT INTO tbl_NonTaxableCollateralSource
		(
			Claim_No,
			EmpTopUp,
			PrivateIns,
			Modification_User,
			Modification_Date
		)
	VALUES
		(
			@Claim_No,
			@EmpTopUp,
			@PrivateIns,
			@Current_User,
			GETDATE()
		)
	END

GO
