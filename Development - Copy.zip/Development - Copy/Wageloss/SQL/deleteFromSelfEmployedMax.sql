use wageloss_db
 
DELETE FROM wageloss_db..selfEmployedMax
WHERE 
effectiveDate = '01-01-2009'