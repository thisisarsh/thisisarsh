SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

if exists (select * from sysobjects where id = object_id('dbo.vwWageLossOverMax') and sysstat & 0xf = 2)
	drop view dbo.vwWageLossOverMax
GO

CREATE VIEW vwWageLossOverMax AS

SELECT
	WageLossCalcFactor.claimNo AS claimNo,
	52 * WageLossCalcFactor.fullWeeklyGrossAmt AS Yearly_Pre_Acc,
	WageLossCalcFactor.fullWeeklyGrossAmt AS Weekly_Pre_Acc,
	WageLossCalcFactor.fullWeekly90NetShelteredAmt AS WCB_Weekly_Rate,
	PaymentItem.paidAmt AS Amount_Paid,
	PaymentItem.daysPaidQty AS Number_of_days_paid,
	Final_Payment = 
		CASE WageLossPaymentRequest.paymentType
			WHEN 'Final' THEN 'yes'
			ELSE 'no'
		END,
	vwEmployerName.firmName1 AS Employer,
	Occupation.jobTitleDesc AS Job_Title,
	InjuryDetails.areaOfInjuryDescription AS Injury,

-- 	cheque_no,

	PaymentItem.fromDate AS paid_from_date,
	PaymentItem.toDate AS paid_to_date,
	CASE
		WHEN PaymentRemittance.paymentDate IS NOT NULL THEN PaymentRemittance.paymentDate
		ELSE PaymentItem.businessDate
	END AS paid_cost_date,
	ClaimPaymentSummary.firstPaymentDate AS first_payment_date,
	Claim.accidentDate AS accidentdate,
	WageLossCalcFactor.wagelossCalcFactorId AS uniqueness,
	'0' AS wageloss_uniqueness,

-- 	paid_cost_type_1.sequence,

	Claim.firmNo AS firm_number
FROM  
	emerge_db..Claim Claim
	INNER JOIN emerge_db..ClaimPaymentSummary ClaimPaymentSummary ON Claim.claimNo = ClaimPaymentSummary.claimNo
	INNER JOIN wageloss_db..WageLossCalcFactor WageLossCalcFactor ON Claim.claimNo = WageLossCalcFactor.claimNo
	INNER JOIN emerge_db..WageLossPaymentRequest WageLossPaymentRequest ON WageLossCalcFactor.wageLossCalcFactorId = WageLossPaymentRequest.wageLossCalcFactorId
	INNER JOIN emerge_db..PaymentRequest PaymentRequest ON WageLossPaymentRequest.paymentRequestId = PaymentRequest.paymentRequestId 
		AND Claim.claimNo = PaymentRequest.claimNo
	INNER JOIN emerge_db..PaymentItem PaymentItem ON PaymentRequest.paymentRequestId = PaymentItem.paymentRequestId
		AND Claim.claimNo = PaymentItem.claimNo
	INNER JOIN emerge_db..PaymentRemittance PaymentRemittance ON PaymentItem.paymentRemittanceId = PaymentRemittance.paymentRemittanceId
	INNER JOIN emerge_db..vwEmployerName vwEmployerName ON Claim.firmNo = vwEmployerName.firmNo
		AND Claim.firmSuffix = vwEmployerName.firmSuffix
	INNER JOIN emerge_db..Occupation Occupation ON Occupation.claimNo = Claim.claimNo
	INNER JOIN emerge_db..InjuryDetails InjuryDetails ON Claim.claimNo = InjuryDetails.claimNo
WHERE
	YEAR( ClaimPaymentSummary.firstPaymentDate ) = YEAR( DATEADD( MONTH, -1, GETDATE() ) )
	AND MONTH( ClaimPaymentSummary.firstPaymentDate ) = MONTH( DATEADD( MONTH, -1, GETDATE() ) )
	AND WageLossCalcFactor.fullAnnualGrossAmt > 60490


GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

GRANT  SELECT  ON dbo.vwWageLossOverMax  TO public
GO
