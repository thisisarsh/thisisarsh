ALTER PROCEDURE usp_Get_Weekly_Sal_History
	@Claim_No	CHAR(8),
	@Index_Year NUMERIC
AS

SELECT
	Claim_No,
	New_Weekly_Wage,
	Old_Weekly_Wage
FROM	
	tbl_Weekly_Sal_History
WHERE
	Claim_No = @Claim_No AND
	Index_Year = @Index_Year AND
	Modification_Date = 
		(
			SELECT 
				TOP 1 Modification_Date
			FROM 
				tbl_Weekly_Sal_History
			WHERE
				Claim_No = @Claim_No AND
				Index_Year = @Index_Year
			ORDER BY Modification_Date DESC
		)

GO
