USE wageloss_db

INSERT INTO wageloss_db..selfEmployedMax(maxSelfEmployed, effectiveDate, userid, dateTimeStamp)
VALUES(19673, '01-01-2009', 1, GETDATE())