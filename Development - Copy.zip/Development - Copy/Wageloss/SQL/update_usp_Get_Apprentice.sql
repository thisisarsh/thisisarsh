ALTER PROCEDURE usp_Get_Apprentice
	@Claim_No	CHAR(8)
AS

SELECT	
	Claim_No,
	Apprentice
FROM	
	tbl_Apprentice
WHERE
	Claim_No = @Claim_No AND
	Modification_Date =  	
		(
			SELECT TOP 1 Modification_Date
			FROM tbl_Apprentice
			WHERE Claim_No	= @Claim_No
			ORDER BY Modification_Date DESC
		) AND
	Active = 'Y'
GO

