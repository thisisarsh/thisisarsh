USE [emerge_db];
GO
SET ANSI_NULLS ON;
GO
SET QUOTED_IDENTIFIER OFF;
GO
ALTER   PROCEDURE [dbo].[uspGetWageLossCalcFactor]
 @claimNo Int
AS

 SET NOCOUNT ON

 
DECLARE @tempWageLossCalcFactorId AS INT
DECLARE @maritalStatusType AS VARCHAR(75)
 
-- Get marital status
-- Check to see if there's a record in the WageLossCalcFactor table for this claim
SET @tempWageLossCalcFactorId = 
(
 SELECT TOP 1
  wlcf.wageLossCalcFactorId
 FROM
  emerge_db..Claim claim
 FULL OUTER JOIN wageloss_db.dbo.WageLossCalcFactor wlcf ON 
  wlcf.claimNo = claim.claimNo
 WHERE
  claim.claimNo = @claimNo
 ORDER BY 
  wlcf.wageLossCalcFactorId DESC
)
 
-- If there is a record then set the marital status to whatever is in the wlcf table
IF @tempWageLossCalcFactorId IS NOT NULL
BEGIN
 
 SET @maritalStatusType =
 (
  SELECT TOP 1
   wlcf.maritalStatusType
  FROM
   wageloss_db..WageLossCalcFactor wlcf
  WHERE
   wlcf.claimNo = @claimNo
  ORDER BY 
   wlcf.wageLossCalcFactorId DESC
 )
END
-- If there is no record, then set the marital status to whatever is in the MaritalStatus table
ELSE IF @tempWageLossCalcFactorId IS NULL
BEGIN
 SET @maritalStatusType =
 (
  SELECT
   MaritalStatus.maritalStatusType
  FROM
   emerge_db..Claim claim
   FULL OUTER JOIN emerge_db..MaritalStatus maritalStatus ON
   claim.claimantId = maritalStatus.claimantId
  WHERE
   claim.claimNo = @claimNo
 )
END
 
SELECT
 TOP 1
 claim.claimNo,
 wlcf.wageLossCalcFactorId,
 wlcf.effectiveDate,
 address.addressLine1,
 address.addressLine2,
 address.municipalityName + ', ' + address.provinceName AS addressLine3,
 address.postalCode,
 claim.firmNo,
 claim.accidentDate,
 claimant.birthDate,
 claimant.phinNumber,
 claimant.socialInsuranceNo,
 desk.deskName,
 person.firstName,
 person.lastName,
 claimPaymentSummary.compensationDaysPaidQty,
 claimPaymentSummary.compensationPaidTo63TaskFlag,
 claimPaymentSummary.compensationWeeksPaidTo63Qty,
 claimPaymentSummary.totalCompensationAmt,
 claimPaymentSummary.wcbAnnuityEarningsAmt,
 claimPaymentSummary.wcbContributionAmt,
 claimPaymentSummary.weeksPaidQty,
 claimPaymentSummary.workerAnnuityEarningsAmt,
 claimPaymentSummary.workerContributionAmt, 
 wlcf.avgEarningsBasedOnType,
 wlcf.childCareExpenseAmt,
 wlcf.childSupportAmt,
 wlcf.claimantReplyDate,
 wlcf.claimantContributionEffectiveDate AS claimantContribEffectiveDate,
 wlcf.collateralNonTaxableAmt,
 wlcf.collateralTaxableAmt,
 wlcf.collateralTaxableNetAmt,
 wlcf.commentText,
 wlcf.cppExemptFlag,
 wlcf.cppPremiumAmt,
 wlcf.cppPremiumShelteredAmt,
 wlcf.creationLoginName,
 wlcf.creationDatetime,
 wlcf.daysWorkedPerWeekQty,
 wlcf.deemedFlag,
 wlcf.dependentsQty,
 wlcf.effective80Date,
 wlcf.fullAnnual80NetLossAmt,
 wlcf.fullAnnual80NetShelteredAmt,
 wlcf.fullAnnual90NetLossAmt,
 wlcf.fullAnnual90NetShelteredAmt,
 wlcf.fullAnnualGrossAmt,
 wlcf.fullAnnualNetLossEarnAmt,
 wlcf.fullClmntContribAmt,
 wlcf.partialClmntContribAmt,
 wlcf.fullClmntPercentContribAmt,
 wlcf.partialClmntPercentContribAmt,
 wlcf.fullWCBContribAmt,
 wlcf.fullWCBPercentContribAmt,
 wlcf.fullWeekly80NetLossAmt,
 wlcf.partial80NetLossAmt,
 wlcf.fullWeekly80NetShelteredAmt,
 wlcf.partial80NetShelteredAmt,
 wlcf.fullWeekly90NetActualAmt,
 wlcf.fullWeekly90NetLossAmt,
 wlcf.partial90NetLossEarnAmt,
 wlcf.partial90NetShelteredAmt,
 wlcf.fullWeekly90NetShelteredAmt,
 wlcf.fullWeeklyNetLossEarnAmt,
 wlcf.hourlyBenefitRateAmt,
 wlcf.incomeTaxExemptFlag,
 wlcf.incomeTaxFederalAmt,
 wlcf.incomeTaxFederalShelteredAmt,
 wlcf.incomeTaxProvincialAmt,
 wlcf.incomeTaxProvincialShelteredAmt AS incomeTaxProvShelteredAmt,
 wlcf.indexedDate,
 wlcf.indexedYear,
 wlcf.infirmDependentsQty,
 wlcf.lossOfEarningsDate,
 @maritalStatusType AS maritalStatusType,
 wlcf.maximumAdjustmentAmt,
 wlcf.postEarnWeeklyGrossAmt,
 wlcf.postEarnWeeklyNetAmt,
 wlcf.recurrenceFlag,
 wlcf.selfEmployedFlag,
 wlcf.spousalSupportAmt,
 wlcf.spouseWorkingFlag,
 wlcf.taxYear,
 wlcf.totalDeductionsAmt,
 wlcf.totalDeductionsShelteredAmt,
 wlcf.uicExemptFlag,
 wlcf.uicPremiumAmt,
 wlcf.uicPremiumShelteredAmt,
 wlcf.week104StatusType,
 wlcf.weeklyClaimantAnnuityContributionShelteredAmt AS wklyClmtAntyContribShelterAmt,
 wlcf.weeklyWageAmt,
 wlcf.weeklyWCBAnnuityContributionAmt AS weeklyWCBAnnuityContribAmt,
 wlcf.weeklyWCBAnnuityContributionShelteredAmt AS wklyWCBAntyContribShelterAmt,
 wlcf.wcbAnnuityReductionPercentageAmt,
 wlcf.reducedNoDaysToPayQty,
 wlcf.reducedNoWeeksToPayQty
FROM 
 emerge_db.dbo.Claim claim
 FULL OUTER JOIN emerge_db.dbo.Claimant claimant ON 
  claimant.claimantId = claim.claimantId
 FULL OUTER JOIN emerge_db.dbo.Person person ON 
  person.personId = claimant.personId
 FULL OUTER JOIN emerge_db.dbo.PersonAddress personAddress ON 
  personAddress.personId = claimant.personId
 FULL OUTER JOIN emerge_db.dbo.Address address ON 
  address.addressId = personAddress.addressId
 FULL OUTER JOIN emerge_db.dbo.Desk desk ON 
  desk.deskId = claim.deskId
 FULL OUTER JOIN emerge_db.dbo.ClaimPaymentSummary claimPaymentSummary ON 
  claimPaymentSummary.claimNo = claim.claimNo
 FULL OUTER JOIN wageloss_db.dbo.WageLossCalcFactor wlcf ON 
  wlcf.claimNo = claim.claimNo
WHERE
 claim.claimNo = @claimNo
ORDER BY 
 wlcf.wageLossCalcFactorId DESC

GO
