

Alter 	TABLE 	[EntitlementPayment] ADD [NumberofPayments] [int] NULL 

GO


alter table EntitlementPayment ALTER COLUMN paymentFromDate DateTime NULL 

Go


