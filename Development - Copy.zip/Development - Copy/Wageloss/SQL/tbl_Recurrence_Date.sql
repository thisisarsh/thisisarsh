if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[tbl_Recurrence_Date]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table [dbo].[tbl_Recurrence_Date]
GO

CREATE TABLE [dbo].[tbl_Recurrence_Date] (
	[Claim_No] 		[Char] (8) NOT NULL ,
	[Recurrence_Date] 	[DateTime] NOT NULL ,
	[Active] 		[Char] (1) NOT NULL ,
	[Modification_Date] 	[DateTime] NULL ,
	[Modification_User] 	[VarChar] (16) NULL 
) ON [PRIMARY]
GO

CREATE 	CLUSTERED INDEX tbl_Recurrence_Date_Claim_No_Idx 
	ON [tbl_Recurrence_Date]
	(Claim_No, Modification_Date)
ON [Primary]