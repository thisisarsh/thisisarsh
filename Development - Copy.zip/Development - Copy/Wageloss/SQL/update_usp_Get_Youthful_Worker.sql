ALTER PROCEDURE usp_Get_Youthful_Worker
	@Claim_No	CHAR(8)
AS

SELECT
	Claim_No,
	Youthful_Worker
FROM	
	tbl_Youthful_Worker
WHERE
	Claim_No = @Claim_No AND
	Modification_Date = 	
		(
			SELECT TOP 1 Modification_Date
			FROM tbl_Youthful_Worker
			WHERE Claim_No	= @Claim_No
			ORDER BY Modification_Date DESC
		) AND
	Active = 'Y'
GO
