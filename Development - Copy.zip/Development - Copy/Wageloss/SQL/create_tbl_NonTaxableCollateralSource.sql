/*
   Date: 10/04/2006
   User: BCOOPER
   Server: WCBAP12
   Database: wageloss_db
*/

CREATE TABLE [tbl_NonTaxableCollateralSource] (
	[Claim_No] [char] (8) NOT NULL ,
	[EmpTopUp] [money] NOT NULL ,
	[PrivateIns] [money] NOT NULL ,
	[Modification_Date] [datetime] NULL ,
	[Modification_User] [varchar] (16) NULL 
)

