/*
   Date: 10/04/2006
   User: BCOOPER
   Server: WCBAP12
   Database: wageloss_db
*/

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[usp_Save_NonTaxableCollateralSource]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[usp_Save_NonTaxableCollateralSource]
GO


CREATE PROCEDURE usp_Save_NonTaxableCollateralSource
	@Claim_No		Char(8),
	@EmpTopUp		Money,
	@PrivateIns		Money,
	@Current_User		VarChar(50)
AS

If	Not Exists	(
		Select	1
		From	tbl_NonTaxableCollateralSource
		Where	Claim_No		= @Claim_No
		And	EmpTopUp		= @EmpTopUp
		And	PrivateIns		= @PrivateIns
		And	Modification_Date	in 
						(
						Select 	Max(Modification_Date)
						From 	tbl_NonTaxableCollateralSource
						Where	Claim_No	= @Claim_No
						) 
			)
	Begin
	Insert	Into	tbl_NonTaxableCollateralSource
		(
		Claim_No,
		EmpTopUp,
		PrivateIns,
		Modification_User,
		Modification_Date
		)
	Values	(
		@Claim_No,
		@EmpTopUp,
		@PrivateIns,
		@Current_User,
		GetDate()
		)
	End

GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

GRANT  EXECUTE  ON [dbo].[usp_Save_NonTaxableCollateralSource]  TO [wageloss_adm]
GO