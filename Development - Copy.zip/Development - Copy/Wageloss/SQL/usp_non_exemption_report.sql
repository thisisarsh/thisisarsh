
------------------------------------------------------------------------------------
-- STORED PROCEDURE:	usp_non_exemption_report 				  --
-- AUTHOR:		Elliot Cunningham                                         --
-- DATE:		18/11/2003						  --
-- DESCRIPTION:         Stored procedure returns the result set for the Top-up    --
			Non Exemption Report                                      --
------------------------------------------------------------------------------------

CREATE  PROCEDURE dbo.usp_non_exemption_report
		  @start_date datetime

AS
SET XACT_ABORT ON

SELECT claim_no, 
       claim_suffix, 
       firm_number,
       CASE
	WHEN no_weeks_of_comp_benefits >= 0 AND no_weeks_of_comp_benefits <= 0.5 THEN 1
	ELSE 0
        END AS InitialPayment,
       CASE
	WHEN no_weeks_of_comp_benefits >= 11.5 AND no_weeks_of_comp_benefits <= 12.5 THEN 1
	ELSE 0
	END AS TwelveWeeks,
       CASE
	WHEN no_weeks_of_comp_benefits >= 63.5 AND no_weeks_of_comp_benefits <= 64.5 THEN 1
	ELSE 0
	END AS SixtyFourWeeks,
       CASE
	WHEN no_weeks_of_comp_benefits >= 103.5 AND no_weeks_of_comp_benefits <= 104.5 THEN 1
	ELSE 0
	END AS OneHundredFourWeeks
FROM csd_info_db..claims_master
WHERE topup_allow_ind = 'N'
AND first_payment_date >= @start_date
AND ((no_weeks_of_comp_benefits >= 0 AND no_weeks_of_comp_benefits <= 0.5)
OR (no_weeks_of_comp_benefits >= 11.5 AND no_weeks_of_comp_benefits <= 12.5)
OR (no_weeks_of_comp_benefits >= 63.5 AND no_weeks_of_comp_benefits <= 64.5)
OR (no_weeks_of_comp_benefits >= 103.5 AND no_weeks_of_comp_benefits <= 104.5))
Order BY CASE
	WHEN no_weeks_of_comp_benefits >= 0 AND no_weeks_of_comp_benefits <= 0.5 THEN 1
	ELSE 0
        END DESC,
       CASE
	WHEN no_weeks_of_comp_benefits >= 11.5 AND no_weeks_of_comp_benefits <= 12.5 THEN 1
	ELSE 0
	END DESC,
       CASE
	WHEN no_weeks_of_comp_benefits >= 63.5 AND no_weeks_of_comp_benefits <= 64.5 THEN 1
	ELSE 0
	END DESC,
       CASE
	WHEN no_weeks_of_comp_benefits >= 103.5 AND no_weeks_of_comp_benefits <= 104.5 THEN 1
	ELSE 0
	END DESC
GO
