ALTER TABLE dbo.WageLossReports DROP CONSTRAINT PK_WageLossReports
GO

ALTER TABLE WageLossReports ALTER COLUMN Report_Time char(12) NOT NULL
GO

ALTER TABLE [dbo].[WageLossReports] ADD 
	CONSTRAINT [PK_WageLossReports] PRIMARY KEY  CLUSTERED 
	(
		[Claim_No],
		[ReportId],
		[Reporting_User],
		[Report_Time],
		[Report_Date]
	)  ON [PRIMARY] 
GO