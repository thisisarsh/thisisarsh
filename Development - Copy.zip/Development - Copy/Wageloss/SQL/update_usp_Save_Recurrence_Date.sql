ALTER PROCEDURE usp_Save_Recurrence_Date
	@Claim_No	CHAR(8),
	@Recurrence_Date DATETIME,
	@Active CHAR(1),
	@Current_User VARCHAR(50)
AS

IF NOT EXISTS
	(
		SELECT 1
		FROM 
			tbl_Recurrence_Date
		WHERE
			Claim_No = @Claim_No AND
			Recurrence_Date = @Recurrence_Date AND
			Modification_Date = 
				(
					SELECT TOP 1 Modification_Date
					FROM tbl_Recurrence_Date
					WHERE Claim_No	= @Claim_No
					ORDER BY Modification_Date DESC
				) 
	)
	BEGIN
	INSERT INTO tbl_Recurrence_Date
		(
			Claim_No,
			Recurrence_Date,
			Active,
			Modification_Date,
			Modification_User
		)
	VALUES
		(
			@Claim_No,
			@Recurrence_Date,
			@Active,
			GETDATE(),
			@Current_User
		)
	END

GO
