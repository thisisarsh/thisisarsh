CREATE  INDEX 
	idxClaimNoModificationDate
	ON dbo.tbl_Apprentice( Claim_No, Modification_Date ) 
	WITH  FILLFACTOR = 90 ON PRIMARY
GO

