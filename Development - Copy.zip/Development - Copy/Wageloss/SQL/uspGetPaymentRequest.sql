DECLARE @table VARCHAR(40),
        @DROP VARCHAR(40)
set @TABLE = 'uspGetPaymentRequest'

PRINT 'CREATE  PROCEDURE ' + @TABLE + ' start ' + convert(varchar(25),getdate(),120)

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[uspGetPaymentRequest]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[uspGetPaymentRequest]

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

CREATE  PROCEDURE uspGetPaymentRequest
 @claimNo Int
AS
 
SELECT
 claim.claimNo,
 wageLossPaymentRequest.wageLossCalcFactorId,
 paymentItem.paidAmt,
 paymentItem.fromDate,
 paymentItem.toDate,
 wageLossPaymentRequest.employerTopUpFlag
FROM 
 emerge_db.dbo.Claim claim
 INNER JOIN emerge_db.dbo.PaymentRequest paymentRequest ON 
  paymentRequest.claimNo = claim.claimNo
 INNER JOIN emerge_db.dbo.WageLossPaymentRequest wageLossPaymentRequest ON 
  wageLossPaymentRequest.paymentRequestId = paymentRequest.paymentRequestId
 INNER JOIN emerge_db.dbo.PaymentItem paymentItem ON 
  paymentItem.paymentRequestId = paymentRequest.paymentRequestId
WHERE
 claim.claimNo = @claimNo
ORDER BY wageLossPaymentRequest.wageLossCalcFactorId DESC

GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

if @@ERROR <>  0
    BEGIN
      PRINT '*******************************************************************'     
      PRINT 'CREATE PROCEDURE uspGetPaymentRequest ended in an error state' 
      RAISERROR ('ERROR  SQL statement.', 16, 127)
    END
else PRINT 'CREATE PROCEDURE uspGetPaymentRequest successful at ' + convert(varchar(25),getdate(),120)