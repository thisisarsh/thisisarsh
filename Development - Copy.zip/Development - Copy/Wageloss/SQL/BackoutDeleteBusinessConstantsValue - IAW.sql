USE emerge_db

-- Backout - CPI value
DELETE FROM BusinessConstantValue
WHERE 
	businessConstantValueId = 47 AND 
	businessConstantId = 1