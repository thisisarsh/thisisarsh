USE wageloss_db

DECLARE @table VARCHAR(40),
        @DROP VARCHAR(40)
set @TABLE = 'WageLossCalcFactor'

PRINT 'CREATE TABLE '+@TABLE +' start ' + convert(varchar(25),getdate(),120)

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].['+@TABLE+']') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
   exec ('drop table [dbo].['+@TABLE+']')


DECLARE @ERR_VAR INT	
SET @ERR_VAR = 0


CREATE TABLE WageLossCalcFactor (
	wagelossCalcFactorId  INT NOT NULL,
	claimNo  INT NOT NULL,
	effectiveDate  DATETIME NOT NULL,
	commentText  VARCHAR(255) NULL,
	actualAnnualNetAmt  MONEY NULL,
	apprenticeFlag  CHAR(1) NULL,
	avgEarningsBasedOnType  VARCHAR(75) NULL,
	childCareExpenseAmt  MONEY NULL,
	childSupportAmt  MONEY NULL,
	claimantContributionEffectiveDate  DATETIME NULL,
	claimantReplyDate  DATETIME NULL,
	collateralNonTaxableAmt  MONEY NULL,
	collateralTaxableAmt  MONEY NULL,
	collateralTaxableNetAmt  MONEY NULL,
	collateralBenefitType  VARCHAR(75) NULL,
	cppExemptFlag  CHAR(1) NULL,
	cppPremiumAmt  MONEY NULL,
	cppPremiumShelteredAmt  MONEY NULL,
	daysWorkedPerWeekQty  DECIMAL(4,2) NULL,
	deemedFlag  CHAR(1) NULL,
	effective80Date  DATETIME NULL,
	fullAnnual80ClmntNetContribAmt  MONEY NULL,
	fullAnnual80NetLossAmt  MONEY NULL,
	fullAnnual80NetShelteredAmt  MONEY NULL,
	fullAnnual90NetLossAmt  MONEY NULL,
	fullAnnual90NetShelteredAmt  MONEY NULL,
	fullAnnualGrossAmt  MONEY NULL,
	fullAnnualNetLossEarnAmt  MONEY NULL,
	fullClmntContribAmt  MONEY NULL,
	fullClmntPercentContribAmt  MONEY NULL,
	fullPercentNetActualAmt  MONEY NULL,
	fullPercentNetClmntContribAmt  MONEY NULL,
	fullPercentOfNetLossAmt  MONEY NULL,
	fullWCBContribAmt  MONEY NULL,
	fullWCBPercentContribAmt  MONEY NULL,
	fullWeekly80ClmntNetContribAmt  MONEY NULL,
	fullWeekly80NetLossAmt  MONEY NULL,
	fullWeekly80NetShelteredAmt  MONEY NULL,
	fullWeekly90NetActualAmt  MONEY NULL,
	fullWeekly90NetLossAmt  MONEY NULL,
	fullWeekly90NetShelteredAmt  MONEY NULL,
	fullWeeklyAdjustedDailyCompRateAmt  MONEY NULL,
	fullWeeklyDailyCompRateAmt  MONEY NULL,
	fullWeeklyGrossAmt  MONEY NULL,
	fullWeeklyNetLossEarnAmt  MONEY NULL,
	fullWeeklyTaxShelteringAmt  MONEY NULL,
	hourlyBenefitRateAmt  MONEY NULL,
	incomeTaxExemptFlag  CHAR(1) NULL,
	incomeTaxFederalAmt  MONEY NULL,
	incomeTaxProvincialAmt  MONEY NULL,
	incomeTaxFederalShelteredAmt  MONEY NULL,
	incomeTaxProvincialShelteredAmt  MONEY NULL,
	indexedDate  DATETIME NULL,
	indexedYear  INT NULL,
	lossOfEarningsDate  DATETIME NULL,
	maritalStatusType  VARCHAR(75) NULL,
	maximumAdjustmentAmt  MONEY NULL,
	minimumWageFlag  CHAR(1) NULL,
	netCollateralBenefitAmt  MONEY NULL,
	net80DailyCompensationRateAmt  MONEY NULL,
	dependentsQty  INT NULL,
	infirmDependentsQty  INT NULL,
	partial80AfterClmtContribAmt  MONEY NULL,
	partial80DailyCompRateAmt  MONEY NULL,
	partial80NetContribAmt  MONEY NULL,
	partial80NetLossAmt  MONEY NULL,
	partial80NetShelteredAmt  MONEY NULL,
	partial90NetLossEarnAmt  MONEY NULL,
	partial90NetShelteredAmt  MONEY NULL,
	partialClmntContribAmt  MONEY NULL,
	partialClmntPercentContribAmt  MONEY NULL,
	partial80DailyCompensationRateAmt  MONEY NULL,
	partialDailyCompRateAmt  MONEY NULL,
	partialNetLossEarnAmt  MONEY NULL,
	partialNetPostInjuryAmt  MONEY NULL,
	partialNetPreInjuryAmt  MONEY NULL,
	partialPercentNetClmntContribAmt  MONEY NULL,
	partialPercentNetLossAmt  MONEY NULL,
	partialPercentNetShelteredAmt  MONEY NULL,
	partialTaxShelteringAmt  MONEY NULL,
	partialWCBContribAmt  MONEY NULL,
	partialWCBPercentContribAmt  MONEY NULL,
	postEarnWeeklyGrossAmt  MONEY NULL,
	postEarnWeeklyNetAmt  MONEY NULL,
	recurrenceFlag  CHAR(1) NULL,
	recurrenceDate  DATETIME NULL,
	selfEmployedFlag  CHAR(1) NULL,
	spousalSupportAmt  MONEY NULL,
	spouseWorkingFlag  CHAR(1) NULL,
	taxYear  INT NULL,
	totalDeductionsAmt  MONEY NULL,
	totalDeductionsShelteredAmt  MONEY NULL,
	uicExemptFlag  CHAR(1) NULL,
	uicPremiumAmt  MONEY NULL,
	uicPremiumShelteredAmt  MONEY NULL,
	week104StatusType  VARCHAR(75) NULL,
	weeklyWCBAnnuityContributionAmt  MONEY NULL,
	weeklyWCBAnnuityContributionShelteredAmt  MONEY NULL,
	weeklyClaimantAnnuityContributionShelteredAmt  MONEY NULL,
	weeklyDeductionsAmt  MONEY NULL,
	weeklyMinimumWageAmt  MONEY NULL,
	weeklyMinimumWageNetAmt  MONEY  NULL,
	weeklyShelterBenefit90Amt  MONEY  NULL,
	weeklyShelterBenefitAmt  MONEY  NULL,
	weeklyWageAmt  MONEY  NULL,
	youthfulWorkerFlag  CHAR(1)  NULL,
        emergeDisplayFlag  CHAR(1) NOT NULL,
	wcbAnnuityReductionPercentageAmt MONEY  NULL,
	taxExemptCode varchar(75) not null,
	taxExemptAmt money not null,
	creationDatetime  DATETIME  NOT NULL,
	creationLoginName  VARCHAR(16)  NOT NULL,
	modificationDatetime  DATETIME  NULL,
	modificationLoginName  VARCHAR(16)  NULL,
	timestamp  TIMESTAMP  NULL,
	CONSTRAINT WageLossCalcFactorIndex01 PRIMARY KEY  CLUSTERED 
	(
		wagelossCalcFactorId
	) WITH  FILLFACTOR = 90 
)
select @ERR_VAR = @@ERROR
if  0 <>   @ERR_VAR 
       GOTO ERROREND 


CREATE  INDEX WageLossCalcFactorIndex02 ON dbo.WageLossCalcFactor(claimNo) WITH  FILLFACTOR = 90

select @ERR_VAR = @@ERROR
if  0 <>   @ERR_VAR 
       GOTO ERROREND 

GRANT  SELECT ,  UPDATE ,  INSERT ,  DELETE  ON dbo.WageLossCalcFactor  TO wlall

ERROREND:

  if @@ERROR <>  @ERR_VAR
      BEGIN
        PRINT '*******************************************************************'     
        PRINT 'CREATE TABLE ' +@TABLE +' ended in an error state' 
        RAISERROR ('ERROR  SQL statement.', 16, 127)
      END
  else PRINT 'CREATE TABLE ' +@TABLE +' at ' + convert(varchar(25),getdate(),120)


GO

