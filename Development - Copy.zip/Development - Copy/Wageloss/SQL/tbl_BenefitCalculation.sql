if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[BenefitCalculation]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table [dbo].[BenefitCalculation]
GO

CREATE TABLE [dbo].[BenefitCalculation] (
	[benefitCalculationId] [int] IDENTITY (1, 1) NOT NULL ,
	[claimNo] [int] NOT NULL ,
	[calculationDate] [datetime] NOT NULL ,
	[rateBasedOnType] [varchar] (75) NOT NULL ,
	[grossWeeklyWageAmt] [money] NOT NULL ,
	[netWeekly90Amt] [money] NOT NULL ,
	[netDaily90Amt] [money] NOT NULL ,
	[daysWorkedPerWeekQty] [float] NOT NULL ,
	[daysOffDescription] [varchar] (255) NULL ,
	[net80Amt] [money] NOT NULL ,
	[net80AmtAfterClmContrib] [money] NOT NULL ,
	[netDaily80Amt] [money] NOT NULL ,
	[clmtContribPercent] [float] NOT NULL ,
	[wcbContribPercent] [float] NOT NULL ,
	[clmtContribAmt] [money] NOT NULL ,
	[wcbContribAmt] [money] NOT NULL ,
	[partialNet90LossAmt] [money] NOT NULL ,
	[partialNetDaily90Amt] [money] NOT NULL ,
	[partialNet80LossAmt] [money] NOT NULL ,
	[partialClmtContribAmt] [money] NOT NULL ,
	[partial80AmtAfterClmContrib] [money] NOT NULL ,
	[partialWcbContribAmt] [money] NOT NULL ,
	[partialDaily80Amt] [money] NOT NULL ,
	[creationDatetime] [datetime] NOT NULL ,
	[creationLoginName] [varchar] (16) NOT NULL ,
	[modificationDatetime] [datetime] NULL ,
	[modificationLoginName] [varchar] (16) NULL ,
	[timestamp] [timestamp] NULL 
) ON [PRIMARY]
GO

ALTER TABLE [dbo].[BenefitCalculation] WITH NOCHECK ADD 
	CONSTRAINT [benefitCalculation_PK] PRIMARY KEY  CLUSTERED 
	(
		[benefitCalculationId]
	) WITH  FILLFACTOR = 90  ON [PRIMARY] 
GO

 CREATE  INDEX [BenefitCalculation_INDEX01] ON [dbo].[BenefitCalculation]([claimNo]) WITH  FILLFACTOR = 90 ON [PRIMARY]
GO

GRANT  SELECT ,  UPDATE ,  INSERT ,  DELETE  ON [dbo].[BenefitCalculation]  TO [wlall]
GO

