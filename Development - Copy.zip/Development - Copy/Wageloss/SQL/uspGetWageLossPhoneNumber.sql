DECLARE @table VARCHAR(40),
        @DROP VARCHAR(40)
set @TABLE = 'uspGetWageLossPhoneNumber'

PRINT 'CREATE  PROCEDURE ' + @TABLE + ' start ' + convert(varchar(25),getdate(),120)

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[uspGetWageLossPhoneNumber]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[uspGetWageLossPhoneNumber]

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

CREATE    PROCEDURE uspGetWageLossPhoneNumber
 @phoneType VARCHAR(75),
 @claimNo INT
AS
 
SELECT
 claim.claimNo, 
 phoneNumber.phoneNumber,
 phoneNumber.phoneNumberType
FROM 
 emerge_db.dbo.Claim claim
 INNER JOIN emerge_db.dbo.Claimant claimant ON 
  claimant.claimantId = claim.claimantId
 INNER JOIN emerge_db.dbo.Person person ON 
  person.personId = claimant.personId
 INNER JOIN emerge_db.dbo.PersonPhone personPhone ON 
  personPhone.personId = person.PersonId
 INNER JOIN emerge_db.dbo.PhoneNumber phoneNumber ON 
  phoneNumber.phoneNumberId = personPhone.phoneNumberId
WHERE
 phoneNumber.phoneNumberType = @phoneType
 AND
 claim.claimNo = @claimNo
 
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

if @@ERROR <>  0
    BEGIN
      PRINT '*******************************************************************'     
      PRINT 'CREATE PROCEDURE uspGetWageLossPhoneNumber ended in an error state' 
      RAISERROR ('ERROR  SQL statement.', 16, 127)
    END
else PRINT 'CREATE PROCEDURE uspGetWageLossPhoneNumber successful at ' + convert(varchar(25),getdate(),120)