if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[EntitlementPayment]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table [dbo].[EntitlementPayment]
GO

CREATE TABLE [dbo].[EntitlementPayment] (
	[entitlementPaymentId] [int] IDENTITY (1, 1) NOT NULL ,
	[claimNo] [int] NOT NULL ,
	[paymentEnteredDate] [datetime] NOT NULL ,
	[weeksPaidQty] [float] NOT NULL ,
	[totalDaysPaidQty] [float] NOT NULL ,
	[netWeeklyPaidAmt] [money] NULL ,
	[paymentAdjustment] [money] NULL ,
	[paymentAmt] [money] NULL ,
	[paymentFromDate] [datetime] NOT NULL ,
	[paymentToDate] [datetime] NULL ,
	[reasonForChangeType] [varchar] (75) NOT NULL ,
	[paymentType] [varchar] (75) NULL ,
	[chequeMessageType] [varchar] (75) NULL ,
	[associatedNoteFlag] [char] (1) NULL ,
	[creationDatetime] [datetime] NOT NULL ,
	[creationLoginName] [varchar] (16) NOT NULL ,
	[modificationDatetime] [datetime] NULL ,
	[modificationLoginName] [varchar] (16) NULL ,
	[timestamp] [timestamp] NULL 
) ON [PRIMARY]
GO

ALTER TABLE [dbo].[EntitlementPayment] WITH NOCHECK ADD 
	CONSTRAINT [entitlementPayment_PK] PRIMARY KEY  CLUSTERED 
	(
		[entitlementPaymentId]
	) WITH  FILLFACTOR = 90  ON [PRIMARY] 
GO

 CREATE  INDEX [EntitlementPayment_INDEX02] ON [dbo].[EntitlementPayment]([claimNo]) WITH  FILLFACTOR = 90 ON [PRIMARY]
GO

GRANT  SELECT ,  UPDATE ,  INSERT ,  DELETE  ON [dbo].[EntitlementPayment]  TO [wlall]
GO

