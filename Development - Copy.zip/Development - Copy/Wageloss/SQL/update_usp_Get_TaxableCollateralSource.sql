ALTER PROCEDURE usp_Get_TaxableCollateralSource
	@Claim_No	CHAR(8)
AS

SELECT
	Claim_No,
	CPPQPP,
	EI,
	DisabilityInsurance,
	EmployerTopUp,
     Combination,
	CPPQPP + EI + DisabilityInsurance + EmployerTopUp + Combination As TotalTaxableCollateral
FROM	
	tbl_TaxableCollateralSource
WHERE
	Claim_No	= @Claim_No And
	Modification_Date =  	
		(
			SELECT TOP 1 Modification_Date
			FROM tbl_TaxableCollateralSource
			WHERE Claim_No	= @Claim_No
			ORDER BY Modification_Date DESC
		)

GO
