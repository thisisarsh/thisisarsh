USE wageloss_db

DECLARE @table VARCHAR(40),
        @DROP VARCHAR(40)
set @TABLE = 'WageLossReports'

PRINT 'ALTER TABLE '+@TABLE +' start ' + convert(varchar(25),getdate(),120)



DECLARE @ERR_VAR INT	
SET @ERR_VAR = 0
ALTER TABLE WageLossReports
 ADD effectiveDate char (15)
	

  if @@ERROR <> 0
      BEGIN
        PRINT '*******************************************************************'     
        PRINT ' ALTERTABLE ' +@TABLE +' ended in an error state' 
        RAISERROR ('ERROR  SQL statement.', 16, 127)
      END
 -- else PRINT ' ALTER TABLE ' +@TABLE +' at ' + convert(varchar(25),getdate(),120)

GO

DECLARE @table VARCHAR(40),
        @DROP VARCHAR(40)
set @TABLE = 'WageLossReports'

  

ALTER TABLE WageLossReports 
 ALTER COLUMN AvgEarningsBasedOn  varchar ( 75 )

ALTER TABLE WageLossReports 
ALTER  column  Marital_Status  varchar(75) 


  if @@ERROR <> 0
      BEGIN
        PRINT '*******************************************************************'     
        PRINT ' ALTERTABLE ' +@TABLE +' ended in an error state' 
        RAISERROR ('ERROR  SQL statement.', 16, 127)
      END
  else PRINT ' ALTER TABLE ' +@TABLE +' at ' + convert(varchar(25),getdate(),120)

