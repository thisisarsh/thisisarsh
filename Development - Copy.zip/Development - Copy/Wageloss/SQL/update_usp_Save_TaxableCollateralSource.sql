ALTER PROCEDURE usp_Save_TaxableCollateralSource
	@Claim_No	CHAR(8),
	@CPPQPP MONEY,
	@EI MONEY,
	@DisabilityInsurance MONEY,
	@EmployerTopUp MONEY,
	@Combination MONEY,
	@Current_User VARCHAR(50)
AS

IF NOT EXISTS
	(
		SELECT 1
		FROM
			tbl_TaxableCollateralSource
		WHERE
			Claim_No = @Claim_No AND
			CPPQPP = @CPPQPP AND
			EI = @EI AND
			DisabilityInsurance	= @DisabilityInsurance AND
			EmployerTopUp = @EmployerTopUp AND 
			Combination = @Combination AND
			Modification_Date = 
				(
					SELECT TOP 1 Modification_Date
					FROM tbl_TaxableCollateralSource
					WHERE Claim_No	= @Claim_No
					ORDER BY Modification_Date DESC
				) 
	)
	BEGIN
	INSERT INTO tbl_TaxableCollateralSource
		(
			Claim_No,
			CPPQPP,
			EI,
			DisabilityInsurance,
			EmployerTopUp,
			Combination,
			Modification_User,
			Modification_Date
		)
	VALUES
		(
			@Claim_No,
			@CPPQPP,
			@EI,
			@DisabilityInsurance,
			@EmployerTopUp,
			@Combination,
			@Current_User,
			GETDATE()
		)
	END

GO
