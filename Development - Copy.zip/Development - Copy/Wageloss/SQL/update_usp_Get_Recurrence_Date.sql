ALTER PROCEDURE usp_Get_Recurrence_Date
	@Claim_No	CHAR(8)
AS

SELECT	
	Claim_No,
	Recurrence_Date
FROM	
	tbl_Recurrence_Date
WHERE
	Claim_No	= @Claim_No And
	Modification_Date = 
		(
			SELECT TOP 1 Modification_Date
			FROM tbl_Recurrence_Date
			WHERE Claim_No	= @Claim_No
			ORDER BY Modification_Date DESC
		) And
	Active = 'Y'

GO
