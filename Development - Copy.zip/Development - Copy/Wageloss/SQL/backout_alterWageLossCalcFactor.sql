USE wageloss_db

ALTER TABLE WageLossCalcFactor
DROP COLUMN reducedNoDaysToPayQty

ALTER TABLE WageLossCalcFactor
DROP COLUMN reducedNoWeeksToPayQty
