ALTER TABLE BenefitCalculation
	ADD Week104Status varchar(32) NULL,
	    Comment varchar(255) NULL

go

update BenefitCalculation
set Week104Status = 'Pre 104 Weeks' 

go