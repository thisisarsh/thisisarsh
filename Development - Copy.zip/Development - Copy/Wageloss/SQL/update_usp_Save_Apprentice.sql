ALTER PROCEDURE usp_Save_Apprentice
	@Claim_No	CHAR(8),
	@Apprentice CHAR(1),
	@Active CHAR(1),
	@Current_User VARCHAR(50)
AS

IF NOT EXISTS
	(
		SELECT 1
		FROM tbl_Apprentice
		WHERE Claim_No	= @Claim_No
		AND Apprentice	= @Apprentice
		AND Modification_Date =  
			(
				SELECT TOP 1 Modification_Date
				FROM tbl_Apprentice
				WHERE Claim_No	= @Claim_No
				ORDER BY Modification_Date DESC
			) 
	)
	BEGIN
	INSERT INTO tbl_Apprentice
	(
		Claim_No,
		Apprentice,
		Active,
		Modification_Date,
		Modification_User
	)
	VALUES
	(
		@Claim_No,
		@Apprentice,
		@Active,
		GetDate(),
		@Current_User
	)
	END
GO
