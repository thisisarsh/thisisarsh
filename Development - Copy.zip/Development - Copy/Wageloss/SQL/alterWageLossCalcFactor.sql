USE wageloss_db

ALTER TABLE WageLossCalcFactor
ADD reducedNoDaysToPayQty DECIMAL( 6, 2 ) NULL

ALTER TABLE WageLossCalcFactor
ADD reducedNoWeeksToPayQty DECIMAL( 6, 2 ) NULL
