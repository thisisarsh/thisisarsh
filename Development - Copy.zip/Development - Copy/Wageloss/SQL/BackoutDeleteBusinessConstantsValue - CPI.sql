USE emerge_db

-- Backout - CPI value
DELETE FROM BusinessConstantValue
WHERE 
	businessConstantValueId = 48 AND 
	businessConstantId = 2