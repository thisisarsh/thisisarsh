use wageloss_db

DELETE FROM wageloss_db..minimumWage
WHERE     (effectiveDate = CONVERT(DATETIME, '2009-01-01 00:00:00', 102))