if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[ClaimIndexDetail]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table [dbo].[ClaimIndexDetail]
GO

CREATE TABLE [dbo].[ClaimIndexDetail] (
	[claimNo] [char] (10) NOT NULL ,
        [ClaimSuffix] [char] (8) NOT NULL,
	[weeklyWage] [money] NULL ,
	[indexFactor] [float] NOT NULL ,
	[indexedWeeklyWage] [money] NOT NULL ,
	[indexedMinimunWage] [money] NOT NULL ,
	[indexYear] [int] NOT NULL ,
	[reportUser] [char] (40) NULL ,
	[reportTime] [char] (10) NULL ,
	[reportDate] [char] (15) NULL 
) ON [PRIMARY]
GO

 CREATE  INDEX [IdxClaimIndexDetClaim] ON [dbo].[ClaimIndexDetail]([claimNo]) WITH  FILLFACTOR = 90 ON [PRIMARY]
GO

GRANT  SELECT ,  UPDATE ,  INSERT ,  DELETE  ON [dbo].[ClaimIndexDetail]  TO [wlall]
GO

GRANT  SELECT ,  UPDATE ,  INSERT ,  DELETE  ON [dbo].[ClaimIndexDetail]  TO [developers]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[ClaimIndexHeader]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table [dbo].[ClaimIndexHeader]
GO

CREATE TABLE [dbo].[ClaimIndexHeader] (
	[claimNo] [char] (10) NOT NULL ,
        [ClaimSuffix] [char] (8) NOT NULL,
	[reportid] [char] (4) NOT NULL ,
	[reportUser] [char] (40) NOT NULL ,
	[reportTime] [char] (10) NOT NULL ,
	[reportDate] [char] (15) NOT NULL ,
	[ClaimantName] [char] (75) NULL ,
	[ClaimantAddress1] [char] (75) NULL ,
	[ClaimantAddress2] [char] (75) NULL ,
	[ClaimantAddress3] [char] (75) NULL ,
	[ClaimantPostalCode] [char] (8) NULL ,
	[ClaimantSIN] [char] (11) NULL ,
	[ClaimantDOB] [char] (15) NULL ,
	[ClaimantHomePhone] [char] (15) NULL ,
	[ClaimantWorkPhone] [char] (15) NULL ,
	[AccidentDate] [char] (15) NULL ,
	[minimunWageInd] [char] (1) NULL ,
	[youthFullWorkerInd] [char] (1) NULL,
	[Apprentice] [char] (1) NULL 
) ON [PRIMARY]
GO

 CREATE  INDEX [IdxClaimIndexHeaderClaim] ON [dbo].[ClaimIndexHeader]([claimNo]) WITH  FILLFACTOR = 90 ON [PRIMARY]
GO

GRANT  SELECT ,  UPDATE ,  INSERT ,  DELETE  ON [dbo].[ClaimIndexHeader]  TO [wlall]
GO

GRANT  SELECT ,  UPDATE ,  INSERT ,  DELETE  ON [dbo].[ClaimIndexHeader]  TO [developers]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[vwClaimIndex]') and OBJECTPROPERTY(id, N'IsView') = 1)
drop view [dbo].[vwClaimIndex]
GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS ON 
GO

CREATE VIEW dbo.vwClaimIndex
AS
SELECT     a.claimNo           , a.reportUser         , a.reportTime      , a.reportDate       , a.minimunWageInd, 
           a.youthFullWorkerInd, B.indexYear          , B.weeklyWage      , B.indexFactor      , B.indexedWeeklyWage,
           B.indexedMinimunWage, a.ClaimantName       , a.ClaimantAddress1, a.ClaimantAddress2 , a.ClaimantAddress3,
           a.ClaimantPostalCode, a.ClaimantSIN        , a.ClaimantDOB     , a.ClaimantHomePhone, a.ClaimantWorkPhone,
           a.AccidentDate      , a.Apprentice, a.ClaimSuffix
FROM       wageloss_db.dbo.ClaimIndexHeader a INNER JOIN wageloss_db.dbo.ClaimIndexDetail B 
           ON a.claimNo     = B.claimNo
           AND a.reportUser = b.reportUser 
           AND a.reportTime = b.reportTime
           AND a.reportDate = b.reportDate


GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

GRANT  SELECT  ON [dbo].[vwClaimIndex]  TO [wlall]
GO

GRANT  SELECT  ON [dbo].[vwClaimIndex]  TO [developers]
GO





