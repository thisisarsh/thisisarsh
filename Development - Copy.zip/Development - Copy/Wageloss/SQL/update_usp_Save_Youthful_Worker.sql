ALTER PROCEDURE usp_Save_Youthful_Worker
	@Claim_No CHAR(8),
	@Youthful_Worker CHAR(1),
	@Active CHAR(1),
	@Current_User VARCHAR(50)
AS

IF NOT EXISTS
	(
		SELECT 1
		FROM
			tbl_Youthful_Worker
		WHERE
			Claim_No = @Claim_No AND
			Youthful_Worker = @Youthful_Worker AND
			Modification_Date = 
				(
					SELECT TOP 1 Modification_Date
					FROM tbl_Youthful_Worker
					WHERE Claim_No	= @Claim_No
					ORDER BY Modification_Date DESC
				) 
	)
	BEGIN
	INSERT INTO tbl_Youthful_Worker
		(
			Claim_No,
			Youthful_Worker,
			Active,
			Modification_Date,
			Modification_User
		)
	VALUES
		(
			@Claim_No,
			@Youthful_Worker,
			@Active,
			GETDATE(),
			@Current_User
		)
	END
GO
