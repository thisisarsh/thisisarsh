--******************************************************************************************
--
-- Changes for for Leg Amendment 2005
--
--******************************************************************************************


if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[usp_Get_Max_Self_Employed]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[usp_Get_Max_Self_Employed]
GO

--******************************************************************************************
--
-- Create the stored Procs for access to selfEmployedMax for Leg Amendment 2005
--
--******************************************************************************************

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO


-- ===============================================================================
--
-- Name: 	Elliot Cunningham
-- Date: 	Sept. 19, 2005
--
-- Purpose:	Returns the Slef Employed Max Adjustment based on accident date.
--
-- ===============================================================================


CREATE   PROCEDURE usp_Get_Max_Self_Employed
	@accidentDate	datetime
AS

SELECT TOP 1 maxSelfEmployed, effectiveDate
  FROM selfEmployedMax
 WHERE effectiveDate <= @accidentDate 
ORDER BY effectiveDate DESC





GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

GRANT  EXECUTE  ON [dbo].[usp_Get_Max_Self_Employed]  TO [wlall]
GO



if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[usp_Get_Minimum_Wage]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[usp_Get_Minimum_Wage]
GO

--******************************************************************************************
--
-- Create the stored Procs for access to selfEmployedMax for Leg Amendment 2005
--
--******************************************************************************************


SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO


-- =================================================================
--
-- Name: 	Elliot Cunningham
-- Date: 	July 14, 2005
--
-- Purpose:	Returns the minimum wage based on accident date.
--
-- =================================================================


CREATE   PROCEDURE usp_Get_Minimum_Wage
	@accidentDate	datetime
AS

SELECT TOP 1 minWage, effectiveDate
  FROM minimumWage
 WHERE effectiveDate <= @accidentDate 
ORDER BY effectiveDate DESC




GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

GRANT  EXECUTE  ON [dbo].[usp_Get_Minimum_Wage]  TO [wlall]
GO



if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[minimumWage]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table [dbo].[minimumWage]
GO

CREATE TABLE [dbo].[minimumWage] (
	[minWage] [money] NOT NULL ,
	[effectiveDate] [datetime] NOT NULL ,
	[userid] [smallint] NULL ,
	[dateTimeStamp] [datetime] NULL 
) ON [PRIMARY]
GO

ALTER TABLE [dbo].[minimumWage] WITH NOCHECK ADD 
	CONSTRAINT [PKminimumWage] PRIMARY KEY  CLUSTERED 
	(
		[minWage],
		[effectiveDate]
	) WITH  FILLFACTOR = 90  ON [PRIMARY] 
GO

GRANT  SELECT ,  UPDATE ,  INSERT ,  DELETE  ON [dbo].[minimumWage]  TO [wlall]
GO


--******************************************************************************************
--
-- Insert Minimum wage for 2006
--
--******************************************************************************************
INSERT INTO minimumWage (minWage, effectiveDate, userid, dateTimeStamp)
VALUES (15600, '01/01/2006', 810, GetDate())




--******************************************************************************************
--
-- Create the Self Employed MAx table
--
--******************************************************************************************

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[selfEmployedMax]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table [dbo].[selfEmployedMax]
GO

CREATE TABLE [dbo].[selfEmployedMax] (
	[maxSelfEmployed] [money] NOT NULL ,
	[effectiveDate] [datetime] NOT NULL ,
	[userid] [smallint] NULL ,
	[dateTimeStamp] [datetime] NULL 
) ON [PRIMARY]
GO

ALTER TABLE [dbo].[selfEmployedMax] WITH NOCHECK ADD 
	CONSTRAINT [PKselfEmployedMax] PRIMARY KEY  CLUSTERED 
	(
		[maxSelfEmployed],
		[effectiveDate]
	) WITH  FILLFACTOR = 90  ON [PRIMARY] 
GO

GRANT  SELECT ,  UPDATE ,  INSERT ,  DELETE  ON [dbo].[selfEmployedMax]  TO [wlall]
GO


--******************************************************************************************
--
-- Insert Minimum Coverage for 2006
--
--******************************************************************************************
INSERT INTO selfEmployedMax (maxSelfEmployed, effectiveDate, userid, dateTimeStamp)
VALUES (17840, '01/01/2006', 810, GetDate())


--******************************************************************************************
--
-- Create the TaxableCollateralSource Table for Leg Amendment
--
--******************************************************************************************



if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[tbl_TaxableCollateralSource]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table [dbo].[tbl_TaxableCollateralSource]
GO

CREATE TABLE [dbo].[tbl_TaxableCollateralSource] (
	[Claim_No] [char] (8) COLLATE SQL_Latin1_General_CP850_CI_AS NOT NULL ,
	[CPPQPP] [money] NOT NULL ,
	[EI] [money] NOT NULL ,
	[DisabilityInsurance] [money] NOT NULL ,
	[EmployerTopUp] [money] NOT NULL ,
	[Combination] [money] NOT NULL ,
	[Modification_Date] [datetime] NULL ,
	[Modification_User] [varchar] (16) COLLATE SQL_Latin1_General_CP850_CI_AS NULL 
) ON [PRIMARY]
GO

 CREATE  CLUSTERED  INDEX [tbl_TaxableCollateralSource_Claim_Idx] ON [dbo].[tbl_TaxableCollateralSource]([Claim_No]) WITH  FILLFACTOR = 90 ON [PRIMARY]
GO

GRANT  SELECT ,  UPDATE ,  INSERT ,  DELETE  ON [dbo].[tbl_TaxableCollateralSource]  TO [dmadill]
GO


GRANT  SELECT ,  UPDATE ,  INSERT ,  DELETE  ON [dbo].[tbl_TaxableCollateralSource]  TO [wlall]
GO


GRANT  SELECT ,  UPDATE ,  INSERT ,  DELETE  ON [dbo].[tbl_TaxableCollateralSource]  TO [ecunning]
GO


--******************************************************************************************
--
-- Create the Stored Procs for access to the TaxableCollateralSource Table for Leg Amendment
--
--******************************************************************************************



if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[usp_Get_TaxableCollateralSource]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[usp_Get_TaxableCollateralSource]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[usp_Save_TaxableCollateralSource]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[usp_Save_TaxableCollateralSource]
GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO


CREATE PROCEDURE usp_Get_TaxableCollateralSource
	@Claim_No	Char(8)
AS

SELECT	Claim_No,
	CPPQPP,
	EI,
	DisabilityInsurance,
	EmployerTopUp,
        Combination,
	CPPQPP + EI + DisabilityInsurance + EmployerTopUp + Combination As TotalTaxableCollateral
FROM	tbl_TaxableCollateralSource
WHERE	Claim_No	= @Claim_No
And	Modification_Date	in 	
				(
				Select 	Max(Modification_Date)
				From 	tbl_TaxableCollateralSource
				Where	Claim_No	= @Claim_No
				)




GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO


GRANT  EXECUTE  ON [dbo].[usp_Get_TaxableCollateralSource] TO [wlall]
GO




SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO


CREATE PROCEDURE usp_Save_TaxableCollateralSource
	@Claim_No		Char(8),
	@CPPQPP			Money,
	@EI			Money,
	@DisabilityInsurance	Money,
	@EmployerTopUp		Money,
	@Combination		Money,
	@Current_User		VarChar(50)
AS

If	Not Exists	(
		Select	1
		From	tbl_TaxableCollateralSource
		Where	Claim_No		= @Claim_No
		And	CPPQPP			= @CPPQPP
		And	EI			= @EI
		And	DisabilityInsurance	= @DisabilityInsurance
		And	EmployerTopUp		= @EmployerTopUp
		And	Combination		= @Combination
		And	Modification_Date	in 
						(
						Select 	Max(Modification_Date)
						From 	tbl_TaxableCollateralSource
						Where	Claim_No	= @Claim_No
						) 
			)
	Begin
	Insert	Into	tbl_TaxableCollateralSource
		(
		Claim_No,
		CPPQPP,
		EI,
		DisabilityInsurance,
		EmployerTopUp,
		Combination,
		Modification_User,
		Modification_Date
		)
	Values	(
		@Claim_No,
		@CPPQPP,
		@EI,
		@DisabilityInsurance,
		@EmployerTopUp,
		@Combination,
		@Current_User,
		GetDate()
		)
	End



GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO


GRANT  EXECUTE  ON [dbo].[usp_Save_TaxableCollateralSource] TO [wlall]
GO


--************************************************************************************
--
-- Alter the BenefitCalculation Table to include the new columns for Leg Amendment
--
--************************************************************************************

Alter TABLE [dbo].[BenefitCalculation] ADD [minWageIndicator] [char] (1) NULL 
GO
Alter TABLE [dbo].[BenefitCalculation] ADD [TaxableCollateralSource] [varchar] (100) NULL 
GO

Update 	[dbo].[BenefitCalculation] 
Set 	[minWageIndicator] 		= 'N',
	[TaxableCollateralSource] 	= ''

Alter TABLE [dbo].[BenefitCalculation] ALTER COLUMN [minWageIndicator] [char] (1) NOT NULL 

GO

Alter TABLE [dbo].[BenefitCalculation] ALTER COLUMN [TaxableCollateralSource] [varchar] (100) NOT NULL 

GO

--************************************************************************************
--
-- Alter the WageLossReports Table to include the new columns for Leg Amendment
--
--************************************************************************************


ALTER TABLE [dbo].[WageLossReports] ADD [weekly_min_wage] [money] NULL

GO

ALTER TABLE [dbo].[WageLossReports] ADD [weekly_shelter_benefit] [money] NULL 

GO

ALTER TABLE [dbo].[WageLossReports] ADD [min_wage_indicator] [char] (1) NULL

GO

ALTER TABLE [dbo].[WageLossReports] ADD [coll_ben_type] [varchar] (100) NULL 

GO

ALTER TABLE [dbo].[WageLossReports] ADD [weekly_shelter_ben_90] [money] NULL 

GO

ALTER TABLE [dbo].[WageLossReports] ADD [annual_net_a] [money] NULL 

GO

ALTER TABLE [dbo].[WageLossReports] ADD [net_coll_ben] [money] NULL 

GO

ALTER TABLE [dbo].[WageLossReports] ADD [weekly_min_wage_net] [money] NULL 

GO

ALTER TABLE [dbo].[WageLossReports] ADD [min_wage_ind_partial] [char] (1) NULL 

GO


