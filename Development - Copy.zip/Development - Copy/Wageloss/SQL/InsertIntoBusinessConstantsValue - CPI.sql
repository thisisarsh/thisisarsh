USE emerge_db

INSERT INTO 
	BusinessConstantValue
	(
		businessConstantValueId, 
		businessConstantId, 
		businessConstantValue, 
		businessConstantValueType, 
		activeDatetime, 
		inactiveDatetime, 
		creationDatetime, 
		creationLoginName, 
		modificationDatetime, 
		modificationLoginName
	)
VALUES
	(
		48, 
		2, 
		2.41718, 
		'real', 
		'01-Jan-2009', 
		'31-Dec-2009', 
		GETDATE(), 
		'bcooper', 
		NULL, 
		NULL
	)