unit NCWrkRptJul26;

interface

uses
  Winapi.Windows, Winapi.Messages, System.SysUtils, System.Variants, System.Classes, Vcl.Graphics,
  Vcl.Controls, Vcl.Forms, Vcl.Dialogs, NCWrkRptJan26;

type
  TWrkRptJul26 = class(TWrkRptJan26)
  function getDateHeading(): String; Override;
  private
    { Private declarations }
  public
    { Public declarations }
  end;

var
  WrkRptJul26: TWrkRptJul26;

implementation

{$R *.dfm}

{ TWrkRptJul26 }

function TWrkRptJul26.getDateHeading: String;
begin
  result:= '2026';
end;

end.
