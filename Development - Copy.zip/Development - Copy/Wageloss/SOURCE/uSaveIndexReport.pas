unit uSaveIndexReport;

interface

Uses SysUtils, Forms, Inifiles, Messages, Dialogs, Windows, Utils, ncrecdef, Math, uTriggerEvent, Classes;

var
  wir: recReport;
  CalcFullClaim, CalcPartClaim: recNCCLAIM;
  formId, Reporting_User, ReportId, Report_Time, Report_Date, ReportDestination, ClaimNumber, ClaimSuffix: String;

  procedure SaveHeader;
  procedure SaveDetail;
  procedure TriggerReport;
  procedure SetRecIndexReport(FormId: String; cc, cp: recNCCLAIM; RptDestination:String);
  function SavePrint(RptDestination:String):Boolean;
  function SQLDouble( dd:double ): shortstring;
  function valueNCINDEXF( y: integer ): double;
  function getMinimumWage: currency;
  function getIndexedMinWage(minWage:Currency; Year_Cnt:Integer): currency;

implementation

uses uADOSecurity, NCDatMod, NCIniMod, uGlobal, uUserMaint, NCBenCal, NCMain, utilmod1;

function SavePrint( RptDestination : String ) : Boolean;
var
   Update_Result : Boolean;
begin
  Update_Result := False;

  try
    SaveHeader;
    SaveDetail;

    if ( RptDestination = 'E' ) then
    begin
      TriggerReport;
    end;

    Update_Result := true;
  finally
    begin
      SavePrint := Update_Result;
    end;
  end; // end try finally block
end;

procedure SetRecIndexReport( FormId : String; cc, cp: recNCCLAIM; RptDestination : String );
Begin
  ReportId := FormId;
  CopyNCClaim( cc, CalcFullClaim );
  CopyNCClaim( cp, CalcPartClaim );
  SavePrint( RptDestination );
end;

procedure SaveHeader;
var
   s, t : String;
   lngTemp : Integer;
begin
  try
     with dm1.qWageLossReport do
        begin
        Reporting_User := UserProfile.givenName + ' ' + userProfile.familyName;
        ReportId := 'WLI1';
        Report_Time := FormatDateTime( 'h:nn AM/PM', utilmod1.getEmergeBusinessDate() );
        Report_Date := FormatDateTime( 'd-mmm-yyyy', utilmod1.getEmergeBusinessDate() );
        ClaimNumber := CalcFullClaim.Claim_No;
        ClaimSuffix := CalcFullClaim.Claim_Suffix;
        close;
        SQL.Clear;
        SQL.Add('DELETE ClaimIndexHeader WHERE ClaimNo = ' + QuotedStr(ClaimNumber));
        SQL.Add(' And ReportUser = ' + QuotedStr(UserProfile.givenName + ' ' + userProfile.familyName));
        execSQL;
        SQL.Clear;
        SQL.add('INSERT INTO ClaimIndexHeader ');
        SQL.Add('(claimNo ,ClaimSuffix, reportid, reportUser, reportTime, reportDate, ClaimantName, ');
        SQL.Add('ClaimantAddress1, ClaimantAddress2, ClaimantAddress3, ClaimantPostalCode, ClaimantSIN, ');
        SQL.Add('ClaimantDOB, ClaimantHomePhone, ClaimantWorkPhone, AccidentDate, minimunWageInd, ');
        SQL.Add('youthFullWorkerInd, Apprentice) ');
        SQL.add('VALUES(');

        if (Length(Trim(CalcFullClaim.Claim_No)) > 0) then
           begin
           SQL.Add(SQLstring(Trim(ClaimNumber)));
           end
        else
           begin
           SQL.Add(SQLString(''));
           end;

        if (Length(Trim(ClaimSuffix)) > 0) then
           begin
           SQL.Add(SQLstring(Trim(ClaimSuffix)));
           end
        else
           begin
           SQL.Add(SQLString(''));
           end;

        SQL.Add(SQLstring(ReportId));
        SQL.Add(SQLstring(Reporting_User));
        SQL.Add(SQLstring(Report_Time));
        SQL.Add(SQLstring(Report_Date));
        SQL.Add(SQLstring(Trim(CalcFullClaim.Clmnts_1st_Name) + ' ' + Trim(CalcFullClaim.Clmnts_Surname)));
        SQL.Add(SQLstring(Trim(CalcFullClaim.Clmnts_Add_No_1)));
        SQL.Add(SQLstring(Trim(CalcFullClaim.Clmnts_Add_No_2)));
        SQL.Add(SQLstring(Trim(CalcFullClaim.Clmnts_Add_No_3) + ' ' + Trim(CalcFullClaim.Clmnts_Post_Code)));

        if (Length(Trim(CalcFullClaim.Clmnts_Post_Code)) > 0) Then
           begin
           SQL.Add(SQLstring(Trim(CalcFullClaim.Clmnts_Post_Code)));
           end
        else
           begin
           SQL.Add(SQLString(''));
           end;

        s := CalcFullClaim.SIN;

        if Length(Trim(s)) = 9 then
           begin
           lngTemp := StrToInt(Trim(s));
           if lngTemp > 0 Then
              begin
              s := Copy(s, 1, 3) + ' ' + Copy(s, 4, 3) + ' ' + Copy (s, 7, 3);
              end
           else
              s := '';
           end
        else
           begin
           s := '';
           end;

        SQL.Add(SQLstring(s));

        if CalcFullClaim.Birth_Date > 0 then
           begin
           SQL.Add(SQLString(FormatDateTime('d-mmm-yyyy', CalcFullClaim.Birth_Date)));
           end
        else
           begin
           SQL.Add(SQLString(''));
           end;

        s := CalcFullClaim.Clmnts_Home_Phone;

        if length(Trim(s)) = 10 Then
           begin
           t := Copy( s, 4, 7 );
           lngTemp := StrToInt( Trim(t) );
           if lngTemp > 0 Then
              begin
              s := '(' + Copy(s, 1, 3) + ') ' + Copy(s, 4, 3) + '-' + Copy(s, 7, 4);
              end
           else
              begin
              s := '';
              end;
           end
        else if Length(Trim(s)) = 7 Then
           begin
           lngTemp := StrToInt(Trim(s));
           if lngTemp > 0 Then
              begin
              s := Copy(s, 4, 3) + '-' + Copy(s, 7, 4);
              end
           else
              begin
              s := '';
              end;
           end
        else
           begin
           s := '';
           end;

        SQL.Add(SQLstring(s));

        s := CalcFullClaim.Clmnts_Work_Phone;

        if length(Trim(s)) = 10 Then
           begin
           t := Copy(s, 4, 7);
           lngTemp := StrToInt(Trim(t));
           if lngTemp > 0 Then
              begin
              s := '(' + Copy(s, 1, 3) + ') ' + Copy(s, 4, 3) + '-' + Copy(s, 7, 4);
              end
           else
              begin
              s := '';
              end;
           end
        else if Length(Trim(s)) = 7 Then
           begin
           lngTemp := StrToInt(s);
           if lngTemp > 0 Then
              begin
              s := Copy(s, 4, 3) + '-' + Copy(s, 7, 4);
              end
           else
              begin
              s := '';
              end;
           end
        else
           begin
           s := '';
           end;

        SQL.Add( SQLstring( s ) );

        if CalcFullClaim.Accident_Date > 0 then
           begin
           SQL.Add(SQLString(FormatDateTime('d-mmm-yyyy', CalcFullClaim.Accident_Date)));
           end
        else
           begin
           SQL.Add(SQLString(''));
           end;

        s := '';

        if CalcFullClaim.Minimum_wage_Flag then
           begin
           s := 'Y';
           end
        else if CalcFullClaim.Pay_At_100_Flag then
           begin
           s := 'R';
           end
        else
           begin
           s := 'N';
           end;

        SQL.Add(SQLstring(s));
        SQL.Add(SQLString(CalcFullClaim.Youthful_Worker));
        s := SQLString(CalcFullClaim.Apprentice);
        s := copy(s, 1, length( s ) - 1);
        SQL.Add(s);
        SQL.add(')');
        execSQL;
        end;
  except
    on e:Exception do
       begin
       applog('uSaveIndexReport.SaveHeader - Exception - Message: ' + e.Message);
       MessageDlg('SaveHeader: Index Report File Creation Failed.  Please notify help desk at 4573. Message:' + e.Message + ' SQL:' + dm1.qWageLossReport.SQL.Text, mtError, [mbOK], 0 );
       end;
  end;
end;

procedure SaveDetail;
var
   NewAmt, OldAmt, minWage, IndexedMinWage, Weekly_Increase : Currency;
   Year_Cnt, min_index_year, lngIndex, i : Integer;
   accidentDate : TDateTime;
   strYouthful_Worker, strApprentice, ClaimNo, s : String;
   Child : TWagelossBenefitCalcForm;
   MoreData : Boolean;
   IndexFactor : Real;
begin
  NewAmt := 0;
  IndexedMinWage := 0;
  //Child := Nil;
  // Set initial salary amount and indexation year for
  // loop through indexation years.
  //
  lngIndex := WagelossMainForm.MDIChildCount;

  for i := 0 to lngIndex - 1 do
     begin
     if WagelossMainForm.MDIChildren[i].ClassType = TWagelossBenefitCalcForm Then
        begin
        Child := WagelossMainForm.MDIChildren[i] as TWagelossBenefitCalcForm;
        if Child.lblAccident_Date.Visible = False then
           begin
           Break;
           end;
        end;
     end;

  try
     with dm1.qWageLossReport do
        begin
        SQL.Clear;
        SQL.Add('DELETE ClaimIndexDetail WHERE ClaimNo = ' + QuotedStr(ClaimNumber));
        SQL.Add('  AND ReportUser = ' + QuotedStr(UserProfile.givenName + ' ' + userProfile.familyName));
        execSQL;
        end;

     MoreData := True; // assume we have something to print
     ClaimNo := CalcFullClaim.Claim_No;
     Year_Cnt := CalcFullClaim.Indexation_Year;
     OldAmt := CalcFullClaim.Wkly_Sal_A;

     while MoreData do
        begin
        with CalcFullClaim do
           begin
           accidentDate := Accident_Date;
           minWage := uGlobal.getMinimumWage(CalcFullClaim.Recurrence, CalcFullClaim.RecurrenceDate, CalcFullClaim.Accident_Date, false);
           //
           // Set minimum indexation year
           //
           if month( Accident_Date ) < 12 then
              min_index_year := year( Accident_Date ) + 2
           else
              min_index_year := year( Accident_Date ) + 3;

           strYouthful_Worker := Youthful_Worker;
           strApprentice := Apprentice;
           end;

        // If indexation year is less than 2 years after the
        // accident, stop processing; otherwise fill in detail
        // line.

        if Year_Cnt < min_index_year then
           begin
           MoreData := False;
           end
        else
           begin
           MoreData := True;
           IndexFactor := valueNCINDEXF( year_cnt );

           if Year(accidentDate) >= 2006 then
              begin
              IndexedMinWage := getIndexedMinWage(minWage, year_cnt);
              end;

           if (strYouthful_Worker = 'N' ) and ( strApprentice = 'N' ) then
              begin
              NewAmt := pdoxRound( oldamt / IndexFactor, 2 );
              end
           else
              begin
              try
                 dm1.usp_Get_Weekly_Sal_History.Parameters.ParamByName( '@Claim_No' ).Value := ClaimNo;
                 dm1.usp_Get_Weekly_Sal_History.Parameters.ParamByName( '@Index_Year' ).Value := year_cnt;
                 dm1.usp_Get_Weekly_Sal_History.Open;
                 OldAmt := dm1.usp_Get_Weekly_Sal_History.Fields[1].Value;
                 NewAmt := dm1.usp_Get_Weekly_Sal_History.Fields[2].Value;
                 Weekly_Increase := OldAmt - NewAmt;

                 if ( strYouthful_Worker = 'Y' ) Then
                    begin
                    IndexFactor := Weekly_Increase;
                    end;

                 dm1.usp_Get_Weekly_Sal_History.Close;
              except
                 on e:Exception Do
                    begin
                    applog('uSaveIndexReport.SaveDetail - Exception - Get Weekly Sal History - Message: ' + e.Message);
                    dm1.usp_Get_Weekly_Sal_History.Close;
                    end;
              end;
              end;

        with dm1.qWageLossReport do
           begin
           SQL.Clear;
           SQL.add( 'INSERT INTO ClaimIndexDetail ' );
           SQL.Add('(claimNo, ClaimSuffix, weeklyWage, indexFactor, indexedWeeklyWage, indexedMinimunWage, ');
           SQL.Add('indexYear, reportUser, reportTime, reportDate ) ');
           SQL.add( 'VALUES(' );

           if (Length(Trim(ClaimNumber)) > 0 ) then
              begin
              SQL.Add(SQLstring(Trim(ClaimNumber)));
              end
           else
              begin
              SQL.Add(SQLString(''));
              end;

           if (Length(Trim(ClaimSuffix)) > 0 ) then
              begin
              SQL.Add(SQLstring(Trim(ClaimSuffix)));
              end
           else
              begin
              SQL.Add(SQLString(''));
              end;

           if NewAmt > 0 then
              begin
              SQL.Add(Format('%8.2f', [NewAmt] ) + ',');
              end
           else
              begin
              SQL.Add(SQLDouble(0));
              end;

           if  IndexFactor > 0 Then
              begin
              SQL.Add( Format('%2.8f', [ IndexFactor ] ) + ',');
              end
           else
              begin
              SQL.Add( SQLDouble( 0 ) );
              end;

           if OldAmt > 0 Then
              begin
              SQL.Add(Format('%8.2f', [OldAmt] ) + ',');
              end
           else
              begin
              SQL.Add(SQLDouble(0));
              end;

           if indexedMinWage > 0 then
              begin
              SQL.Add( Format('%8.2f', [indexedMinWage] ) + ',');
              end
           else
              begin
              SQL.Add(SQLDouble(0));
              end;

           if year_cnt > 0 Then
              begin
              SQL.Add(SQLInteger(year_cnt));
              end
           else
              begin
              SQL.Add(SQLDouble(0));
              end;

           SQL.Add(SQLstring(Reporting_User));
           SQL.Add(SQLstring(Report_Time));

           s := SQLstring(Report_Date);
           s := copy( s, 1, length( s ) - 1 );
           SQL.Add( s );
           SQL.add( ')' );
           execSQL;
           end;
        OldAmt := NewAmt;
        dec(Year_Cnt);
        end;
     end;
  except
     on e:Exception do
        begin
        Applog('uSaveIndexReport.SaveDetail - Exxception - Message: ' + e.Message);
        MessageDlg('SaveDetail: Index Report File Creation Failed.  Please notify help desk at 4573. Message:' + e.Message + ' SQL:' + dm1.qWageLossReport.SQL.Text, mtError, [mbOK], 0 );
        end;
  end;
end;

function valueNCINDEXF( y : integer ) : double;
var
  iii : integer;
begin
  { Get indexation factor for the specified year.}
  indexNCINDEXF := -1;
  for iii := low( arrayNCINDEXF ) to high( arrayNCINDEXF ) do
  begin
    if ( arrayNCINDEXF[iii].Indexation_Year = y ) then
    begin
      indexNCINDEXF:=iii;
      result := arrayNCINDEXF[iii].Indexing_Factor;
      exit;
    end
  end;

  if ( indexNCINDEXF < 0 ) then
  begin
    result:=0.0;
    exit;
  end;

  result:=0.0;
end;

procedure TriggerReport;
var
  ep : TEventPublisher;
  strString : String;
  paramList : TStringList;
begin
  paramList := TStringList.Create;
  strString := 'ReportId=' + ReportId;
  paramList.Add( strString );
  strString := 'Reporting_User=' + Reporting_User;
  paramList.Add( strString );
  strString := 'Report_Time=' + Report_Time;
  paramList.Add( strString );
  strString := 'Report_Date=' + Report_Date;
  paramList.Add( strString );
  try
    ep := TEventPublisher.create( dm1.dbSharedLookup, dm1.dbEmerge, HTTPHOST, 'WAGELOSS', userProfile.loginName, '');
    ep.publishFileDocumentEvent( MQMANAGERNAME, 'IndexationReport', uTriggerEvent.METHOD_OTHER, CalcFullClaim.Claim_No, utilmod1.getEmergeBusinessDate(), paramList );
	except
    on e:Exception do
    begin
		  showAppMessage( e.Message, 2 );
    end;
	end;
  paramList.Free;
end;

(******************************************************************************)
(*                                                                            *)
(*  Convert a double to SQL friendly format                                  *)
(*                                                                            *)
(******************************************************************************)
function SQLDouble( dd : double ) : shortstring;
begin
  result := format('%.3g', [ dd ] ) + ',';
end;

function getMinimumWage: currency;
var
  lngReturn : Integer;
begin
  Result := 0;

  try
     dm1.usp_Get_Minimum_Wage.Parameters.ParamByName( '@accidentDate' ).Value := CalcFullClaim.Accident_Date;
     dm1.usp_Get_Minimum_Wage.Open;
     lngReturn := dm1.usp_Get_Minimum_Wage.Parameters.ParamByName( '@RETURN_VALUE' ).Value;

     if lngReturn = 0 Then
        begin
        if Not dm1.usp_Get_Minimum_Wage.Eof Then
           begin
           Result := dm1.usp_Get_Minimum_Wage.FieldByName( 'minWage' ).Value;
           end;

        dm1.usp_Get_Minimum_Wage.Close;
        end;
  except
     on e:Exception do
        begin
        applog('uSaveIndexReport.getMinimumWage - Exception - Message: ' + e.Message);
        Result := 0;
        dm1.usp_Get_Minimum_Wage.Close;
        MessageDlg( '*Retrieve of Minimum Wage Failed.  Please notify help desk at 4573.', mtError, [mbOK], 0 );
        end;
  end;
end;

function getIndexedMinWage( minWage : Currency; Year_Cnt : Integer ) : currency;
var
  nc_index_amt : currency;
  nc_cnt, accidentYear : integer;
begin
  if month( CalcFullClaim.Accident_Date ) < 12 then
    accidentYear := year( CalcFullClaim.Accident_Date ) + 2
  else
    accidentYear := year( CalcFullClaim.Accident_Date ) + 3;

  nc_index_amt := minWage;

  for nc_cnt := accidentYear to Year_Cnt do
  begin
    nc_index_amt := pdoxRound( nc_index_amt * valueNCINDEXF( nc_cnt ), 2 )
  end;

  Result := nc_index_amt;
end;

end.
