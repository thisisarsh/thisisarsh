unit NCWrkRptJul18;

interface

uses
  Winapi.Windows, Winapi.Messages, System.SysUtils, System.Variants, System.Classes, Vcl.Graphics,
  Vcl.Controls, Vcl.Forms, Vcl.Dialogs, NCWrkRptJan18;

type
  TWrkRptJul18 = class(TWrkRptJan18)
  function getDateHeading():String; Override;
  private
    { Private declarations }
  public
    { Public declarations }
  end;

var
  WrkRptJul18: TWrkRptJul18;

implementation

{$R *.dfm}

{ TWrkRptJul18 }
(******************************************************************************)
(*                                                                            *)
(*  override this function for each class to avoid having to bring in all of  *)
(*    the methods that contain the date in the heading.                       *)
(*   IE:  the jan 09 class should return  2008/2009                           *)
(*        the july 09 class should return 2009                                *)
(*                                                                            *)
(******************************************************************************)

function TWrkRptJul18.getDateHeading: String;
begin
  Result:='2018'
end;

end.
