unit CrystalPrev;

//*******************************************************************************
//Author:      Dale Madill
//Description: This unit will provide the Crystal Preview and print functionality
//             to the Wageloss system.
//
//Maintenance:
//
//*******************************************************************************


interface

uses
  Windows, Classes, Graphics, Forms, Controls,Menus,
  ExtCtrls, Buttons, Dialogs, SysUtils, UCRPE32, StdCtrls, Printers, Mask,
  ComCtrls, UCrpeClasses;

type
  TfCrystalPrev = class(TForm)
    pnlControl: TPanel;
    Crpe1: TCrpe;
    procedure FormClose(Sender: TObject; var Action: TCloseAction);
    procedure FormResize(Sender: TObject);
    procedure Do_Preview(const RptName: string;
			                   const RptTitle: String;
                         const RptDestination:String;
                         const parms : array of variant);
    procedure bitBtnCloseClick(Sender: TObject);
    procedure FormDestroy(Sender: TObject);
    procedure FormCreate(Sender: TObject);
    procedure Crpe1wOnCloseBtnClick(WindowHandle: HWND; ViewIndex: Word;
                                    var Cancel: Boolean);
    procedure Crpe1wOnCloseWindow(WindowHandle: HWND; var Cancel: Boolean);
    procedure Crpe1WindowClose(Sender: TObject);
    procedure Crpe1wOnCancelBtnClick(WindowHandle: HWND; var Cancel: Boolean);
  private
    { Private declarations }
  public
    { Public declarations }
    procedure Rpt_Prev(const RptName: string;
                       const RptTitle: String;
                       const RptDestination:String;
                       const parms : array of variant);
  end;


var
  fCrystalPrev: TfCrystalPrev;

implementation

uses uADOSecurity, uGlobal, uSavePrint, NCDatMod, NCIniMod;

{$R *.DFM}

procedure TfCrystalPrev.FormClose(Sender: TObject; var Action: TCloseAction);
begin
  Crpe1.CloseWindow;
  Action := caFree;
end;

procedure TfCrystalPrev.FormResize(Sender: TObject);
var
   MyWindow : hWnd;
begin
  MyWindow := Crpe1.ReportWindowHandle;
  SetWindowPos(MyWindow, HWND_TOP, 0, Self.pnlControl.Height, Self.ClientWidth-1,
               Self.ClientHeight-Self.pnlControl.Height, SWP_NOZORDER);
end;

procedure TfCrystalPrev.Do_Preview(const RptName: string;
			                             const RptTitle: String;
                                   const RptDestination:String;
                                   const parms : array of variant);
var
  i : Byte;
begin

  Screen.Cursor := crHourGlass;
  //--
  FreeAndNil(Crpe1);
  Crpe1 := TCrpe.Create(Self);
  Crpe1.Clear;
  //--
  try
     //
     // Get the name and Title of the report
     //
     Crpe1.ReportName := ExtractFilePath(application.ExeName) + RptName;

     if Length(RptTitle) <> 0 then
        Crpe1.ReportTitle:=RptTitle
     else
	      Crpe1.ReportTitle:=RptName;
     //
     // Use the Window Parent Handle to make the owner of the Crystal Preview window
     //the MDIChild form.  The preview window will then appear as part of the Child
     //form.  This is what allows a true MDI Child behavior for a Crystal Report
     //preview window}
     //
     Crpe1.ProgressDialog:=True;
     //
     // Configure the appearance of the preview window within the Child form
     //
     if RptDestination = 'P' Then
        Crpe1.Output := toPrinter
     else
        Crpe1.Output := toWindow;

     Crpe1.WindowParent := self;
     Crpe1.DialogParent := self;
     Crpe1.WindowButtonBar.Visible := True;
     Crpe1.WindowStyle.SystemMenu := False;
     Crpe1.WindowStyle.BorderStyle := bsNone;
     Crpe1.WindowSize.Top := 1;
     Crpe1.WindowSize.Left := 1;
     Crpe1.WindowSize.Height := Self.ClientHeight - pnlControl.Height;
     Crpe1.WindowSize.Width := Self.ClientWidth - 1;
     Crpe1.WindowButtonBar.RefreshBtn:=True;
     Crpe1.WindowButtonBar.ProgressCtls:=False;
     Crpe1.WindowButtonBar.CloseBtn:=True;
     Crpe1.WindowButtonBar.NavigationCtls:=True;
     Crpe1.WindowButtonBar.PrintBtn:=True;
     Crpe1.WindowButtonBar.PrintSetupBtn:=True;
     Crpe1.WindowButtonBar.SearchBtn:=True;
     Crpe1.WindowButtonBar.ExportBtn:=True;
     Crpe1.Printer.Orientation := orPortrait;
     //
     // Get and set data connection settings
     //
     //{$IFDEF VER120}
     //Crpe1.ConnectMethod:=useConnect;
     //Crpe1.Connect.Retrieve;
     //Crpe1.DiscardSavedData:=True;
     //{$ENDIF}
     //
     // For
     //
     Crpe1.Connect.ServerName := uGlobal.CurrServer1;
     Crpe1.Connect.DatabaseName := uGlobal.CurrDataBaseName1;
     //Crpe1.Connect.DatabaseName:='Wageloss_DB';  // set to the ODBC Name
     Crpe1.Connect.UserID:=uADOSecurity.userProfile.sqlLoginName;
     Crpe1.Connect.Password:=uADOSecurity.userProfile.sqlLoginPassword;
     //{$IFDEF VER120}
     //Crpe1.Connect.Propagate := True;
     //{$ENDIF}
     //
     // Modify the zone on the report to match the screen size
     // the larger the screen width the larger the zoom
     //
     if Screen.Width < 1024 Then
        Crpe1.WindowZoom.Magnification := 85
     else if Screen.Width < 1280 Then
        Crpe1.WindowZoom.Magnification := 100
     else
        Crpe1.WindowZoom.Magnification := 110;
     //
     //	Get the Parameters of the report
     //
     if low(parms)< High(parms) then
     	begin
      //{$IFDEF VER120}
     	//Crpe1.ParamFields.Retrieve;
      //{$ENDIF}
     	if Crpe1.ParamFields.Count > 0 then
           begin
     	   for i := low(parms) to high(parms) do
              begin
              //{$IFDEF VER120}
              //Crpe1.ParamFields[i].Value := parms[i];
              //{$ELSE}
              Crpe1.ParamFields[i].CurrentValue := parms[i];
              //{$ENDIF}
     	      end;
     	   end;
     	end;

     if Crpe1.Connect.Test Then
        Crpe1.Execute
     else
        ShowMessage('Error Logging on to Server');

     Screen.Cursor := crDefault;
  except
     Screen.Cursor := crDefault;
     raise;
  end;
end;

procedure TfCrystalPrev.bitBtnCloseClick(Sender: TObject);
begin
  Close;
end;

procedure TfCrystalPrev.Rpt_Prev(const RptName: string;
		                             const RptTitle: String;
                                 const RptDestination:String;
                                 const parms : array of variant);
begin
  LockWindowUpdate(Application.Handle);
  Do_Preview(RptName,RptTitle, RptDestination, parms);
  LockWindowUpdate(0);
  if RptDestination = 'P' then
     Close;
end;


procedure TfCrystalPrev.FormDestroy(Sender: TObject);
begin
//
  Close;
end;


procedure TfCrystalPrev.FormCreate(Sender: TObject);
begin
  Crpe1.WindowEvents := True;
end;


procedure TfCrystalPrev.Crpe1WindowClose(Sender: TObject);
begin
  Close;
end;

procedure TfCrystalPrev.Crpe1wOnCancelBtnClick(WindowHandle: HWND;
  var Cancel: Boolean);
begin
Close;
end;

procedure TfCrystalPrev.Crpe1wOnCloseBtnClick(WindowHandle: HWND;
  ViewIndex: Word; var Cancel: Boolean);
begin
Close;
end;


procedure TfCrystalPrev.Crpe1wOnCloseWindow(WindowHandle: HWND;
  var Cancel: Boolean);
begin
  Close;
end;

end.
 