inherited WrkRptJul11: TWrkRptJul11
  Left = 538
  Top = 164
  Caption = 'WrkRptJul11'
  PixelsPerInch = 96
  TextHeight = 13
end
