unit NCIndexFactorRpt;

interface

uses
  Windows, Messages, SysUtils, Variants, Classes, Graphics, Controls, Forms,
  Dialogs, QRCtrls, QuickRpt, ExtCtrls;

type
  TPrintIndexForm = class(TForm)
    QRIndexationFactors: TQuickRep;
    QRBand1: TQRBand;
    QRSysData2: TQRSysData;
    QRSysData1: TQRSysData;
    QRSysData3: TQRSysData;
    QRUserID: TQRLabel;
    QRLabel9: TQRLabel;
    QRLabel1: TQRLabel;
    QRLabel2: TQRLabel;
    QRBand2: TQRBand;
    QRLabel3: TQRLabel;
    QRLabel4: TQRLabel;
    QRBand3: TQRBand;
    QRIndexYear: TQRLabel;
    QRIndexFactor: TQRLabel;
    procedure QRIndexationFactorsBeforePrint(Sender: TCustomQuickRep;
      var PrintReport: Boolean);
    procedure QRIndexationFactorsNeedData(Sender: TObject;
      var MoreData: Boolean);
    procedure QRBand3BeforePrint(Sender: TQRCustomBand;
      var PrintBand: Boolean);
  private
    { Private declarations }
     acdntYear, iii, jjj: integer;
  public
    { Public declarations }
  end;

var
  PrintIndexForm: TPrintIndexForm;

implementation

{$R *.dfm}
uses
  NCIniMod, NCMain, uADOSecurity;

procedure TPrintIndexForm.QRIndexationFactorsBeforePrint(
  Sender: TCustomQuickRep; var PrintReport: Boolean);
begin
  {Set starting point for both indexation factor and
   annual maximum arrays.}
  iii := low(arrayNCINDEXF);
  jjj := low(arrayNCANNMAX);
  QRUserID.caption := UserProfile.givenName + ' ' + userProfile.familyName;
  acdntYear := arrayNCANNMAX[jjj].Accident_Year; //***
  //QRBand3.Frame.DrawBottom := False; //***

end;

procedure TPrintIndexForm.QRIndexationFactorsNeedData(Sender: TObject;
  var MoreData: Boolean);
begin
  If (iii > high(arrayNCINDEXF)) then
     MoreData := False {the end of the array has been reached}
  Else
  If ((iii <= high(arrayNCINDEXF)) and (length(IntToStr(arrayNCINDEXF[iii].Indexation_Year)) <= 1)) then
     MoreData := False {lengths of 1 indicate blank array values}
  Else
     MoreData := True;

  // Print values from Indexation Factors Array
  If (iii <= high(arrayNCINDEXF)) and
     (length(IntToStr(arrayNCINDEXF[iii].Indexation_Year)) > 1) then
  Begin
    QRIndexYear.caption  := IntToStr(arrayNCINDEXF[iii].Indexation_Year);
    QRIndexFactor.caption := Format('%.7n', [arrayNCINDEXF[iii].Indexing_Factor]);
    Inc(iii);
  End
  Else
  Begin
    QRIndexYear.Caption  := '';
    QRIndexFactor.Caption := '';
  End;


end;

procedure TPrintIndexForm.QRBand3BeforePrint(Sender: TQRCustomBand;
  var PrintBand: Boolean);
var
  i : Integer;
begin
  with QRBand3 do
  begin
    for i := 0 to ControlCount-1 do
    begin
      if TQRLabel(Controls[i]).Color = $00F0F0F0 then
         TQRLabel(Controls[i]).Color := $00E0E0E0
      else
        TQRLabel(Controls[i]).Color := $00F0F0F0;
    end;
  end;
end;

end.
