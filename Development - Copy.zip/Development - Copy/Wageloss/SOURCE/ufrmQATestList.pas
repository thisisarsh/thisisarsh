unit ufrmQATestList;

interface

uses
  Windows, Messages, SysUtils, Variants, Classes, Graphics, Controls, Forms,
  Dialogs, StdCtrls, DB, Grids, DBGrids, DBCtrls, ExtCtrls,
  Buttons, Mask, ComCtrls,NCDatMod, NCMain, Menus, Utils, Data.Win.ADODB, ADOInt;

type
  TfrmQATestList = class(TForm)
    DataSource1: TDataSource;
    Panel1: TPanel;
    Panel2: TPanel;
    Edit1: TEdit;
    CheckBox1: TCheckBox;
    Button3: TButton;
    ComboBox2: TComboBox;
    ComboBox1: TComboBox;
    Panel3: TPanel;
    DBNavigator1: TDBNavigator;
    btnRefreshData: TBitBtn;
    cmbYear: TComboBox;
    lblSearchField: TLabel;
    Label1: TLabel;
    Label22: TLabel;
    Label24: TLabel;
    cbxIndexationOnly: TCheckBox;
    dbgridQAData: TDBGrid;
    PopupMenu1: TPopupMenu;
    Delete1: TMenuItem;
    Edit2: TMenuItem;
    NewAttachtoIndex1: TMenuItem;
    qryQATestList: TADOQuery;
    Q: TADOQuery;
    procedure FormCreate(Sender: TObject);
    procedure FormShow(Sender: TObject);
    procedure FormClose(Sender: TObject; var Action: TCloseAction);
    procedure dbgridQADataTitleClick(Column: TColumn);
    procedure qryQATestListFilterRecord(DataSet: TDataSet; var Accept: Boolean);
    procedure btnRefreshDataClick(Sender: TObject);
    procedure dbgridQADataKeyPress(Sender: TObject; var Key: Char);
    procedure CheckBox1Click(Sender: TObject);
    procedure Button3Click(Sender: TObject);
    procedure ComboBox2Change(Sender: TObject);
    procedure ComboBox1DrawItem(Control: TWinControl; Index: Integer;
      Rect: TRect; State: TOwnerDrawState);
    procedure ComboBox1Select(Sender: TObject);
    procedure cmbYearChange(Sender: TObject);
    procedure dbgridQADataDblClick(Sender: TObject);
    procedure dbgridQADataDrawColumnCell(Sender: TObject; const Rect: TRect;
      DataCol: Integer; Column: TColumn; State: TGridDrawState);
    procedure Edit1Change(Sender: TObject);
    procedure Edit2Click(Sender: TObject);
    procedure Delete1Click(Sender: TObject);
    procedure dbgridQADataKeyUp(Sender: TObject; var Key: Word;
      Shift: TShiftState);
    procedure NewAttachtoIndex1Click(Sender: TObject);
  private
    { Private declarations }
    saveIsTestCalculator:boolean;
    saveIsRunManualTest:boolean;
    saveIsRunAutoTest:boolean;
    sortField : String;
    sortFieldType : TFieldType;
    savePlace : TBookmark;
    Selected: array of Boolean;
    procedure ResetGrid(isDefault : Boolean);
  public
    { Public declarations }
  end;

var
  frmQATestList: TfrmQATestList;


const
  sqlQA  = 'SELECT *'+#13#10+'FROM QAData'+#13#10+
           'WHERE QATestID IN (SELECT QATestID FROM QAData GROUP BY QATestID HAVING COUNT(*) = 1  )'+#13#10+
           'ORDER BY QADataID, QATestIndexID';

  sqlQAwithWhere  = 'SELECT *'+#13#10+'FROM QAData'+#13#10+
           'WHERE QATestID IN (SELECT QATestID FROM QAData GROUP BY QATestID HAVING COUNT(*) = 1  )'+#13#10+
           'AND Year(Accident_Date) = %S'+#13#10+
           'ORDER BY QADataID, QATestIndexID';

  sqlQAIndex = 'SELECT *'+#13#10+'FROM QAData'+#13#10+
               'WHERE QATestID IN (SELECT QATestID FROM QAData GROUP BY QATestID HAVING COUNT(*) > 1  )'+#13#10+
               'ORDER BY QADataID, QATestIndexID';

  sqlQAIndexWithWhere = 'SELECT *'+#13#10+'FROM QAData'+#13#10+
               'WHERE QATestID IN (SELECT QATestID FROM QAData GROUP BY QATestID HAVING COUNT(*) > 1  )'+#13#10+
               'AND Year(Accident_Date) = %S'+#13#10+
               'ORDER BY QADataID, QATestIndexID';


implementation

uses DateUtils, Math, NCBencal;

{$R *.dfm}

procedure FreeObjects(const strings: TStrings) ;
var
  idx : integer;
begin

  for idx := 0 to Pred(strings.Count) do
     begin
     strings.Objects[idx].Free;
     strings.Objects[idx] := nil;
     end;
end;

procedure FreeBookmks(const strings: TStrings) ;
var
  idx : integer;
begin
  for idx := 0 to Pred(strings.Count) do
     begin
     strings.Strings[idx] := EmptyStr;
     end;
end;

procedure LoadCombo(_sql :String; var Combo:TComboBox);
begin
  with dm1.Query1 do
     begin
     try
        Close;
        SQL.Text := '';
        SQL.Text := _sql;
        Open;
        Combo.Items.Clear;
        Combo.Text:='';
        Combo.Items.Add('All');
        while not Eof do
           begin
           Combo.Items.Add(Fields.Fields[0].AsString);
           Next;
           end;
        Close;
        SQL.Text:='';
     except
        on e: Exception do
           begin
           applog('Exception detected - frmQATestList.LoadCombo. Message = ' + e.Message);
           end;
     end;
     end;

end;


procedure TfrmQATestList.dbgridQADataTitleClick(Column: TColumn);
var
  i : Integer;
  newOrderBySQL : String;
begin

  ResetGrid(False);

  sortField := Column.FieldName;
  sortFieldType := Column.Field.DataType;

  LockWindowUpdate(Handle);

  Edit1.Text := '';
  CheckBox1.Checked := False;

  Column.Title.Font.Style := Column.Title.Font.Style + [fsBold];
  lblSearchField.Caption := 'Search By ' + Column.Title.Caption;

  newOrderBySQL := 'order by ' + Column.Title.Caption;

  with qryQATestList do
     begin
     DisableControls;
     Filtered := False;
     Close;

     if Active then
        Close;

     for i := 0 to SQL.Count - 1 do
        begin
        if (Pos(LowerCase(newOrderBySQL), LowerCase(SQL[i])) > 0) then
           begin
           if (Pos(' desc',LowerCase(SQL[i])) > 0) then
              SQL[i] := newOrderBySQL
           else
              begin
              SQL[i] := newOrderBySQL +' desc';
              Column.Title.Font.Color := clRed;
              end;
           end
        else if (Pos('order by', LowerCase(SQL[i])) > 0) then
           begin
           SQL[i] := newOrderBySQL
           end;
        Column.Color := $00D4D4D4;
        end;

      // re-add params here if necessary

      if not Active then
         Open;
      EnableControls;
     end;
  LockWindowUpdate(0);
end;

procedure TfrmQATestList.qryQATestListFilterRecord(DataSet: TDataSet;
  var Accept: Boolean);
begin

  if Edit1.Text = '' then
     begin
     Accept := True;
     qryQATestList.Filtered := False;
     end
  else
     begin
     Accept := Pos( LowerCase(Edit1.Text), LowerCase(DataSet.FieldByName(sortField).AsString) ) > 0;
     end;
end;


procedure TfrmQATestList.btnRefreshDataClick(Sender: TObject);
begin
  cmbYearChange(cmbYear);
end;

procedure TfrmQATestList.dbgridQADataKeyPress(Sender: TObject; var Key: Char);
begin
  if Key in ['A'..'Z', 'a'..'z','0'..'9','-','_'] then
     begin
     Edit1.Text := Key;
     Edit1.SetFocus;
     Edit1.SelLength := 0;

     Edit1.SelStart  := Length(Edit1.Text);
     end;
end;

procedure TfrmQATestList.FormShow(Sender: TObject);
var
 i : Integer;
 S : String;
begin

  with dbgridQAData do
     begin
     for i := 0 to Columns.Count -1  do
        begin
        if Columns[i].FieldName = 'QATestID' then
           begin
           sortField := Columns[i].FieldName;
           sortFieldType := Columns[i].Field.DataType;
           lblSearchField.Caption := 'Search By '+Columns[i].Title.Caption;
           Columns[i].Title.Font.Style := Columns[i].Title.Font.Style + [fsBold];
           Columns[i].Color := $00D4D4D4;
           end;
        end;
     end;

  S := 'select distinct Year(Accident_Date) from QAData order by Year(Accident_Date) DESC';

  LoadCombo(S, cmbYear);
end;

procedure TfrmQATestList.FormClose(Sender: TObject; var Action: TCloseAction);
begin
  with qryQATestList do
     begin
     Filtered := False;
     Close;
     end;

  ComboBox2.Items.Clear;
  Action := caFree;
  frmQATestList := nil;
end;

procedure TfrmQATestList.CheckBox1Click(Sender: TObject);
begin
  if not qryQATestList.Filtered and (Edit1.Text <> EmptyStr) and CheckBox1.Checked then
     qryQATestList.Filtered := True
  else
     qryQATestList.Filtered := False;

  Edit1.SetFocus;
  Edit1.SelStart  := Length(Edit1.Text);
end;

procedure TfrmQATestList.Button3Click(Sender: TObject);
begin

  with qryQATestList, ComboBox2 do
     begin
     AddItem(FieldByName('QATestID').AsString, TObject(GetBookmark));
     end;

end;

procedure TfrmQATestList.ComboBox2Change(Sender: TObject);
var
  currentBookMark : TBookmark;
begin
  if ComboBox2.Items.Count > 0 then
     begin
     currentBookMark := TBookmark(ComboBox2.Items.Objects[ComboBox2.ItemIndex]);
     qryQATestList.GotoBookmark(currentBookMark);
     end;
end;

procedure TfrmQATestList.ResetGrid(isDefault : Boolean);
var
  i : Integer;
begin

  for i := 0 to qryQATestList.FieldCount - 1 do
     begin
     if qryQATestList.Fields.Fields[i].Visible then
        qryQATestList.Fields.Fields[i].Alignment := taRightJustify;
     end;

  with dbgridQAData do
     begin
     for i := 0 to Columns.Count - 1 do
        begin
        Columns[i].Title.Font.Style := Columns[i].Title.Font.Style - [fsBold];
        Columns[i].Title.Font.Color := clWindowText;
        Columns[i].Color:= clWindow;

        if isDefault and (Columns[i].FieldName = 'QATestID') then
           begin
           sortField := Columns[i].FieldName;
           sortFieldType := Columns[i].Field.DataType;
           lblSearchField.Caption := 'Search By '+Columns[i].Title.Caption;
           Columns[i].Title.Font.Style := Columns[i].Title.Font.Style + [fsBold];
           Columns[i].Color := $00D4D4D4;
           end;
        end;

     Refresh;
     end;
end;

procedure TfrmQATestList.ComboBox1DrawItem(Control: TWinControl; Index: Integer;
  Rect: TRect; State: TOwnerDrawState);
begin
  SetLength(Selected, TComboBox(Control).Items.Count);

  with TComboBox(Control).Canvas do
     begin
     FillRect(rect);

     Rect.Left := Rect.Left + 1;
     Rect.Right := Rect.Left + 13;
     Rect.Bottom := Rect.Bottom;
     Rect.Top := Rect.Top;

     if not (odSelected in State) and (Selected[Index]) then
        DrawFrameControl(Handle, Rect, DFC_BUTTON, DFCS_BUTTONCHECK or DFCS_CHECKED or DFCS_FLAT)
     else if (odFocused in State) and (Selected[Index]) then
        DrawFrameControl(Handle, Rect, DFC_BUTTON, DFCS_BUTTONCHECK or DFCS_CHECKED or DFCS_FLAT)
     else if (Selected[Index]) then
        DrawFrameControl(Handle, Rect, DFC_BUTTON, DFCS_BUTTONCHECK or DFCS_CHECKED or DFCS_FLAT)
     else if not (Selected[Index]) then
        DrawFrameControl(Handle, Rect, DFC_BUTTON, DFCS_BUTTONCHECK or DFCS_FLAT);

     TextOut(Rect.Left + 15, Rect.Top, TComboBox(Control).Items[Index]);
     end;
end;

procedure TfrmQATestList.FormCreate(Sender: TObject);
var
  i : Integer;
  pForm:TWagelossBenefitCalcForm;
begin

  if not FindCmdLineSwitch('D') then
     Delete1.Visible := False;

  qryQATestList.Open;

  for i := 0 to qryQATestList.FieldCount - 1 do
     begin
     if qryQATestList.Fields.Fields[i].Visible then
        qryQATestList.Fields.Fields[i].Alignment := taRightJustify;

     end;

    with WagelossMainForm do
     begin
     SaveIsTestCalculator := isTestCalculator;
     SaveIsRunManualTest := isRunManualTest;
     SaveIsRunAutoTest := isRunAutoTest;
     end;

  ComboBox1.Clear;

  for i := 0 to qryQATestList.FieldCount - 1 do
     begin
     ComboBox1.Items.Add(qryQATestList.FieldDefList.FieldDefs[i].Name);
     end;
end;

procedure TfrmQATestList.ComboBox1Select(Sender: TObject);
var
  i: Integer;
  Sel: string;
begin
  Sel := EmptyStr;
  Selected[TComboBox(Sender).ItemIndex] := not Selected[TComboBox(Sender).ItemIndex];

  for i := 0 to TComboBox(Sender).Items.Count - 1 do
     begin
     if Selected[i] then
        Sel := Sel + TComboBox(Sender).Items[i] + ' ';
     end;
end;

procedure TfrmQATestList.cmbYearChange(Sender: TObject);
begin
  LockWindowUpdate(Handle);
  Edit1.Text := '';
  CheckBox1.Checked := False;

  try
     with qryQATestList do
        begin
        DisableControls;
        Close;
        if cmbYear.Text = 'All' then
           begin
           if cbxIndexationOnly.Checked then
              SQL.Text := sqlQAIndex
           else
              SQL.Text := sqlQA;
           end
        else if cmbYear.Text <> '' then
           begin
           if cbxIndexationOnly.Checked then
              SQL.Text := Format(sqlQAIndexWithWhere,[cmbYear.Text])
           else
              SQL.Text := Format(sqlQAwithWhere,[cmbYear.Text]);
           end;
        Open;
        ResetGrid(True);
        EnableControls;
        end;
  finally
     ComboBox2.Items.Clear;
     ComboBox2.Text := '';
     LockWindowUpdate(0);
  end;
end;

procedure TfrmQATestList.dbgridQADataDblClick(Sender: TObject);
var
  pForm: TWagelossBenefitCalcForm;
  sQATestID : String;
begin
  if cbxIndexationOnly.Checked and (qryQATestList.FieldByName('Indexed_Year').AsInteger > 0) then
     begin
     MyMessageDialog('Indexed Year should be 0, for re-do Indexation.',
                     mtInformation,[mbOK] ,['OK']);
     exit;
     end;

  if cbxIndexationOnly.Checked and
     (MyMessageDialog(Format('Remove Current Indexation entries of %D and create new entries  ?',[qryQATestList.FieldByName('QATestID').AsInteger]),
                      mtConfirmation, mbOKCancel,
                      ['Re-Create', 'Cancel']) = mrCancel ) then
     begin
     exit;
     end;

  pForm :=  Application.FindComponent('WagelossBenefitCalcForm') as TWagelossBenefitCalcForm;

  if pForm = nil then
     begin
     WagelossMainForm.isRunManualTest := saveIsRunManualTest;
     WagelossMainForm.isTestCalculator := saveIsTestCalculator;
     WagelossMainForm.isRunAutoTest := saveIsRunAutoTest;
     WagelossMainForm.inTesting := WagelossMainForm.isRunManualTest or WagelossMainForm.isTestCalculator or WagelossMainForm.isRunAutoTest;
     pForm := TWagelossBenefitCalcForm.Create(application);
     if WagelossMainForm.isTestCalculator then
       pForm.Caption := 'WageLoss Benefit Calculator - Test Data capture';
     if WagelossMainForm.isRunManualTest then
       pForm.Caption := 'WageLoss Benefit Calculator - Manual Test';
     if WagelossMainForm.isRunAutoTest then
       pForm.Caption := 'WageLoss Benefit Calculator - Auto Test';
     pForm.lblAccident_Date.Visible := False;
     end;

  if (WagelossMainForm.inTesting) then
     begin
     try
        LockWindowUpdate(pForm.Handle);
        sQATestID := qryQATestList.FieldByName('QATestID').AsString;

        if sQATestID <> EmptyStr then
           begin
           pForm.isInTestIndexationEditMode := cbxIndexationOnly.Checked;
           pForm.qryEditTestRecord := qryQATestList;

           if cbxIndexationOnly.Checked and
              (MyMessageDialog(Format(' Do you want remove all Indexation Entries for %D now ? or leave it as it is and create a new set !',
                                      [qryQATestList.FieldByName('QATestID').AsInteger]),
                                      mtConfirmation, mbOKCancel,
                                      ['Remove It', 'Leave It']) = mrOK ) then
              begin
              with dm1.Query1 do
                 begin
                 try
                    Close;
                    SQL.Text := Format('DELETE FROM QAData WHERE QATestID = %D',[qryQATestList.FieldByName('QATestID').AsInteger]);
                    ExecSQL;
                    btnRefreshDataClick(btnRefreshData);
                    SQL.Text := '';
                 except

                 end;
                 end;
              end;
           end;
     finally
        LockWindowUpdate(0);
        pForm.cmbAccidentYear.ItemIndex := pForm.cmbAccidentYear.Items.IndexOf(Copy(sQATestID,0,4));
        if pForm.ValidateAndRecalcBen and WagelossMainForm.isRunManualTest then
           begin
           pForm.CheckForMisMatchValues;
           end;
        pForm.Update;
        pForm.Show;
     end;
     end;
end;

procedure TfrmQATestList.dbgridQADataDrawColumnCell(Sender: TObject;
  const Rect: TRect; DataCol: Integer; Column: TColumn;
  State: TGridDrawState);
begin
  if (gdFocused in State) or (gdSelected in State) then
     begin
     with dbgridQAData.Canvas do
        begin
        Brush.Color := clBlack;
        Font.Style  := Font.Style + [fsBold];
        Font.Color  := clYellow;
        end;

     end;

  dbgridQAData.DefaultDrawColumnCell(Rect, DataCol, Column, State);
end;

procedure TfrmQATestList.Edit1Change(Sender: TObject);
begin
  if Edit1.Text <> EmptyStr then
     begin
     with qryQATestList do
        begin
        Filtered := CheckBox1.Checked;
        if not Filtered then
           Locate(sortField,Edit1.Text,[loCaseInsensitive,loPartialKey])
        end;
     end;
end;

procedure TfrmQATestList.Edit2Click(Sender: TObject);
begin
  dbgridQADataDblClick(dbgridQAData);
end;

procedure TfrmQATestList.Delete1Click(Sender: TObject);
begin
  if MessageDlg(' Do you want to delete this entry.  Delete now ?', mtConfirmation, [mbYes, mbNo], 0) = mrYes then
     begin
     with dm1.Query1 do
        begin
        try
           Close;
           SQL.Text := Format('DELETE FROM QAData WHERE QADataID = %D',[qryQATestList.FieldByName('QADataID').AsInteger]);
           ExecSQL;
           btnRefreshDataClick(btnRefreshData);
           SQL.Text := '';
        except
        end;
        end;
     end;
end;

procedure TfrmQATestList.dbgridQADataKeyUp(Sender: TObject; var Key: Word;
  Shift: TShiftState);
begin
  if (Key = VK_RETURN) and (Shift = [ssCtrl]) then
     dbgridQADataDblClick(dbgridQAData);
end;

procedure TfrmQATestList.NewAttachtoIndex1Click(Sender: TObject);
var
  pForm: TWagelossBenefitCalcForm;
  sQATestID : String;
begin

  if cbxIndexationOnly.Checked and (qryQATestList.FieldByName('Indexed_Year').AsInteger > 0) then
     begin
     MyMessageDialog('Indexed Year should be 0, for re-do Indexation.',
                     mtInformation,[mbOK] ,['OK']);
     exit;
     end;

  if cbxIndexationOnly.Checked and
    (MyMessageDialog(Format('Remove Current Indexation entries of %D and create new entries  ?',[qryQATestList.FieldByName('QATestID').AsInteger]),
                     mtConfirmation, mbOKCancel,
                     ['Re-Create', 'Cancel']) = mrCancel ) then
     begin
     exit;
     end;



  pForm :=  Application.FindComponent('WagelossBenefitCalcForm') as TWagelossBenefitCalcForm;
  if WagelossMainForm.isTestCalculator then
     begin
     try
        LockWindowUpdate(pForm.Handle);
        sQATestID := qryQATestList.FieldByName('QATestID').AsString;

        if sQATestID <> EmptyStr then
           begin
           pForm.isInTestIndexationEditMode := cbxIndexationOnly.Checked;
           pForm.qryEditTestRecord := qryQATestList;
           if cbxIndexationOnly.Checked and
              (MyMessageDialog(Format(' Do you want remove all Indexation Entries for %D now ? or leave it as it is and create a new set !',
                                      [qryQATestList.FieldByName('QATestID').AsInteger]),
                                      mtConfirmation, mbOKCancel,
                                      ['Remove It', 'Leave It']) = mrOK ) then
              with dm1.Query1 do
                 begin
                 try
                    Close;
                    SQL.Text := Format('DELETE FROM QAData WHERE QATestID = %D',[qryQATestList.FieldByName('QATestID').AsInteger]);
                    ExecSQL;
                    btnRefreshDataClick(btnRefreshData);
                    SQL.Text := '';
                 except

                 end;
                 end;

           pForm.Show;
           end;
     finally
        LockWindowUpdate(0);
     end;
     end;
end;

end.
