(*****************************************************************)
(*  Wageloss System                                              *)
(*                                                               *)
(*  Claim Indexation Report                                      *)
(*                                                               *)
(*                                                               *)
(*  Author: Ron Warkentin / WCB                                  *)
(*  Date:   August 1997                                          *)
(*****************************************************************)
(*                                                               *)
(*  Change Log                                                   *)
(*                                                               *)
(*  Oct 97 - use WagelossBenefitCalcForm.CalcFullClaim instead   *)
(*           of dataClaim to allow report to be printed before   *)
(*           updating.                                           *)
(*                                                               *)
(*  Jan 98 - Calculate mimimum accident year, depending on month *)
(*           of accident.  Since the basis for indexation is     *)
(*           the month after accident, December claims           *)
(*           are only indexed beginning 3 years after accident,  *)
(*           versus 2 years for other claims.                    *)
(*                                                               *)
(*****************************************************************)

unit NCIdxClm;

interface

uses
  Windows, Messages, SysUtils, Classes, Graphics, Controls, Forms, Dialogs,
  Qrctrls, quickrpt, ExtCtrls;

type
  TPrintClaimIndexationForm = class(TForm)
    QRIndexedClaim: TQuickRep;
    QRBand1: TQRBand;
    QRLabel1: TQRLabel;
    QRLabel2: TQRLabel;
    QRSysData4: TQRSysData;
    QRSysData2: TQRSysData;
    QRSysData1: TQRSysData;
    QRUserID: TQRLabel;
    QRSysData3: TQRSysData;
    QRLabel3: TQRLabel;
    QRLabel4: TQRLabel;
    QRLabel5: TQRLabel;
    QRClaimNumber: TQRLabel;
    QRName: TQRLabel;
    QRAddr1: TQRLabel;
    QRAddr2: TQRLabel;
    QRAddr3: TQRLabel;
    QRLabel6: TQRLabel;
    QRLabel7: TQRLabel;
    QRLabel8: TQRLabel;
    QRLabel9: TQRLabel;
    QRSIN: TQRLabel;
    QRBirthDate: TQRLabel;
    QRHomePhone: TQRLabel;
    QRWorkPhone: TQRLabel;
    QRLabel11: TQRLabel;
    QRAccidentDate: TQRLabel;
    QRLabel13: TQRLabel;
    QRlblWeeklyWage: TQRLabel;
    QRlblIndexingFactor: TQRLabel;
    QRlblIndexedWage: TQRLabel;
    QRBand2: TQRBand;
    QRYearIndexed: TQRLabel;
    QRWeeklyWage: TQRLabel;
    QRIndexingFactor: TQRLabel;
    QRIndexedWeeklyWage: TQRLabel;
    QRlblMinWage: TQRLabel;
    QRMinimumWage: TQRLabel;
    procedure QRIndexedClaimBeforePrint(Sender: TCustomQuickRep; var PrintReport: Boolean);
    procedure QRIndexedClaimNeedData(Sender: TObject; var MoreData: Boolean);
    procedure QRSINPrint(sender: TObject; var Value: String);
    procedure QRHomePhonePrint(sender: TObject; var Value: String);
    procedure QRWorkPhonePrint(sender: TObject; var Value: String);
    procedure FormClose(Sender: TObject; var Action: TCloseAction);
  private
    { Private declarations }
    accidentDate : TDateTime;
    minWage : currency;
    NewAmt, OldAmt : real;
    Year_Cnt, min_index_year : integer;
    strYouthful_Worker, strClaim_No, strApprentice:String;
    function valueNCINDEXF( y: integer ): double;
    function getMinimumWage: currency;
    function getIndexedMinWage: currency;
  public
    { Public declarations }
  end;

var
  PrintClaimIndexationForm: TPrintClaimIndexationForm;

implementation

uses NCMain, NCIniMod, UtilMod1, Ncbenidx, NCBencal, uADOSecurity, NCDatMod, utils;

{$R *.DFM}

procedure TPrintClaimIndexationForm.QRIndexedClaimBeforePrint(
  Sender: TCustomQuickRep; var PrintReport: Boolean);
var
   lngIndex, i:Integer;
   blnFound:Boolean;
   Child:TWagelossBenefitCalcForm;
begin
  //
  // See if we can find a Wageloss form already loaded
  //
  child := nil;
  lngIndex := WagelossMainForm.MDIChildCount;
  blnFound := False;
  For i := 0 to lngIndex - 1 do
     Begin
     if WagelossMainForm.MDIChildren[i].ClassType = TWagelossBenefitCalcForm Then
        Begin
        Child := WagelossMainForm.MDIChildren[i] as TWagelossBenefitCalcForm;
        If Child.lblAccident_Date.Visible = True then
           Begin
           blnFound := True;
           Break;
           End;
        End;
     End;

  { Move general claim information to report labels }
  if blnFound Then
     Begin
     with Child.CalcFullClaim do
        begin
        QRUserID.caption := UserProfile.givenName + ' ' + userProfile.familyName;
        QRClaimNumber.caption :=
            pdoxTrim(Claim_No) + ' / ' + pdoxTrim(Claim_Suffix);
        strClaim_No := pdoxTrim(Claim_No);
        QRName.caption :=
            pdoxTrim(Clmnts_1st_Name) + ' ' +
            pdoxTrim(Clmnts_Surname);
        QRSIN.caption  := SIN;
        QRAddr1.caption := Clmnts_Add_No_1;
        QRAddr2.caption := Clmnts_Add_No_2;
        QRAddr3.caption :=
            pdoxTrim(Clmnts_Add_No_3) + ' ' +
            pdoxTrim(Clmnts_Post_Code);
        if Birth_Date > 0 then
           QRBirthDate.caption := FormatDateTime('d-mmm-yyyy', Birth_Date)
        else
           QRBirthDate.caption := '';
        QRHomePhone.caption  := Clmnts_Home_Phone;
        QRWorkPhone.caption  := Clmnts_Work_Phone;
        if Accident_Date > 0 then
           QRAccidentDate.caption := FormatDateTime('d-mmm-yyyy', Accident_Date)
        else
           QRAccidentDate.caption := '';

        // Set initial salary amount and indexation year for
        // loop through indexation years.
        OldAmt := Wkly_Sal_A;
        Year_Cnt := Indexation_Year;
        accidentDate := Accident_Date;
        minWage := getMinimumWage;

        //suppress min wage stuff for all pre 2006 claims
        if Year(Accident_Date) >= 2006 then begin
            QRlblMinWage.Enabled := true;
            QRMinimumWage.Enabled := true;
        end else begin
            QRlblMinWage.Enabled := false;
            QRMinimumWage.Enabled := false;
        end;

        // Set minimum indexation year
        if month(Accident_Date) < 12 then
           min_index_year := year(Accident_Date) + 2
        else
           min_index_year := year(Accident_Date) + 3;

        strYouthful_Worker := Youthful_Worker;
        strApprentice := Apprentice;

        if Youthful_Worker = 'Y' Then
           begin
           QRlblIndexingFactor.Caption := 'IAW Increase';
           end;

        if Apprentice = 'Y' Then
           begin
           QRlblWeeklyWage.Caption := 'Original Apprentice Weekly Wage';
           QRlblIndexingFactor.Enabled := False;
           QRlblIndexedWage.Caption := 'Updated Apprentice Weekly Wage';
           QRIndexingFactor.Enabled := False;
           end;
        end;
     End;
end;

procedure TPrintClaimIndexationForm.QRIndexedClaimNeedData(Sender: TObject;
  var MoreData: Boolean);

var IndexFactor : Double;
    Weekly_Increase : Double;
    indexedMinWage : currency;
begin
  indexedMinWage := 0;
  // If indexation year is less than 2 years after the
  // accident, stop processing; otherwise fill in detail
  // line.
  if Year_Cnt < min_index_year then
     MoreData := False
  else
     begin
     MoreData := True;
     IndexFactor := valueNCINDEXF( year_cnt );
     QRYearIndexed.caption  := IntToStr( year_cnt );
     if Year(accidentDate) >= 2006 then
        indexedMinWage := getIndexedMinWage;
        
     if (strYouthful_Worker = 'N') And (strApprentice = 'N') Then
        Begin
        NewAmt := pdoxRound(oldamt / IndexFactor,2);
        QRIndexingFactor.caption := Format('%.7n', [IndexFactor]);
        QRIndexedWeeklyWage.caption := Format('%n', [oldamt]);
        QRWeeklyWage.caption := Format('%n',[newamt]);
        if Year(accidentDate) >= 2006 then
          QRMinimumWage.Caption := Format('%n', [pdoxRound(indexedMinWage/52,2)]);
        OldAmt := NewAmt;
        end
     else
        begin
        try
           dm1.usp_Get_Weekly_Sal_History.Parameters.ParamByName('@Claim_No').Value := strClaim_No;
           dm1.usp_Get_Weekly_Sal_History.Parameters.ParamByName('@Index_Year').Value := year_cnt;
           dm1.usp_Get_Weekly_Sal_History.Open;
           NewAmt := dm1.usp_Get_Weekly_Sal_History.Fields[1].Value;
           OldAmt := dm1.usp_Get_Weekly_Sal_History.Fields[2].Value;
           Weekly_Increase := NewAmt - OldAmt;
           QRIndexingFactor.caption := Format('%n', [Weekly_Increase]);
           QRIndexedWeeklyWage.caption := Format('%n', [NewAmt]);
           QRWeeklyWage.caption := Format('%n',[OldAmt]);
           dm1.usp_Get_Weekly_Sal_History.Close;
        except
           on e:Exception Do
              begin
              dm1.usp_Get_Weekly_Sal_History.Close;
              end;
        end;

        End;

     dec(Year_Cnt);
     end;
end;

function TPrintClaimIndexationForm.valueNCINDEXF( y: integer ): double;
var
  iii: integer;
begin
  { Get indexation factor for the specified year.}
  indexNCINDEXF:=-1;
  for iii := low(arrayNCINDEXF) to high(arrayNCINDEXF) do
  begin
    if ( arrayNCINDEXF[iii].Indexation_Year = y ) then
       begin
         indexNCINDEXF:=iii;
         result := arrayNCINDEXF[iii].Indexing_Factor;
         exit;
       end
  end;
  if ( indexNCINDEXF < 0 ) then
  begin
    result:=0.0;
    exit;
  end;
  result:=0.0;
end;

procedure TPrintClaimIndexationForm.QRSINPrint(sender: TObject;
  var Value: String);
var
   s:String;
begin
if Length(Value) = 9 then
   s := Copy(Value, 1, 3) + ' ' + Copy(Value, 4, 3) + ' ' + Copy (Value, 7, 3)
else
   s := Value;

Value := s;
end;

procedure TPrintClaimIndexationForm.QRHomePhonePrint(sender: TObject;
  var Value: String);
var
   s:String;
begin
   if length(Value) = 10 Then
      s := '(' + Copy(Value, 1, 3) + ') ' + Copy(Value, 4, 3) + '-' + Copy(Value,7,4)
   else if Length(Value) = 7 Then
      s := Copy(Value, 4, 3) + '-' + Copy(Value,7,4)
   else
      s := Value;

   Value := s;
end;

procedure TPrintClaimIndexationForm.QRWorkPhonePrint(sender: TObject;
  var Value: String);
var
   s:String;
begin
   if length(Value) = 10 Then
      s := '(' + Copy(Value, 1, 3) + ') ' + Copy(Value, 4, 3) + '-' + Copy(Value,7,4)
   else if Length(Value) = 7 Then
      s := Copy(Value, 4, 3) + '-' + Copy(Value,7,4)
   else
      s := Value;

   Value := s;
end;

procedure TPrintClaimIndexationForm.FormClose(Sender: TObject;
  var Action: TCloseAction);
begin
Action := caFree;
end;

function TPrintClaimIndexationForm.getMinimumWage: currency;
var
  lngReturn: Integer;
begin
  Result := 0;
  try
     dm1.usp_Get_Minimum_Wage.Parameters.ParamByName( '@accidentDate' ).Value := accidentDate;
     dm1.usp_Get_Minimum_Wage.Open;
     lngReturn := dm1.usp_Get_Minimum_Wage.Parameters.ParamByName('@RETURN_VALUE').Value;

     if lngReturn = 0 Then
        begin
        if Not dm1.usp_Get_Minimum_Wage.Eof Then
           begin
          Result := dm1.usp_Get_Minimum_Wage.FieldByName('minWage').Value;
          end;

        dm1.usp_Get_Minimum_Wage.Close;
        end;
  except
     on E:Exception do
        begin
        applog('TPrintClaimIndexationForm.getMinimumWage - Exception - Message: ' + e.Message);
        Result := 0;
        dm1.usp_Get_Minimum_Wage.Close;
        MessageDlg('*Retrieve of Minimum Wage Failed.  Please notify help desk at 4573.', mtError, [mbOK], 0 );
        end;
  end;
end;

function TPrintClaimIndexationForm.getIndexedMinWage: currency;
var
  nc_index_amt: currency;
  nc_cnt, accidentYear: integer;
begin

  if month(accidentDate) < 12 then
    accidentYear := year(accidentDate) + 2
  else
    accidentYear := year(accidentDate) + 3;

  nc_index_amt := minWage;

  for nc_cnt := accidentYear to Year_Cnt do
  begin
    nc_index_amt := pdoxRound(nc_index_amt * valueNCINDEXF(nc_cnt),2)
  end;

  Result := nc_index_amt;
end;


end.
