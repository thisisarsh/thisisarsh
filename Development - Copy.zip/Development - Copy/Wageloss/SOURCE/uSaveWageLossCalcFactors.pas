unit uSaveWageLossCalcFactors;

interface

Uses SysUtils, Forms, Inifiles, Messages, Dialogs,
     Windows, Utils, ncrecdef, Math, uTriggerEvent, Classes;

var
  wr: RECFactors;
  CalcFullClaim, CalcPartClaim: recNCCLAIM;
  formId: String;

  procedure SaveWageLossCalcFactors;
  procedure DoClaim;
  function UpdateWageLossCalcFactors: boolean;
  function UpdateClaimPaymentSummary: boolean;
  function checkWagelossCalcFactors: boolean;
  function setStrAsFloat(aValue: String):String;
  function IsNumeric(aValue: String): Boolean;
  function SQLDouble( dd:double ): shortstring;
  function TestForNegative(amount : currency) : currency;

implementation

uses utilmod1, uADOSecurity, NCDatMod, uGlobal, uUserMaint, uDmGener, NCBenCal;

procedure SaveWageLossCalcFactors;
begin
  DoClaim;
  if checkWagelossCalcFactors then
  begin
     UpdateWageLossCalcFactors;
     UpdateClaimPaymentSummary;
  end;
end;

function checkWagelossCalcFactors: boolean;
var
  s: string;
  bReturn: boolean;
begin
  bReturn := True;
  try
     with dm1.qWageLossFactors do
        begin
        close;
        SQL.Clear;
        SQL.add('Select * from WageLossCalcFactor ');
        SQL.add('Where ClaimNo = ');
        s := SQLInteger( StrToInt( wr.ClaimNo ) );
        s := copy(s,1,length(s)-1);
        SQL.Add( s );
        SQL.Add(' And wageLossCalcFactorId = ');
        s := SQLInteger( StrToInt( wr.Uniquness ) );
        s := copy(s,1,length(s)-1);
        SQL.Add( s );
        Open;
        end;

     dm1.qWageLossFactors.Last;

     if dm1.qWageLossFactors.RecordCount > 0 then
        begin
        bReturn := False;
        end;
  except
     on e:Exception do
        begin
        applog('uSaveWageLossCalcFactors.checkWagelossCalcFactors - Exception - Message: ' + e.Message);
        MessageDlg('WageLossCalcFactor Select Failed.  Please notify help desk at 4573.', mtError, [mbOK], 0 );
        bReturn := false;
        end;
  end;

  Result := bReturn;
end;


procedure DoClaim;
var
   Acc_Year, Acc_Month, Acc_Day, Idx_Month:Word;
   WorkDate:TDateTime;
   collBenefits:String;
begin
  with CalcFullClaim do
  begin
    wr.Uniquness := IntToStr( uGlobal.getNextKey( 'WageLossCalcFactor_Sequence', 1, -1 ) );

    DecodeDate( Accident_Date, Acc_Year, Acc_Month, Acc_Day );
    if ( ( Indexation_Year > 0 ) AND ( Tax_Year <> Acc_Year ) ) Then
      Idx_Month := Max( ( ( Acc_Month + 1 ) Mod 13 ),1 )
    else
      Idx_Month := Acc_Month;

    //Throws error on Shelter Rebate because the year translates to 0 (zero)
    //This is not a valid year...
    WorkDate := EncodeDate( Min( Max( Indexation_Year, Acc_Year ), Tax_Year ), Idx_Month, 1 );

    wr.ClaimNo := pdoxTrim( Claim_No ); //claimNo

    if Accident_Date > 0 then
      wr.AccidentDate := FormatDateTime( 'd-mmm-yyyy', Accident_Date )
    else
      wr.AccidentDate := '';

    wr.WeeklyWage := Wkly_Sal_A; //weeklyWageAmt
    wr.TaxYear := Tax_Year; //taxYear
    wr.IndexedYear := Indexation_Year; //indexedYear
    wr.IndexedDate := FormatDateTime( 'd-mmm-yyyy', WorkDate ); //indexedDate
    wr.Recurence := copy( Recurrence, 1, 1 ); //recurrenceFlag

    if RecurrenceDate > 0 then
      wr.RecurrenceDate := FormatDateTime( 'd-mmm-yyyy', RecurrenceDate ) //recurrenceDate
    else
      wr.RecurrenceDate := '';

    wr.DaysWeek := Days_Worked_per_Week; //daysWorkedPerWeekQty

    if Loss_Earn_Date > 0 then
      wr.LossOfEarningsDate := Loss_Earn_Date //lossOfEarningsDate
    else
      wr.LossOfEarningsDate := 0;

    //Added Emerge R4
    if effectiveDate > 0 then
      wr.effectiveDate := FormatDateTime( 'd-mmm-yyyy', effectiveDate ) //effectiveDate
    else
      wr.effectiveDate := '';

    wr.YouthfulWorker := Youthful_Worker; //youthfulWorkerFlag
    wr.SelfEmployed := copy( Self_Employed, 1, 1 ); //selfEmployedFlag

    wr.MaritalStatus := Marital_Status;
    wr.SpouseWorking := Spouse_Working; //spouseWorkingFlag
    wr.ClaimSpouseForTaxPurposes := ClaimSpouseForTaxPurposes;
    wr.NumberOfDependants := No_Of_Dependnts; //dependentsQty
    wr.NumberOfInfirmDeps := No_Infirm; //infirmDependentsQty
    wr.UICExempt := copy( EI_Exempt, 1, 1 ); //uicExemptFlag
    wr.CPPExempt := copy( CPP_Exempt, 1, 1 ); //cppExemptFlag
    wr.IncomeTaxExempt := copy( Tax_Exempt, 1, 1 ); //incomeTaxExemptFlag
    wr.ChildCareExpense := Child_Care_Exp; //childCareExpenseAmt
    wr.SpousalSupport := Spousal_Support; //spousalSupportAmt
    wr.ChildSupport := Child_Support; //childSupportAmt
    wr.IncomeTaxFederal := Inc_Tax_Fed; //incomeTaxFederalAmt
    wr.IncomeTaxProv := Inc_Tax_Man; //incomeTaxProvincialAmt
    wr.CPPPremium := CPP_Prem; //cppPremiumAmt
    wr.CPP2Premium := CPP2_Prem; //cpp2PremiumAmt
    wr.UICPremium := EI_Prem; //uicPremiumAmt
    wr.TotalDeductions := Total_Deds; //totalDeductionsAmt
    wr.WeeklyDeductions := PdoxRound( Total_Deds / 52.0, 2 ); //weeklyDeductionsAmt
    wr.CollateralTaxable := Collateral_Ben_Tax; //collateralTaxableAmt
    wr.CollateralTaxableNet := CalcPartClaim.Coll_Ben_Tax_Net; //collateralTaxableNetAmt
    wr.CollateralNonTaxable := Collateral_Ben_Non_Tax; //collateralNonTaxableAmt
    wr.PostEarnWeeklyGross := Post_Injury_Earn; //postEarnWeeklyGrossAmt
    wr.PostEarnWeeklyNet := Post_Injury_Earn_Net; //postEarnWeeklyNetAmt

    if nc_104_Wk_Effective_Date > 0 then
      wr.EffectiveDate80 := nc_104_Wk_Effective_Date //effective80Date
    else
      wr.EffectiveDate80 := 0;

    if nc_104_Wk_Clmt_P_Eff_Date > 0 then
      wr.ClmntContribEffectiveDate := nc_104_Wk_Clmt_P_Eff_Date //claimantContributionEffectiveDate
    else
      wr.ClmntContribEffectiveDate := 0;

    wr.FullWeeklyGross := Wkly_Sal_A; //fullWeeklyGrossAmt
    wr.FullAnnualGross := Annual_Gross; //fullAnnualGrossAmt

    //fullWeeklyNetLossEarnAmt
    if Year( Accident_Date ) >= 2006 then begin
      if ( CalcPartClaim.Minimum_Wage_Flag_Partial ) or ( CalcPartClaim.Pay_At_100_Flag_Partial ) then
      begin
        wr.FullWeeklyNetLossEarn := Weekly_Net;
      end else if Self_Employed = 'Y' then
      begin
        wr.FullWeeklyNetLossEarn := Weekly_90;
      end else
      begin
        wr.FullWeeklyNetLossEarn := PDoxRound( Annual_Net_A / 52, 2 );
      end;
    end
    else
    begin
      wr.FullWeeklyNetLossEarn := Weekly_Net;
    end;
    wr.FullAnnualNetLossEarn := Annual_Net;

    //
    // Modified for Leg Review Ammendment 2006
    // Changed to display 100% net actual
    //
    if Year( CalcFullClaim.Accident_Date ) >= 2006 Then
       wr.FullWeekly90NetActual := PdoxRound( ( Weekly_Net_A ), 2 ) //fullWeekly90NetActualAmt
    else
       wr.FullWeekly90NetActual := PdoxRound( ( Weekly_Net_A * 0.90 ), 2 ); //fullWeekly90NetActualAmt

    wr.FullWeekly90NetLoss := Weekly_90; //fullWeekly90NetLossAmt
    wr.FullAnnual90NetLoss := Annual_90; //fullAnnual90NetLossAmt
    wr.FullWeeklyTaxSheltering := pdoxround( ( Weekly_90 - Weekly_90_S ) , 2); //fullWeeklyTaxShelteringAmt
    wr.FullWeekly90NetSheltered := Weekly_90_S; //fullWeekly90NetShelteredAmt
    wr.FullAnnual90NetSheltered := Annual_90_S; //fullAnnual90NetShelteredAmt
    wr.FullWeeklyDailyCompRate := ( Weekly_90_S / Days_Worked_per_Week ); //fullWeeklyDailyCompRateAmt
    wr.FullWeekly80NetLoss := Weekly_80; //fullWeekly80NetLossAmt
    wr.FullAnnual80NetLoss := Annual_80; //fullAnnual80NetLossAmt
    wr.FullWeekly80NetSheltered := Weekly_80_S; //fullWeekly80NetShelteredAmt
    wr.FullAnnual80NetSheltered := Annual_80_S; //fullAnnual80NetShelteredAmt
    wr.FullClmntPercentContrib := NC_104_Wk_Clmt_P_Contrib; //fullClmntPercentContribAmt
    wr.FullClmntContrib := Wkly_Clmt_Anty_Con_Amt; //fullClmntContribAmt
    wr.reducedNoDaysToPay := reducedNoDaysToPay; //reducedNoDaysToPayQty
    wr.reducedNoWeeksToPay := reducedNoWeeksToPay; //reducedNoWeeksToPayQty
    
    if Year( Accident_Date ) >= 2006 then
    begin
      wr.FullWeekly80ClmntNetContrib := pdoxround( ( Weekly_90_S  - Wkly_Clmt_Anty_Con_Amt ), 2 ); //fullWeekly80ClmntNetContribAmt
      wr.FullWCBContrib := pdoxround( ( ( ( ( nc_104_Wk_WCB_p_Contrib ) * Weekly_90_S ) / 100.00 ) ), 2 ); //fullWCBContribAmt
      wr.FullWeeklyAdjustedDailyCompRate := pdoxround( ( Weekly_90_S  - Wkly_Clmt_Anty_Con_Amt ), 2 ) / Days_Worked_per_Week; //fullWeeklyAdjustedDailyCompRateAmt
    end
    else
    begin
      wr.FullWeekly80ClmntNetContrib := pdoxround( ( Weekly_80  - Wkly_Clmt_Anty_Con_Amt ), 2 ); //fullWeekly80ClmntNetContribAmt
      wr.FullWCBContrib := pdoxround( ( ( ( ( 5 - nc_104_Wk_WCB_p_Contrib_Red ) * Weekly_80 ) / 100.00 ) ), 2 ); //fullWCBContribAmt
      wr.FullWeeklyAdjustedDailyCompRate := pdoxround( ( Weekly_80  - Wkly_Clmt_Anty_Con_Amt ), 2) / Days_Worked_per_Week; //fullWeeklyAdjustedDailyCompRateAmt
    end;

    wr.FullAnnual80ClmntNetContrib := pdoxround( ( Annual_80 - ( 52* Wkly_Clmt_Anty_Con_Amt ) ), 2); //fullAnnual80ClmntNetContribAmt
    wr.FullWCBPercentContrib := ( nc_104_Wk_WCB_p_Contrib ); //fullWCBPercentContribAmt
    wr.wcbAnnuityReductionPercentageAmt := nc_104_Wk_WCB_p_Contrib_Red; //wcbAnnuityReductionPercentageAmt
    wr.ClmntContribEffectiveDate := nc_104_Wk_Clmt_p_Eff_Date;  //ClmntContribEffectiveDate

    wr.Apprentice := pdoxTrim( Apprentice ); //apprenticeFlag
    wr.Deemed := pdoxTrim( Deemed_Earnings ); //deemedFlag
    wr.AverageEarningsBasedOn := AverageEarningsBasedOn;  //avgEarningsBasedOnType

    wr.AnnualNetA := Annual_Net_A; //actualAnnualNetAmt

    //weeklyShelterBenefitAmt
    if Pay_At_100_Flag then begin
      wr.WeeklyShelterBenefit :=  PDoxRound( Weekly_Shelter_Ben_Amount_90 * 1.11111, 2 );
    end else begin
      wr.WeeklyShelterBenefit := Weekly_Shelter_Ben_Amount;
    end;

    wr.WeeklyShelterBen90 := Weekly_Shelter_Ben_Amount_90; //weeklyShelterBenefit90Amt
    wr.WeeklyMinWageNet := (Min_Wage_Annual_Net_A / 52.0); //weeklyMinimumWageNetAmt
    wr.WeeklyMinWage := (Minimum_wage / 52.0); //weeklyMinimumWageAmt
    wr.NetCollBen := Tax_Coll_Ben_Only; //netCollateralBenefitAmt

    //collateralBenefitType
    collBenefits := ' ';
    if TaxCollBen_CPPQPP > 0 then
      collBenefits := 'CPP/QPP ';
    if TaxCollBen_EI > 0 then
      collBenefits := collBenefits + 'EI ';
    if TaxCollBen_DisabilityIns > 0 then
      collBenefits := collBenefits + 'Disability Insurance ';
    if TaxCollBen_EmpTopUp > 0 then
      collBenefits := collBenefits + 'Employer Top Up ';
    if TaxCollBen_Combination > 0 then
      collBenefits := collBenefits + 'Combination';
    wr.collbentype := collBenefits;

    //minimumWageFlag
    if Minimum_wage_Flag then
      wr.MinimumWageIndicator := 'Y'
    else if Pay_At_100_Flag then
      wr.MinimumWageIndicator := 'R'
    else
      wr.MinimumWageIndicator := 'N';

    //net80DailyCompensationRateAmt
    if ( wr.DaysWeek <> 0 ) then begin
      wr.net80DailyCompensationRateAmt := StrToFloat( format('%.2f', [ wr.WeeklyShelterBen90 / wr.DaysWeek ]) );

        //set next value whether or not it is a post 2006 claim
        if Year( Accident_Date) >= 2006 then
        begin
          wr.net80DailyCompensationRateAmt := StrToFloat( format('%.2f', [ pdoxround( ( wr.WeeklyShelterBen90  - wr.FullClmntContrib), 2) / wr.DaysWeek ]) );
        end
        else
        begin
          wr.net80DailyCompensationRateAmt := StrToFloat( format('%.2f', [ pdoxround( ( wr.FullWeekly80NetLoss  - wr.FullClmntContrib), 2) / wr.DaysWeek ]) );
        end;
    end
    else
    begin
      wr.net80DailyCompensationRateAmt := 0;
    end;

    wr.week104StatusType := week104StatusType; //week104StatusType
    wr.taxExemptCode := Tax_Code; //taxExemptCode
    wr.taxExemptAmt := Tax_Exemption; //taxExemptAmt
  end; //CalcFullClaim

  if ( CalcFullClaim.Post_Injury_Earn = 0.0 ) then
  begin
    wr.PartialNetPreInjury := 0;            //partialNetPreInjuryAmt
    wr.PartialNetPostInjury := 0;           //partialNetPostInjuryAmt
    wr.PartialNetLossEarn := 0;             //partialNetLossEarnAmt
    wr.Partial90NetLossEarn := 0;           //partial90NetLossEarnAmt
    wr.PartialTaxSheltering := 0;           //partialTaxShelteringAmt
    wr.Partial90NetSheltered := 0;          //partial90NetShelteredAmt
    wr.PartialDailyCompRate := 0;           //partialDailyCompRateAmt
    wr.Partial80NetLoss := 0;               //partial80NetLossAmt
    wr.Partial80NetSheltered := 0;          //partial80NetShelteredAmt
    wr.PartialClmntPercentContrib := 0;     //partialClmntPercentContribAmt
    wr.PartialClmntContrib := 0;            //partialClmntContribAmt
    wr.Partial80NetContrib := 0;            //partial80NetContribAmt
    wr.PartialWCBPercentContrib := 0;       //partialWCBPercentContribAmt
    wr.PartialWCBContrib := 0;              //partialWCBContribAmt
    wr.Partial80DailyCompRate := 0;         //partial80DailyCompensationRateAmt
    wr.partial80AfterClmtContribAmt := 0;   //partial80AfterClmtContribAmt
  end
  else
  begin
    with CalcPartClaim do
    begin
      // bug?
      if Year( CalcFullClaim.Accident_Date ) >= 2006 Then
      begin
        if Minimum_Wage_Flag_Partial or Pay_At_100_Flag_Partial then
          wr.PartialNetPreInjury := CalcFullClaim.Weekly_Net //partialNetPreInjuryAmt
        else
          wr.PartialNetPreInjury := pdoxround( (CalcFullClaim.Annual_Net_A / 52 ), 2 ); //partialNetPreInjuryAmt
      end
      else
      begin
        wr.PartialNetPreInjury := CalcFullClaim.Weekly_Net //partialNetPreInjuryAmt
      end;


      wr.PartialNetPostInjury := Post_Injury_Earn_Net;  //partialNetPostInjuryAmt
      wr.PostEarnWeeklyNet := Post_Injury_Earn_Net; //postEarnWeeklyNetAmt
      wr.PartialNetLossEarn := wr.PartialNetPreInjury - wr.PostEarnWeeklyNet; //partialNetLossEarnAmt
      wr.Partial90NetLossEarn := Weekly_90; //partial90NetLossEarnAmt
      wr.PartialTaxSheltering := pdoxround( ( Weekly_90 - Weekly_90_S ) , 2); //partialTaxShelteringAmt
      wr.Partial90NetSheltered := Weekly_90_S; //partial90NetShelteredAmt
      wr.PartialDailyCompRate := Weekly_90_S / Days_Worked_per_Week; //partialDailyCompRateAmt
      wr.Partial80NetLoss := Weekly_80; //partial80NetLossAmt
      wr.Partial80NetSheltered := Weekly_80_S; //partial80NetShelteredAmt
      wr.PartialClmntPercentContrib := NC_104_Wk_Clmt_P_Contrib; //partialClmntPercentContribAmt
      wr.PartialClmntContrib := Wkly_Clmt_Anty_Con_Amt; //partialClmntContribAmt

      if Year(Accident_Date) >= 2006 then begin
        wr.Partial80NetContrib := pdoxround( ( Weekly_90_S  - Wkly_Clmt_Anty_Con_Amt), 2); //partial80NetContribAmt
        wr.PartialWCBContrib := pdoxround( ( (((nc_104_Wk_WCB_p_Contrib)*Weekly_90_S)/100.00) ), 2); //partialWCBContribAmt
        wr.Partial80DailyCompRate := pdoxround( ( Weekly_90_S  - Wkly_Clmt_Anty_Con_Amt), 2) / Days_Worked_per_Week; //partial80DailyCompensationRateAmt
      end else begin
        wr.Partial80NetContrib := pdoxround( ( Weekly_80  - Wkly_Clmt_Anty_Con_Amt), 2); //partial80NetContribAmt
        wr.PartialWCBContrib := pdoxround( ( (((5 - nc_104_Wk_WCB_p_Contrib_Red)*Weekly_80)/100.00) ), 2); //partialWCBContribAmt
        wr.Partial80DailyCompRate := pdoxround( ( Weekly_80  - Wkly_Clmt_Anty_Con_Amt), 2) / Days_Worked_per_Week; //partial80DailyCompensationRateAmt
      end;

      wr.PartialWCBPercentContrib := ( nc_104_Wk_WCB_p_Contrib ); //partialWCBPercentContribAmt

      if Minimum_Wage_Flag_Partial then
        wr.MinimumWageIndicatorPartial := 'Y'
      else if Pay_At_100_Flag_Partial then
        wr.MinimumWageIndicatorPartial := 'R'
      else
        wr.MinimumWageIndicatorPartial := 'N';

      //partial80AfterClmtContribAmt
      if Year(Accident_Date) >= 2006 then
      begin
        if ( wr.WeeklyShelterBen90 / wr.DaysWeek < 0 ) then
        begin
          wr.partial80AfterClmtContribAmt := 0;
        end
        else
        begin
          wr.partial80AfterClmtContribAmt := StrToFloat( format( '%.2f', [ pdoxround( ( wr.WeeklyShelterBen90  - wr.FullClmntContrib ), 2 ) ] ) );
        end;
      end
      else
      begin
        wr.partial80AfterClmtContribAmt := StrToFloat( format('%.2f',
          [ pdoxround( ( wr.FullWeekly80NetLoss  - wr.FullClmntContrib ), 2) ] ) );
      end;
    end;//CalcPartClaim
  end;
end;


function UpdateWageLossCalcFactors: boolean;
var
  s, t: string;
  bReturn: boolean;
begin
bReturn := True;
  try
    with dm1.qWageLossFactors do
    begin
      close;
      SQL.Clear;                
      SQL.Add('INSERT INTO WageLossCalcFactor( ');
			SQL.Add('		wagelossCalcFactorId, ');
			SQL.Add('		claimNo, ');
			SQL.Add('		effectiveDate, ');
			SQL.Add('		actualAnnualNetAmt, ');
			SQL.Add('		apprenticeFlag, ');
			SQL.Add('		avgEarningsBasedOnType, ');
			SQL.Add('		childCareExpenseAmt, ');
			SQL.Add('		childSupportAmt, ');
			SQL.Add('		claimantContributionEffectiveDate, '); 
			SQL.Add('		claimantReplyDate, ');
			SQL.Add('		collateralNonTaxableAmt, ');
			SQL.Add('		collateralTaxableAmt, ');
			SQL.Add('		collateralTaxableNetAmt, ');
			SQL.Add('		collateralBenefitType, ');
			SQL.Add('		cppExemptFlag, ');
			SQL.Add('		cppPremiumAmt, ');
			SQL.Add('		cppPremiumShelteredAmt, ');
      SQL.Add('		cpp2PremiumAmt, ');
      SQL.Add('		cpp2PremiumShelteredAmt, ');
			SQL.Add('		daysWorkedPerWeekQty, ');
			SQL.Add('		deemedFlag, ');
			SQL.Add('		effective80Date, ');
			SQL.Add('		fullAnnual80ClmntNetContribAmt, ');
			SQL.Add('		fullAnnual80NetLossAmt, ');
			SQL.Add('		fullAnnual80NetShelteredAmt, ');
			SQL.Add('		fullAnnual90NetLossAmt, ');
			SQL.Add('		fullAnnual90NetShelteredAmt, ');
			SQL.Add('		fullAnnualGrossAmt, ');  
			SQL.Add('		fullAnnualNetLossEarnAmt, ');
			SQL.Add('		fullClmntContribAmt, ');
			SQL.Add('		fullClmntPercentContribAmt, ');
			SQL.Add('		fullPercentNetActualAmt, ');
			SQL.Add('		fullPercentNetClmntContribAmt, ');
			SQL.Add('		fullPercentOfNetLossAmt, ');
			SQL.Add('		fullWCBContribAmt, ');
			SQL.Add('		fullWCBPercentContribAmt, ');
			SQL.Add('		fullWeekly80ClmntNetContribAmt, ');
			SQL.Add('		fullWeekly80NetLossAmt, ');
			SQL.Add('		fullWeekly80NetShelteredAmt, ');
			SQL.Add('		fullWeekly90NetActualAmt, ');
			SQL.Add('		fullWeekly90NetLossAmt, ');
			SQL.Add('		fullWeekly90NetShelteredAmt, ');
			SQL.Add('		fullWeeklyAdjustedDailyCompRateAmt, ');
			SQL.Add('		fullWeeklyDailyCompRateAmt, ');
			SQL.Add('		fullWeeklyGrossAmt, ');
			SQL.Add('		fullWeeklyNetLossEarnAmt, ');
			SQL.Add('		fullWeeklyTaxShelteringAmt, ');
			SQL.Add('		hourlyBenefitRateAmt, ');
			SQL.Add('		incomeTaxExemptFlag, ');
			SQL.Add('		incomeTaxFederalAmt, ');
			SQL.Add('		incomeTaxProvincialAmt, ');
			SQL.Add('		incomeTaxFederalShelteredAmt, ');
			SQL.Add('		incomeTaxProvincialShelteredAmt, ');   
			SQL.Add('		indexedDate, ');
			SQL.Add('		indexedYear, ');
			SQL.Add('		lossOfEarningsDate, ');
			SQL.Add('		maritalStatusType, ');
			SQL.Add('		maximumAdjustmentAmt, ');
			SQL.Add('		minimumWageFlag, ');
			SQL.Add('		netCollateralBenefitAmt, ');
      SQL.Add('		net80DailyCompensationRateAmt, ');
			SQL.Add('		dependentsQty, ');
			SQL.Add('		infirmDependentsQty, ');
      SQL.Add('		partial80AfterClmtContribAmt, ');
      SQL.Add('		emergeDisplayFlag, ' );
      SQL.Add('		taxExemptCode, ' );
      SQL.Add('		taxExemptAmt, ' );
			SQL.Add('		creationDatetime, ');
			SQL.Add('		creationLoginName, ');
			SQL.Add('		modificationDatetime, ');
			SQL.Add('		modificationLoginName ) ');
			SQL.Add('VALUES( ');
			SQL.Add( SQLString( wr.Uniquness ) ); //wageLossCalcFactorId
			SQL.Add( SQLString( wr.ClaimNo ) ); //claimNo
      SQL.Add( SQLString( wr.effectiveDate ) ); //effectiveDate
 			SQL.Add( SQLCurrency( TestForNegative(wr.AnnualNetA) ) ); //actualAnnualNetAmt
			SQL.Add( SQLString( wr.Apprentice ) ); //apprenticeFlag
			SQL.Add( SQLString( wr.AverageEarningsBasedOn ) ); //avgEarningsBasedOnType
			SQL.Add( SQLCurrency( TestForNegative(wr.ChildCareExpense) ) ); //childCareExpenseAmt
			SQL.Add( SQLCurrency( TestForNegative(wr.ChildSupport) ) ); //childSupportAmt

			if wr.ClmntContribEffectiveDate > 0 Then
         SQL.Add( SQLString( FormatDateTime( 'yyyy/mm/dd', wr.ClmntContribEffectiveDate ) ) )
      else
         SQL.Add('NULL,'); //claimantContributionEffectiveDate

      if CalcFullClaim.nc_104_Wk_Clmt_Reply_Date > 0 then
        SQL.Add( SQLString( FormatDateTime( 'yyyy/mm/dd', CalcFullClaim.nc_104_Wk_Clmt_Reply_Date ) ) ) //claimantReplyDate
      else
        SQL.Add('NULL,');

			SQL.Add( SQLCurrency( TestForNegative(wr.CollateralNonTaxable) ) ); //collateralNonTaxableAmt
			SQL.Add( SQLCurrency( TestForNegative(wr.CollateralTaxable) ) ); //collateralTaxableAmt
			SQL.Add( SQLCurrency( TestForNegative(wr.CollateralTaxableNet) ) ); //collateralTaxableNetAmt
			SQL.Add( SQLString( wr.collBenType ) ); //collateralBenefitType
			SQL.Add( SQLString( wr.CPPExempt ) ); //cppExemptFlag
			SQL.Add( SQLCurrency( TestForNegative(wr.CppPremium) ) ); //cppPremiumAmt
			SQL.Add( SQLCurrency( TestForNegative(CalcFullClaim.CPP_Prem_S) ) ); //cppPremiumShelteredAmt
			SQL.Add( SQLCurrency( TestForNegative(wr.Cpp2Premium) ) ); //cppPremiumAmt
			SQL.Add( SQLCurrency( TestForNegative(CalcFullClaim.CPP2_Prem_S) ) ); //cppPremiumShelteredAmt
			SQL.Add( SQLDouble ( wr.DaysWeek ) ); //daysWorkedPerWeekQty
			SQL.Add( SQLString( wr.Deemed ) ); //deemedFlag

			if wr.EffectiveDate80 > 0 then
         SQL.Add( SQLString( FormatDateTime('yyyy/mm/dd', wr.EffectiveDate80 )) )
      else
         SQL.Add('NULL,'); //effective80Date

			SQL.Add( SQLCurrency( TestForNegative(wr.FullAnnual80ClmntNetContrib) ) ); //fullAnnual80ClmntNetContribAmt
			SQL.Add( SQLCurrency( TestForNegative(wr.FullAnnual80NetLoss) ) ); //fullAnnual80NetLossAmt
			SQL.Add( SQLCurrency( TestForNegative(wr.FullAnnual80NetSheltered) ) ); //fullAnnual80NetShelteredAmt
			SQL.Add( SQLCurrency( TestForNegative(wr.FullAnnual90NetLoss) ) ); //fullAnnual90NetLossAmt
			SQL.Add( SQLCurrency( TestForNegative(wr.FullAnnual90NetSheltered) ) ); //fullAnnual90NetShelteredAmt

			if (wr.MinimumWageIndicator = 'Y') Then
         SQL.Add( SQLCurrency( TestForNegative(wr.WeeklyMinWage * 52) ) )
      else
         SQL.Add( SQLCurrency( TestForNegative(wr.FullAnnualGross) ) ); //fullAnnualGrossAmt

      if (wr.MinimumWageIndicator = 'Y') Then
         SQL.Add( SQLCurrency( TestForNegative(wr.FullAnnual90NetLoss) ))
      else
         SQL.Add( SQLCurrency( TestForNegative(wr.FullAnnualNetLossEarn) )); //fullAnnualNetLossEarnAmt

			SQL.Add( SQLCurrency( TestForNegative(wr.FullClmntContrib) ) ); //fullClmntContribAmt
			SQL.Add( SQLDouble( wr.FullClmntPercentContrib ) ); //fullClmntPercentContribAmt

      if (Year(CalcFullClaim.Accident_Date) >= 2006) then
         SQL.Add( SQLCurrency( 100 ) )
      else
         SQL.Add( SQLCurrency( 90 ) ); //fullPercentNetActualAmt

			if CalcFullClaim.Pay_At_100_Flag Or CalcFullClaim.Minimum_wage_Flag then
         SQL.Add( SQLCurrency( 100 ) )
      else
         SQL.Add( SQLCurrency( 90 ) ); //fullPercentNetClmntContribAmt

			if CalcFullClaim.Pay_At_100_Flag Or CalcFullClaim.Minimum_wage_Flag then
         SQL.Add( SQLCurrency( 100 ) )
      else
         SQL.Add( SQLCurrency( 90 ) ); //fullPercentOfNetLossAmt

			SQL.Add( SQLCurrency( TestForNegative(wr.FullWCBContrib) ) ); //fullWCBContribAmt
			SQL.Add( SQLDouble( wr.FullWCBPercentContrib ) ); //fullWCBPercentContribAmt
			SQL.Add( SQLCurrency( TestForNegative(wr.FullWeekly80ClmntNetContrib) ) ); //fullWeekly80ClmntNetContribAmt
			SQL.Add( SQLCurrency( TestForNegative(wr.FullWeekly80NetLoss) ) ); //fullWeekly80NetLossAmt
      SQL.Add( SQLCurrency( TestForNegative(wr.FullWeekly80NetSheltered) ) ); //fullWeekly80NetShelteredAmt
			SQL.Add( SQLCurrency( TestForNegative(wr.FullWeekly90NetActual) ) ); //fullWeekly90NetActualAmt
			SQL.Add( SQLCurrency( TestForNegative(wr.FullWeekly90NetLoss) ) ); //fullWeekly90NetLossAmt
			SQL.Add( SQLCurrency( TestForNegative(wr.FullWeekly90NetSheltered) ) ); //fullWeekly90NetShelteredAmt
			SQL.Add( SQLCurrency( TestForNegative(wr.FullWeeklyAdjustedDailyCompRate) ) ); //fullWeeklyAdjustedDailyCompRateAmt
			SQL.Add( SQLCurrency( TestForNegative(wr.FullWeeklyDailyCompRate) ) ); //fullWeeklyDailyCompRateAmt

      if (wr.MinimumWageIndicator = 'Y') Then
         SQL.Add( SQLCurrency( TestForNegative(wr.WeeklyMinWage) ) )
      else
         SQL.Add( SQLCurrency( TestForNegative(wr.FullWeeklyGross) ) ); //fullWeeklyGrossAmt

		  SQL.Add( SQLCurrency( TestForNegative(wr.FullWeeklyNetLossEarn) ) ); //fullWeeklyNetLossEarnAmt
			SQL.Add( SQLCurrency( TestForNegative(wr.FullWeeklyTaxSheltering) ) ); //fullWeeklyTaxShelteringAmt
			SQL.Add( SQLCurrency( TestForNegative(wr.hourlyBenefitRateAmt) ) ); //hourlyBenefitRateAmt
			SQL.Add( SQLString( wr.IncomeTaxExempt ) ); //incomeTaxExemptFlag
			SQL.Add( SQLCurrency( TestForNegative(wr.IncomeTaxFederal) ) ); //incomeTaxFederalAmt
			SQL.Add( SQLCurrency( TestForNegative(wr.IncomeTaxProv) ) ); //incomeTaxProvincialAmt
			SQL.Add( SQLCurrency( TestForNegative(CalcFullClaim.Inc_Tax_Fed_S) ) ); //incomeTaxFederalShelteredAmt
			SQL.Add( SQLCurrency( TestForNegative(CalcFullClaim.Inc_Tax_Man_S) ) );  //incomeTaxProvincialShelteredAmt

			if wr.IndexedYear > 0 Then
         SQL.Add(SQLString(wr.IndexedDate))
      else
         SQL.Add('NULL, '); //indexedDate

			SQL.Add( SQLInteger( wr.IndexedYear ) ); //indexedYear

      if ( wr.LossOfEarningsDate > 0) then
         SQL.Add( SQLString( FormatDateTime('yyyy/mm/dd', wr.LossOfEarningsDate) ) )
      else
         SQL.Add('NULL, '); //lossOfEarningsDate
         
			SQL.Add( SQLString( wr.MaritalStatus ) ); //maritalStatusType
			SQL.Add( SQLCurrency( TestForNegative(CalcFullClaim.Max_Adjustment) ) ); //maximumAdjustmentAmt
			SQL.Add( SQLString( wr.MinimumWageIndicator ) ); //minimumWageFlag
			SQL.Add( SQLCurrency( TestForNegative(wr.NetCollBen) ) ); //netCollateralBenefitAmt
      SQL.Add( SQLCurrency( TestForNegative(wr.net80DailyCompensationRateAmt) ) ); //net80DailyCompensationRateAmt
			SQL.Add( SQLInteger( wr.NumberOfDependants ) ); //dependentsQty
			SQL.Add( SQLInteger( wr.NumberOfInfirmDeps ) ); //infirmDependentsQty
      SQL.Add( SQLCurrency( TestForNegative(wr.partial80AfterClmtContribAmt) ) ); //partial80AfterClmtContribAmt
      SQL.Add( SQLString('Y')); // emergeDisplayFlag
      //SQL.Add( '''' + 'Y' + '''' + ',' ); //emergeDisplayFlag
      SQL.Add( SQLString( wr.taxExemptCode )  ); //taxExemptCode
      SQL.Add( SQLCurrency( TestForNegative(wr.taxExemptAmt) ) ); //taxExemptAmt
			SQL.Add( SQLString( FormatDateTime( 'yyyy/mm/dd HH:mm:ss', Now ) ) ); //creationDatetime
			SQL.Add( SQLString( UserProfile.loginName ) ); //creationLoginName
			SQL.Add( SQLString( FormatDateTime( 'yyyy/mm/dd HH:mm:ss', Now ) ) ); //modificationDateTime
      s := SQLString( UserProfile.loginName );
      s := copy( s, 1, length( s ) -1 );   //remove the trailing comma
      SQL.Add( s ); //modificationLoginName
      SQL.Add(')');
      execSQL;   //Execute Insert

      //Update same claim - Delphi BDE restriction - Insert statement is too large to accomodate all fields
      close;
      SQL.Clear;                
      SQL.Add('UPDATE WageLossCalcFactor SET ');
			SQL.Add('		partial80DailyCompRateAmt = ' + SQLCurrency( TestForNegative(wr.Partial80DailyCompRate) ) );
      SQL.Add('		partial80NetContribAmt = ' + SQLCurrency( TestForNegative(wr.Partial80NetContrib) ) );
			SQL.Add('		partial80NetLossAmt = ' + SQLCurrency( TestForNegative(wr.Partial80NetLoss) ) );
			SQL.Add('		partial80NetShelteredAmt = ' + SQLCurrency( TestForNegative(wr.Partial80NetSheltered) ) );
			SQL.Add('		partial90NetLossEarnAmt = ' + SQLCurrency( TestForNegative(wr.Partial90NetLossEarn) ) );
			SQL.Add('		partial90NetShelteredAmt = ' + SQLCurrency( TestForNegative(wr.Partial90NetSheltered) ) );
			SQL.Add('		partialClmntContribAmt = ' + SQLCurrency( TestForNegative(wr.PartialClmntContrib) ) );
			SQL.Add('		partialClmntPercentContribAmt = ' + SQLDouble( wr.PartialClmntPercentContrib ) );
			SQL.Add('		partial80DailyCompensationRateAmt = ' + SQLCurrency( TestForNegative(wr.Partial80DailyCompRate) ) ); //partial80DailyCompensationRateAmt   *****  SHOULD BE REMOVED *****
			SQL.Add('		partialDailyCompRateAmt = ' + SQLCurrency( TestForNegative(wr.PartialDailyCompRate) ) );
			SQL.Add('		partialNetLossEarnAmt = ' + SQLCurrency( TestForNegative(wr.PartialNetLossEarn) ) );
			SQL.Add('		partialNetPostInjuryAmt = ' + SQLCurrency( TestForNegative(wr.PartialNetPostInjury) ) );
			SQL.Add('		partialNetPreInjuryAmt = ' + SQLCurrency( TestForNegative(wr.PartialNetPreInjury) ) );

			if CalcPartClaim.Pay_At_100_Flag_Partial Or CalcPartClaim.Minimum_Wage_Flag_Partial then
         SQL.Add('		partialPercentNetClmntContribAmt = ' + SQLCurrency( 100 ) )
      else
         SQL.Add('		partialPercentNetClmntContribAmt = ' + SQLCurrency( 90 ) ); //partialPercentNetClmntContribAmt

			if CalcPartClaim.Pay_At_100_Flag_Partial Or CalcPartClaim.Minimum_Wage_Flag_Partial then
         SQL.Add('		partialPercentNetLossAmt = ' + SQLCurrency( 100 ) )
      else
         SQL.Add('		partialPercentNetLossAmt = ' + SQLCurrency( 90 ) ); //partialPercentNetLossAmt

			if CalcPartClaim.Pay_At_100_Flag_Partial Or CalcPartClaim.Minimum_Wage_Flag_Partial then
         SQL.Add('		partialPercentNetShelteredAmt = ' + SQLCurrency( 100 ) )
      else
         SQL.Add('		partialPercentNetShelteredAmt = ' + SQLCurrency( 90 ) ); //partialPercentNetShelteredAmt

			SQL.Add('		partialTaxShelteringAmt = ' + SQLCurrency( TestForNegative(wr.PartialTaxSheltering) ) );
			SQL.Add('		partialWCBContribAmt = ' + SQLCurrency( TestForNegative(wr.PartialWCBContrib) ) );
			SQL.Add('		partialWCBPercentContribAmt = ' + SQLDouble( wr.PartialWCBPercentContrib ) );
			SQL.Add('		postEarnWeeklyGrossAmt = ' + SQLCurrency( TestForNegative(wr.PostEarnWeeklyGross) ) );
			SQL.Add('		postEarnWeeklyNetAmt = ' + SQLCurrency( TestForNegative(wr.PostEarnWeeklyNet) ) );
			SQL.Add('		recurrenceFlag = ' + SQLString( wr.Recurence ) );

			if (Length(Trim(wr.RecurrenceDate)) > 0) then
         t := SQLString( wr.RecurrenceDate )
      else
         t := 'NULL, '; //recurrenceDate
			SQL.Add('		recurrenceDate = ' + t );
			SQL.Add('		selfEmployedFlag = ' + SQLString( wr.SelfEmployed ) );
			SQL.Add('		spousalSupportAmt = ' + SQLCurrency( TestForNegative(wr.SpousalSupport) ) );
			SQL.Add('		spouseWorkingFlag = ' + SQLString( wr.SpouseWorking ) );
      SQL.Add(('  ClaimSpouseForTaxPurposes = ' + SQLString( wr.ClaimSpouseForTaxPurposes) ));
			SQL.Add('		taxYear = ' + SQLInteger( wr.TaxYear ) );
			SQL.Add('		totalDeductionsAmt = ' + SQLCurrency( TestForNegative(wr.TotalDeductions) ) );
			SQL.Add('		totalDeductionsShelteredAmt = ' + SQLCurrency( TestForNegative(CalcFullClaim.Total_Deds_S) ) );
			SQL.Add('		uicExemptFlag = ' + SQLString( wr.UicExempt ) );
			SQL.Add('		uicPremiumAmt = ' + SQLCurrency( TestForNegative(wr.UicPremium) ) );
			SQL.Add('		uicPremiumShelteredAmt = ' + SQLCurrency( TestForNegative(CalcFullClaim.EI_Prem_S) ) );
			SQL.Add('		week104StatusType = ' +  SQLString( wr.week104StatusType ) );
			SQL.Add('		weeklyWCBAnnuityContributionAmt = ' + SQLCurrency( TestForNegative(CalcFullClaim.Wkly_WCB_Anty_Con_Amt) ) );
			SQL.Add('		weeklyWCBAnnuityContributionShelteredAmt = ' + SQLCurrency( TestForNegative(CalcFullClaim.Wkly_WCB_Anty_Con_Amt_S) ) );
			SQL.Add('		weeklyClaimantAnnuityContributionShelteredAmt = ' + SQLCurrency( TestForNegative(CalcFullClaim.Wkly_Clmt_Anty_Con_Amt_S) ) );
			SQL.Add('		weeklyDeductionsAmt = ' + SQLCurrency( TestForNegative(wr.WeeklyDeductions) ) );
			SQL.Add('		weeklyMinimumWageAmt = ' + SQLCurrency( TestForNegative(wr.WeeklyMinWage) ) );
			SQL.Add('		weeklyMinimumWageNetAmt = ' + SQLCurrency( TestForNegative(wr.WeeklyMinWageNet) ) );
			SQL.Add('		weeklyShelterBenefit90Amt = ' + SQLCurrency( TestForNegative(wr.weeklyShelterBen90) ) );
			SQL.Add('		weeklyShelterBenefitAmt = ' + SQLCurrency( TestForNegative(wr.WeeklyShelterBenefit) ) );
			SQL.Add('		weeklyWageAmt = ' + SQLCurrency( TestForNegative(wr.WeeklyWage) ) );
      SQL.Add('   wcbAnnuityReductionPercentageAmt = ' + SQLCurrency( TestForNegative(wr.wcbAnnuityReductionPercentageAmt) ) );
      SQL.Add('   reducedNoDaysToPayQty = ' + SQLCurrency( TestForNegative(wr.reducedNoDaysToPay) ) );
      SQL.Add('   reducedNoWeeksToPayQty = ' + SQLCurrency( TestForNegative(wr.reducedNoWeeksToPay) ) );
			SQL.Add('		youthfulWorkerFlag = ' );
      s := ( SQLString( wr.YouthfulWorker ) );
      s := copy( s, 1, length( s ) -1 );   //remove the trailing comma
      SQL.Add( s );
      SQL.Add( ' WHERE wageLossCalcFactorId = ' + wr.Uniquness );
      execSQL; //Execute Update
    end;
  except
     on E:Exception do
        begin
        applog('uSaveWageLossCalcFactors.UpdateWageLossCalcFactors - Exception - Message: ' + e.Message);
        MessageDlg('WageLossCalcFactor Update Failed. ' + Chr(10) + Chr(13) +  E.Message +
                   Chr(10) + Chr(13) +  'Please notify help desk at 4573.', mtError, [mbOK], 0 );
        bReturn := false;
        end;
  end;

  try
    with dm1.qryGeneralEmerge do
    begin
      close;
      SQL.Clear;
      SQL.Add('UPDATE Claim ');
      SQL.Add( 'SET modificationDatetime = ''' +  FormatDateTime( 'mm/dd/yyyy h:nn:ss', Now ) + ''',' ); //modificationDatetime
      SQL.Add( '    modificationLoginName = ''' +  UserProfile.loginName + ''',' ); //modificationLoginName
			SQL.Add('   lossOfEarningsDate = ' );
      if ( wr.LossOfEarningsDate > 0) then
         s := SQLString( FormatDateTime( 'yyyy/mm/dd HH:mm:ss', wr.LossOfEarningsDate ) )
      else
         s := 'NULL,'; //lossOfEarningsDate
      s := copy( s, 1, length( s ) -1 );   //remove the trailing comma
      SQL.Add( s );
      SQL.Add( ' WHERE claimNo = ' + wr.ClaimNo );
      execSQL; //Execute Update
    end;
  except
    on e:Exception do
      begin
      applog('uSaveWageLossCalcFactors.UpdateWageLossCalcFactors - Exception (try #2) - Message: ' + e.Message);
      MessageDlg('Claim lossOfEarningsDate Update Failed. ' + Chr(10) + Chr(13) +  E.Message +
                   Chr(10) + Chr(13) +  'Please notify help desk at 4573.', mtError, [mbOK], 0 );
      bReturn := false;
      end;
  end;

  Result := bReturn;
end;


function UpdateClaimPaymentSummary: boolean;
var
  setSqlString: string;
  bReturn: boolean;
begin
bReturn := True;
setSqlString := '';
  if ( ( CalcFullClaim.nc_104_Wk_Clmt_Reply_Date > 0 ) or
        ( wr.EffectiveDate80 > 0 ) or
        ( wr.FullWCBContrib > 0 ) or
        ( wr.FullWCBPercentContrib > 0 ) or
        ( wr.ClmntContribEffectiveDate > 0 ) or
        ( wr.FullClmntPercentContrib > 0 ) ) then
  begin

    try
      with dm1.qryGeneralEmerge do
      begin
        close;
        SQL.Clear;
        SQL.Add('UPDATE ClaimPaymentSummary ');
  			SQL.Add('SET ');

        if CalcFullClaim.nc_104_Wk_Clmt_Reply_Date > 0 then
        begin
          setSqlString :=  setSqlString +  'week104ReplyByDate = ''' + FormatDateTime( 'yyyy/mm/dd', CalcFullClaim.nc_104_Wk_Clmt_Reply_Date ) + ''',';//claimantReplyDate //week104ReplyByDate
        end
        else
        if CalcFullClaim.nc_104_Wk_Clmt_Reply_Date = 0 then
        begin
           setSqlString :=  setSqlString +  'week104ReplyByDate = NULL,';//claimantReplyDate //week104ReplyByDate
        end;

  			if wr.EffectiveDate80 > 0 then
        begin
          setSqlString :=  setSqlString + 'week104EffectiveDate = ''' + FormatDateTime( 'yyyy/mm/dd', wr.EffectiveDate80 ) + ''','; //effective80Date //week104EffectiveDate
        end
        else if wr.EffectiveDate80 = 0 then
        begin
          setSqlString :=  setSqlString + 'week104EffectiveDate = NULL,'; //effective80Date //week104EffectiveDate
        end;

        if wr.FullWCBContrib >= 0 then
          setSqlString :=  setSqlString + 'week104WcbContributionPercent = ' + FloatToStr( wr.FullWCBPercentContrib ) + ','; //fullWCBPercentContribAmt //week104WcbContributionPercent

        if wr.FullWCBPercentContrib >= 0 then
          setSqlString :=  setSqlString + 'week104WcbContributionReductionPercent = ' + FloatToStr( wr.wcbAnnuityReductionPercentageAmt ) + ','; //wcbAnnuityReductionPercentageAmt //week104WcbContributionReductionPercent

        if wr.week104WcbContributionEffectiveDate > 0 Then
        begin
          setSqlString :=  setSqlString + 'week104WcbContributionEffectiveDate = ''' + FormatDateTime( 'yyyy/mm/dd', wr.week104WcbContributionEffectiveDate ) + ''',';  //week104WcbContributionEffectiveDate //week104WcbContributionEffectiveDate
        end
        else if wr.week104WcbContributionEffectiveDate = 0 then
        begin
          setSqlString :=  setSqlString + 'week104WcbContributionEffectiveDate = NULL,';  //week104WcbContributionEffectiveDate //week104WcbContributionEffectiveDate
        end;

        if wr.ClmntContribEffectiveDate > 0 Then
        begin
          setSqlString :=  setSqlString + 'week104WorkerContributionEffectiveDate = ''' + FormatDateTime( 'yyyy/mm/dd', wr.ClmntContribEffectiveDate ) + ''',';  //claimantContributionEffectiveDate //week104WorkerContributionEffectiveDate
        end
        else if wr.ClmntContribEffectiveDate = 0 then
        begin
          setSqlString :=  setSqlString + 'week104WorkerContributionEffectiveDate = NULL,';  //claimantContributionEffectiveDate //week104WorkerContributionEffectiveDate
        end;

        if wr.FullClmntPercentContrib >= 0 then
          setSqlString :=  setSqlString + 'week104WorkerContributionPercent = ' + FloatToStr( wr.FullClmntPercentContrib ) + ',';  //week104WorkerContributionPercent

        setSqlString := copy( setSqlString, 1, length( setSqlString ) -1 );   //remove the trailing comma

        SQL.Add( setSqlString );
        SQL.Add( ' WHERE claimNo = ' + wr.ClaimNo );
        execSQL;   //Execute Insert
      end;
    except
       on E:Exception do
          begin
          applog('uSaveWageLossCalcFactors.UpdateClaimPaymentSummary - Exception - Message: ' + e.Message);
          MessageDlg('ClaimPaymentSummary Update Failed. ' + Chr(10) + Chr(13) +  E.Message +
                     Chr(10) + Chr(13) +  'Please notify help desk at 4573.', mtError, [mbOK], 0 );
          bReturn := false;
          end;
    end;

  end;
  Result := bReturn;
end;

function setStrAsFloat(aValue: String): String;
begin
  If IsNumeric(aValue) then
    result := aValue
  else
    result := '0.00';
end;

function IsNumeric(aValue: String): Boolean;
var
  bIsNumeric: boolean;
begin
  bIsNumeric := true;
  try
    if (strtofloat(aValue) = 0) or (strtofloat(aValue) < 0) then
      bIsNumeric := true;
  except
    bIsNumeric := false;
  end;
  result := bIsNumeric;
end;

(******************************************************************************)
(*                                                                            *)
(*  Convert a double to SQL friendly format                                  *)
(*                                                                            *)
(******************************************************************************)
function SQLDouble( dd:double ): shortstring;
begin
  result := format('%.3g', [ dd ] ) + ',';
end;

function TestForNegative(amount : currency) : currency;
begin
  if amount < 0 then
    result := 0
  else
    result := amount;
end;

end.

