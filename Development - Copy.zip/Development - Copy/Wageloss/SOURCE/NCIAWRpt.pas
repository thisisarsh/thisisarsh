unit NCIAWRpt;

interface

uses
  Windows, Messages, SysUtils, Variants, Classes, Graphics, Controls, Forms,
  Dialogs, QRCtrls, QuickRpt, ExtCtrls;

type
  TIAWRptForm = class(TForm)
    QRIAWRpt: TQuickRep;
    QRBand1: TQRBand;
    QRSysData2: TQRSysData;
    QRSysData1: TQRSysData;
    QRSysData3: TQRSysData;
    QRUserID: TQRLabel;
    QRLabel1: TQRLabel;
    QRLabel2: TQRLabel;
    QRSysData4: TQRSysData;
    QRBand2: TQRBand;
    QRLabel6: TQRLabel;
    QRLabel10: TQRLabel;
    QRBand3: TQRBand;
    QRTaxYear: TQRLabel;
    QRAverageWage: TQRLabel;
    QRHalfAverageWage: TQRLabel;
    QRLabel4: TQRLabel;
    procedure QRIAWRptBeforePrint(Sender: TCustomQuickRep;
      var PrintReport: Boolean);
    procedure QRIAWRptNeedData(Sender: TObject; var MoreData: Boolean);
    procedure QRBand3BeforePrint(Sender: TQRCustomBand;
      var PrintBand: Boolean);
  private
    { Private declarations }
    iii : integer;
  public
    { Public declarations }
  end;

var
  IAWRpt: TIAWRptForm;

implementation

{$R *.dfm}

uses
  NCIniMod, NCMain, utilmod1, uADOSecurity;

procedure TIAWRptForm.QRIAWRptBeforePrint(Sender: TCustomQuickRep;
  var PrintReport: Boolean);
begin
  {Set starting point for both indexation factor and
   annual maximum arrays.}
  iii := low(arrayNCIAWMAX);
  QRUserID.caption := UserProfile.givenName + ' ' + userProfile.familyName;
end;

procedure TIAWRptForm.QRIAWRptNeedData(Sender: TObject;
  var MoreData: Boolean);
begin
  If ( iii > high( arrayNCIAWMAX ) )then
     MoreData := False {the end of the array has been reached}
  Else
  If ( length( IntToStr( arrayNCIAWMAX[iii].Tax_Year ) ) <= 1 ) then
     MoreData := False {lengths of 1 indicate blank array values}
  Else
     MoreData := True;

  // Print values from Industrial Average Wage Array
  If ( iii <= high( arrayNCIAWMAX ) ) and
     ( length( IntToStr( arrayNCIAWMAX[iii].Tax_Year ) ) > 1 ) then
  Begin
    QRTaxYear.caption  := IntToStr( arrayNCIAWMAX[iii].Tax_Year );
    QRAverageWage.caption := Format( '%.2n', [arrayNCIAWMAX[iii].IAW_Maximum]);
    QRHalfAverageWage.caption := Format( '%.2n', [PdoxRound( ( arrayNCIAWMAX[iii].IAW_Maximum/2 ), 2 )]);
    Inc(iii);
  End
  Else
  Begin
    QRTaxYear.Caption  := '';
    QRAverageWage.Caption := '';
  End;
end;

procedure TIAWRptForm.QRBand3BeforePrint(Sender: TQRCustomBand;
  var PrintBand: Boolean);
var
 i : Integer;
begin

  with QRBand3 do
  begin
    for i := 0 to ControlCount-1 do
    begin
      if TQRLabel(Controls[i]).Color = $00F0F0F0 then
         TQRLabel(Controls[i]).Color := $00E0E0E0
      else
        TQRLabel(Controls[i]).Color := $00F0F0F0;
    end;
  end;

end;

end.
