unit NCWrkRptJan15;

interface

uses
  Windows, Messages, SysUtils, Variants, Classes, Graphics, Controls, Forms,
  Dialogs, NCWrkRptJul14;

type
  TWrkRptJan15 = class(TWrkRptJul14)
  function getDateHeading():String; Override;
  private
    { Private declarations }
  public
    { Public declarations }
  end;

var
  WrkRptJan15: TWrkRptJan15;

implementation

{$R *.dfm}

{ TWrkRptJan15 }

function TWrkRptJan15.getDateHeading: String;
begin
  result:='2014/2015'
end;

end.
