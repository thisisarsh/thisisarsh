unit NCWrkRptJul20;

interface

uses
  Winapi.Windows, Winapi.Messages, System.SysUtils, System.Variants, System.Classes, Vcl.Graphics,
  Vcl.Controls, Vcl.Forms, Vcl.Dialogs, NCWrkRptJan20;

type
  TWrkRptJul20 = class(TWrkRptJan20)
    function getDateHeading():String; Override;
  private
    { Private declarations }
  public
    { Public declarations }
  end;

var
  WrkRptJul20: TWrkRptJul20;

implementation

{$R *.dfm}

(******************************************************************************)
(*                                                                            *)
(*  override this function for each class to avoid having to bring in all of  *)
(*    the methods that contain the date in the heading.                       *)
(*   IE:  the jan 09 class should return  2008/2009                           *)
(*        the july 09 class should return 2009                                *)
(*                                                                            *)
(******************************************************************************)

function TWrkRptJul20.getDateHeading: String;
begin
  Result:='2020';
end;

end.

