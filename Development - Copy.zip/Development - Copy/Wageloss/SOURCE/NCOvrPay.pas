{$A+,B-,C+,D+,E-,F-,G+,H+,I+,J+,K-,L+,M-,N+,O-,P+,Q+,R+,S-,T-,U+,V+,W+,X+,Y+,Z1}

{$MINSTACKSIZE $00004000}

{$MAXSTACKSIZE $00800000}

{$IMAGEBASE $00400000}

{$APPTYPE GUI}

(******************************************************************************)
(*  Wageloss System                                                           *)
(*                                                                            *)
(*  Overpayment Search and Display Form                                       *)
(*                                                                            *)
(*    Properties have been defined to allow overides on the following:        *)
(*                                                                            *)
(*      HasOverpayments:          Is set to true if query to search for       *)
(*                                overpayments found any. As the form create  *)
(*                                runs the query, this is available right     *)
(*                                after the create.                           *)
(*                                                                            *)
(*  Author: Brad Trupp  / Capella Systems Group, Inc.                         *)
(*  Date:   August 1997                                                       *)
(******************************************************************************)

unit NCOvrPay;

interface

uses
  Windows, Messages, SysUtils, Classes, Graphics, Controls, Forms, Dialogs,
  ExtCtrls, StdCtrls;

type
  TBenefitsOverpaymentSearchForm = class(TForm)
    Label1: TLabel;
    Label2: TLabel;
    Label3: TLabel;
    lblClaim_No: TLabel;
    lblClmnts_Name: TLabel;
    lblClmnts_Add_No_1: TLabel;
    lblClmnts_Add_No_2: TLabel;
    Label8: TLabel;
    Label9: TLabel;
    Label10: TLabel;
    lblSIN: TLabel;
    lblBirth_Date: TLabel;
    lblClmnts_Home_Phone: TLabel;
    lblClmnts_Post_Code: TLabel;
    lblClaim_Suffix: TLabel;
    lblClmnts_Work_Phone: TLabel;
    Label13: TLabel;
    Label29: TLabel;
    Bevel1: TBevel;
    lbOverPayments: TListBox;
    Label4: TLabel;
    Label5: TLabel;
    Label6: TLabel;
    Label7: TLabel;
    Label11: TLabel;
    Label12: TLabel;
    Label14: TLabel;
    Label15: TLabel;
    chkSoundEx: TCheckBox;
    btnSearch: TButton;
    lblOverPayment: TLabel;
    procedure FormCreate(Sender: TObject);
    procedure FormDestroy(Sender: TObject);
    procedure FormKeyDown(Sender: TObject; var Key: Word; Shift: TShiftState);
    procedure FormClose(Sender: TObject; var Action: TCloseAction);
    procedure lbOverPaymentsDrawItem(Control: TWinControl; Index: Integer; ARect: TRect; State: TOwnerDrawState);
    procedure FormActivate(Sender: TObject);
    procedure btnSearchClick(Sender: TObject);
  private
    { Private declarations }
    bHasOverpayments: boolean;
    procedure ResetInfoLine2;
    procedure SetLblOverPayment;
    procedure PrintOverPaymentReport;
    procedure fillInForm;
    procedure DoSearch;
  public
    { Public declarations }
    property HasOverpayments: boolean read bHasOverpayments write bHasOverpayments;
  end;

var
  BenefitsOverpaymentSearchForm: TBenefitsOverpaymentSearchForm;

implementation

uses NCMain, NCIniMod, Utilmod1, NCDatMod, NCOvrRpt, QPreview, utils;

{$R *.DFM}

(******************************************************************************)
(*                                                                            *)
(*  Form Create                                                               *)
(*                                                                            *)
(******************************************************************************)
procedure TBenefitsOverpaymentSearchForm.FormCreate(Sender: TObject);
begin
  bHasOverpayments:=false;
  fillInForm;
  ResetInfoLine2;
  DoSearch;
end;

(******************************************************************************)
(*                                                                            *)
(*  Form Destroy                                                              *)
(*                                                                            *)
(******************************************************************************)
procedure TBenefitsOverpaymentSearchForm.FormDestroy(Sender: TObject);
begin
  BenefitsOverpaymentSearchForm:=nil;
  WagelossMainForm.ShowInfoLine1('');
  if bHasOverpayments then
    WagelossMainForm.ShowInfoLine2('')
  else
    WagelossMainForm.ShowInfoLine2('No overpayments found');
end;

(******************************************************************************)
(*                                                                            *)
(*  Key Down - preview and process keypresses on form.                        *)
(*                                                                            *)
(******************************************************************************)
procedure TBenefitsOverpaymentSearchForm.FormKeyDown(Sender: TObject;
  var Key: Word; Shift: TShiftState);
begin
  case Key of
    VK_F1: begin
           Key:=0;
           Application.HelpCommand(HELP_CONTENTS, 0);
           end;
    VK_F7: begin
           Key:=0;
           close;
           end;
    VK_F8: begin
           Key:=0;
           PrintOverPaymentReport;
           end;
  end;
end;

(******************************************************************************)
(*                                                                            *)
(*  Display Info line standard message.                                       *)
(*                                                                            *)
(******************************************************************************)
procedure TBenefitsOverpaymentSearchForm.ResetInfoLine2;
begin
  WagelossMainForm.ShowInfoLine2('F7 - Exit  F8 - Print Report');
end;

(******************************************************************************)
(*                                                                            *)
(*  Print Overpayment Report.                                                 *)
(*                                                                            *)
(******************************************************************************)
procedure TBenefitsOverpaymentSearchForm.PrintOverPaymentReport;
var
  MyPreview: TQRCustomPreviewForm;
  MyReport: TPrintOverpayForm;
begin
  screen.cursor:=crHourGlass;
  try
    MyPreview := TQRCustomPreviewForm.create(application);

    MyReport := TPrintOverpayForm.create(Self);
    // load stringlist
    MyReport.sList.Assign(lbOverPayments.Items);

    MyPreview.ParentQuickReportForm:=MyReport;
    MyPreview.ParentQuickReport:=MyReport.QROvrPay;
    MyPreview.caption:='Overpayment Search';
    screen.cursor:=crDefault;
    try
      MyReport.QROvrPay.OnPreview := MyPreview.CustomPreview;
      MyReport.QROvrPay.Preview;
    finally
      screen.cursor:=crDefault;
    end;
  finally
  screen.cursor:=crDefault;
  end;
end;

(******************************************************************************)
(*                                                                            *)
(*  Fill in form from claim record.                                           *)
(*                                                                            *)
(******************************************************************************)
procedure TBenefitsOverpaymentSearchForm.fillInForm;
begin
  with dataClaim do
  begin
    lblClaim_No.caption:= Claim_No;
    lblClaim_Suffix.caption:=Claim_Suffix;
    lblClmnts_Name.caption:= pdoxTrim(Clmnts_1st_Name) + ' ' + pdoxTrim(Clmnts_Surname);
    lblClmnts_Add_No_1.caption:= Clmnts_Add_No_1;
    lblClmnts_Add_No_2.caption:= Clmnts_Add_No_2;
    lblSIN.caption:= SIN;
    if Birth_Date > 0 then
       begin
       //lblBirth_Date.caption:= formatdatetime('c',Birth_Date);
       lblBirth_Date.caption := FormatDateTime('ddddd', Birth_Date);
       end
    else
       lblBirth_Date.caption:= '';
    lblClmnts_Post_Code.caption:=Clmnts_Post_Code;
    lblClmnts_Home_Phone.caption:= Clmnts_Home_Phone;
    lblClmnts_Work_Phone.caption:= Clmnts_Work_Phone;
  end;
end;

(******************************************************************************)
(*                                                                            *)
(*  Form Close                                                                *)
(*                                                                            *)
(******************************************************************************)
procedure TBenefitsOverpaymentSearchForm.FormClose(Sender: TObject;
  var Action: TCloseAction);
begin
  action:=caFree;
end;


(******************************************************************************)
(*                                                                            *)
(*  Search routine for overpayments.                                          *)
(*                                                                            *)
(******************************************************************************)
procedure TBenefitsOverpaymentSearchForm.DoSearch;
var
  ws: string;
  strMatch: string;
  iClaim_No : integer;
begin
  try
     iClaim_No := StrToInt(dataClaim.Claim_No);
  except
     iClaim_No := 0;
  end;

  try
     with dm1 do
        begin
        if query1.active then
           begin
           query1.close;
           end;

        query1.sql.clear;
        query1.sql.add('select * from overpayments a where');
        query1.sql.add('  a.claim_no = ' + intToStr(iClaim_No) + ' ');

        if (length( pdoxTrim(dataClaim.SIN)) > 5) then
           begin
           query1.sql.add('or a.sin = "' + dataClaim.SIN + '" ');
           end;

        if ( length( pdoxTrim(dataClaim.PHIN) ) > 5 ) then
           begin
           query1.sql.add('or a.phin = "' + dataClaim.PHIN + '" ');
           end;

        if ( dataClaim.Birth_Date > 0 ) then
           begin
           query1.sql.add('or ( a.surname = "' + dataClaim.Clmnts_Surname + '" ');
           query1.sql.add('    and a.birth_date = "' + formatdatetime('mm/dd/yyyy',dataClaim.Birth_Date) + '") ');
           end;

        query1.sql.add('or ( a.surname = "' + dataClaim.Clmnts_Surname + '" ');
        query1.sql.add('    and a.first_name = "' + dataClaim.Clmnts_1st_Name + '") ');

        //EC July 9/2004 - check if soundex checked and create appropriate SQL

        if chkSoundEx.Checked = True then
           begin
           if ((length(pdoxTrim(dataClaim.SIN) ) > 5 ) AND
               (dataClaim.SIN <> '000000000'))         Then
              begin
              query1.sql.add('or ((SOUNDEX(a.surname) = SOUNDEX("' + dataClaim.Clmnts_Surname + '")) ');
              query1.sql.add('and Len(LTrim(RTrim(a.SIN))) < 5)');
              end
           else
              begin
              query1.sql.add('or (SOUNDEX(a.surname) = SOUNDEX("' + dataClaim.Clmnts_Surname + '")) ');
              end;
           end;

        query1.open;

        if query1.recordcount < 1 then
           begin
           bHasOverpayments := false;
           //EC July 9/2004 - add variable to get message to user correct
           if chkSoundEx.Checked then
              begin
              strMatch := 'No overpayments found by SoundEx match';
              end
           else
              begin
              strMatch := 'No overpayments found by exact match';
              end;

           ws := #1#2+strMatch+#3#4#5#6#7#8#9;
           lbOverPayments.items.add( ws );
           WagelossMainForm.ShowInfoLine2(strMatch);
           end
        else
           begin
           bHasOverpayments := true;
           end;

        try
           query1.first;

           while not query1.eof do
              begin
              try
                 ws := #1 + query1.fieldByName('claim_no').asString +
                       #2 + query1.fieldByName('surname').asString +
                       #3 + query1.fieldByName('first_name').asString;

                 if query1.fieldByName('birth_date').asDateTime > 0 then
                    ws:= ws+ #4 + formatdatetime('mm/dd/yyyy',query1.fieldByName('birth_date').asDatetime)
                 else
                    ws:= #4 + ' ';

                 if (comparetext(query1.fieldByName('claim_no').asString,dataClaim.Claim_No) = 0) then
                    ws := ws + #5 + 'Claim'
                 else if (length( pdoxTrim(dataClaim.SIN)) > 3) and
                         (comparetext(query1.fieldByName('sin').asString, pdoxTrim(dataClaim.SIN)) = 0) then
                    ws := ws + #5 + 'SIN'
                 else if (length( pdoxTrim(dataClaim.PHIN) ) > 3) and
                         (comparetext(query1.fieldByName('phin').asString,pdoxTrim(dataClaim.PHIN)) = 0) then
                    ws := ws + #5 + 'PHIN'
                 else if ((comparetext(query1.fieldByName('surname').asString,pdoxTrim(dataClaim.Clmnts_Surname)) = 0) and
                          (dataClaim.Birth_Date > 0) and
                          (query1.fieldByName('birth_date').asDateTime = dataClaim.Birth_Date)) then
                    ws := ws + #5 + 'Birth Date'
                 else if ((comparetext(query1.fieldByName('surname').asString,pdoxTrim(dataClaim.Clmnts_Surname)) = 0 ) and
                          (comparetext(query1.fieldByName('first_name').asString,pdoxTrim(dataClaim.Clmnts_1st_Name)) = 0 )) then
                    ws := ws + #5 + 'NAME'
                 else if chkSoundEx.Checked then
                    ws := ws + #5 + 'SoundEx'
                 else
                    ws := ws + #5 + 'Other';

                 ws := ws + #6 + query1.fieldByName('sin').asString +
                       #7 + query1.fieldByName('phin').asString +
                       #8 + format('%.2n', [ query1.fieldByName('overpayment_balance').asFloat ]) + #9;
                 lbOverPayments.items.add(ws);
              finally
                 query1.next;
              end;
              end;
        finally
           ;
        end;

        query1.close;
        end
  except
     on e:exception do
        begin
        applog('TBenefitsOverpaymentSearchForm.DoSearch - Exception - Message: ' + e.Message);
        MessageDlg('Error accessing OverPayment Information' + #10#10 + E.message,
                   mtError,[mbOk], 0);
        end;
  end;

end;

(******************************************************************************)
(*                                                                            *)
(*  Draw routine for 2 line display of overpayments                           *)
(*                                                                            *)
(******************************************************************************)
procedure TBenefitsOverpaymentSearchForm.lbOverPaymentsDrawItem(
  Control: TWinControl; Index: Integer; ARect: TRect; State: TOwnerDrawState);
var
  wd, l0, l1, l2: integer;
  ln: string;
  ws: array[1..8] of string;
  r: tRect;
begin
with (Control as TListBox).Canvas do
	begin
    FillRect(ARect);
    ln:=(Control as TListBox).Items[Index];
    ws[1]:=copy(ln, pos(#1,ln)+1, (pos(#2,ln)-pos(#1,ln))-1 );
    ws[2]:=copy(ln, pos(#2,ln)+1, (pos(#3,ln)-pos(#2,ln))-1 );
    ws[3]:=copy(ln, pos(#3,ln)+1, (pos(#4,ln)-pos(#3,ln))-1 );
    ws[4]:=copy(ln, pos(#4,ln)+1, (pos(#5,ln)-pos(#4,ln))-1 );
    ws[5]:=copy(ln, pos(#5,ln)+1, (pos(#6,ln)-pos(#5,ln))-1 );
    ws[6]:=copy(ln, pos(#6,ln)+1, (pos(#7,ln)-pos(#6,ln))-1 );
    ws[7]:=copy(ln, pos(#7,ln)+1, (pos(#8,ln)-pos(#7,ln))-1 );
    ws[8]:=copy(ln, pos(#8,ln)+1, (pos(#9,ln)-pos(#8,ln))-1 );

    wd:=( ARect.Bottom - ARect.Top ) + 1;
    l0 := ARect.Top; l1:= ARect.Top + wd div 2; l2:= ARect.Bottom;

    r:=Rect( ARect.Left    , l0, ARect.Left + 100, l1 );
    TextOut(r.Left, r.Top, ws[1]);
    r:=Rect( ARect.Left+101, l0, ARect.Left + 250, l1 );
    TextOut(r.Left, r.Top, ws[2]);
    r:=Rect( ARect.Left+251, l0, ARect.Left + 400, l1 );
    TextOut(r.Left, r.Top, ws[3]);
    r:=Rect( ARect.Left+401, l0, ARect.Left + 525, l1 );
    TextOut(r.Left, r.Top, ws[4]);
    r:=Rect( ARect.Left+526, l0, ARect.Left + 650, l1 );
    TextOut(r.Left, r.Top, ws[5]);
    r:=Rect( ARect.Left+101, l1, ARect.Left + 250, l2 );
    TextOut(r.Left, r.Top, ws[6]);
    r:=Rect( ARect.Left+251, l1, ARect.Left + 400, l2 );
    TextOut(r.Left, r.Top, ws[7]);
    r:=Rect( ARect.Left+401, l1, ARect.Left + 525, l2 );
    TextOut(r.Left, r.Top, ws[8]);
	end;
end;

(******************************************************************************)
(*                                                                            *)
(*  Form Activate                                                             *)
(*                                                                            *)
(******************************************************************************)
procedure TBenefitsOverpaymentSearchForm.FormActivate(Sender: TObject);
begin
  ResetInfoLine2;
  SetLblOverPayment;
end;

procedure TBenefitsOverpaymentSearchForm.btnSearchClick(Sender: TObject);
begin
     lbOverPayments.Clear;
     DoSearch;
end;

(******************************************************************************)
(*                                                                            *)
(*  Display the overpayment level if necessary.                               *)
(*                                                                            *)
(******************************************************************************)
procedure TBenefitsOverpaymentSearchForm.SetLblOverPayment;
begin
  if WagelossMainForm.blnSoundexSearch then
  begin
    lblOverPayment.Caption := 'A SoundEx match for this claimant exists';
  end;
end;
end.

