unit NCWrkRptJan10;

interface

uses
  Windows, Messages, SysUtils, Variants, Classes, Graphics, Controls, Forms,
  Dialogs, NCWrkRptJul09, NCWrkRptJan09;

type
  TWrkRptJan10 = class(TWrkRptJul09)
  function getDateHeading():String; Override;
  private
    { Private declarations }
  public
    { Public declarations }
  end;

var
  WrkRptJan10: TWrkRptJan10;

implementation

function TWrkRptJan10.getDateHeading():String;
begin
  result:='2009/2010'
end;


{$R *.dfm}

end.
