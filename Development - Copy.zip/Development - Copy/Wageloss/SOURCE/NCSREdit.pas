(******************************************************************************)
(*  Wageloss System                                                           *)
(*                                                                            *)
(*  Shelter Rebate Edit Form                                                  *)
(*                                                                            *)
(*                                                                            *)
(*  Author: Brad Trupp  / Capella Systems Group, Inc.                         *)
(*  Date:   October 1998                                                      *)
(*                                                                            *)
(*  Nov 98 - BT - year 2000 windowing fixes                                   *)
(*                                                                            *)
(******************************************************************************)

unit NCSREdit;

interface

uses
  Windows, Messages, SysUtils, Classes, Graphics, Controls, Forms, Dialogs,
  StdCtrls, ExtCtrls, NCRecDef;

type

  iCycleType  = ( Cycle1, Cycle2, Cycle3 );
  iSRCurrentSortOrder = ( byClaim, bySuffixClaim );

  TShelterRebateEditForm = class(TForm)
    ScrollBox1: TScrollBox;                                
    Label2: TLabel;
    lblClaim_No: TLabel;
    lblClmnts_Name: TLabel;
    lblClaim_Suffix: TLabel;
    edPlaceholder1: TEdit;
    edPlaceholder2: TEdit;
    Label5: TLabel;
    Label15: TLabel;
    Label16: TLabel;
    Label17: TLabel;
    Label18: TLabel;
    Label20: TLabel;
    Label32: TLabel;
    Label33: TLabel;
    Label34: TLabel;
    Label35: TLabel;
    Label36: TLabel;
    Label37: TLabel;
    lblInc_Tax_Fed: TLabel;
    lblInc_Tax_Man: TLabel;
    lblCPP_Prem: TLabel;
    lblEI_Prem: TLabel;
    lblTotal_Deds: TLabel;
    edMarital_Status: TLabel;
    edEI_Exempt: TLabel;
    edNo_Of_Dependnts: TLabel;
    edNo_Infirm: TLabel;
    edSpouse_Working: TLabel;
    Label40: TLabel;
    Label41: TLabel;
    Label42: TLabel;
    Label44: TLabel;
    Label45: TLabel;
    lblWkly_Sal_A: TLabel;
    lblWeekly_Net: TLabel;
    lblAnnual_Gross: TLabel;
    lblAnnual_Net: TLabel;
    Label52: TLabel;
    Label53: TLabel;
    Label54: TLabel;
    lblWeekly_90: TLabel;
    lblCalcTaxSheltering: TLabel;
    lblWeekly_90_S: TLabel;
    Label51: TLabel;
    Label57: TLabel;
    Label58: TLabel;
    edAccum_Wks_Yr_PdCst: TEdit;
    edAccum_Wks_Yr_90Net: TEdit;
    Label59: TLabel;
    Label60: TLabel;
    Label64: TLabel;
    lblSRWeeks_Worked2: TLabel;
    Label66: TLabel;
    lblSRTotal_Deds2: TLabel;
    Label68: TLabel;
    lblSRTotal_Deds_P_A2: TLabel;
    lblSRTotal_Deds_A2: TLabel;
    lblSRTax_Shelter_Bnft2: TLabel;
    Label75: TLabel;
    Label76: TLabel;
    lblSRShelter_Rebate_Year2: TLabel;
    Label82: TLabel;
    Label83: TLabel;
    lblSRAccum_Wks_Yr_90Net3: TLabel;
    Label85: TLabel;
    lnlSRWkly_Tax_S3: TLabel;
    Label87: TLabel;
    lblSRTax_Shelter_Deduct3: TLabel;
    lblSRTax_Shelter_Bnft3: TLabel;
    lblSRRebate_Amount3: TLabel;
    Label94: TLabel;
    Label95: TLabel;
    lblSRShelter_Rebate_Year3: TLabel;
    Label100: TLabel;
    lblDeleted: TLabel;
    lblPaymentIssued: TLabel;
    Label101: TLabel;
    Label3: TLabel;
    Label4: TLabel;
    Label6: TLabel;
    Label7: TLabel;
    lblWeeks_Worked: TLabel;
    lblAnnual_Gross_A: TLabel;
    lblAnnual_Net_A: TLabel;
    Bevel2: TBevel;
    Label12: TLabel;
    Bevel1: TBevel;
    Bevel3: TBevel;
    Bevel4: TBevel;
    Bevel5: TBevel;
    Label28: TLabel;
    Label29: TLabel;
    Label30: TLabel;
    Label31: TLabel;
    Label38: TLabel;
    Label39: TLabel;
    lblActualInc_Tax_Fed: TLabel;
    lblActualInc_Tax_Man: TLabel;
    lblActualCPP_Prem: TLabel;
    lblActualEI_Prem: TLabel;
    lblActualTotal_Deds: TLabel;
    edTax_Year: TEdit;
    lblShelter_Rebate_Year: TLabel;
    edActual_Shelter_Deduct: TEdit;
    Label8: TLabel;
    Label9: TLabel;
    Label10: TLabel;
    edInc_Tax_Exempt: TLabel;
    Label19: TLabel;
    Label21: TLabel;
    Label22: TLabel;
    Label23: TLabel;
    edSelf_Employed: TLabel;
    edRecurrence: TLabel;
    edChild_Care_Expense: TLabel;
    edPost_Injury_Earn: TLabel;
    Label43: TLabel;
    edSpousal_Support: TLabel;
    edAccident_Date: TLabel;
    Label50: TLabel;
    edCPP_Exempt: TLabel;
    edRecurrenceDate: TLabel;
    Label14: TLabel;
    edYouthful_Worker: TLabel;
    lblPost104: TLabel;
    edAccum_Wks_Yr_90NetPost: TEdit;
    Label11: TLabel;
    lblWorkerAnnuityAmt: TLabel;
    lblWCBAnnuityAmt: TLabel;
    lblRebatePreAnnuity3: TLabel;
    Label27: TLabel;
    lblWorkerAnnuityPercent: TLabel;
    Label48: TLabel;
    Label49: TLabel;
    lblRebatePreAnnuity3b: TLabel;
    Label62: TLabel;
    Label63: TLabel;
    lblRebatePreAnnuity3c: TLabel;
    Label67: TLabel;
    lblWCBAnnuityPercent: TLabel;
    Label70: TLabel;
    Label71: TLabel;
    Bevel6: TBevel;
    Label24: TLabel;
    Label25: TLabel;
    Label26: TLabel;
    Label47: TLabel;
    Label56: TLabel;
    Label65: TLabel;
    Label69: TLabel;
    Label72: TLabel;
    lblDisplayWeeksCompensation: TLabel;
    Label74: TLabel;
    lblDisplayShelterBeforeAnnuity: TLabel;
    Label78: TLabel;
    lblDisplayAnnuityEarnings: TLabel;
    lblDisplayWeeks90NetPost: TLabel;
    Label81: TLabel;
    Label73: TLabel;
    lblEmployerPaid: TLabel;
    lblIndexationYear: TLabel;
    Label55: TLabel;
    lblStatus: TLabel;
    Label13: TLabel;
    edBypassBatchProcess: TEdit;
    Label61: TLabel;
    lblDateProcessed: TLabel;
    Label46: TLabel;
    edClaimSpouseForTaxPurposes: TLabel;
    Label77: TLabel;
    lblCPP2_Prem: TLabel;
    Label79: TLabel;
    lblActualCPP2_Prem: TLabel;
    procedure FormClose(Sender: TObject; var Action: TCloseAction);
    procedure FormDestroy(Sender: TObject);
    procedure FormKeyDown(Sender: TObject; var Key: Word; Shift: TShiftState);
    procedure FormKeyPress(Sender: TObject; var Key: Char);
    procedure FormCreate(Sender: TObject);
    procedure FormActivate(Sender: TObject);
    procedure edAccum_Wks_Yr_PdCstKeyPress(Sender: TObject; var Key: Char);
    procedure edAccum_Wks_Yr_90NetKeyPress(Sender: TObject; var Key: Char);
    procedure edAccum_Wks_Yr_PdCstExit(Sender: TObject);
    procedure edAccum_Wks_Yr_90NetExit(Sender: TObject);
    procedure FormCloseQuery(Sender: TObject; var CanClose: Boolean);
    procedure edTax_YearKeyPress(Sender: TObject; var Key: Char);
    procedure edTax_YearExit(Sender: TObject);
    procedure edActual_Shelter_DeductExit(Sender: TObject);
    procedure edActual_Shelter_DeductKeyPress(Sender: TObject; var Key: Char);
    procedure SetMenu(CycleType:iCycleType);
    procedure ScrollBox1MouseWheelDown(Sender: TObject; Shift: TShiftState; MousePos: TPoint; var Handled: Boolean);
    procedure ScrollBox1MouseWheelUp(Sender: TObject; Shift: TShiftState; MousePos: TPoint; var Handled: Boolean);
    procedure edBypassBatchProcessExit(Sender: TObject);
    procedure FormResize(Sender: TObject);
  private
    { Private declarations }
    fCycleType : iCycleType;
    fSRClaim : recWLREBDTL;
    //fWorking : recConst;
    fSRCurrentSortOrder: iSRCurrentSortOrder;
    isChanged: boolean;
    globalEditError:boolean;
    TempNoShelter: currency;
    TempNet90: currency;
    TempNet90Post: currency;
    procedure SetMenuChoices;
    procedure ResetMenuChoices;
    procedure GenerateReport;
    procedure ResetInfoLine2;
    procedure DisplaySRRecord;
    procedure NextSRRecord;
    procedure PreviousSRRecord;
    procedure fillInForm;
    procedure payclaim;
    procedure LookupADifferentClaim;
    procedure MessWithSortOrder;
    procedure SelectClaimsByClaim(bDisplayRecord:boolean);
    procedure SelectClaimsBySuffixClaim(bDisplayRecord:boolean);
    procedure InsertOrDeleteOrReinstate;
    procedure AddNewSRClaim;
    procedure DeleteSRClaim;
    procedure ReinstateSRClaim;
    function ValidateAndRecalcBen: boolean;
    procedure RecalcBen;
    function addNewSRRecord( mySRrecord:recWLREBDTL): boolean;
    procedure updateSRRecord( mySRrecord:recWLREBDTL);
    function isUpdatePending:boolean;
    function isUpdatePendingForReporting:boolean;
    procedure DoTheActualLookup(clm:String);
    procedure RefreshTheList;
  public
    { Public declarations }
    constructor CreateExtended(cycleType: iCycleType; AOwner: TComponent); virtual;
  end;

var
  ShelterRebateEditForm: TShelterRebateEditForm;

implementation

uses NCMain, NCSRLtr1, NCDatMod, UtilMod1, NCInIMod, NCClmWL0,
  NCChoice, QPreview, NCSRDtlR, NCSRSumR, ncbenpay, uGlobal, Utils, uADOSecurity;
  //, CICSAPI1;

{$R *.DFM}

(******************************************************************************)
(*                                                                            *)
(*  Create Constructor                                                        *)
(*                                                                            *)
(*  Payment type is specified in order to customize form appropriately.       *)
(*                                                                            *)
(******************************************************************************)
constructor TShelterRebateEditForm.CreateExtended(cycleType: iCycleType; AOwner: TComponent);
begin
  // call inherited create which calls Form Create
  inherited create(AOwner);
  SetMenu(CycleType);
end;

(******************************************************************************)
(*                                                                            *)
(*  Form Close                                                                *)
(*                                                                            *)
(******************************************************************************)
procedure TShelterRebateEditForm.FormClose(Sender: TObject; var Action: TCloseAction);
begin
  Action := caFree;
end;

(******************************************************************************)
(*                                                                            *)
(*  Form Destroy                                                              *)
(*                                                                            *)
(******************************************************************************)
procedure TShelterRebateEditForm.FormDestroy(Sender: TObject);
begin
  try
     with dm1 do
        begin
        if query2.active then
           query2.close;
        end;
  finally
     ;
  end;

  ShelterRebateEditForm:=nil;
  WagelossMainForm.ShowInfoLine1('');
  WagelossMainForm.ShowInfoLine2('');
  ResetMenuChoices;
end;

(******************************************************************************)
(*                                                                            *)
(*  Key Down - preview and process keypresses on form.                        *)
(*                                                                            *)
(******************************************************************************)
procedure TShelterRebateEditForm.FormKeyDown(Sender: TObject; var Key: Word; Shift: TShiftState);
begin
  //
  // If the capability is Default the user can see the shelter records, can alter
  // and calculate them but will not be able to save them.
  // Setting the isChanged to False will allow the user to navigate away from
  // the record without saving
  //
  if CapabilityExists('Default') then
     isChanged := False;

  case Key of
    VK_F1: begin
           Key:=0;
           Application.HelpCommand(HELP_CONTENTS, 0);
           end;
    VK_F2: begin
           Key:=0;
           // F2-GoToClm
           if not isUpdatePending then
             LookupADifferentClaim;
           end;
    VK_F3: begin
           Key:=0;
           // F3-SortOrder
           if not isUpdatePending then
             MessWithSortOrder;
           end;
    VK_F4: begin
           Key:=0;
           // F4-Ins/Del
           if (Not CapabilityExists('Default')) Then
              if ( fCycleType = Cycle1 ) then
                 begin
                 if not isUpdatePending then
                    InsertOrDeleteOrReinstate;
                 end
              else
                 begin
                 end
           else
              begin
              messagebeep(0)
              end;
           end;
    VK_F5: begin
           Key:=0;
           // F5-Prev
           if not isUpdatePending then
             PreviousSRRecord;
           end;
    VK_F6: begin
           Key:=0;
           // F6-Next
           if not isUpdatePending then
             NextSRRecord;
           end;
    VK_F7: begin
           Key:=0;
           if not isUpdatePending then
             close;
           end;
    VK_F8: begin
           if ( fCycleType = Cycle1 ) then
           begin
               Key:=0;
               if fSRClaim.Logical_Delete_Flag then
                 messagebeep(0)
               else
               if not isUpdatePendingForReporting then
                 GenerateReport;
           end
           end;
    VK_F9: begin
           Key:=0;
           // F9-Calc or Pay
           if ( fCycleType = Cycle1 ) then
              begin
              if fSRClaim.Logical_Delete_Flag then
                 messagebeep(0)
              else
                 begin
                 ValidateAndRecalcBen;
                 scrollbox1.VertScrollBar.position:=scrollbox1.VertScrollBar.range;
                 end;
              end
           else
              if ( fCycleType = Cycle3 ) then
                 begin
                    if fSRClaim.Logical_Delete_Flag then
                       messagebeep(0)
                    else
                       begin
                       if (Not CapabilityExists('Default')) Then
                          payClaim;
                       end;
                 end;
           end;
    VK_F10: begin
            Key:=0;
            // F10-Calc/Updt
            if ( fCycleType = Cycle1 ) then
               begin
               if not fSRClaim.Logical_Delete_Flag then
                  begin
                  if ValidateAndRecalcBen AND (Not CapabilityExists('Default')) then
                     begin
                     scrollbox1.VertScrollBar.position:=scrollbox1.VertScrollBar.range;
                     updateSRRecord( fSRClaim )
                     end;
                  end;
               end;
            end;
    VK_NEXT: begin
           Key:=0;
           scrollbox1.VertScrollBar.position:=scrollbox1.VertScrollBar.range;
           end;
    VK_PRIOR: begin
           Key:=0;
           scrollbox1.VertScrollBar.position:=0;
           end;
  end;
end;

(******************************************************************************)
(*                                                                            *)
(*  Key Press - preview and process keypresses on form.                       *)
(*                                                                            *)
(******************************************************************************)
procedure TShelterRebateEditForm.FormKeyPress(Sender: TObject; var Key: Char);
begin
  case Key of
    Chr(VK_RETURN):
      begin
        Key:=#0;
        SelectNext(ActiveControl as tWinControl, true, true );
      end;
  end;
end;

(******************************************************************************)
(*                                                                            *)
(*  Set wageloss menu choices to enabled.                                     *)
(*                                                                            *)
(******************************************************************************)
procedure TShelterRebateEditForm.SetMenuChoices;
begin
  with WagelossMainForm do begin
      SRClaimDetailReportIndividualClaimMenu.enabled:=true;
  end;
end;

(******************************************************************************)
(*                                                                            *)
(*  Reset wageloss menu choices to disabled.                                  *)
(*                                                                            *)
(******************************************************************************)
procedure TShelterRebateEditForm.ResetMenuChoices;
begin
  with WagelossMainForm do begin
      SRClaimDetailReportIndividualClaimMenu.enabled:=false;
  end;
end;

(******************************************************************************)
(*                                                                            *)
(*   Filler  method for createExtended to call                                *)
(*                                                                            *)
(******************************************************************************)
procedure TShelterRebateEditForm.FormCreate(Sender: TObject);
begin
  SetFont(Self);
end;

(******************************************************************************)
(*                                                                            *)
(*    Generate Report                                                         *)
(*                                                                            *)
(******************************************************************************)
procedure TShelterRebateEditForm.GenerateReport;
var
  MyPreview: TQRCustomPreviewForm;
  MyReport: TShelterRebateDetailForm;
begin
  screen.cursor:=crHourGlass;
  try
    MyPreview := TQRCustomPreviewForm.create(application);

    MyReport := TShelterRebateDetailForm.create(Self);
    // store cycle type
    MyReport.fSRDetailReportType := iSingle;

    MyPreview.ParentQuickReportForm:=MyReport;
    MyPreview.ParentQuickReport:=MyReport.QRShelterRebateDetailReport;
    MyPreview.caption:='Shelter Rebate Claim Detail - Individual Claim';
    screen.cursor:=crDefault;
    try
      MyReport.QRShelterRebateDetailReport.OnPreview := MyPreview.CustomPreview;
      MyReport.QRShelterRebateDetailReport.Preview;
    finally
      screen.cursor:=crDefault;
    end;
  finally
  screen.cursor:=crDefault;
  end;
end;

(******************************************************************************)
(*                                                                            *)
(*  Display default Info message                                              *)
(*                                                                            *)
(******************************************************************************)
procedure TShelterRebateEditForm.ResetInfoLine2;
begin
  case fcycleType of
    cycle1:
      begin
        if fSRClaim.Logical_Delete_Flag then
           WagelossMainForm.ShowInfoLine2('F2-GoToClm  F3-SortOrder  F4-Ins/Del  F5-Prev  F6-Next  F7-Exit')
        else
           if (CapabilityExists('Default')) Then
              WagelossMainForm.ShowInfoLine2('F2-GoToClm  F3-SortOrder  F5-Prev  F6-Next  F7-Exit  F8-Rpt  F9-Calc')
           else
              WagelossMainForm.ShowInfoLine2('F2-GoToClm  F3-SortOrder  F4-Ins/Del  F5-Prev  F6-Next  F7-Exit  F8-Rpt  F9-Calc  F10-Calc/Updt');
      end;
    cycle2:
      begin
        WagelossMainForm.ShowInfoLine2('F2-GoToClm  F3-SortOrder  F5-Prev  F6-Next  F7-Exit');
      end;
    cycle3:
      begin
        if fSRClaim.Logical_Delete_Flag then
        WagelossMainForm.ShowInfoLine2('F2-GoToClm  F3-SortOrder  F5-Prev  F6-Next  F7-Exit')
      else
         if (CapabilityExists('Default')) Then
            WagelossMainForm.ShowInfoLine2('F2-GoToClm  F3-SortOrder  F5-Prev  F6-Next  F7-Exit')
         else
            WagelossMainForm.ShowInfoLine2('F2-GoToClm  F3-SortOrder  F5-Prev  F6-Next  F7-Exit  F9-Payment');
      end;
    end;
end;

(******************************************************************************)
(*                                                                            *)
(*   Form Activate method                                                     *)
(*                                                                            *)
(******************************************************************************)
procedure TShelterRebateEditForm.FormActivate(Sender: TObject);
begin
    WagelossMainForm.ShowStatusLine2('');
    ResetInfoLine2;
end;

(******************************************************************************)
(*                                                                            *)
(*    Display Shelter Rebate Record                                           *)
(*                                                                            *)
(******************************************************************************)
procedure TShelterRebateEditForm.DisplaySRRecord;
var
   clm: string;
begin
  isChanged:=false;
  try
    with dm1 do
       begin
       clm := query2.fieldbyname('Claim_No').asString;

       if query1.active then
          query1.close;
          
       query1.sql.clear;
       query1.sql.add('SELECT * FROM dbo.WLREBDTL where Claim_No = ''' + clm + '''');
       query1.open;
       query1.first;
       end;
  finally
     ;
  end;

  if not (uGlobal.logActivity(clm, uGlobal.LOG_TYPE_SELECT, 'ShelterRebate')) then
  begin
    WagelossMainForm.ShowInfoLine2( '*Logging Failed.  Claim Load Not Allowed!*' );
    exit;
  end;

  try
    with dm1 do
     begin
     with fSRClaim do
        begin
          Claim_No := query1.FieldByName('Claim_No').asString;
        	Claim_Suffix := query1.FieldByName('Claim_Suffix').asString;
          Clmt_Name_Initials := query1.FieldByName('Clmt_Name_Initials').asString;
        	Tax_Year := query1.FieldByName('Tax_Year').asInteger;
        	Marital_Status :=query1.FieldByName('Marital_Status').asString;
        	Spouse_Working := query1.FieldByName('Spouse_Working').asString;
          ClaimSpouseForTaxPurposes := query1.FieldByName('ClaimSpouseForTaxPurposes').asString;
        	Nbr_Of_Dependants :=query1.FieldByName('Nbr_Of_Dependants').asInteger;
        	Nbr_Of_Infirm_Deps :=query1.FieldByName('Nbr_Of_Infirm_Deps').asInteger;
        	Uic_Exempt :=query1.FieldByName('Uic_Exempt').asString;
        	Accum_Wks_Yr_PdCst :=query1.FieldByName('Accum_Wks_Yr_PdCst').asCurrency;
        	Accum_Wks_Yr_90Net :=query1.FieldByName('Accum_Wks_Yr_90Net').asCurrency;
          TempNet90 := query1.FieldByName('Accum_Wks_Yr_90Net').asCurrency;
        	Wkly_Sal :=query1.FieldByName('Wkly_Sal').asCurrency;
        	Wkly_Net :=query1.FieldByName('Wkly_Net').asCurrency;
        	Wkly_90 :=query1.FieldByName('Wkly_90').asCurrency;
        	Wkly_90_S :=query1.FieldByName('Wkly_90_S').asCurrency;
        	Wkly_80 :=query1.FieldByName('Wkly_80').asCurrency;
        	Annual_Gross :=query1.FieldByName('Annual_Gross').asCurrency;
        	Annual_Net :=query1.FieldByName('Annual_Net').asCurrency;
        	Annual_90 :=query1.FieldByName('Annual_90').asCurrency;
        	Annual_90_S :=query1.FieldByName('Annual_90_S').asCurrency;
         	Annual_80 :=query1.FieldByName('Annual_80').asCurrency;
        	Tax_Exemption :=query1.FieldByName('Tax_Exemption').asCurrency;
        	Inc_Tax_Fed :=query1.FieldByName('Inc_Tax_Fed').asCurrency;
        	Inc_Tax_Prov :=query1.FieldByName('Inc_Tax_Prov').asCurrency;
        	Cpp_Prem := query1.FieldByName('Cpp_Prem').asCurrency;
          Cpp2_Prem := query1.FieldByName('Cpp2_Prem').asCurrency;
        	Uic_Prem :=query1.FieldByName('Uic_Prem').asCurrency;
        	Total_Deds :=query1.FieldByName('Total_Deds').asCurrency;
        	Wkly_Sal_A :=query1.FieldByName('Wkly_Sal_A').asCurrency;
        	Annual_Gross_A :=query1.FieldByName('Annual_Gross_A').asCurrency;
        	Annual_Net_A :=query1.FieldByName('Annual_Net_A').asCurrency;
        	Tax_Exemption_A :=query1.FieldByName('Tax_Exemption_A').asCurrency;
        	Inc_Tax_Fed_A :=query1.FieldByName('Inc_Tax_Fed_A').asCurrency;
        	Inc_Tax_Prov_A :=query1.FieldByName('Inc_Tax_Prov_A').asCurrency;
        	Cpp_Prem_A := query1.FieldByName('Cpp_Prem_A').asCurrency;
          Cpp2_Prem_A := query1.FieldByName('Cpp2_Prem_A').asCurrency;
        	Uic_Prem_A :=query1.FieldByName('Uic_Prem_A').asCurrency;
        	Tax_Shelter_Bnft :=query1.FieldByName('Tax_Shelter_Bnft').asCurrency;
        	Tax_Shelter_Deduct :=query1.FieldByName('Tax_Shelter_Deduct').asCurrency;
        	Rebate_Amount :=query1.FieldByName('Rebate_Amount').asCurrency;
        	Weeks_Worked :=query1.FieldByName('Weeks_Worked').asCurrency;
        	Wkly_Tax_S :=query1.FieldByName('Wkly_Tax_S').asCurrency;
        	Total_Deds_A :=query1.FieldByName('Total_Deds_A').asCurrency;
        	Total_Tax_S :=query1.FieldByName('Total_Tax_S').asCurrency;
        	Total_Deds_P_A :=query1.FieldByName('Total_Deds_P_A').asCurrency;
        	Shelter_Rebate_Year :=query1.FieldByName('Shelter_Rebate_Year').asInteger;
          Prime_Firm_No :=query1.FieldByName('Prime_Firm_No').asString;
          Payment_Issued_Flag :=query1.FieldByName('Payment_Issued_Flag').asBoolean;
          Logical_Delete_Flag :=query1.FieldByName('Logical_Delete_Flag').asBoolean;
          Accident_Date := query1.FieldByName('Accident_Date').asDateTime;
        	Self_Employed :=query1.FieldByName('Self_Employed').asString;
        	Recurrence :=query1.FieldByName('Recurrence').asString;
        	CPP_Exempt := query1.FieldByName('CPP_Exempt').asString;
        	Tax_Exempt :=query1.FieldByName('income_tax_exempt').asString;
        	Child_Care_Exp :=query1.FieldByName('child_care_expense').asCurrency;
        	Spousal_Support :=query1.FieldByName('Spousal_Support').asCurrency;
        	Child_Support :=query1.FieldByName('Child_Support').asCurrency;
          PostInjuryEarnings :=query1.FieldByName('Post_Injury_Earnings').asCurrency;
        	Nbr_Act_Shelter_Deduct :=query1.FieldByName('no_of_actual_shelter_deduc').asCurrency;
          if query1.FieldByName('Recurrence_Date').IsNull Then
            Recurrence_Date := 0
          else
            Recurrence_Date := query1.FieldByName('Recurrence_Date').AsDateTime;
          if query1.FieldByName('Youthful_Worker').IsNull then
            Youthful_Worker := 'N'
          else
            Youthful_Worker := query1.FieldByName('Youthful_Worker').AsString;
          Accum_Wks_Yr_90Net_Post := query1.FieldByName('Accum_Wks_Yr_90Net_Post').asCurrency;
          TempNet90Post := query1.FieldByName('Accum_Wks_Yr_90Net_Post').asCurrency;
          workerAnnuityContributionPercent := query1.fields[060].asCurrency;
          wcbAnnuityContributionPercent := query1.FieldByName('wcbAnnuityContributionPercent').asCurrency;
          workerShetlerAnnuityContribAmt := query1.FieldByName('workerShetlerAnnuityContribAmt').asCurrency;
          wcbShelterAnnuityContribAmt := query1.FieldByName('wcbShelterAnnuityContribAmt').asCurrency;
          paidFromDate := query1.FieldByName('paidFromDate').AsDateTime;
          paidToDate := query1.FieldByName('paidToDate').AsDateTime;
          employerPaidFlag := query1.FieldByName('employerPaidFlag').AsString;
          indexationYear := query1.FieldByName('indexedYear').asInteger;
          Max_Adjustment :=query1.FieldByName('maximumadjustmentamt').asCurrency;
          reportType := query1.FieldByName('reportType').AsString;
          doNotBatchProcessFlag := query1.FieldByName('doNotBatchProcessFlag').AsString;
          fSRClaim.collateralTaxableAmt := query1.FieldByName('collateralTaxableAmt').asCurrency;
          fSRClaim.collateralNonTaxableAmt := query1.FieldByName('collateralNonTaxableAmt').asCurrency;
          fSRClaim.processDateTime := query1.FieldByName('processDateTime').AsDateTime;
        end;

     end;
  finally
     ;
  end;

  fillInForm;
  ResetInfoLine2;
end;

(******************************************************************************)
(*                                                                            *)
(*    Go to next record                                                       *)
(*                                                                            *)
(******************************************************************************)
procedure TShelterRebateEditForm.NextSRRecord;
var
  bDone : boolean;
  saveClaim : string;
begin
  saveClaim := dm1.query2.fieldbyname('Claim_No').asString;
  bDone := false;

  While not bDone do
     begin
     if not dm1.query2.eof then
        begin
        dm1.query2.next;
        if (dm1.query2.fieldbyname('processDateTime').asDateTime = 0) AND (dm1.query2.fieldbyname('reportType').asString <> 'DISQUALIFY') then
           begin
           bDone := true;
           DisplaySRRecord;
           end;
        end
     else
        begin
        bDone := true;
        DoTheActualLookup(saveClaim);
       end;
     end;
//  if not dm1.query2.eof then
//    dm1.query2.next;
//  DisplaySRRecord;
end;

(******************************************************************************)
(*                                                                            *)
(*    Go to previous record                                                   *)
(*                                                                            *)
(******************************************************************************)
procedure TShelterRebateEditForm.PreviousSRRecord;
var
  bDone : boolean;
  saveClaim : string;
begin
  saveClaim := dm1.query2.fieldbyname('Claim_No').asString;
  bDone := false;
  While not bDone do
  begin
    if not dm1.query2.bof then
    begin
      dm1.query2.prior;
      if (dm1.query2.fieldbyname('processDateTime').asDateTime = 0) AND (dm1.query2.fieldbyname('reportType').asString <> 'DISQUALIFY') then
      begin
        bDone := true;
        DisplaySRRecord;
      end;
    end
    else
    begin
      bDone := true;
      DoTheActualLookup(saveClaim);
    end;
  end;
//  if not dm1.query2.bof then
//    dm1.query2.prior;

//  DisplaySRRecord;
end;


(******************************************************************************)
(*                                                                            *)
(*  Fill in form from claim record(s)                                         *)
(*                                                                            *)
(******************************************************************************)
procedure TShelterRebateEditForm.fillInForm;
var
  eligEarn:currency;
begin
  with fSRClaim do
  begin
    if Logical_Delete_Flag or (fCycleType = Cycle2) or (fCycleType = Cycle3) then
       begin
       setEditToRead(edTax_Year);
       setEditToRead(edAccum_Wks_Yr_PdCst);
       setEditToRead(edAccum_Wks_Yr_90Net);
       setEditToRead(edAccum_Wks_Yr_90NetPost);
       setEditToRead(edBypassBatchProcess);
       end
    else
       begin
       setEditToNormal(edTax_Year);
       setEditToNormal(edAccum_Wks_Yr_PdCst);
       setEditToNormal(edAccum_Wks_Yr_90Net);
       setEditToNormal(edAccum_Wks_Yr_90NetPost);
       setEditToNormal(edBypassBatchProcess);
       end;

    lblDeleted.visible:=Logical_Delete_Flag;
    lblPaymentIssued.visible:=Payment_Issued_Flag;
    lblClaim_No.caption:= Claim_No;
    lblClaim_Suffix.caption:=Claim_Suffix;
    lblClmnts_Name.caption:= Clmt_Name_Initials;
    edTax_Year.text := format('%d', [ Tax_Year ] );
    lblShelter_Rebate_Year.caption := format('%d', [ Shelter_Rebate_Year ] );
    edAccum_Wks_Yr_PdCst.text := format('%.2n', [ Accum_Wks_Yr_PdCst ] );
    lblInc_Tax_Fed.caption := format('%.2n', [ Inc_Tax_Fed ] );
    lblInc_Tax_Man.caption := format('%.2n', [ Inc_Tax_Prov ] );
    lblCPP_Prem.caption := format('%.2n', [ Cpp_Prem ] );
    lblCPP2_Prem.caption := format('%.2n', [ Cpp2_Prem ] );
    lblEI_Prem.caption := format('%.2n', [ Uic_Prem ] );
    lblTotal_Deds.caption := format('%.2n', [ Total_Deds ] );
    edTax_Year.text := format('%d', [ Tax_Year ] );
    edMarital_Status.caption := Marital_Status;
    edEI_Exempt.caption := Uic_Exempt;
    edNo_Of_Dependnts.caption := format('%d', [ Nbr_Of_Dependants ] );
    edNo_Infirm.caption := format('%d', [ Nbr_Of_Infirm_Deps ] );
    edSpouse_Working.caption := Spouse_Working;
    edClaimSpouseForTaxPurposes.Caption := ClaimSpouseForTaxPurposes;
    lblWkly_Sal_A.caption := format('%.2n', [ Wkly_Sal ] );
    lblWeekly_Net.caption := format('%.2n', [ Wkly_Net ] );
    lblAnnual_Gross.caption := format('%.2n', [ Annual_Gross ] );
    lblAnnual_Net.caption := format('%.2n', [ Annual_Net ] );
    lblWeekly_90.caption := format('%.2n', [ Wkly_90 ] );
    lblCalcTaxSheltering.caption := format('%.2n', [ Wkly_Tax_S ] );
    lblWeekly_90_S.caption := format('%.2n', [ Wkly_90_S ] );
    //lblAnnual_90.caption := format('%.2n', [ Annual_90 ] );
    //lblAnnual_90_S.caption := format('%.2n', [ Annual_90_S ] );
    //lblWeekly_80.caption := format('%.2n', [ Wkly_80 ] );
    //lblAnnual_80.caption := format('%.2n', [ Annual_80 ] );
    lblWeeks_Worked.caption := format('%.2n', [ Weeks_Worked ] );
    //lblTax_Exemption.caption := format('%.2n', [ Tax_Exemption ] );
    lblAnnual_Gross_A.caption := format('%.2n', [ Annual_Gross_A ] );
    lblAnnual_Net_A.caption := format('%.2n', [ Annual_Net_A ] );
    //lblActualTax_Exemption.caption := format('%.2n', [ Tax_Exemption_A ] );
    lblActualInc_Tax_Fed.caption := format('%.2n', [ Inc_Tax_Fed_A ] );
    lblActualInc_Tax_Man.caption := format('%.2n', [ Inc_Tax_Prov_A ] );
    lblActualCPP_Prem.caption := format('%.2n', [ Cpp_Prem_A ] );
    lblActualCPP2_Prem.caption := format('%.2n', [ Cpp2_Prem_A ] );
    lblActualEI_Prem.caption := format('%.2n', [ Uic_Prem_A ] );
    lblActualTotal_Deds.caption := format('%.2n', [ Total_Deds_A ] );
    lblSRWeeks_Worked2.caption :=  format('%n', [ Weeks_Worked ] );
    lblSRTotal_Deds2.caption := format('%.2n', [ Total_Deds  ] );
    lblSRTotal_Deds_P_A2.caption := format('%.2n', [ Total_Deds_P_A ] );
    lblSRTotal_Deds_A2.caption := format('%.2n', [ Total_Deds_A  ] );
    lblSRTax_Shelter_Bnft2.caption := format('%.2n', [ Tax_Shelter_Bnft  ] );
    lblSRShelter_Rebate_Year2.caption := format('%d', [ Shelter_Rebate_Year ] );
    edAccum_Wks_Yr_90NetPost.text := format('%.2n', [ Accum_Wks_Yr_90Net_Post ] );
    if (year(Accident_Date) < 2006) then
       begin
       lblSRAccum_Wks_Yr_90Net3.caption := format('%.2n', [ Accum_Wks_Yr_90Net ] );
       //if Nbr_Act_Shelter_Deduct > 0 then
       if (PostInjuryEarnings > 0) then
          lblSRAccum_Wks_Yr_90Net3.caption := format('%.2n', [ Nbr_Act_Shelter_Deduct ] );
       setEditToRead(edAccum_Wks_Yr_90NetPost);
       //Label61.Caption := '80% of Net Loss';
       end
    else
       begin
       lblSRAccum_Wks_Yr_90Net3.caption := format('%.2n', [ Accum_Wks_Yr_90Net + Accum_Wks_Yr_90Net_Post ] );
       //if Nbr_Act_Shelter_Deduct > 0 then
       if (PostInjuryEarnings > 0) then
          lblSRAccum_Wks_Yr_90Net3.caption := format('%.2n', [ Nbr_Act_Shelter_Deduct ] );
       if NOT Logical_Delete_Flag and NOT (fCycleType = Cycle2) and NOT (fCycleType = Cycle3) then
          setEditToNormal(edAccum_Wks_Yr_90NetPost);
       //Label61.Caption := '90% of Net Loss Post 104';
       end;
    fSRClaim.Accum_Wks_Yr_90Net := TempNet90;
    edAccum_Wks_Yr_90Net.text := format('%.2n', [ Accum_Wks_Yr_90Net ] );
    lnlSRWkly_Tax_S3.caption := format('%.2n', [ Wkly_Tax_S  ] );
    lblSRTax_Shelter_Deduct3.caption := format('%.2n', [ Tax_Shelter_Deduct  ] );
    lblSRTax_Shelter_Bnft3.caption := format('%.2n', [ Tax_Shelter_Bnft  ] );

    if Accum_Wks_Yr_PdCst <> 0 then
      eligEarn := Accum_Wks_Yr_90Net_Post / Accum_Wks_Yr_PdCst
    else
      eligEarn := 0;
    lblRebatePreAnnuity3.caption := format('%.2n', [ Rebate_Amount + workerShetlerAnnuityContribAmt  ] );
    lblWorkerAnnuityPercent.caption := format('%.2n', [ workerAnnuityContributionPercent  ] ) + '%';
    if year(Accident_Date) > 2005 then
       begin
       lblRebatePreAnnuity3b.caption := format('%.2n', [ (Rebate_Amount + workerShetlerAnnuityContribAmt) *  eligEarn ] );
       lblRebatePreAnnuity3c.caption := format('%.2n', [ (Rebate_Amount + workerShetlerAnnuityContribAmt) *  eligEarn  ] );
       lblDisplayWeeks90NetPost.caption := format('%.2n', [ Accum_Wks_Yr_90Net_Post  ] );
       //lblDisplayWeeksCompensation.caption := format('%.2n', [ Accum_Wks_Yr_PdCst  ] );
       lblDisplayWeeksCompensation.caption := format('%.2n', [ Accum_Wks_Yr_PdCst  ] );
       lblDisplayShelterBeforeAnnuity.caption := format('%.2n', [ Rebate_Amount + workerShetlerAnnuityContribAmt  ] );
       lblDisplayAnnuityEarnings.caption := format('%.2n', [ (Rebate_Amount + workerShetlerAnnuityContribAmt) *  eligEarn  ] );
       end
    else
       begin
       lblRebatePreAnnuity3b.caption := '0.00';
       lblRebatePreAnnuity3c.caption := '0.00';
       lblDisplayWeeks90NetPost.caption := '0.00';
       lblDisplayWeeksCompensation.caption := '0.00';
       lblDisplayShelterBeforeAnnuity.caption := '0.00';
       lblDisplayAnnuityEarnings.caption := '0.00';
       end;
    lblWorkerAnnuityAmt.caption := format('%.2n', [ workerShetlerAnnuityContribAmt  ] );
    lblSRRebate_Amount3.caption := format('%.2n', [ Rebate_Amount  ] );
    lblSRShelter_Rebate_Year3.caption := format('%d', [ Shelter_Rebate_Year ] );
    lblWCBAnnuityPercent.caption := format('%.2n', [ wcbAnnuityContributionPercent  ] ) + '%';
    lblWCBAnnuityAmt.caption := format('%.2n', [ wcbShelterAnnuityContribAmt  ] );
    //edAccident_Date.Caption := FormatDateTime('c', Accident_Date );
    edAccident_Date.Caption := FormatDateTime('ddddd', Accident_Date );
    edCPP_Exempt.caption := CPP_Exempt;
    edInc_Tax_exempt.caption := Tax_Exempt;
    edSelf_Employed.caption := Self_Employed;
    edRecurrence.Caption := Recurrence;

    if Recurrence_Date <> 0 Then
       begin
       //edRecurrenceDate.Caption := FormatDateTime('c', Recurrence_Date);
       edRecurrenceDate.Caption := FormatDateTime('ddddd', Recurrence_Date);
       end
    else
       edRecurrenceDate.Caption := '';

    edYouthful_Worker.Caption := Youthful_Worker;
    //
    edSpousal_Support.Caption := format('%.2n', [ spousal_support ] );
    edChild_Care_Expense.caption := format('%.2n', [ child_care_exp ] );
    edPost_Injury_Earn.caption := format('%.2n', [ PostInjuryEarnings ] );
    //fSRClaim.Nbr_Act_Shelter_Deduct := TempNoShelter;
    edActual_Shelter_Deduct.text := format('%.2n', [ Nbr_Act_Shelter_Deduct ] );
    if ((PostInjuryEarnings > 0.00) and NOT(fCycleType = Cycle3)) then
      setEditToNormal(edActual_Shelter_Deduct)
    else
      setEditToRead(edActual_Shelter_Deduct);
    lblEmployerPaid.caption := employerPaidFlag;
    lblIndexationYear.caption := format('%d', [ indexationYear ] );
    lblStatus.Caption := reportType;
    edBypassBatchProcess.Text := doNotBatchProcessFlag;

    if processDateTime <> 0 then
       begin
       //lblDateProcessed.Caption := FormatDateTime('c', processDateTime );
       lblDateProcessed.Caption := FormatDateTime('ddddd', processDateTime);
       end
    else
       lblDateProcessed.Caption := '';
  end; // with fSRClaim do..
end;

(******************************************************************************)
(*                                                                            *)
(*   Pay shelter rebate claim                                                 *)
(*                                                                            *)
(******************************************************************************)
procedure TShelterRebateEditForm.payclaim;
var
  //rc: integer;
  saveClaim: recNCCLAIM;
begin
  if fSRClaim.Logical_Delete_Flag then exit;

  if fSRClaim.Rebate_Amount = 0 then
  begin
       WagelossMainForm.ShowInfoLine2('*Worker is not due a rebate - payment can not be sent.');
       messagebeep(0);
       exit;
  end;
(*
  try
    rc:=0;
    GetChoiceForm:=TGetChoiceForm.create(application);
    GetChoiceForm.Message:='Generate a Shelter Rebate Letter?';
    GetChoiceForm.AddChoice('Y - Yes');
    GetChoiceForm.AddChoice('N - No');
    GetChoiceForm.showmodal;
    rc := GetChoiceForm.Selected;
  finally
    GetChoiceForm.free;
  end;

  if rc = 0 then GenerateLetter;
*)
  copyNCCLAIM( dataClaim, saveClaim);
  ClearNCCLAIM( dataClaim );

  with dataClaim do
  begin
      dataClaim.Claim_No:=fSRClaim.Claim_No;
      dataClaim.Claim_Suffix:=fSRClaim.Claim_Suffix;
      dataClaim.Clmnts_Surname:=fSRClaim.Clmt_Name_Initials;
      dataClaim.Tax_Year:=fSRClaim.Tax_Year;
      dataClaim.Marital_Status:=fSRClaim.Marital_Status;
      dataClaim.Spouse_Working:=fSRClaim.Spouse_Working;
      dataClaim.ClaimSpouseForTaxPurposes := fSRClaim.ClaimSpouseForTaxPurposes;
      dataClaim.No_Of_Dependnts:=fSRClaim.Nbr_Of_Dependants;
      dataClaim.No_Infirm:=fSRClaim.Nbr_Of_Infirm_Deps;
      dataclaim.EI_Exempt := fSRClaim.Uic_Exempt;
      dataClaim.Wkly_Sal_A:=fSRClaim.Wkly_Sal;
      dataClaim.Date_Pd_From_Cheq := fSRClaim.paidFromDate;
      dataClaim.Date_Pd_To_Cheq := fSRClaim.paidToDate;
      dataClaim.Payment_Anty_Earn := (fSRClaim.Rebate_Amount + fSRClaim.workerShetlerAnnuityContribAmt) *  (fSRClaim.Accum_Wks_Yr_90Net_Post / fSRClaim.Accum_Wks_Yr_PdCst);
      dataClaim.Payment_Clmt_Contrib := fSRClaim.workerShetlerAnnuityContribAmt;
      dataClaim.Payment_WCB_Contrib := fSRClaim.wcbShelterAnnuityContribAmt;
      dataClaim.Accident_Date := fSRClaim.Accident_Date;

      dataClaim.Benefit_Type_Code:='9';
      dataClaim.Benefit_Type:='Shelter Rebate';
      dataClaim.Weekly_Benefit:=0;

      dataClaim.Prime_Firm_No:=fSRClaim.Prime_Firm_No;
      if ( length( pdoxtrim( dataClaim.Prime_Firm_No ) ) < 1 ) then
        dataClaim.CFIO := '?'
      else
      if Check_Self_Assurer( dataClaim.Prime_Firm_No ) then
       //changes made by Larry Caruk. If firms 0050229AL OR 0050229AX OR 0050229Aj OR 0050229AT
       //the the CFIO flag is set to 'N'.
       //
       if (dataClaim.Prime_Firm_No = '0050229AL') or
          (dataClaim.Prime_Firm_No = '0050229AX') or
          (dataClaim.Prime_Firm_No = '0050229AJ') or
          (dataClaim.Prime_Firm_No = '0050229AT') then
       begin
         dataClaim.CFIO := 'N';
       end
       else
       begin
         dataClaim.CFIO := 'Y';
       end
       else
        dataClaim.CFIO := 'N';

        dataclaim.Amount_Paid:=fSRClaim.Rebate_Amount;
  end;

  (****************************************************************************)
  (* Finally create the payment form...                                       *)
  (****************************************************************************)
  try
    WagelossPaymentForm:=TWagelossPaymentForm.CreateExtended(iShelterRebate, application);
    WagelossPaymentForm.showmodal;
    RefreshTheList;
    // Now mark as updated.
    //markSRClaimAsPaid;
  finally
    WagelossPaymentForm.free;
  end;

  copyNCCLAIM( saveClaim, dataClaim);
end;

(******************************************************************************)
(*                                                                            *)
(*    Refresh The Shelter List to allow for paid claims                                                     *)
(*                                                                            *)
(******************************************************************************)
procedure TShelterRebateEditForm.RefreshTheList;
var
    clm:string;
begin
  clm := dm1.query2.fieldbyname('Claim_No').asString;
  if ( fSRCurrentSortOrder = byClaim ) then
    SelectClaimsByClaim(false)
  else
    SelectClaimsBySuffixClaim(false);

  with dm1 do
  begin
    if not query2.Locate('Claim_No', clm , []) then
    begin
      messagebeep(0);
    end;
  end;
end;

(******************************************************************************)
(*                                                                            *)
(*  Perform Select Claim and open Wageloss Benefits window.                   *)
(*                                                                            *)
(******************************************************************************)
procedure TShelterRebateEditForm.LookupADifferentClaim;
//var
//    clm:string;
begin
  ResetInfoLine2;

  try
     SelectClaimForm := TSelectClaimForm.create(application);

     if (SelectClaimForm.showmodal = mrOK) then
        begin
        // Nov 98 - BT - year 2000 windowing fixes
//        if (copy(SelectClaimForm.edClaimNumber.text,1,2) < '92' ) and
//           (copy(SelectClaimForm.edClaimNumber.text,1,2) > '20' ) then
//           begin
//           WagelossMainForm.ShowInfoLine2('*Claim number must be 1992 or greater.');
//           abort;
//           end;

//    clm := SelectClaimForm.edClaimNumber.text;

        DoTheActualLookup(SelectClaimForm.edClaimNumber.text)

//    try
//      with dm1 do
//      begin
//        if query2.Locate('Claim_No', clm , []) then
//        begin
//           DisplaySRRecord;
//           ResetInfoLine2;
//        end
//        else
//        begin
//           messagebeep(0);
//           WagelossMainForm.ShowInfoLine2('*Claim ' + clm + ' not Found.');
//        end;
//      end;
//    finally
//    ;
//    end;

        end;
  finally
     SelectClaimForm.free;
  end;

end;

procedure TShelterRebateEditForm.DoTheActualLookup(clm:String);
begin
  try
     with dm1 do
        begin
        if query2.Locate('Claim_No', clm , []) then
           begin
           DisplaySRRecord;
           ResetInfoLine2;
           end
        else
           begin
           messagebeep(0);
           WagelossMainForm.ShowInfoLine2('*Claim ' + clm + ' not Found.');
           end;
        end;
  finally
     ;
  end;
end;

(******************************************************************************)
(*                                                                            *)
(*    Change sort order of claims for display                                 *)
(*                                                                            *)
(******************************************************************************)
procedure TShelterRebateEditForm.MessWithSortOrder;
var
  rc: integer;
  clm: string;
begin
  try
    rc:=0;
    GetChoiceForm:=TGetChoiceForm.create(application);
    GetChoiceForm.Caption := 'Sort Order Selection';
    GetChoiceForm.Message:='Please select your sort order for claims.';
    GetChoiceForm.AddChoice('L - Do not change sort order');
    GetChoiceForm.AddChoice('C - By Claim');
    GetChoiceForm.AddChoice('S - By Suffix and Claim');
    if fSRCurrentSortOrder = byClaim then
      GetChoiceForm.selected:= 2
    else
      GetChoiceForm.selected:= 1;
    GetChoiceForm.showmodal;
    rc := GetChoiceForm.Selected;
  finally
    GetChoiceForm.free;
  end;
  with dm1 do
  begin
    clm := query2.fieldbyname('Claim_No').asString;
  end;
  case rc of
  0:
      begin
        exit;
      end;
  1:
      begin
      SelectClaimsByClaim(true);
      end;
  2:
      begin
      SelectClaimsBySuffixClaim(true);
      end;
  end;
  // find current claim again
  with dm1 do
  begin
    if query2.Locate('Claim_No', clm , []) then
    begin
       DisplaySRRecord;
       ResetInfoLine2;
   end
  end;
end;

(******************************************************************************)
(*                                                                            *)
(*    Select all shelter rebate claims in claim order                         *)
(*                                                                            *)
(******************************************************************************)
procedure TShelterRebateEditForm.SelectClaimsByClaim(bDisplayRecord:boolean);
begin
  try
    with dm1 do
    begin
      if query2.active then query2.close;
      query2.sql.clear;
      query2.sql.add('SELECT Claim_No, Claim_Suffix, processDateTime, reportType FROM dbo.WLREBDTL ORDER BY Claim_No');
      query2.open;
      query2.first;
    end;
  finally
  ;
  end;
  fSRCurrentSortOrder := byClaim;
  if bDisplayRecord then
    if (dm1.query2.fieldbyname('processDateTime').asDateTime = 0) AND (dm1.query2.fieldbyname('reportType').asString <> 'DISQUALIFY') then
      DisplaySRRecord
    else
      NextSRRecord;
end;

(******************************************************************************)
(*                                                                            *)
(*    Select all shelter rebate claims in suffix/claim order                  *)
(*                                                                            *)
(******************************************************************************)
procedure TShelterRebateEditForm.SelectClaimsBySuffixClaim(bDisplayRecord:boolean);
begin
  try
    with dm1 do
    begin
      if query2.active then query2.close;
      query2.sql.clear;
      query2.sql.add('SELECT Claim_No, Claim_Suffix,processDateTime, reportType FROM dbo.WLREBDTL ORDER BY Claim_Suffix, Claim_No');
      query2.open;
      query2.first;
    end;
  finally
  ;
  end;
  fSRCurrentSortOrder := bySuffixClaim;
  if bDisplayRecord then
    if (dm1.query2.fieldbyname('processDateTime').asDateTime = 0) AND (dm1.query2.fieldbyname('reportType').asString <> 'DISQUALIFY') then
      DisplaySRRecord
    else
      NextSRRecord;
end;

(******************************************************************************)
(*                                                                            *)
(*   Prompt for Insert, Delete, Reinstate actions                             *)
(*                                                                            *)
(******************************************************************************)
procedure TShelterRebateEditForm.InsertOrDeleteOrReinstate;
var
  rc: integer;
begin
  try
     rc := 0;
     GetChoiceForm := TGetChoiceForm.create(application);
     GetChoiceForm.Caption := 'Select Claim Action';
     GetChoiceForm.Message:='Please select Claim Action.';
     GetChoiceForm.AddChoice('X - Cancel');
     //GetChoiceForm.AddChoice('A - Add a new claim');

     if not fSRClaim.Logical_Delete_Flag then
        GetChoiceForm.AddChoice('D - Delete Current Claim')
     else
        GetChoiceForm.AddChoice('R - Reinstate Current Claim');

     GetChoiceForm.showmodal;
     rc := GetChoiceForm.Selected;
  finally
     GetChoiceForm.free;
  end;

//  if ( rc = 1 ) then
//     begin
//     // Add new
//     //AddNewSRClaim;
//     end
//  else
  if ( rc = 1 ) and ( not fSRClaim.Logical_Delete_Flag ) then
     begin
     // Mark as deleted
     DeleteSRClaim;
     end
  else if ( rc = 1 ) and ( fSRClaim.Logical_Delete_Flag ) then
     begin
     // Mark as re-instated
     ReinstateSRClaim;
     end;
end;

(******************************************************************************)
(*                                                                            *)
(*    Add new shelter rebate claim                                            *)
(*                                                                            *)
(******************************************************************************)
procedure TShelterRebateEditForm.AddNewSRClaim;
var
  newNCClaim: recNCCLAIM;
begin
  ClearNCCLAIM(newNCClaim);
  WagelossMainForm.ShowInfoLine2('');

  try
     SelectClaimForm := TSelectClaimForm.create(application);

     if (SelectClaimForm.showmodal = mrOK) then
        begin
        // Nov 98 - BT - year 2000 windowing fixes
//        if (copy(SelectClaimForm.edClaimNumber.text,1,2) < '92') and
//           (copy(SelectClaimForm.edClaimNumber.text,1,2) > '20') then
//           begin
//           WagelossMainForm.ShowInfoLine2('*Claim number must be 1992 or greater.');
//           abort;
//           end;

        newNCClaim.Claim_No := SelectClaimForm.edClaimNumber.text;
        SelectClaimForm.free;
        //
        // Check if claim already exists
        //
        try
           with dm1 do
              begin
              if query2.Locate('Claim_No', newNCClaim.Claim_No , []) then
                 begin
                 DisplaySRRecord;
                 ResetInfoLine2;
                 messagebeep(0);
                 WagelossMainForm.ShowInfoLine2('*Claim ' + newNCClaim.Claim_No + ' already exists.');
                 abort;
                 end;
              end;
        finally
           ;
        end;

        newNCClaim.Claim_No := newNCClaim.Claim_No;

        clearWLREBDTL( fSRClaim );

        fSRClaim.Claim_No := newNCClaim.Claim_No;
        fSRClaim.Claim_Suffix := newNCClaim.Claim_Suffix;
        fSRClaim.Clmt_Name_Initials := newNCClaim.Clmnts_Surname + ', ' + pdoxtrim(newNCClaim.Clmnts_1st_Name);
        fSRClaim.Tax_Year := newNCClaim.Tax_Year;
        fSRClaim.Marital_Status := newNCClaim.Marital_Status;
        fSRClaim.Spouse_Working := newNCClaim.Spouse_Working;
        fSRClaim.ClaimSpouseForTaxPurposes := newNCClaim.ClaimSpouseForTaxPurposes;
        fSRClaim.Nbr_Of_Dependants := newNCClaim.No_Of_Dependnts;
        fSRClaim.Nbr_Of_Infirm_Deps := newNCClaim.No_Infirm;
        fSRClaim.Uic_Exempt := newNCClaim.EI_Exempt;
        fSRClaim.Wkly_Sal_A := newNCClaim.Wkly_Sal_A;
        fSRClaim.Self_Employed := newNCClaim.Self_Employed;
        fSRClaim.Recurrence := newNCClaim.Recurrence;
        fSRClaim.CPP_Exempt := newNCClaim.CPP_Exempt;
        fSRClaim.Tax_Exempt := newNCClaim.Tax_Exempt;
        fSRClaim.Child_Care_Exp := newNCClaim.Child_Care_Exp;
        fSRClaim.Spousal_Support := newNCClaim.Spousal_Support;
        fSRClaim.Child_Support := newNCClaim.Child_Support;
        fSRClaim.Accident_Date := newNCClaim.Accident_Date;
        fSRClaim.Wkly_Sal := newNCClaim.Wkly_Sal_A;
        fSRClaim.Shelter_Rebate_Year := year( utilmod1.getEmergeBusinessDate() ) - 1;
        fSRClaim.Prime_Firm_No := newNCClaim.Prime_Firm_No;

        RecalcBen;

        WagelossMainForm.ShowInfoLine2('*Add for claim ' + fSRClaim.Claim_No );

        if(MessageDlg('Add this Claim to Shelter Rebate?'+#10#10+
                      fSRClaim.Claim_No + '/' + fSRClaim.Claim_Suffix + '  ' +
                      fSRClaim.Clmt_Name_Initials + #10#10 +
                      'Press [OK] to continue or [Cancel] to cancel.',
                      mtConfirmation,
                      mbOkCancel, 0) ) <> mrOK then
           begin
           abort;
           end;

         if not addNewSRRecord(fSRClaim) then
            begin
            abort;
            end;
         end;
  finally
     //
     // Note: DisplaySRRecord reloads fSRClaim based on current claim for
     //       Query2 -- which will be unchanged if insert fails.
     //
     DisplaySRRecord;
     ResetInfoLine2;
  end;
end;

(******************************************************************************)
(*                                                                            *)
(*    Delete ( logically ) a shelter rebate claim                             *)
(*                                                                            *)
(******************************************************************************)
procedure TShelterRebateEditForm.DeleteSRClaim;
var
  clm:string;
begin
  try
     with dm1 do
        begin
        clm := query2.fieldbyname('Claim_No').asString;
        applog('TShelterRebateEditForm.DeleteSRClaim - Delete SR Claim: ' + clm + '  Action Starting.');
        if query1.active then
           query1.close;

        query1.sql.clear;
        query1.sql.add('update dbo.WLREBDTL' );
        query1.sql.add('  set Logical_Delete_Flag = ''Y''');
        query1.sql.add('  where Claim_No = ''' + clm + '''');
        query1.execSQL;
        applog('TShelterRebateEditForm.DeleteSRClaim - Delete SR Claim: ' + clm + '  Action Complete.');
        end;
  finally
     DisplaySRRecord;
     ResetInfoLine2;
  end;
end;

(******************************************************************************)
(*                                                                            *)
(*     Reinstate or undelete a shelter rebate claim                           *)
(*                                                                            *)
(******************************************************************************)
procedure TShelterRebateEditForm.ReinstateSRClaim;
var
   clm:string;
begin
  try
     with dm1 do
        begin
        clm := query2.fieldbyname('Claim_No').asString;
        applog('TShelterRebateEditForm.ReinstateSRClaim - Reinstate SR Claim: ' + clm + '  Action Starting.');

        if query1.active then
           query1.close;

        query1.sql.clear;
        query1.sql.add('update dbo.WLREBDTL' );
        query1.sql.add('  set Logical_Delete_Flag = ''N''');
        query1.sql.add('  where Claim_No = ''' + clm + '''');
        query1.execSQL;
        applog('TShelterRebateEditForm.ReinstateSRClaim - Reinstate SR Claim: ' + clm + '  Action Complete.');
        end;
  finally
     DisplaySRRecord;
     ResetInfoLine2;
  end;
end;

(******************************************************************************)
(*                                                                            *)
(*     Recalculate Benefit levels                                             *)
(*                                                                            *)
(******************************************************************************)
procedure TShelterRebateEditForm.RecalcBen;
begin
  uGlobal.SetUpAndRecalcBen(fSRClaim, edActual_Shelter_Deduct.enabled, textAsCurrency( edActual_Shelter_Deduct ));
end;

(******************************************************************************)
(*                                                                            *)
(*    Key Press method for Weeks Paid for year                                *)
(*                                                                            *)
(******************************************************************************)
procedure TShelterRebateEditForm.edAccum_Wks_Yr_PdCstKeyPress(Sender: TObject; var Key: Char);
begin
  case Key of
  #0..#31,'0'..'9','.','+':
  else
    Key:=#0;
  end;
end;

(******************************************************************************)
(*                                                                            *)
(*    Key Press method for Weeks paid for year at 90% net                     *)
(*                                                                            *)
(******************************************************************************)
procedure TShelterRebateEditForm.edAccum_Wks_Yr_90NetKeyPress(Sender: TObject; var Key: Char);
begin
  case Key of
  #0..#31,'0'..'9','.','+':
  else
    Key:=#0;
  end;
end;

(******************************************************************************)
(*                                                                            *)
(*     Exit method for weeks paid for year                                    *)
(*                                                                            *)
(******************************************************************************)
procedure TShelterRebateEditForm.edAccum_Wks_Yr_PdCstExit(Sender: TObject);
var
  f:currency;
begin
  if not validateAsCurrency( edAccum_Wks_Yr_PdCst ) then
  begin
    globalEditError := displayError( '*Invalid Accumulated # Weeks on Compensation', edAccum_Wks_Yr_PdCst );
    exit;
  end;

  f := textAsCurrency(edAccum_Wks_Yr_PdCst);
  if (f < 40.0) or (f > 52.0) then
  begin
    globalEditError := displayError( '*Accumulated # Weeks on Compensation must be between 40 and 52', edAccum_Wks_Yr_PdCst );
    exit;
  end;

  if (fSRclaim.Accum_Wks_Yr_PdCst <> textAsCurrency(edAccum_Wks_Yr_PdCst)) then isChanged:=true;
  edAccum_Wks_Yr_PdCst.text:=format('%.2n',[ textAsCurrency(edAccum_Wks_Yr_PdCst) ] );

  if not globalEditError then
      ResetInfoLine2;
end;

(******************************************************************************)
(*                                                                            *)
(*    Exit method for weeks paid for year at 90% net                          *)
(*                                                                            *)
(******************************************************************************)
procedure TShelterRebateEditForm.edAccum_Wks_Yr_90NetExit(Sender: TObject);
var
  f, f2, f3 :currency;
begin
  if not validateAsCurrency( edAccum_Wks_Yr_90Net ) then
  begin
    globalEditError := displayError( '*Invalid Accumulated Weeks 90 Net', edAccum_Wks_Yr_90Net );
    exit;
  end;
  if not validateAsCurrency( edAccum_Wks_Yr_90NetPost ) then
  begin
    globalEditError := displayError( '*Invalid Accumulated Weeks 90 Net Post 104', edAccum_Wks_Yr_90NetPost );
    exit;
  end;

  f:=textAsCurrency(edAccum_Wks_Yr_90Net);
  f2:=textAsCurrency(edAccum_Wks_Yr_PdCst);
  f3:=textAsCurrency(edAccum_Wks_Yr_90NetPost);
  //if ( f + f3 < 0.0 ) or ( f + f3 > f2 ) then
  if ( f + f3 > f2 ) then
  begin
    globalEditError := displayError( '*Accumulated Weeks 90 Net can not be greater than # weeks on Compensation', edAccum_Wks_Yr_90Net );
    exit;
  end;
  //if ( f <= 0.0 ) or ( f > 52.0 ) then
  if ( f <= 0.0 ) AND (year(StrtoDate(edAccident_Date.Caption)) < 2006) then
  begin
    globalEditError := displayError( '*Accumulated Weeks 90 Net must be greater than 0', edAccum_Wks_Yr_90Net );
    exit;
  end;

  if (fSRclaim.Accum_Wks_Yr_90Net <> textAsCurrency(edAccum_Wks_Yr_90Net)) then isChanged:=true;
  if (fSRclaim.Accum_Wks_Yr_90Net_Post <> textAsCurrency(edAccum_Wks_Yr_90NetPost)) then isChanged:=true;
  edAccum_Wks_Yr_90Net.text:=format('%.2n',[ textAsCurrency(edAccum_Wks_Yr_90Net) ] );
  edAccum_Wks_Yr_90NetPost.text:=format('%.2n',[ textAsCurrency(edAccum_Wks_Yr_90NetPost) ] );
  TempNet90 := f;
  TempNet90Post := f3;
  if not globalEditError then
      ResetInfoLine2;
end;

(******************************************************************************)
(*                                                                            *)
(*    Validate data entry fields and recalculate benefit levels               *)
(*                                                                            *)
(******************************************************************************)
function TShelterRebateEditForm.ValidateAndRecalcBen: boolean;
var
  res: boolean;
begin
  result:=false;
  ResetInfoLine2;
  globalEditError:=false;

  { validate all fields }
  res := validateAsInteger( edTax_Year );
  if not res then exit;
  res := validateAsCurrency( edAccum_Wks_Yr_PdCst );
  if not res then exit;
  res := validateAsCurrency( edAccum_Wks_Yr_90Net );
  if not res then exit;
  res := validateAsCurrency( edAccum_Wks_Yr_90NetPost );
  if not res then exit;

  // do exit processing on all fields to enforce exit edits
  if edTax_Year.enabled then edTax_YearExit(edTax_Year);
  if globalEditError then exit;
  if edAccum_Wks_Yr_PdCst.enabled then edAccum_Wks_Yr_PdCstExit(edAccum_Wks_Yr_PdCst);
  if globalEditError then exit;
  if edAccum_Wks_Yr_90Net.enabled then edAccum_Wks_Yr_90NetExit(edAccum_Wks_Yr_90Net);
  if globalEditError then exit;
  if edAccum_Wks_Yr_90NetPost.enabled then edAccum_Wks_Yr_90NetExit(edAccum_Wks_Yr_90NetPost);
  if globalEditError then exit;
  if edActual_Shelter_Deduct.enabled then edActual_Shelter_DeductExit(edActual_Shelter_Deduct);
  if globalEditError then exit;
  if edBypassBatchProcess.enabled then edBypassBatchProcessExit(edBypassBatchProcess);
  if globalEditError then exit;
  // Apply updates from edit fields
  fSRClaim.Accum_Wks_Yr_PdCst:=textAsCurrency( edAccum_Wks_Yr_PdCst );
  fSRClaim.Accum_Wks_Yr_90Net:=textAsCurrency( edAccum_Wks_Yr_90Net );
  fSRClaim.Accum_Wks_Yr_90Net_Post:=textAsCurrency( edAccum_Wks_Yr_90NetPost );
  fSRClaim.Tax_Year:=textAsInteger( edTax_Year );
  fSRClaim.doNotBatchProcessFlag := edBypassBatchProcess.Text;

  RecalcBen;
  fillInForm;
  isChanged:=true;
  ResetInfoLine2;

  result:=true;
end;

(******************************************************************************)
(*                                                                            *)
(*      Add query to insert new shelter rebate claim                          *)
(*                                                                            *)
(******************************************************************************)
function TShelterRebateEditForm.addNewSRRecord( mySRrecord:recWLREBDTL): boolean;
var
  s, stringClaim: string;
begin
  result :=false;
  // load to WLREBDTL record to table
  try
    stringClaim := mySRrecord.Claim_No;
    if not (uGlobal.logActivity(stringClaim, uGlobal.LOG_TYPE_UPDATE, 'ShelterRebate')) then
       begin
       WagelossMainForm.ShowInfoLine2( '*Logging Failed.  Shelter Update Not Allowed!*' );
       exit;
       end;

    with dm1 do
      begin
      if query1.active then
         query1.close;

      query1.sql.clear;
      query1.sql.add('INSERT INTO dbo.WLREBDTL');
      query1.SQL.Add('( ');
      query1.SQL.Add('Claim_No, ');
      query1.SQL.Add('Claim_Suffix,');
      query1.SQL.Add('Clmt_Name_Initials,');
      query1.SQL.Add('Tax_Year,');
      query1.SQL.Add('Marital_Status,');
      query1.SQL.Add('Spouse_Working,');
      query1.SQL.Add('ClaimSpouseForTaxPurposes ');
      query1.SQL.Add('Nbr_Of_Dependants,');
      query1.SQL.Add('Nbr_Of_Infirm_Deps,');
      query1.SQL.Add('Uic_Exempt,');
      query1.SQL.Add('Accum_Wks_Yr_PdCst,');
      query1.SQL.Add('Accum_Wks_Yr_90Net,');
      query1.SQL.Add('Wkly_Sal,');
      query1.SQL.Add('Wkly_Net,');
      query1.SQL.Add('Wkly_90,');
      query1.SQL.Add('Wkly_90_S,');
      query1.SQL.Add('Wkly_80,');
      query1.SQL.Add('Annual_Gross,');
      query1.SQL.Add('Annual_Net,');
      query1.SQL.Add('Annual_90,');
      query1.SQL.Add('Annual_90_S,');
      query1.SQL.Add('Annual_80,');
      query1.SQL.Add('Tax_Exemption,');
      query1.SQL.Add('Inc_Tax_Fed,');
      query1.SQL.Add('Inc_Tax_Prov,');
      query1.SQL.Add('Cpp_Prem,');
      query1.SQL.Add('Cpp2_Prem,');
      query1.SQL.Add('Uic_Prem,');
      query1.SQL.Add('Total_Deds,');
      query1.SQL.Add('Wkly_Sal_A,');
      query1.SQL.Add('Annual_Gross_A,');
      query1.SQL.Add('Annual_Net_A,');
      query1.SQL.Add('Tax_Exemption_A,');
      query1.SQL.Add('Inc_Tax_Fed_A,');
      query1.SQL.Add('Inc_Tax_Prov_A,');
      query1.SQL.Add('Cpp_Prem_A,');
      query1.SQL.Add('Cpp2_Prem_A,');
      query1.SQL.Add('Uic_Prem_A,');
      query1.SQL.Add('Tax_Shelter_Bnft,');
      query1.SQL.Add('Tax_Shelter_Deduct,');
      query1.SQL.Add('Rebate_Amount,');
      query1.SQL.Add('Weeks_Worked,');
      query1.SQL.Add('Wkly_Tax_S,');
      query1.SQL.Add('Total_Deds_A,');
      query1.SQL.Add('Total_Tax_S,');
      query1.SQL.Add('Total_Deds_P_A,');
      query1.SQL.Add('Shelter_Rebate_Year,');
      query1.SQL.Add('Prime_Firm_No,');
      query1.SQL.Add('Payment_Issued_Flag,');
      query1.SQL.Add('Logical_Delete_Flag,');
      query1.SQL.Add('accident_date,');
      query1.SQL.Add('self_employed,');
      query1.SQL.Add('recurrence,');
      query1.SQL.Add('child_care_expense,');
      query1.SQL.Add('spousal_support,');
      query1.SQL.Add('child_support,');
      query1.SQL.Add('cpp_exempt,');
      query1.SQL.Add('income_tax_exempt,');
      query1.SQL.Add('maximumAdjustmentAmt,');
      query1.SQL.Add('no_of_actual_shelter_deduc,');
      query1.SQL.Add('Recurrence_Date,');
      query1.SQL.Add('Youthful_Worker,');
      query1.SQL.Add('Accum_Wks_Yr_90Net_Post,');
      query1.SQL.Add('workerAnnuityContributionPcnt,');
      query1.SQL.Add('wcbAnnuityContributionPercent,');
      query1.SQL.Add('workerShetlerAnnuityContribAmt,');
      query1.SQL.Add('wcbShelterAnnuityContribAmt,');
      query1.SQL.Add('paidFromDate,');
      query1.SQL.Add('paidToDate,');
      query1.SQL.Add('employerPaidFlag,');
      query1.SQL.Add('processDateTime');
      query1.SQL.Add(' ) ');

      query1.sql.add('VALUES(');

      with mySRrecord do
         begin
     	   query1.sql.add( SQLstring( Claim_No ) );
         query1.sql.add( SQLstring( Claim_Suffix ) );
         query1.sql.add( SQLstring( Clmt_Name_Initials ) );
      	 query1.sql.add( SQLinteger( Tax_Year ) );
      	 query1.sql.add( SQLstring( Marital_Status ) );
      	 query1.sql.add( SQLstring( Spouse_Working ) );
         query1.SQL.Add(SQLString(ClaimSpouseForTaxPurposes));
      	 query1.sql.add( SQLinteger( Nbr_Of_Dependants ) );
      	 query1.sql.add( SQLinteger( Nbr_Of_Infirm_Deps) );
      	 query1.sql.add( SQLstring( Uic_Exempt ) );
      	 query1.sql.add( SQLcurrency( Accum_Wks_Yr_PdCst ) );
      	 query1.sql.add( SQLcurrency( Accum_Wks_Yr_90Net ) );
      	 query1.sql.add( SQLcurrency( Wkly_Sal ) );
      	 query1.sql.add( SQLcurrency( Wkly_Net ) );
	       query1.sql.add( SQLcurrency( Wkly_90 ) );
      	 query1.sql.add( SQLcurrency( Wkly_90_S ) );
      	 query1.sql.add( SQLcurrency( Wkly_80 ) );
      	 query1.sql.add( SQLcurrency( Annual_Gross ) );
      	 query1.sql.add( SQLcurrency( Annual_Net ) );
      	 query1.sql.add( SQLcurrency( Annual_90 ) );
      	 query1.sql.add( SQLcurrency( Annual_90_S ) );
      	 query1.sql.add( SQLcurrency( Annual_80 ) );
      	 query1.sql.add( SQLcurrency( Tax_Exemption ) );
      	 query1.sql.add( SQLcurrency( Inc_Tax_Fed ) );
      	 query1.sql.add( SQLcurrency( Inc_Tax_Prov ) );
      	 query1.sql.add( SQLcurrency( Cpp_Prem ) );
         query1.sql.add( SQLcurrency( Cpp2_Prem ) );
      	 query1.sql.add( SQLcurrency( Uic_Prem ) );
      	 query1.sql.add( SQLcurrency( Total_Deds ) );
      	 query1.sql.add( SQLcurrency( Wkly_Sal_A ) );
      	 query1.sql.add( SQLcurrency( Annual_Gross_A ) );
      	 query1.sql.add( SQLcurrency( Annual_Net_A ) );
      	 query1.sql.add( SQLcurrency( Tax_Exemption_A ) );
      	 query1.sql.add( SQLcurrency( Inc_Tax_Fed_A ) );
      	 query1.sql.add( SQLcurrency( Inc_Tax_Prov_A ) );
      	 query1.sql.add( SQLcurrency( Cpp_Prem_A ) );
         query1.sql.add( SQLcurrency( Cpp2_Prem_A ) );
      	 query1.sql.add( SQLcurrency( Uic_Prem_A ) );
      	 query1.sql.add( SQLcurrency( Tax_Shelter_Bnft ) );
      	 query1.sql.add( SQLcurrency( Tax_Shelter_Deduct ) );
      	 query1.sql.add( SQLcurrency( Rebate_Amount ) );
      	 query1.sql.add( SQLcurrency( Weeks_Worked ) );
      	 query1.sql.add( SQLcurrency( Wkly_Tax_S ) );
      	 query1.sql.add( SQLcurrency( Total_Deds_A ) );
      	 query1.sql.add( SQLcurrency( Total_Tax_S ) );
      	 query1.sql.add( SQLcurrency( Total_Deds_P_A ) );
      	 query1.sql.add( SQLinteger( Shelter_Rebate_Year ) );
      	 query1.sql.add( SQLstring( Prime_Firm_No ) );
         query1.sql.add( SQLboolean( Payment_Issued_Flag ) );
         query1.sql.add( SQLboolean( Logical_Delete_Flag ) );
         query1.SQL.add( SQLDateTime( Accident_Date ) );
         query1.sql.add( SQLstring( Self_Employed ) );
         query1.sql.add( SQLstring( Recurrence ) );
         query1.sql.add( SQLcurrency( Child_Care_Exp ) );
         query1.sql.add( SQLcurrency( Spousal_Support ) );
         query1.sql.add( SQLcurrency( Child_Support ) );
         query1.sql.add( SQLstring( CPP_Exempt ) );
         query1.sql.add( SQLstring( Tax_Exempt ) );
         query1.sql.add( SQLcurrency( Max_Adjustment ) );
         query1.sql.add( SQLcurrency( Nbr_Act_Shelter_Deduct ) );
         query1.sql.add( SQLDateTime( Recurrence_Date ) );
         query1.sql.add( SQLstring( Youthful_Worker ) );
         query1.sql.add( SQLcurrency( Accum_Wks_Yr_90Net_Post ) );
         query1.sql.add( SQLcurrency( workerAnnuityContributionPercent ) );
         query1.sql.add( SQLcurrency( wcbAnnuityContributionPercent ) );
         query1.sql.add( SQLcurrency( workerShetlerAnnuityContribAmt ) );
         query1.sql.add( SQLcurrency( wcbShelterAnnuityContribAmt ) );
         query1.sql.add( SQLDateTime( paidFromDate ) );
         query1.sql.add( SQLDateTime( paidToDate ) );
         query1.sql.add( SQLstring( employerPaidFlag ) );
         // drop comma on last field...
         s := SQLDateTime( processDateTime );
         s := copy(s,1,length(s)-1);
         query1.sql.add(s);
         end; // with r do

      query1.sql.add(')');
      query1.execSQL;
      // Redo query2 select
      if ( fSRCurrentSortOrder = byClaim ) then
        SelectClaimsByClaim(true)
      else
        SelectClaimsBySuffixClaim(true);
      // Position to new claim record
      with dm1 do
         begin
         if not query2.Locate('Claim_No', mySRrecord.Claim_No , []) then
            begin
            messagebeep(0);
            end;
         end;
      end;
    result := true;
  except
    on e:exception do
       begin
       MessageDlg('Error adding into Shelter Rebate table for Wageloss System' + #10#10 + E.message,
                  mtError,[mbOk], 0);
       end;
  end;
end;

(******************************************************************************)
(*                                                                            *)
(*    Update query to modify shelter rebate claim                             *)
(*                                                                            *)
(******************************************************************************)
procedure TShelterRebateEditForm.updateSRRecord( mySRrecord:recWLREBDTL);
var
  s, stringClaim: string;
begin
  // load to WLREBDTL record to table
  try
    with dm1 do
      begin
      stringClaim := mySRrecord.Claim_No;
      if not (uGlobal.logActivity(stringClaim, uGlobal.LOG_TYPE_UPDATE, 'ShelterRebate')) then
      begin
        WagelossMainForm.ShowInfoLine2( '*Logging Failed.  Shelter Update Not Allowed!*' );
        exit;
      end;
      if query1.active then query1.close;
      query1.sql.clear;
      query1.sql.add('UPDATE dbo.WLREBDTL');
      query1.sql.add('SET ');
      with mySRrecord do
      begin
        query1.sql.add( 'Tax_Year = ' + SQLinteger( Tax_Year ) );
	      query1.sql.add( 'Accum_Wks_Yr_PdCst =' + SQLcurrency( Accum_Wks_Yr_PdCst ) );
	      query1.sql.add( 'Accum_Wks_Yr_90Net =' + SQLcurrency( Accum_Wks_Yr_90Net ) );
        query1.sql.add( 'Accum_Wks_Yr_90Net_Post =' + SQLcurrency( Accum_Wks_Yr_90Net_Post ) );
      	query1.sql.add( 'Wkly_Sal =' + SQLcurrency( Wkly_Sal ) );
      	query1.sql.add( 'Wkly_Net =' + SQLcurrency( Wkly_Net ) );
      	query1.sql.add( 'Wkly_90 =' + SQLcurrency( Wkly_90 ) );
      	query1.sql.add( 'Wkly_90_S =' + SQLcurrency( Wkly_90_S ) );
      	query1.sql.add( 'Wkly_80 =' + SQLcurrency( Wkly_80 ) );
      	query1.sql.add( 'Annual_Gross =' + SQLcurrency( Annual_Gross ) );
      	query1.sql.add( 'Annual_Net =' + SQLcurrency( Annual_Net ) );
      	query1.sql.add( 'Annual_90 =' + SQLcurrency( Annual_90 ) );
      	query1.sql.add( 'Annual_90_S =' + SQLcurrency( Annual_90_S ) );
      	query1.sql.add( 'Annual_80 =' + SQLcurrency( Annual_80 ) );
      	query1.sql.add( 'Tax_Exemption =' + SQLcurrency( Tax_Exemption ) );
      	query1.sql.add( 'Inc_Tax_Fed =' + SQLcurrency( Inc_Tax_Fed ) );
      	query1.sql.add( 'Inc_Tax_Prov =' + SQLcurrency( Inc_Tax_Prov ) );
      	query1.sql.add( 'Cpp_Prem =' + SQLcurrency( Cpp_Prem ) );
        query1.sql.add( 'Cpp2_Prem =' + SQLcurrency( Cpp2_Prem ) );
      	query1.sql.add( 'Uic_Prem =' + SQLcurrency( Uic_Prem ) );
      	query1.sql.add( 'Total_Deds =' + SQLcurrency( Total_Deds ) );
      	query1.sql.add( 'Wkly_Sal_A =' + SQLcurrency( Wkly_Sal_A ) );
      	query1.sql.add( 'Annual_Gross_A =' + SQLcurrency( Annual_Gross_A ) );
      	query1.sql.add( 'Annual_Net_A =' + SQLcurrency( Annual_Net_A ) );
      	query1.sql.add( 'Tax_Exemption_A =' + SQLcurrency( Tax_Exemption_A ) );
      	query1.sql.add( 'Inc_Tax_Fed_A =' + SQLcurrency( Inc_Tax_Fed_A ) );
      	query1.sql.add( 'Inc_Tax_Prov_A =' + SQLcurrency( Inc_Tax_Prov_A ) );
      	query1.sql.add( 'Cpp_Prem_A =' + SQLcurrency( Cpp_Prem_A ) );
        query1.sql.add( 'Cpp2_Prem_A =' + SQLcurrency( Cpp2_Prem_A ) );
      	query1.sql.add( 'Uic_Prem_A =' + SQLcurrency( Uic_Prem_A ) );
      	query1.sql.add( 'Tax_Shelter_Bnft =' + SQLcurrency( Tax_Shelter_Bnft ) );
      	query1.sql.add( 'Tax_Shelter_Deduct =' + SQLcurrency( Tax_Shelter_Deduct ) );
      	query1.sql.add( 'Rebate_Amount =' + SQLcurrency( Rebate_Amount ) );
      	query1.sql.add( 'Weeks_Worked =' + SQLcurrency( Weeks_Worked ) );
      	query1.sql.add( 'Wkly_Tax_S =' + SQLcurrency( Wkly_Tax_S ) );
      	query1.sql.add( 'Total_Deds_A =' + SQLcurrency( Total_Deds_A ) );
      	query1.sql.add( 'Total_Tax_S =' + SQLcurrency( Total_Tax_S ) );
      	query1.sql.add( 'Total_Deds_P_A =' + SQLcurrency( Total_Deds_P_A ) );
        query1.sql.add( 'Shelter_Rebate_Year =' + SQLinteger( Shelter_Rebate_Year ) );
        query1.SQL.add( 'accident_date =' + SQLDateTime( Accident_Date ) );
        query1.sql.add( 'self_employed =' + SQLstring( Self_Employed ) );
        query1.sql.add( 'recurrence =' + SQLstring( Recurrence ) );
        query1.sql.add( 'child_care_expense =' + SQLcurrency( Child_Care_Exp ) );
        query1.sql.add( 'spousal_support =' + SQLcurrency( Spousal_Support ) );
        query1.sql.add( 'child_support =' + SQLcurrency( Child_Support ) );
        query1.sql.add( 'cpp_exempt =' + SQLstring( CPP_Exempt ) );
        query1.sql.add( 'income_tax_exempt =' + SQLstring( Tax_Exempt ) );
        query1.sql.add( 'post_injury_earnings =' + SQLcurrency( PostInjuryEarnings ) );
        query1.sql.add( 'Recurrence_Date =' + SQLDateTime( Recurrence_Date ) );
        query1.sql.add( 'Youthful_Worker =' + SQLstring( Youthful_Worker ) );
        query1.sql.add( 'doNotBatchProcessFlag =' + SQLstring( doNotBatchProcessFlag ) );
        query1.sql.add( 'workerShetlerAnnuityContribAmt =' + SQLcurrency( workerShetlerAnnuityContribAmt ) );
        query1.sql.add( 'wcbShelterAnnuityContribAmt =' + SQLcurrency( wcbShelterAnnuityContribAmt ) );
        s:=SQLcurrency( Nbr_Act_Shelter_Deduct );
        s:=copy(s,1,length(s)-1);
        query1.sql.add('no_of_actual_shelter_deduc =' + s);
        query1.sql.add( 'WHERE Claim_No = ''' + Claim_No + '''' );
      end; // with mySRrecord do

      query1.execSQL;

    end;

    DisplaySRRecord;
    ResetInfoLine2;
  except
    On e:exception do
    begin
      MessageDlg('Error updating Shelter Rebate table for Wageloss System' + #10#10 + E.message,
        mtError,[mbOk], 0);
    end;
  end;
end;

(******************************************************************************)
(*                                                                            *)
(*    Form Close Query method                                                 *)
(*                                                                            *)
(******************************************************************************)
procedure TShelterRebateEditForm.FormCloseQuery(Sender: TObject; var CanClose: Boolean);
begin
  CanClose:=true;
  if isChanged then
  begin
    WagelossMainForm.ShowInfoLine2('*Update Shelter Rebate Claim is pending.');
    messagebeep(0);
    if( MessageDlg('Update Shelter Rebate Claim is pending.'+#10#10+
      'Are you sure you want to close the'+#10+
      'Shelter Rebate Edit Screen?', mtConfirmation,
      mbOkCancel, 0) ) <> mrOK then CanClose:=false;
  end;
end;

(******************************************************************************)
(*                                                                            *)
(*    Prompt for update pending                                               *)
(*                                                                            *)
(******************************************************************************)
function TShelterRebateEditForm.isUpdatePending:boolean;
begin
  if isChanged then
  begin
    WagelossMainForm.ShowInfoLine2('*Update Shelter Rebate Claim is pending.');
    messagebeep(0);
    if( MessageDlg('Update Shelter Rebate Claim is pending.'+#10#10+
      'Are you sure you want to discard these changes?'+#10#10+
      'To continue working on this claim, select [Cancel]'
      , mtConfirmation,
      mbOkCancel, 0) ) = mrOK then isChanged:=false;
  end;
  result:=isChanged;
end;

(******************************************************************************)
(*                                                                            *)
(*   Prompt for update pending before reporting                               *)
(*                                                                            *)
(******************************************************************************)
function TShelterRebateEditForm.isUpdatePendingForReporting:boolean;
begin
  result:=isChanged;
  if isChanged then
  begin
    WagelossMainForm.ShowInfoLine2('*Update Shelter Rebate Claim is pending.');
    messagebeep(0);
    if( MessageDlg('Update Shelter Rebate Claim is pending.'+#10#10+
      'Note: Your report or letter will show previous claim values unless' +#10+
      'you update the claim first.'
      +#10#10+
      'Press [OK] to continue or [Cancel] to return to editing.'
      , mtConfirmation,
      mbOkCancel, 0) ) = mrOK then result:=false;
  end;
end;

(******************************************************************************)
(*                                                                            *)
(*    Key press method for Tax Year                                           *)
(*                                                                            *)
(******************************************************************************)
procedure TShelterRebateEditForm.edTax_YearKeyPress(Sender: TObject; var Key: Char);
begin
  case Key of
  #0..#31,'0'..'9':
  else
    Key:=#0;
  end;
end;

(******************************************************************************)
(*                                                                            *)
(*    Exit method for Tax Year                                                *)
(*                                                                            *)
(******************************************************************************)
procedure TShelterRebateEditForm.edTax_YearExit(Sender: TObject);
var
  isFound: boolean;
  iii, testTax_Year, testClaimYear: Integer;
  Work_Date:TDateTime;
  Work_Year, Work_Month, Work_Day:Word;
begin
  isFound := False;
  
  // Get values from TAX CODE TABLE

  testTax_Year:= textAsInteger(edTax_Year);
  SetTaxYear(fSRClaim.Accident_date, 0, testTax_Year);

  for iii := low(arrayNCTAXRAT) to high(arrayNCTAXRAT) do
     begin
     if (arrayNCTAXRAT[iii].Tax_Year = GetTaxYear) and
        (arrayNCTAXRAT[iii].Tax_Year > 1991)       then
        begin
        isFound := True;
        Break;
        end;
     end;

  if not isFound then
     begin
     globalEditError := displayError( '*Please enter a valid Tax year', edTax_Year );
     exit;
     end;

  //
  // Test the on screen tax year contained in the TestTax_Year variable
  //
  // First check to see if we have a future date
  //

  Work_Date := 0;

  if Length(edRecurrence.Caption) > 0 Then
     begin
     if UpperCase(edRecurrence.Caption) = 'Y' then
        begin
        if Length(edRecurrenceDate.Caption) > 0 then
           begin
           Work_Date := StrtoDate(edRecurrenceDate.Caption);
           end;
        end;
     end;

  if Not (Work_Date > 0) Then
     begin
     Work_Date := StrtoDate(edAccident_Date.Caption);
     end;

  DecodeDate(Work_Date, Work_Year, Work_Month, Work_Day);

  if ((testTax_Year = NCMain.cnst_Max_Tax_Year) And (Work_Month > NCMain.cnst_Max_Tax_Month)) OR
      (testTax_Year > NCMain.cnst_Max_Tax_Year)                                   Then
     begin
     globalEditError := displayError( '*Please enter a valid tax year', edTax_Year );
     exit;
     end;

  //
  // for claims side only - cross check Tax Year against Accident Year
  // Tax year must be greater than or equal to the year
  // of the accident
  //
  if  ((UpperCase(edRecurrence.Caption) <> 'Y') or (Length(edRecurrenceDate.Caption) = 0)) then
     iii := testTax_Year - year(StrtoDate(edAccident_Date.Caption))
  else
     iii := testTax_Year - year(StrtoDate(edRecurrenceDate.Caption));

  if ( iii  < 0) then
     begin
     //messagebeep(0);
     if  ((UpperCase(edRecurrence.Caption) <> 'Y') or (Length(edRecurrenceDate.Caption) = 0)) then
        globalEditError := displayError( '*Tax year must be on or after the incident year', edTax_Year )
     else
        globalEditError := displayError( '*Tax year must be on or after year of the recurrence', edTax_Year );
     exit;
     end;

  try
//     if (copy( fSRClaim.Claim_No,1,2) > '20') then
//        testClaimYear :=  1900 + strToInt(copy(fSRClaim.Claim_No,1,2))
//     else
//        testClaimYear :=  2000 + strToInt(copy(fSRClaim.Claim_No,1,2));

     testClaimYear := year(fSRClaim.Accident_Date);
     if (testTax_Year < testClaimYear) then
        begin
        globalEditError := displayError( '*Tax year can not be prior to Incident year', edTax_Year );
        exit;
        end;
  except
     ;
  end;

  if (fSRClaim.Tax_Year <> textAsInteger(edTax_Year)) then
     isChanged := True;

  if not globalEditError then
     ResetInfoLine2;
end;

procedure TShelterRebateEditForm.edActual_Shelter_DeductExit(Sender: TObject);
begin
  if edPost_Injury_Earn.caption = '0.00' then
     exit;

  if edActual_Shelter_Deduct.text='' then
     edActual_Shelter_Deduct.text:='0';

  if not validateAsCurrency(edActual_Shelter_Deduct) then
  begin
    globalEditError := displayError( '*Invalid No. Of Shelter Deductions', edActual_Shelter_Deduct );
    exit;
  end;

  TempNoShelter:=textAsCurrency(edActual_Shelter_Deduct);
  if ( (TempNoShelter <= 0) OR (TempNoShelter > 52)) then
  begin
    globalEditError := displayError( '*No Of Shelter Deductions Must Be Greater Than 0.00 And Not Greater Than 52.00', edActual_Shelter_Deduct );
    exit;
  end;

  edActual_Shelter_Deduct.text:=format('%.2n',[ textAsCurrency(edActual_Shelter_Deduct) ] );
  ResetInfoLine2;
end;

procedure TShelterRebateEditForm.edActual_Shelter_DeductKeyPress(Sender: TObject; var Key: Char);
begin
  case Key of
  #0..#31,'0'..'9','.','+':
  else
    Key:=#0;
  end;
end;

procedure TShelterRebateEditForm.SetMenu(CycleType: iCycleType);
begin
  // store cycle type
  fcycleType := cycleType;
  // make additional changes
    case fcycleType of
    cycle1:
      begin
          caption := 'Shelter Rebate Cycle 1 - Edit Claims';
      end;
    cycle2:
      begin
          caption := 'Shelter Rebate Cycle 2 - Generate Letters';
      end;
    cycle3:
      begin
          caption := 'Shelter Rebate Cycle 3 - Pay Claims';
      end;
    end;

    ResetInfoLine2;
    SelectClaimsByClaim(true);
    SetMenuChoices;
end;

procedure TShelterRebateEditForm.ScrollBox1MouseWheelDown(Sender: TObject; Shift: TShiftState; MousePos: TPoint; var Handled: Boolean);
Const
   iScroll_Increment = 15;
var
   iScroll:Integer;
begin
if scrollbox1.VertScrollBar.position < scrollbox1.VertScrollBar.range Then
   Begin
   if  scrollbox1.VertScrollBar.position <  (scrollbox1.VertScrollBar.range - iScroll_Increment) Then
       iScroll := scrollbox1.VertScrollBar.position + 15
   else
       iScroll := scrollbox1.VertScrollBar.range;
   scrollbox1.VertScrollBar.position := iScroll;
   End;
Handled := True;
end;

procedure TShelterRebateEditForm.ScrollBox1MouseWheelUp(Sender: TObject; Shift: TShiftState; MousePos: TPoint; var Handled: Boolean);
Const
   iScroll_Increment = 15;
var
   iScroll:Integer;
begin
If scrollbox1.VertScrollBar.position > 0 Then
   Begin
   if  scrollbox1.VertScrollBar.position >  iScroll_Increment Then
       iScroll := scrollbox1.VertScrollBar.position - 15
   else
       iScroll := 0;
   scrollbox1.VertScrollBar.position := iScroll;
   End;
   Handled := True;
end;

procedure TShelterRebateEditForm.edBypassBatchProcessExit(Sender: TObject);
begin
    if (edBypassBatchProcess.Text <> 'N') AND (edBypassBatchProcess.Text <> 'Y') then
    begin
      globalEditError := displayError( '*Bypass Batch Process must be Y or N', edBypassBatchProcess );
      exit;
    end;
end;

procedure TShelterRebateEditForm.FormResize(Sender: TObject);
begin
{
  ScrollBox1.Height := (Self.height - 110);
  Application.ProcessMessages;
  ScrollBox1.left := (Self.width div 2) - ScrollBox1.width div 2;
  if Self.Height > ScrollBox1.Height then
     ScrollBox1.top := (Self.height div 2) - ScrollBox1.height div 2
  else
     ScrollBox1.top := (ScrollBox1.height div 2) - (Self.height div 2);
}
end;

end.

