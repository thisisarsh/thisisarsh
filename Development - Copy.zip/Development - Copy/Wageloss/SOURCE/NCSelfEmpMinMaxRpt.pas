unit NCSelfEmpMinMaxRpt;

interface

uses
  Windows, Messages, SysUtils, Classes, Graphics, Controls, Forms, Dialogs,
  ExtCtrls, quickrpt, Qrctrls, DB;

type
  TSelfEmpMinMaxForm = class(TForm)
    QRBand1: TQRBand;
    QRSysData2: TQRSysData;
    QRSysData1: TQRSysData;
    QRSysData3: TQRSysData;
    QRUserID: TQRLabel;
    QRLabel1: TQRLabel;
    QRLabel2: TQRLabel;
    QRSysData4: TQRSysData;
    QRBand2: TQRBand;
    QRLabel6: TQRLabel;
    QRLabel7: TQRLabel;
    QRBand3: TQRBand;
    QRLabel10: TQRLabel;
    QRSelfEmpMinMaxRpt: TQuickRep;
    QRTaxYear: TQRLabel;
    QRAnnualMax: TQRLabel;
    QRAnnualMin: TQRLabel;
    QRLabel3: TQRLabel;
    QRLabel4: TQRLabel;
    QRLabel5: TQRLabel;
    procedure QRSelfEmpMinMaxRptBeforePrint(Sender: TCustomQuickRep;
      var PrintReport: Boolean);
//    procedure QRSelfEmpMinMaxRptNeedData(Sender: TObject;
//      var MoreData: Boolean);
    procedure QRBand3BeforePrint(Sender: TQRCustomBand;
      var PrintBand: Boolean);
  private
    { Private declarations }
     jjj: integer;
     globalEditError:boolean;
  public
    { Public declarations }
  end;

var
  SelfEmpMinMaxForm: TSelfEmpMinMaxForm;


implementation

{$R *.DFM}

uses
  NCIniMod, NCMain, utilmod1, uADOSecurity, NCDatMod;

procedure TSelfEmpMinMaxForm.QRSelfEmpMinMaxRptBeforePrint(
  Sender: TCustomQuickRep; var PrintReport: Boolean);
begin
  {Set starting point for annual maximum array.}
  //*** jjj := low(arrayNCANNMAX);
  //*** QRUserID.caption := UserProfile.givenName + ' ' + userProfile.familyName;

  dm1.qrySelfEmployedMax.Open;
  QRLabel6.Caption := 'Voluntary Coverage Effective Date';

end;



(*//***
procedure TSelfEmpMinMaxForm.QRSelfEmpMinMaxRptNeedData(Sender: TObject; var MoreData: Boolean);
var
  minSelfEmployed : double;
begin
  If (jjj > high(arrayNCANNMAX))then
     MoreData := False {the end of the array has been reached}
  Else
  If (length(IntToStr(arrayNCANNMAX[jjj].Accident_Year)) <= 1) then
     MoreData := False {lengths of 1 indicate blank array values}
  Else
  begin
    if ( arrayNCANNMAX[jjj].Accident_Year = arrayNCANNMAX[jjj].Tax_Year )then
	  begin
      // Print values from Annual Maximums Array
      If ( length(IntToStr(arrayNCANNMAX[jjj].Accident_Year)) > 1 ) then
      Begin

	      QRTaxYear.caption  := IntToStr(arrayNCANNMAX[jjj].Tax_Year);

	      //leg. review changes
	      if (arrayNCANNMAX[jjj].Accident_Year >= 2006) then
	        QRAnnualMax.caption := 'No Max.'
	      else
	        QRAnnualMax.caption := Format('%.2n', [arrayNCANNMAX[jjj].Annual_Maximum]);

	      try
	        with dm1.Query1 do
	        begin
	          if Active then
	            Close;
	          SQL.Clear;

	          SQL.Add( 'SELECT maxSelfEmployed AS ''minSelfEmployed'' ' );
	          SQL.Add( 'FROM wageloss_db..selfEmployedMax ' );
	          SQL.Add( 'WHERE ' );
	          SQL.Add( '  effectiveDate BETWEEN ''01-01-' + IntToStr( arrayNCANNMAX[jjj].Accident_Year ) +
	                                 ''' AND ''12-31-' + IntToStr( arrayNCANNMAX[jjj].Accident_Year ) + '''');
	          Open;
	        end;

	        dm1.Query1.First;
	        while not dm1.Query1.Eof do
	        begin
	          try
	            minSelfEmployed := dm1.Query1.FieldByName( 'minSelfEmployed').AsCurrency;
	            QRAnnualMin.Caption := Format( '%.2n', [minSelfEmployed] );
	          finally
	            dm1.Query1.Next;
	          end;
	        end;
	        except
	        on E:Exception do
	        begin
	          messagebeep(0);
	          MessageDlg( 'Self Employed Min./Max Report Failed.  Please contact help desk at 4573.' + chr(10) + chr(13) + E.Message, mtError, [mbOK], 0 );
	          globalEditError := true;
	          exit;
	        end;
	      end;
	    end;

      Inc(jjj);
    End
    Else
    Begin
      Inc(jjj);
      QRTaxYear.Caption  := '';
      QRAnnualMax.Caption := '';
      QRAnnualMin.Caption := '';
    End;

    MoreData := True;
  end;
end;
*** *)


procedure TSelfEmpMinMaxForm.QRBand3BeforePrint(Sender: TQRCustomBand;
  var PrintBand: Boolean);
var
  minSelfEmployed, maxSelfEmployed : double;
  i : Integer;
begin

  {//***
  if QRTaxYear.Caption = '' then
  begin
    QRBand3.Height := 0;
  end
  else
  begin
    QRBand3.Height := 16;
  end;
  *** }

  QRTaxYear.Caption := FormatDateTime('mmm d, yyyy',dm1.qrySelfEmployedMax.FieldByName('effectiveDate').AsDateTime);
  minSelfEmployed   := dm1.qrySelfEmployedMax.FieldByName('minSelfEmployed').AsCurrency;
  QRAnnualMin.caption := Format('%.2n', [minSelfEmployed]);
  maxSelfEmployed   := dm1.qrySelfEmployedMax.FieldByName('maxSelfEmployed').AsCurrency;

  if maxSelfEmployed <= 0 then
    QRAnnualMax.caption := 'No Max.'
  else
    QRAnnualMax.caption := Format('%.2n', [maxSelfEmployed]);

  QRBand3.Height := 22;

  if QRTaxYear.Caption = 'Jan 1, 2009' then
  begin
    QRBand3.Height := 105;
    QRLabel3.Caption := 'Optional/Personal Coverage Effective Date';
    QRLabel4.Caption := 'Minimum';
    QRLabel5.Caption := 'Maximum';
    QRLabel6.Caption := 'Optional/Personal Coverage Effective Date';
  end
  else
  begin
    QRLabel3.Caption := '';
    QRLabel4.Caption := '';
    QRLabel5.Caption := '';
  end;

  with QRBand3 do
  begin
    for i := 0 to ControlCount-1 do
    begin
      if TQRLabel(Controls[i]).Color = $00F0F0F0 then
         TQRLabel(Controls[i]).Color := $00E0E0E0
      else
        TQRLabel(Controls[i]).Color := $00F0F0F0;
    end;
  end;

  QRLabel3.Color := clWhite;
  QRLabel4.Color := clWhite;
  QRLabel5.Color := clWhite;
end;

end.
