unit NCWrkRptJul24;

interface

uses
  Winapi.Windows, Winapi.Messages, System.SysUtils, System.Variants, System.Classes, Vcl.Graphics,
  Vcl.Controls, Vcl.Forms, Vcl.Dialogs, NCWrkRptJan24;

type
  TWrkRptJul24 = class(TWrkRptJan24)
     function getDateHeading():String; Override;
     function  Set_nc_bc_cpp2(sIncType: shortString): currency;
     procedure TaxCalculationBand1P2(const income: currency;
                                     Nc_Bc_Ann_Sal_Net: currency;
                                     Nc_Bc_Uic: currency;
                                     Nc_Bc_Cpp: currency;
                                     Nc_Bc_Cpp2: Currency;
                                     Nc_Bc_Nrtc: currency;
                                     Nc_Bc_Mb_Nrtc: currency;
                                     nc_mbFamilyTaxBenefitAmt: currency);Overload;
     function TaxCalculationBand1P3(Nc_Bc_Ann_Sal_Net: currency;
                                    Nc_Bc_Nrtc: currency): currency;Override;
     procedure TaxCalculationBand1(const income: currency;
		    													 sIncomeType: shortstring );Override;
     procedure TaxCalculationBand1P8(Nc_Bc_Cpp: currency;
                                     Nc_Bc_Cpp2: currency;
                                     Nc_Bc_Uic: currency;
                                     Fed_Tax: currency);Overload;
     procedure TaxCalculationBand1P10(const income: currency;
                                      sIncType: shortString;
																			Nc_Bc_Mb_Tax: currency;
                                      Nc_Bc_Td: currency;
                                      Nc_Bc_Cpp: currency;
                                      Nc_Bc_Cpp2: currency;
																			Nc_Bc_Uic: currency;
                                      Nc_Bc_Bft: Currency;
                                      Nc_Bc_Fst: Currency;
                                      Nc_Bc_Netinc: currency;
                                      Nc_Bc_Mbt: currency);Overload;
  private
    { Private declarations }
  public
    { Public declarations }
  end;

var
  WrkRptJul24: TWrkRptJul24;

implementation

uses NCIniMod;

{$R *.dfm}

(******************************************************************************)
(*                                                                            *)
(*  override this function for each class to avoid having to bring in all of  *)
(*    the methods that contain the date in the heading.                       *)
(*   IE:  the jan 09 class should return  2008/2009                           *)
(*        the july 09 class should return 2009                                *)
(*                                                                            *)
(******************************************************************************)

function TWrkRptJul24.getDateHeading: String;
begin
  Result:='2024';
end;

function TWrkRptJul24.Set_nc_bc_cpp2(sIncType: shortString): currency;
begin
	if sIncType = 'Actual' then
	   begin
 		 result := fWorking.Work_nc_bc_cpp2_a;
 	   end
 	else if sIncType = 'Maximum' then
 	   begin
   	 result := fWorking.Work_nc_bc_cpp2_b;
 	   end
 	else if sIncType = 'Sheltered' then
 	   begin
   	 result := fWorking.Work_nc_bc_cpp2_c;
 	   end
  else if sIncType = 'Minimum Annual Earnings (AA)' then
     begin
     result := fWorking.Work_nc_bc_cpp2_m;
     end
  else if sIncType = 'Collateral Benefits - Only' then
     begin
     result := fWorking.Work_nc_bc_cpp2_d;
     end
  else if sIncType = 'Sheltered (CC)' then
     begin
     result := fWorking.Work_nc_bc_cpp2_s;
     end
  else
 	   begin
  	 result:=fWorking.Work_nc_bc_cpp2_e;
 	   end;
end;

Procedure TWrkRptJul24.TaxCalculationBand1P8(Nc_Bc_Cpp: currency;
                                             Nc_Bc_Cpp2: currency;
                                             Nc_Bc_Uic: currency;
                                             Fed_Tax: currency);
begin
  sRpt.add('Total Deductions ');
  sRpt.add(' ');
  sRpt.add(format('%-56s %-14s %-14s', [
           '    CPP: amount (J) above',
           formatF( Nc_Bc_Cpp, 12, 2 ),
           ' '
           ] ));
  sRpt.add(' ');
  sRpt.add(format('%-56s %-14s %-14s', [
           '    CPP2: amount (J2) above',
           formatF( Nc_Bc_Cpp2, 12, 2 ),
           ' '
           ] ));
  sRpt.add(' ');
  sRpt.add(format('%-56s %-14s %-14s', [
           '    EI: amount (K) above',
           formatF( Nc_Bc_Uic, 12, 2 ),
           ' '
           ] ));
  sRpt.add(' ');
  sRpt.add(format('%-56s %-14s %-14s', [
           '    Basic Federal Tax: amount (O) above',
           formatF( Fed_Tax, 12, 2 ),
           ' '
           ] ));
end;

Procedure TWrkRptJul24.TaxCalculationBand1P10(const income: currency;
                                              sIncType: shortString;
																							Nc_Bc_Mb_Tax: currency;
                                              Nc_Bc_Td: currency;
                                              Nc_Bc_Cpp: currency;
                                              Nc_Bc_Cpp2: currency;
																							Nc_Bc_Uic: currency;
                                              Nc_Bc_Bft: Currency;
                                              Nc_Bc_Fst: Currency;
                                              Nc_Bc_Netinc: currency;
                                              Nc_Bc_Mbt: currency);
begin
  sRpt.add(' ');
  sRpt.add(format('%-56s %-14s %-14s', [
           '    Manitoba Tax: amount (U) above',
           formatF( Nc_Bc_Mbt, 12, 2 ),
           ' '
           ] ));
  sRpt.add(format('%-56s %-14s %-14s', [ ' ',  dash(12),  ' '      ]));
  sRpt.add(format('%-56s %-14s %-14s (V)', [
           '    Total Deductions',
           ' ',
           formatF(Nc_Bc_Td, 12, 2 )
           ] ));
  sRpt.add(format('%-56s %-14s %-14s', [ ' ',  ' ', dash(12)]));
  sRpt.add(' ');
  sRpt.add(format('%-56s %-14s %-14s', [
           '    Annual Income: amount (I) above',
           formatF( income, 12, 2 ),
           ' '
           ] ));
  sRpt.add(' ');
  sRpt.add(format('%-56s %-14s %-14s', [
           '    Less: Total Deductions: Amount (V) above',
           formatF( Nc_Bc_Td, 12, 2 ),
           ' '
           ] ));
  sRpt.add(format('%-56s %-14s %-14s', [ ' ',  dash(12),  ' '      ]));
  sRpt.add(format('%-56s %-14s %-14s', [
           '    Annual Net Income',
           ' ',
           formatF( Nc_Bc_Netinc, 12, 2 )
           ] ));
  sRpt.add(format('%-56s %-14s %-14s', [ ' ', ' ', dDash(12)  ]));
  sRpt.add(' ');
  sRpt.add('Carry this amount forward for "' + sIncType +
           '"');
  sRpt.add('under Calculated Net Income amounts.' );
  sRpt.add(' ');
  sRpt.add(dash(91));
end;

procedure TWrkRptJul24.TaxCalculationBand1P2(const income: currency;
                                             Nc_Bc_Ann_Sal_Net: currency;
                                             Nc_Bc_Uic: currency;
                                             Nc_Bc_Cpp: currency;
                                             Nc_Bc_Cpp2: Currency;
                                             Nc_Bc_Nrtc: currency;
                                             Nc_Bc_Mb_Nrtc: currency;
                                             nc_mbFamilyTaxBenefitAmt: currency);
var
  t: currency;
  ws: string;
  Cpp2BaseAmount:Currency;
begin
  sRpt.add('    CPP: ');
  ws:=format('    ( $%.2n - $%.2n ) x %.4n%% = ( Maximum $%.2n )',
    [
    income,
    arrayNCTAXRAT[indexNCTAXRAT].CPP_basic_exemption,
    ( arrayNCTAXRAT[indexNCTAXRAT].CPP_contrib_rate *100.00 ),
    arrayNCTAXRAT[indexNCTAXRAT].CPP_max_annual_contrib
    ]
    );
  sRpt.add( format('%-70s  %-14s (J)', [ ws, formatF( Nc_Bc_Cpp, 12, 2 ) ] ));
  sRpt.add( format('%-56s %-14s %-14s', [ '     Amount (I) above',  ' ', dash(12)  ]));
  sRpt.add(' ');

  Cpp2BaseAmount := (arrayNCTAXRAT[indexNCTAXRAT].CPP_max_annual_contrib / arrayNCTAXRAT[indexNCTAXRAT].CPP_contrib_rate) + arrayNCTAXRAT[indexNCTAXRAT].CPP_basic_exemption;
  sRpt.add('    CPP2: ');
  ws:=format('    ( $%.2n - $%.2n ) x %.4n%% = ( Maximum $%.2n )',
    [
    income,
    Cpp2BaseAmount,
    ( arrayNCTAXRAT[indexNCTAXRAT].CPP2_contrib_rate *100.00 ),
    arrayNCTAXRAT[indexNCTAXRAT].CPP2_max_annual_contrib
    ]
    );
  sRpt.add( format('%-70s  %-14s (J2)', [ ws, formatF( Nc_Bc_Cpp2, 12, 2 ) ] ));
  sRpt.add( format('%-56s %-14s %-14s', [ '     Amount (I) above',  ' ', dash(12)  ]));
  sRpt.add(' ');

  sRpt.add('    EI: ');
  ws:=format('    $%.2n  x %.2n%% = ( Maximum $%.2n )',
    [
    income,
    (arrayNCTAXRAT[indexNCTAXRAT].UIC_premium_rate * 100.00),
    arrayNCTAXRAT[indexNCTAXRAT].UIC_max_annual_premium
    ] );
  sRpt.add( format('%-70s  %-14s (K)', [ ws, formatF( Nc_Bc_Uic, 12, 2 ) ] ));
  sRpt.add( format('%-56s %-14s %-14s', [ '     Amount (I) above',  ' ', dash(12) ]));
  sRpt.add(' ');
  sRpt.Add( 'Manitoba Family Tax Benefit:' );
  sRpt.add(' ');

  if (wrkClaim.Claim_No <> '00000000') Then
     begin
     sRpt.add( format('%-56s %-14s %-14s', [
         '    Manitoba Family Tax Benefit Amount (H) from pg. 4',
         formatF( fworking.Work_nc_iii_credit, 12, 2 ),
         ' '
         ] ));

     t := Nc_Bc_Ann_Sal_Net * ( arrayNCTAXRAT[indexNCTAXRAT].mbFamilyTaxBenefitRate );
     manitobaFamilyTaxBenefitAmt := nc_mbFamilyTaxBenefitAmt;

     if manitobaFamilyTaxBenefitAmt < 0 then
        manitobaFamilyTaxBenefitAmt := 0;

     sRpt.add( format('%-56s %-14s %-14s (MF)', [
              '    Less: Amount (LK) above '+
              formatF(Nc_Bc_Ann_Sal_Net, 12, 2 ) +
              ' X ' + format( '%.2n', [(arrayNCTAXRAT[indexNCTAXRAT].mbFamilyTaxBenefitRate*100.00) ] ) + '%',
              formatF( t, 12, 2 ),
              formatF( manitobaFamilyTaxBenefitAmt, 12, 2 )
              ] ));
     sRpt.add( format('%-56s %-14s %-14s', [ ' ',  ' ', dash(12) ]));
     end
  else
     begin
     sRpt.add( format('%-56s %-14s %-14s', [
              '    Manitoba Family Tax Benefit Amount (H) from pg. 4:',
              formatF(0.00, 12, 2 ),
              ' '
              ] ));
     sRpt.add(' ');
     sRpt.add( format('%-56s %-14s %-14s (MF)', [
              '    Less: Amount (LK) above '+
              formatF(Nc_Bc_Ann_Sal_Net, 12, 2 ) +
              ' X ' + format( '%.2n', [(arrayNCTAXRAT[indexNCTAXRAT].mbFamilyTaxBenefitRate*100.00) ] ) + '%',
              formatF( 0.00, 12, 2 ),
              formatF( 0.00, 12, 2 )
              ] ));
     sRpt.add( format('%-56s %-14s %-14s', [ ' ',  ' ', dash(12) ]));
     end;

  sRpt.add(' ');
  sRpt.add('Non Refundable Tax Credit:');
  sRpt.add(' ');

  sRpt.add('(i) Federal');
  sRpt.add(format('%-56s %-14s %-14s', [
           '    CPP amount (J) above',
  formatF(Nc_Bc_Cpp, 12, 2 ),
          ' '
          ] ));
  sRpt.add(' ');
  sRpt.add(format('%-56s %-14s %-14s', [
           '    CPP2 amount (J2) above',
  formatF(Nc_Bc_Cpp2, 12, 2 ),
          ' '
          ] ));
  sRpt.add(' ');
  sRpt.add( format('%-56s %-14s %-14s', [
    '    EI amount (K) above',
    formatF( Nc_Bc_Uic, 12, 2 ),
    ' '
    ] ));
  sRpt.add(' ');

  if (wrkClaim.Claim_No <> '00000000') Then
     begin
     sRpt.add( format('%-56s %-14s %-14s', [
         '    Total Federal Personal Amounts (F) from pg. 4',
         formatF( fworking.Work_nc_tax_exmp, 12, 2 ),
         ' '
         ] ));
     sRpt.add( format('%-56s %-14s %-14s', [ ' ',  dash(12),  ' '      ]));
     t := Nc_Bc_Cpp + Nc_Bc_Cpp2 + Nc_Bc_Uic + fworking.Work_nc_tax_exmp;
     sRpt.add( format('%-56s %-14s %-14s (L)', [
         '    Total x '+
         format( '%.2n', [(arrayNCTAXRAT[indexNCTAXRAT].FED_tax_rate_i*100.00) ] ) +
         '%' + ' (lowest Federal tax rate)',
         formatF( t, 12, 2 ),
         formatF( Nc_Bc_Nrtc, 12, 2 )
         ] ));
     end
  else
     Begin
     sRpt.add( format('%-56s %-14s %-14s', [
         '    Total Federal Personal Amounts (F) from pg. 4',
         formatF(0.00, 12, 2 ),
         ' '
         ] ));
     sRpt.add( format('%-56s %-14s %-14s', [ ' ',  dash(12),  ' '      ]));
     sRpt.add( format('%-56s %-14s %-14s (L)', [
         '    Total x '+
         format( '%.2n', [(arrayNCTAXRAT[indexNCTAXRAT].FED_tax_rate_i*100.00) ] ) +
         '%' + ' (lowest Federal tax rate)',
         formatF( 0.00, 12, 2 ),
         formatF( 0.00, 12, 2 )
         ] ));
     end;
  sRpt.add( format('%-56s %-14s %-14s', [ ' ', dDash(12), dDash(12) ]));

  //
  sRpt.add(' ');
  sRpt.add('(ii) Provincial');
  sRpt.add( format('%-56s %-14s %-14s', [
    '    CPP amount (J) above',
  formatF( Nc_Bc_Cpp, 12, 2 ),
    ' '
    ] ));
  sRpt.add(' ');
  sRpt.add( format('%-56s %-14s %-14s', [
    '    CPP2 amount (J2) above',
  formatF( Nc_Bc_Cpp2, 12, 2 ),
    ' '
    ] ));
  sRpt.add(' ');
  sRpt.add( format('%-56s %-14s %-14s', [
    '    EI amount (K) above',
    formatF( Nc_Bc_Uic, 12, 2 ),
    ' '
    ] ));
  sRpt.add(' ');
  if (wrkClaim.Claim_No <> '00000000') Then
     begin
     sRpt.add(format('%-56s %-14s %-14s', [
              '    Total Provincial Personal Amounts (G) from pg. 4',
              formatF( fworking.Work_nc_mb_tax_exmp, 12, 2 ),
              ' '
              ] ));
     sRpt.add(' ');
     sRpt.add(format('%-56s %-14s %-14s', [
              '    Manitoba Family Tax Benefit Amount (MF) above',
              formatF( manitobaFamilyTaxBenefitAmt, 12, 2 ),
              ' '
              ] ));
     sRpt.add( format('%-56s %-14s %-14s', [ ' ',  dash(12),  ' '      ]));

     if manitobaFamilyTaxBenefitAmt < 0 then
        manitobaFamilyTaxBenefitAmt := 0;

     t := Nc_Bc_Cpp + Nc_Bc_Cpp2 + Nc_Bc_Uic + fworking.Work_nc_mb_tax_exmp + manitobaFamilyTaxBenefitAmt;

     sRpt.add(format('%-56s %-14s %-14s (M)', [
              '    Total x '+
              format( '%.1n', [(arrayNCTAXRAT[indexNCTAXRAT].MB_tax_rate_i*100.00) ] ) +
              '%' + ' (lowest Manitoba Tax Rate)',
              formatF( t, 12, 2 ),
              formatF( Nc_Bc_Mb_Nrtc, 12, 2 )
              ] ));
     end
  else
     begin
     sRpt.add(format('%-56s %-14s %-14s', [
              '    Total Provincial Personal Amounts (G) from pg. 4',
              formatF( 0.00, 12, 2 ),
              ' '
              ] ));
              sRpt.add(' ');
     sRpt.add(format('%-56s %-14s %-14s', [
              '    Manitoba Family Tax Benefit Amount (MF) above',
              formatF( 0.00, 12, 2 ),
              ' '
              ] ));
     sRpt.add(format('%-56s %-14s %-14s', [ ' ',  dash(12),  ' '      ]));
     sRpt.add(format('%-56s %-14s %-14s (M)', [
              '    Total x '+
              format( '%.1n', [(arrayNCTAXRAT[indexNCTAXRAT].MB_tax_rate_i*100.00) ] ) +
              '%' + ' (lowest Manitoba Tax Rate)',
              formatF( 0.00, 12, 2 ),
              formatF( 0.00, 12, 2 )
              ] ));
     end;

  sRpt.add( format('%-56s %-14s %-14s', [ ' ', dDash(12), dDash(12) ]));
  sRpt.add(' ');
  sRpt.add(getDateHeading() + ' Federal Tax Rates and Income Thresholds (WCB):');
  sRpt.add(' ');
end;

function TWrkRptJul24.TaxCalculationBand1P3(Nc_Bc_Ann_Sal_Net: currency;
                                             Nc_Bc_Nrtc: currency): currency;
Var
  const1, const2, const3, const4: currency;
  f1i, f2p, work, temp: currency;
begin
  with arrayNCTAXRAT[indexNCTAXRAT] do
     begin
     sRpt.add('    +'+ dash(76) + '+');
     sRpt.add(format('    | %-28s | %-20s | %-20s |', [
              'Taxable Income Amount',
              'Federal Tax Rate',
              'Constant'
              ]));
     sRpt.add('    +'+ dash(76) + '+');
     sRpt.add(format('    | %-28s | %-20s | %-20s |', [
              format('%.0n',[FED_income_level_i]) + ' or less',
              format('%.2n',[(FED_tax_rate_i*100.00)]) + '%',
              format('%.2n',[0.00])
              ]));
     const1 := FED_income_level_i * (FED_tax_rate_ii - FED_tax_rate_i);
     temp := Round(const1);
     sRpt.add(format('    | %-28s | %-20s | %-20s |', [
              '> ' + format('%.0n',[FED_income_level_i]),
              format('%.1n',[(FED_tax_rate_ii*100.00)]) + '%',
              format('%.2n',[temp])
              ]));
     const2 := FED_income_level_ii * (FED_tax_rate_iii - FED_tax_rate_ii)
              + const1;
     temp := Round(const2);
     sRpt.add(format('    | %-28s | %-20s | %-20s |', [
              '> ' + format('%.0n',[FED_income_level_ii]),
              format('%.1n',[(FED_tax_rate_iii*100.00)]) + '%',
              format('%.2n',[temp])
              ]));
     const3 := FED_income_level_iii * (FED_tax_rate_iiii - FED_tax_rate_iii)
               + const2;
     temp := Round(const3);
     sRpt.add(format('    | %-28s | %-20s | %-20s |', [
              '> ' + format('%.0n',[FED_income_level_iii]),
              format('%.1n',[(FED_tax_rate_iiii*100.00)]) + '%',
              format('%.2n',[temp])
              ]));
     const4 := FED_income_level_iiii * (FED_tax_rate_iiiii - FED_tax_rate_iiii)
               + const3;
     temp := Round(const4);
     sRpt.add(format('    | %-28s | %-20s | %-20s |', [
              '> ' + format('%.0n',[FED_income_level_iiii]),
              format('%.1n',[(FED_tax_rate_iiiii*100.00)]) + '%',
              format('%.2n',[temp])
              ]));
     sRpt.add('    +'+ dash(76) + '+');
     sRpt.add(' ');
     sRpt.add('Federal Tax:');
     sRpt.add(' ');
     sRpt.add('    For ' + formatF(Nc_Bc_Ann_Sal_Net, 11, 2 ) +' (Amount (LK) above):' );
     const1 := Round(const1);
     const2 := Round(const2);
     const3 := Round(const3);
     const4 := Round(const4);

     if (Nc_Bc_Ann_Sal_Net > FED_income_level_iiii) then
        begin
        f2p := FED_tax_rate_iiiii;
        f1i := const4;
        end
     else if (Nc_Bc_Ann_Sal_Net > FED_income_level_iii) then
        begin
        f2p := FED_tax_rate_iiii;
        f1i := const3;
        end
     else if (Nc_Bc_Ann_Sal_Net > FED_income_level_ii) then
        begin
        f2p := FED_tax_rate_iii;
        f1i := const2;
        end
     else if (Nc_Bc_Ann_Sal_Net > FED_income_level_i) then
        begin
        f2p := FED_tax_rate_ii;
        f1i := const1;
        end
     else
        begin
        f2p := FED_tax_rate_i;
        f1i := 0.00;
        end;
     end;

    // added tax exempt here  jwd
  if (wrkClaim.Claim_No = '00000000') or ( wrkClaim.Tax_Exempt = 'Y' ) Then
     begin
     f2p := 0; // set the tax rate to be a blank
     end;

  sRpt.add(' ');
  sRpt.add(format('%-56s %-14s %-14s', [
           '    Multiply by tax rate from above table ' + format('%.2n',[f2p * 100]){FormatF((f2p * 100), 5, 1)} + '%',
           formatF((Nc_Bc_Ann_Sal_Net * f2p), 12, 2 ), ' '
           ] ));
  sRpt.add(' ');
  sRpt.add(format('%-56s %-14s %-14s', [
           '    Less:  Constant from above table',
           formatF(f1i, 12, 2 ), ' '
           ] ));
  work := (Nc_Bc_Ann_Sal_Net * f2p) - f1i;
  if work < 0 then work := 0.00;
  sRpt.add( format('%-56s %-14s %-14s', [ ' ',  dash(12), ' '       ]));
  sRpt.add(format('%-56s %-14s %-14s', [
           '    Federal Tax ',
           formatF( work, 12, 2 ),
           ' (N)'
           ] ));
  sRpt.add(' ');

  if (wrkClaim.Claim_No <> '00000000') Then
     sRpt.add(format('%-56s %-14s %-14s', [
              '    Less: Non Refundable Tax Credit (L) above ',
              formatF( Nc_Bc_Nrtc, 12, 2 ),
              ' '
              ] ))
  else
     sRpt.add(format('%-56s %-14s %-14s', [
              '    Less: Non Refundable Tax Credit (L) above ',
              formatF(0.00, 12, 2 ),
              ' '
              ] ));

  result := ((Nc_Bc_Ann_Sal_Net * f2p) - f1i) - Nc_Bc_Nrtc;
  if result < 0 then
     result := 0;
  sRpt.add( format('%-56s %-14s %-14s', [ ' ',  dash(12), ' '       ]));
  sRpt.add(format('%-56s %-14s %-14s', [
           '    Basic Federal Tax ',
           formatf( result, 12, 2),
           ' (O)'
           ] ));
  sRpt.add( format('%-56s %-14s %-14s', [ ' ', dDash(12), ' '       ]));
  sRpt.add(' ');
end;

(******************************************************************************)
(*                                                                            *)
(*  Create Tax Calculation Band                                               *)
(*                                                                            *)
(******************************************************************************)
procedure TWrkRptJul24.TaxCalculationBand1( const income: currency;
																						sIncomeType: shortstring );
var
  t2: currency;
  a: currency;
  b: currency;
  ws_Work_nc_bc_ann_sal_net:currency;
  ws_Work_nc_bc_bft:currency;
  ws_Work_nc_bc_cpp:currency;
  ws_Work_nc_bc_cpp2:currency;
  ws_Work_nc_bc_uic:currency;
  ws_Work_nc_bc_nrtc:currency;
  ws_Work_nc_bc_fst:currency;
  ws_Work_nc_bc_mbt:currency;
  ws_Work_nc_bc_mb_nrtc:currency;
  ws_Work_nc_bc_mb_tax:currency;
  ws_Work_nc_bc_netinc:currency;
  ws_Work_nc_bc_td:currency;
  mbFamilyTaxBenefitRate:currency;
begin
  ws_Work_nc_bc_ann_sal_net := Set_nc_bc_ann_sal_net(sIncomeType);
  ws_Work_nc_bc_bft					:= Set_nc_bc_bft(sIncomeType);
  ws_Work_nc_bc_cpp					:= Set_nc_bc_cpp(sIncomeType);
  ws_Work_nc_bc_cpp2				:= Set_nc_bc_cpp2(sIncomeType);
  ws_Work_nc_bc_uic					:= Set_nc_bc_uic(sIncomeType);
  ws_Work_nc_bc_nrtc				:= Set_nc_bc_nrtc(sIncomeType);
  ws_Work_nc_bc_fst					:= Set_nc_bc_fst(sIncomeType);
  ws_Work_nc_bc_mbt					:= Set_nc_bc_mbt(sIncomeType);
  ws_Work_nc_bc_mb_nrtc			:= Set_nc_bc_mb_nrtc(sIncomeType);
  ws_Work_nc_bc_mb_tax			:= Set_nc_bc_mb_tax(sIncomeType);
  ws_Work_nc_bc_netinc			:= Set_nc_bc_netinc(sIncomeType);
  ws_Work_nc_bc_td					:= Set_nc_bc_td(sIncomeType);
  mbFamilyTaxBenefitRate    := Set_mbFamilyTaxBenefitAmt(sIncomeType);
  TaxCalculationBand1P1(income, sIncomeType, ws_Work_nc_bc_ann_sal_net);
  TaxCalculationBand1P2(income, ws_Work_nc_bc_ann_sal_net,
                        ws_Work_nc_bc_uic, ws_Work_nc_bc_cpp, ws_Work_nc_bc_cpp2,
                        ws_Work_nc_bc_nrtc, ws_Work_nc_bc_mb_nrtc, mbFamilyTaxBenefitRate);
  t2 := TaxCalculationBand1P3(ws_Work_nc_bc_ann_sal_net, ws_Work_nc_bc_nrtc);
  a := TaxCalculationBand1P5b(ws_Work_nc_bc_ann_sal_net,
                              ws_Work_nc_bc_mb_nrtc,
                              ws_Work_nc_bc_mbt);
  b := TaxCalculationBand1P6(ws_Work_nc_bc_ann_sal_net);
  TaxCalculationBand1P7(ws_Work_nc_bc_ann_sal_net, ws_Work_nc_bc_mb_tax, a, b);
  TaxCalculationBand1P8(ws_Work_nc_bc_cpp, ws_Work_nc_bc_cpp2, ws_Work_nc_bc_uic, t2);
  TaxCalculationBand1P10(income, sIncomeType, ws_Work_nc_bc_mb_tax, ws_Work_nc_bc_td,
                         ws_Work_nc_bc_cpp, ws_Work_nc_bc_cpp2, ws_Work_nc_bc_uic, ws_Work_nc_bc_bft,
                         ws_Work_nc_bc_fst, ws_Work_nc_bc_netinc, ws_Work_nc_bc_mbt);
end;

end.
