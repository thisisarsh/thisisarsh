inherited WrkRptJan10: TWrkRptJan10
  Caption = 'WrkRptJan10'
  PixelsPerInch = 96
  TextHeight = 13
end
