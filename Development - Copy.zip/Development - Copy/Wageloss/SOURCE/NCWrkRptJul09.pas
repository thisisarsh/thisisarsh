unit NCWrkRptJul09;

interface

uses
  Windows, Messages, SysUtils, Variants, Classes, Graphics, Controls, Forms,
  Dialogs, NCWrkRptJan09, UtilMod1, NCRecDef, NCIniMod;

type
  TWrkRptJul09 = class(TWrkRptJan09)
  function getDateHeading():String; Override;
  procedure GrossIncomeBand1; Override;
  private
    { Private declarations }
  public
    { Public declarations }
  end;

var
  WrkRptJul09: TWrkRptJul09;

implementation

uses NCDatMod;

{$R *.dfm}
(******************************************************************************)
(*                                                                            *)
(*  override this function for each class to avoid having to bring in all of  *)
(*    the methods that contain the date in the heading.                       *)
(*   IE:  the jan 09 class should return  2008/2009                           *)
(*        the july 09 class should return 2009                                *)
(*                                                                            *)
(******************************************************************************)

function TWrkRptJul09.getDateHeading():String;
begin
  result:='2009'
end;

(******************************************************************************)
(*                                                                            *)
(*  Create Gross Income Band                                                  *)
(*                                                                            *)
(******************************************************************************)
procedure TWrkRptJul09.GrossIncomeBand1;
begin
  with wrkClaim do
  begin
    if Year(Accident_Date) >= 2006 then begin
      sRpt.add(' ');
      sRpt.add('Gross Income Amounts:');
      sRpt.add(' ');

      sRpt.add(
        format('%-14s %-42s %-14s (A) %-14s',
          [ formatF(Wkly_Sal_A, 11, 2  ),
          ' x 52 = ( actual annual income )',
          formatF( Annual_Gross_A, 12, 2),
          ' '
          ] ));
      sRpt.add( format('%-14s %-42s %-14s %-14s', [ dash(12), ' ', dDash(12), ' ' ] ));
      sRpt.add( format('%-14s %-56s %-14s', [ '  Weekly Wage', ' ', ' ' ] ));
      sRpt.add(' ');
      sRpt.add( format('%-57s %-14s (AA) %-14s', [ 'WCB Minimum Gross Annual Earnings',
                                                    formatF(Minimum_wage, 12, 2),
                                                    ' '] ));
      sRpt.add( format('%-57s %-14s %-14s', [ ' ', dDash(12), ' ' ] ));
      sRpt.add(' ');

      sRpt.add('See Minimum Wage Report for indexed values.');
      sRpt.add(' ');
      sRpt.add(' ');

      if Max_Adjustment <> 0 then
        sRpt.add(
          format('%-57s %-14s (B) %-14s',
            [ 'Max Adjustment Override',
               formatF( Max_Adjustment, 12, 2),
               ' '] ))
      else
        sRpt.add(
          format('%-57s %-14s (B) %-14s',
            [ 'Max Adjustment Override', ' ', ' '
            ] ));

      sRpt.add( format('%-57s %-14s %-14s', [ ' ', dDash(12), ' ' ] ));
      sRpt.add(' ');

      sRpt.add('PRORATING FACTOR FOR TAX DEDUCTIONS (ONLY IF ACTUAL > MAX ADJ OVERRIDE):');
      sRpt.add(' ');

      //dont know if i have to change anything to the following if statement....
      if Annual_Gross_A > Annual_Gross then
      begin
        sRpt.add(
          format('%-76s %-.4n%% (FT)',
            [
            ' (Max (B)  ' + formatF(Annual_Gross, 12, 2) +
            ' / Actual (A)  ' + formatF(Annual_Gross_A, 12, 2) + ' =',
            (fWorking.Work_nc_prorate*100.00)
            ] ));
        sRpt.add( format('%-56s %-14s %-14s', [ ' ',  ' ', dDash(12) ] ));
      end
      else
      begin
        sRpt.add(
          format('%-84s (FT)',
            [
            ' (Max (B)             /Actual (A)             ='
            ] ));
        sRpt.add(
          format('%-71s %-14s',
            [
            '         ' + dash(12) + '             ' + dash(12),
            dDash(12)
            ] ));
      end;
      sRpt.add(' ');

      sRpt.add(
        format('%-14s %-56s %-14s (C)',
          [ formatF( Annual_Gross, 12, 2  ),
          ' x 75% = ( annual sheltered income )',
          formatF( ( Annual_Gross * 0.75 ), 12, 2 )
          ] ));
      sRpt.add( format('%-14s %-56s %-14s', [ dash(12), ' ', dDash(12) ] ));
      sRpt.add( format('%-56s %-14s %-14s', [ '  Lessor of (A) or (B) above', ' ', ' ' ] ));
      sRpt.add(' ');

      sRpt.add(
        format('%-14s %-56s %-14s (CC)',
          [ formatF( Minimum_wage, 12, 2  ),
          ' x 75% = ( annual sheltered income )',
          formatF( ( Minimum_wage * 0.75 ), 12, 2 )
          ] ));
      sRpt.add( format('%-14s %-56s %-14s', [ dash(12), ' ', dDash(12) ] ));
      sRpt.add( format('%-56s %-14s %-14s', [ '  Based on minimum (AA)', ' ', ' ' ] ));
      sRpt.add(' ');

      sRpt.add(
        format('%-14s %-56s %-14s',
          [  formatF( Collateral_Ben_Tax, 12, 2 ),
          ' (i)   Weekly Taxable Collateral benefits',
          ' '
          ] ));
      sRpt.add(
        format('%-14s %-56s %-14s',
          [ formatF( Post_Injury_Earn, 12, 2  ),
          ' (ii) + Weekly Post Injury Earnings ',
          ' '
          ] ));

      sRpt.add(
        format('%-14s %-56s %-14s (E)',
          [ formatF( ( Collateral_Ben_Tax + Post_Injury_Earn ), 12, 2 ),
          ' (D)  x 52 =( annual benefits + earnings )',
          formatF( (( Collateral_Ben_Tax + Post_Injury_Earn )* 52), 12, 2 )
          ] ));
      sRpt.add( format('%-14s %-56s %-14s', [ dash(12), ' ', dDash(12) ] ));
      sRpt.add( format('%-56s %-14s %-14s', [ ' total ( i + ii )', ' ', ' ' ] ));
    end
    else //if Accident_Date < 2006
    begin
        sRpt.add(' ');
        sRpt.add('Gross Income Amounts:');
        sRpt.add(' ');

        sRpt.add(
          format('%-14s %-56s %-14s (A)',
          [ formatF(Wkly_Sal_A, 11, 2  ),
          ' x 52 = ( actual annual income )',
          formatF( Annual_Gross_A, 12, 2)
          ] ));
        sRpt.add( format('%-14s %-56s %-14s', [ dash(12), ' ', dDash(12) ] ));
        sRpt.add( format('%-14s %-56s %-14s', [ '  Weekly Wage', ' ', ' ' ] ));
        sRpt.add(' ');
        sRpt.add(' ');

        if Max_Adjustment <> 0 then
          sRpt.add(
          format('%-71s %-14s (B)',
            [ 'Max Adjustment Override', formatF( Max_Adjustment, 12, 2)
            ] ))
        else
          sRpt.add(
          format('%-71s %-14s (B)',
            [ 'Max Adjustment Override', ' '
            ] ));

        sRpt.add( format('%-71s %-14s', [ ' ', dDash(12) ] ));

        sRpt.add(' ');
        sRpt.add(
          format('%-56s %-14s %-14s (B)',
          [ 'WCB Maximum Gross Annual Income',
            ' ',
          formatF(Annual_Gross, 12, 2 )
          ] ));
        sRpt.add( format('%-14s %-56s %-14s', [ ' ', ' ', dDash(12) ] ));

        sRpt.add(' ');
        sRpt.add('See Annual Maximum Report for indexed values.');
        sRpt.add(' ');
        sRpt.add(' ');

        sRpt.add('PRORATING FACTOR FOR TAX DEDUCTIONS (ONLY IF ACTUAL > MAX):');
        sRpt.add(' ');
        if Annual_Gross_A > Annual_Gross then
        begin
          sRpt.add(
            format('%-76s %-.4n%% (FT)',
            [
            ' (Max (B)  ' + formatF(Annual_Gross, 12, 2) +
            ' / Actual (A)  ' + formatF(Annual_Gross_A, 12, 2) + ' =',
            (fWorking.Work_nc_prorate*100.00)
            ] ));
          sRpt.add( format('%-56s %-14s %-14s', [ ' ',  ' ', dDash(12) ] ));
        end
        else
        begin
          sRpt.add(
            format('%-84s (FT)',
              [
              ' (Max (B)             /Actual (A)             ='
              ] ));
          sRpt.add(
            format('%-71s %-14s',
              [
              '         ' + dash(12) + '             ' + dash(12),
              dDash(12)
              ] ));
        end;
        sRpt.add(' ');

        sRpt.add(
          format('%-14s %-56s %-14s (C)',
            [ formatF( Annual_Gross, 12, 2  ),
            ' x 75% = ( annual sheltered income )',
            formatF( ( Annual_Gross * 0.75 ), 12, 2 )
            ] ));
        sRpt.add( format('%-14s %-56s %-14s', [ dash(12), ' ', dDash(12) ] ));
        sRpt.add( format('%-56s %-14s %-14s', [ '  lessor of (A) or (B) above', ' ', ' ' ] ));
        sRpt.add(' ');

        sRpt.add(
          format('%-14s %-56s %-14s',
          [  formatF( Collateral_Ben_Tax, 12, 2 ),
          ' (i)   Weekly Taxable Collateral benefits',
          ' '
          ] ));
        sRpt.add(
          format('%-14s %-56s %-14s',
          [ formatF( Post_Injury_Earn, 12, 2  ),
          ' (ii) + Weekly Post Injury Earnings ',
          ' '
          ] ));

        sRpt.add(
          format('%-14s %-56s %-14s (E)',
          [ formatF( ( Collateral_Ben_Tax + Post_Injury_Earn ), 12, 2 ),
          ' (D)  x 52 =( annual benefits + earnings )',
          formatF( (( Collateral_Ben_Tax + Post_Injury_Earn )* 52), 12, 2 )
          ] ));
        sRpt.add( format('%-14s %-56s %-14s', [ dash(12), ' ', dDash(12) ] ));
        sRpt.add( format('%-56s %-14s %-14s', [ ' total ( i + ii )', ' ', ' ' ] ));
    end;

    sRpt.add(' ');

    sRpt.add(dash(91));
  end;
end;


end.
