(*  // SQL Queries of interest

    select Claim_No, Clmnts_Surname, Rebate_Amount
      from WLREBDTL order by claim_no

    TRUNCATE TABLE dbo.WLREBDTL

    DUMP TRAN wageloss_db WITH NO_LOG

*)

(******************************************************************************)
(*  Wageloss System                                                           *)
(*                                                                            *)
(*  Shelter Rebate Database Load                                              *)
(*                                                                            *)
(*                                                                            *)
(*  Author: Brad Trupp  / Capella Systems Group, Inc.                         *)
(*  Date:   October 1998                                                      *)
(*                                                                            *)
(******************************************************************************)
unit NCSRLoad;

interface

uses
  Windows, Messages, SysUtils, Classes, Graphics, Controls, Forms, Dialogs,
  StdCtrls, ExtCtrls, Buttons, NCIniMod, NCRecdef, DateUtils, ADODB;

type
  TShelterRebateLoadForm = class(TForm)
    lblWarning: TLabel;
    lblStep1: TLabel;
    btnStep1: TSpeedButton;
    btnStep2: TSpeedButton;
    btnStep3: TSpeedButton;
    btnStep4: TSpeedButton;
    btnCancel: TButton;
    lblStep2: TLabel;
    lblStep3: TLabel;
    lblStep4: TLabel;
    Memo1: TMemo;
    btnStep5: TSpeedButton;
    lblStep5: TLabel;
    OpenDialog1: TOpenDialog;
    procedure FormDestroy(Sender: TObject);
    procedure FormActivate(Sender: TObject);
    procedure btnCancelClick(Sender: TObject);
    procedure btnStep1Click(Sender: TObject);
    procedure btnStep2Click(Sender: TObject);
    procedure btnStep3Click(Sender: TObject);
    procedure btnStep4Click(Sender: TObject);
    procedure FormCreate(Sender: TObject);
    procedure btnStep5Click(Sender: TObject);
    procedure lblStep4Click(Sender: TObject);
  private
    { Private declarations }
    fImportFileName: string;
    fShelterRebateYear: integer;
    fType: String;
    procedure ResetInfoLine2;
    procedure ReadThroughSRFile;
    function EmptySRTable: boolean;
    procedure LoadSRRecord();
    function LogonToDataDB: boolean;
  public
    { Public declarations }
    w: recWLREBDTL;
  end;
	procedure SimpleCalcBen(r2:RecNCClaim);
  function SimpleCalcBenW(w2:recWLREBDTL):recWLREBDTL;
var
  ShelterRebateLoadForm: TShelterRebateLoadForm;
  r: RecNCClaim;
  fWorking : recConst;
  count2: integer;
implementation

uses NCMain, NCDatMod, utilmod1, Utils, uADOSecurity, uGlobal;

{$R *.DFM}

(******************************************************************************)
(*                                                                            *)
(*  Form Destroy                                                              *)
(*                                                                            *)
(******************************************************************************)
procedure TShelterRebateLoadForm.FormDestroy(Sender: TObject);
begin
  WagelossMainForm.ShowInfoLine1('');
  WagelossMainForm.ShowInfoLine2('');
end;

procedure TShelterRebateLoadForm.lblStep4Click(Sender: TObject);
begin

end;

(******************************************************************************)
(*                                                                            *)
(*  Display default Info message                                              *)
(*                                                                            *)
(******************************************************************************)
procedure TShelterRebateLoadForm.ResetInfoLine2;
begin
    WagelossMainForm.ShowInfoLine2('*Shelter Rebate Information Load')
end;

(******************************************************************************)
(*                                                                            *)
(*    Form Activate method                                                    *)
(*                                                                            *)
(******************************************************************************)
procedure TShelterRebateLoadForm.FormActivate(Sender: TObject);
begin
    ResetInfoLine2;
end;

(******************************************************************************)
(*                                                                            *)
(*    Cancel Button Click method                                              *)
(*                                                                            *)
(******************************************************************************)
procedure TShelterRebateLoadForm.btnCancelClick(Sender: TObject);
begin
   close;
end;

(******************************************************************************)
(*                                                                            *)
(*    Step 1 click                                                            *)
(*                                                                            *)
(******************************************************************************)
procedure TShelterRebateLoadForm.btnStep1Click(Sender: TObject);
var
  sType : string;
begin
    if month( utilmod1.getEmergeBusinessDate() ) <> 1 then
      sType := 'Initial'
    else
      sType := 'Final';

    if ( InputQuery('Shelter Rebate', 'Enter Shelter Rebate Type:', sType) ) then
    begin
      try
        if NOT(sType = 'Initial') and NOT(sType = 'Final') then
          raise exception.create('');
        Memo1.lines.add('Type entered as ' + sType );
        fType := sType;
        lblStep1.Color:=clBtnFace;
        lblStep2.Color:=clYellow;
        btnStep1.enabled:=false;
        btnStep2.enabled:=true;
      except
        messagebeep(0);
        Memo1.lines.add('Invalid Type entered - ' + sType );
      end;
    end;
end;

(******************************************************************************)
(*                                                                            *)
(*    Step 2 click                                                            *)
(*                                                                            *)
(******************************************************************************)
procedure TShelterRebateLoadForm.btnStep2Click(Sender: TObject);
var
  sYear: string;
begin
    if month( utilmod1.getEmergeBusinessDate() ) < 6 then
      fShelterRebateYear:= year( utilmod1.getEmergeBusinessDate() ) - 1
    else
      fShelterRebateYear:= year( utilmod1.getEmergeBusinessDate() );

    sYear:=intToStr( fShelterRebateYear );
    sYear := '';
    if ( InputQuery('Shelter Rebate', 'Enter Shelter Rebate Year:', sYear) ) then
    begin
      try
        fShelterRebateYear:=strtoint(sYear);
        Memo1.lines.add('Year entered as ' + inttostr(fShelterRebateYear) );
        lblStep2.Color:=clBtnFace;
        lblStep3.Color:=clYellow;
        btnStep2.enabled:=false;
        btnStep3.enabled:=true;
      except
        messagebeep(0);
        Memo1.lines.add('Invalid Year entered - ' + sYear );
      end;
    end;

end;

(******************************************************************************)
(*                                                                            *)
(*    Step 3 click                                                            *)
(*                                                                            *)
(******************************************************************************)
procedure TShelterRebateLoadForm.btnStep3Click(Sender: TObject);
begin
    Memo1.lines.add('Verified OK to proceed');
    lblStep3.Color:=clBtnFace;
    lblStep4.Color:=clYellow;
    btnStep3.enabled:=false;
    btnStep4.enabled:=true;
end;

(******************************************************************************)
(*                                                                            *)
(*    Step 4 click                                                            *)
(*                                                                            *)
(******************************************************************************)
procedure TShelterRebateLoadForm.btnStep4Click(Sender: TObject);
begin
    btnCancel.enabled:=false;
    if LogonToDataDB then
    begin
      if EmptySRTable then
        begin
        ReadThroughSRFile;
        Memo1.lines.Add( 'Update Wage Loss Shelter Rebate Detail Table... Complete.' );
        lblStep4.Color:=clBtnFace;
        lblStep5.Color:=clYellow;
        btnStep4.enabled:=false;
        btnStep5.enabled:=true;
        end;
    end
    else
    begin
      MessageDlg('Error connecting to reporting database.', mtError,[mbOk], 0);
    end;
end;

(******************************************************************************)
(*                                                                            *)
(*    Step 5 click                                                            *)
(*                                                                            *)
(******************************************************************************)
procedure TShelterRebateLoadForm.btnStep5Click(Sender: TObject);
begin
    Close;
end;

(******************************************************************************)
(*                                                                            *)
function TShelterRebateLoadForm.LogonToDataDB: boolean;
begin
  result:=true;
  try
    with dm1 do
    begin
      userProfile := getUserProfile();
      dbLogin(userProfile, dm1.dbEmerge_Reporting, CurrServer7, CurrDatabaseName7);
      dbEmerge_Reporting.Connected := True;
      if not dbEmerge_Reporting.Connected = True then
        result := false;
    end;
  except
    On e:exception do
    begin
      result := false;
      MessageDlg('Error Logging onto Batch Database' + #10#10 + E.message,
        mtError,[mbOk], 0);
    end;
  end;
end;

(******************************************************************************)
(*                                                                            *)
(*    Form Create method                                                      *)
(*                                                                            *)
(******************************************************************************)
procedure TShelterRebateLoadForm.FormCreate(Sender: TObject);
begin
    lblStep1.Color:=clYellow;
    fImportFileName:='';
    Memo1.clear;
    SetFont(Self);
end;

(******************************************************************************)
(*                                                                            *)
(*    Read through input shelter rebate data file                             *)
(*                                                                            *)
(******************************************************************************)
procedure TShelterRebateLoadForm.ReadThroughSRFile;
var
    cntr, lngReturn: integer;
    bill25StartDate : TDateTime;
begin
    try
      cntr:=0;
      Memo1.lines.Add( 'Updating Wage Loss Shelter Rebate Detail Table...' );
      bill25StartDate := StrToDate('01/01/2006');
      dm1.uspShelterRebateData.Close;

      dm1.uspShelterRebateData.Parameters.ParamByName('@shelterYear').Value := inttostr(fShelterRebateYear);
      dm1.uspShelterRebateData.Parameters.ParamByName('@runType').Value := fType;
      dm1.uspShelterRebateData.Open;
      lngReturn := dm1.uspShelterRebateData.Parameters.ParamByName('@RETURN_VALUE').Value;
      if lngReturn = 0 Then
      Begin
        dm1.uspShelterRebateData.First;
        while not (dm1.uspShelterRebateData.eof) do
        begin
          inc( cntr );
          count2 := cntr;
          ClearNCCLAIM( r );
        try
          with r do
          begin
            Claim_No := Replicate('0',8-Length(Trim(dm1.uspShelterRebateData.FieldByName('claimNo').asString))) + Trim(dm1.uspShelterRebateData.FieldByName('claimNo').asString);
            Date_Pd_From_Cheq := dm1.uspShelterRebateData.FieldByName('fromDate').asDateTime; //MIN( PaidCostReporting.paidFromDate ) - minimum from date of all paymentItem for the year
            Date_Pd_To_Cheq := dm1.uspShelterRebateData.FieldByName('toDate').asDateTime; //MAX( PaymentItem.toDate ) - maximum to date of all paymentItem for the year
  	        Claim_Suffix := dm1.uspShelterRebateData.FieldByName('deskName').asString;
  	        Prime_Firm_No := dm1.uspShelterRebateData.FieldByName('firmNo').asString;
  	        Clmnts_Surname := dm1.uspShelterRebateData.FieldByName('workerName').asString;
  	        Tax_Year := dm1.uspShelterRebateData.FieldByName('taxYear').asInteger;
  	        Marital_Status := dm1.uspShelterRebateData.FieldByName('maritalStatus').asString;
  	        Spouse_Working := dm1.uspShelterRebateData.FieldByName('spouseWorkingFlag').asString;
            ClaimSpouseForTaxPurposes := dm1.uspShelterRebateData.FieldByName('ClaimSpouseForTaxPurposes').asString;
  	        No_Weeks_of_Comp_Bnfts := dm1.uspShelterRebateData.FieldByName('sumWeeksPaidQty').asCurrency; //SUM( PaymentItem.weeksPaidQty ) - Sum of weeks paid from all paymentItems for the year.
  	        Comp_Wks_Pd_to_63 := dm1.uspShelterRebateData.FieldByName('sumWeeksPaidNet90Qty').asCurrency; //SUM( PaymentItem.weeksPaidQty ) - total weeks paid to 104 effective date
  	        Accident_Date := dm1.uspShelterRebateData.FieldByName('accidentDate').asDateTime;
  	        No_Of_Dependnts := dm1.uspShelterRebateData.FieldByName('dependentsQty').asInteger;
  	        No_Infirm := dm1.uspShelterRebateData.FieldByName('infirmDependentsQty').asInteger;
  	        Tax_Exemption := dm1.uspShelterRebateData.FieldByName('taxExemptAmt').asCurrency;
  	        Weekly_Net := dm1.uspShelterRebateData.FieldByName('fullWeeklyNetLossEarnAmt').asCurrency;
  	        Weekly_90 := dm1.uspShelterRebateData.FieldByName('fullWeekly90NetLossAmt').asCurrency;
  	        Weekly_90_S := dm1.uspShelterRebateData.FieldByName('fullWeekly90NetShelteredAmt').asCurrency;
  	        Weekly_80 := dm1.uspShelterRebateData.FieldByName('fullWeekly80NetLossAmt').asCurrency;
  	        Annual_Gross := dm1.uspShelterRebateData.FieldByName('fullAnnualGrossAmt').asCurrency;
            Annual_Gross_A := 0.00;
  	        Annual_Net := dm1.uspShelterRebateData.FieldByName('fullAnnualNetLossEarnAmt').asCurrency;
  	        Annual_Net_A := 0.00;
  	        Annual_90 := dm1.uspShelterRebateData.FieldByName('fullAnnual90NetLossAmt').asCurrency;
  	        Annual_90_S := dm1.uspShelterRebateData.FieldByName('fullAnnual90NetShelteredAmt').asCurrency;
  	        Annual_80 := dm1.uspShelterRebateData.FieldByName('fullAnnual80NetLossAmt').asCurrency;
  	        Inc_Tax_Fed := dm1.uspShelterRebateData.FieldByName('incomeTaxFederalAmt').asCurrency;
  	        Inc_Tax_Man := dm1.uspShelterRebateData.FieldByName('incomeTaxProvincialAmt').asCurrency;
  	        CPP_Prem := dm1.uspShelterRebateData.FieldByName('cppPremiumAmt').asCurrency;
            CPP2_Prem := dm1.uspShelterRebateData.FieldByName('cpp2PremiumAmt').asCurrency;
  	        EI_Exempt := dm1.uspShelterRebateData.FieldByName('uicExemptFlag').asString;
  	        EI_Prem := dm1.uspShelterRebateData.FieldByName('uicPremiumAmt').asCurrency;
  	        Total_Deds := dm1.uspShelterRebateData.FieldByName('totalDeductionsAmt').asCurrency;
  	        Weekly_Benefit := dm1.uspShelterRebateData.FieldByName('fullWeeklyTaxShelteringAmt').asCurrency;
            if Weekly_Benefit < 0.00 then
              Weekly_Benefit := 0.00;
  	        No_Weeks_Paid := dm1.uspShelterRebateData.FieldByName('weeksWorked').asCurrency; //52 - sumWeeksPaidQty + overpayments
  	        Original_Wkly_Sal := dm1.uspShelterRebateData.FieldByName('weeklyWageAmt').asCurrency;
            Tot_Clmt_Anty_Elig_Earn := 0.00;
  	        Post_Injury_Earn := dm1.uspShelterRebateData.FieldByName('postEarnWeeklyGrossAmt').asCurrency;
  	        Self_Employed := dm1.uspShelterRebateData.FieldByName('selfEmployedFlag').asString;
  	        Recurrence := dm1.uspShelterRebateData.FieldByName('recurrenceFlag').asString;
            RecurrenceDate := dm1.uspShelterRebateData.FieldByName('recurrenceDate').AsDateTime;
  	        Child_Care_Exp := dm1.uspShelterRebateData.FieldByName('childCareExpenseAmt').asCurrency;
  	        Spousal_Support := dm1.uspShelterRebateData.FieldByName('spousalSupportAmt').asCurrency;
  	        Child_Support := dm1.uspShelterRebateData.FieldByName('childSupportAmt').asCurrency;
            CPP_Exempt := dm1.uspShelterRebateData.FieldByName('cppExemptFlag').asString;
  	        Tax_Exempt := dm1.uspShelterRebateData.FieldByName('incomeTaxExemptFlag').asString;
            workerAnnuityContributionPercent := dm1.uspShelterRebateData.FieldByName('week104WorkerContributionPercent').asCurrency;
            wcbAnnuityContributionPercent := dm1.uspShelterRebateData.FieldByName('week104WcbContributionPercent').asCurrency;
            employerPaidFlag := dm1.uspShelterRebateData.FieldByName('employerPaidFlag').asString;
            Indexation_Year := dm1.uspShelterRebateData.FieldByName('indexedYear').asInteger;
            Max_Adjustment := dm1.uspShelterRebateData.FieldByName('maximumAdjustmentAmt').asCurrency;
            reportType := dm1.uspShelterRebateData.FieldByName('reportType').AsString;
            collateralTaxableAmt := dm1.uspShelterRebateData.FieldByName('collateralTaxableAmt').asCurrency;
            collateralNonTaxableAmt := dm1.uspShelterRebateData.FieldByName('collateralNonTaxableAmt').asCurrency;
            actualWeeksPaidQty := dm1.uspShelterRebateData.FieldByName('sumActualWeeksPaidQty').asCurrency; //SUM( PaymentItem.actualWeeksPaidQty ) - Sum of actual weeks paid from all paymentItems for the year.
            paidOver52WeeksFlag := dm1.uspShelterRebateData.FieldByName('paidOver52WeeksFlag').asString;
            rejectionReasonDesc := dm1.uspShelterRebateData.FieldByName('rejectionReasonDesc').asString;
            Youthful_Worker := dm1.uspShelterRebateData.FieldByName('youthfulWorkerFlag').asString;
            if year(Accident_Date) < 2006 then
            begin
              workerAnnuityContributionPercent := 0;
              wcbAnnuityContributionPercent := 0;
            end;
            Wkly_Sal_A := (dm1.uspShelterRebateData.FieldByName('weeksWorked').asCurrency * dm1.uspShelterRebateData.FieldByName('fullWeeklyGrossAmt').asCurrency) / 52;
            Tot_Clmt_Anty_Elig_Earn := (No_Weeks_Paid * Total_Deds) / 52.00;
            if Accident_Date < bill25StartDate THEN
              Tot_WCB_Anty_Contib_Amt := (Comp_Wks_Pd_to_63 + dm1.uspShelterRebateData.FieldByName('pre104').asCurrency)  * Weekly_Benefit
            else
              Tot_WCB_Anty_Contib_Amt := (No_Weeks_of_Comp_Bnfts + dm1.uspShelterRebateData.FieldByName('post104').asCurrency + dm1.uspShelterRebateData.FieldByName('pre104').asCurrency) * Weekly_Benefit;
            Accum_Wks_Yr_90Net_Post := No_Weeks_of_Comp_Bnfts - Comp_Wks_Pd_to_63  + dm1.uspShelterRebateData.FieldByName('post104').asCurrency;
            If reportType = 'MULTIPLE CLAIMS' then
              doNotBatchProcessFlag := 'Y'
            else
              doNotBatchProcessFlag := 'N';
            if  Post_Injury_Earn = 0.00 then
               actualWeeksPaidQty := 0;
            No_Weeks_of_Comp_Bnfts := No_Weeks_of_Comp_Bnfts + dm1.uspShelterRebateData.FieldByName('post104').asCurrency + dm1.uspShelterRebateData.FieldByName('pre104').asCurrency;
            Comp_Wks_Pd_to_63 := Comp_Wks_Pd_to_63 + dm1.uspShelterRebateData.FieldByName('pre104').asCurrency;
            nc_104_Wk_Effective_Date := dm1.uspShelterRebateData.FieldByName('week104EffectiveDate').asDateTime;
            payeeId := dm1.uspShelterRebateData.FieldByName('payeeId').asInteger;
	        end; // end r
        except
        On e:exception do
        begin
          MessageDlg('Error loading temp table for claim ' + dm1.uspShelterRebateData.FieldByName('claimNo').asString + #10#10 + E.message,
          mtError,[mbOk], 0);
          end;
        end;
          LoadSRRecord();
          dm1.uspShelterRebateData.Next;
        end;
        Memo1.lines.add(inttostr(cntr) + ' records imported. ');
      end;
    finally
      dm1.uspShelterRebateData.Close;
    end;
end;

(******************************************************************************)
(*                                                                            *)
(*    Empty existing shelter rebate table                                     *)
(*                                                                            *)
(******************************************************************************)
function TShelterRebateLoadForm.EmptySRTable: boolean;
begin
  result:=true;
  try
    with dm1 do
    begin
      if query1.active then query1.close;
      query1.sql.clear;
      query1.sql.add('DELETE FROM dbo.WLREBDTL');
      query1.execSQL;
    end;
  except
    On e:exception do
    begin
      result := false;
      MessageDlg('Error emptying Shelter Rebate table for Wageloss System' + #10#10 + E.message,
        mtError,[mbOk], 0);
    end;
  end;
end;

(******************************************************************************)
(*                                                                            *)
(*    Load shelter rebate record from import data                             *)
(*                                                                            *)
(******************************************************************************)
procedure TShelterRebateLoadForm.LoadSRRecord();
begin
  // Create WLREBDTL record
  begin
		w.Claim_No := r.Claim_No;
		w.Claim_Suffix := r.Claim_Suffix;
		w.Clmt_Name_Initials := r.Clmnts_Surname;
		w.Tax_Year := r.Tax_Year;
		w.Marital_Status := r.Marital_Status;
		w.Spouse_Working := r.Spouse_Working;
    w.ClaimSpouseForTaxPurposes := r.ClaimSpouseForTaxPurposes;
		w.Nbr_Of_Dependants := r.No_Of_Dependnts;
		w.Nbr_Of_Infirm_Deps := r.No_Infirm;
		w.Uic_Exempt := r.EI_Exempt;
		w.Accum_Wks_Yr_PdCst := r.No_Weeks_of_Comp_Bnfts;
		w.Accum_Wks_Yr_90Net := r.Comp_Wks_Pd_to_63;
		w.Wkly_Sal := r.Original_Wkly_Sal;
		w.Wkly_Net := r.Weekly_Net;
		w.Wkly_90 := r.Weekly_90;
		w.Wkly_90_S := r.Weekly_90_S;
		w.Wkly_80 := r.Weekly_80;
		w.Annual_Gross := r.Annual_Gross;
		w.Annual_Net := r.Annual_Net;
		w.Annual_90 := r.Annual_90;
		w.Annual_90_S := r.Annual_90_S;
		w.Annual_80 := r.Annual_80;
		w.Tax_Exemption := r.Tax_Exemption;
		w.Tax_Exemption_A := r.Tax_Exemption; // not used in old version
		w.Inc_Tax_Fed := r.Inc_Tax_Fed;
		w.Inc_Tax_Prov := r.Inc_Tax_Man;
		w.Cpp_Prem := r.Cpp_Prem;
    w.Cpp2_Prem := r.Cpp2_Prem;
		w.Uic_Prem := r.EI_Prem;
		w.Total_Deds := r.Total_Deds;
		w.Wkly_Sal_A := r.Wkly_Sal_A;
		w.Total_Deds_A := r.Total_Deds;
		w.Weeks_Worked := r.No_Weeks_Paid;
		w.Wkly_Tax_S := r.Weekly_Benefit;
		w.Tax_Shelter_Deduct := r.Tot_WCB_Anty_Contib_Amt;
		w.Total_Tax_S := r.Tot_Clmt_Anty_Elig_Earn;
		w.Total_Deds_P_A := r.Tot_Clmt_Anty_Elig_Earn;
		w.Shelter_Rebate_Year := fShelterRebateYear;
    w.Prime_Firm_No := r.Prime_Firm_No;
    w.Payment_Issued_Flag := FALSE;
    w.Logical_Delete_Flag := FALSE;
    w.accident_date:=r.accident_date;
    w.Self_Employed:=r.Self_Employed;
    w.Recurrence:=r.Recurrence;
    w.Recurrence_Date := r.RecurrenceDate;
    w.CPP_Exempt:=r.CPP_Exempt;
    w.Tax_Exempt:=r.Tax_Exempt;
    w.Child_Care_Exp:=r.Child_Care_Exp;
    w.Spousal_Support:=r.Spousal_Support;
    w.Child_Support:=r.Child_Support;
    w.Max_Adjustment:=r.Max_Adjustment;
    w.Nbr_Act_Shelter_Deduct:=r.actualWeeksPaidQty;
    w.indexationYear := r.Indexation_Year;
    w.PostInjuryEarnings := r.Post_Injury_Earn;
    w.Accum_Wks_Yr_90Net_Post := r.Accum_Wks_Yr_90Net_Post;
    w.workerAnnuityContributionPercent := r.workerAnnuityContributionPercent;
    w.wcbAnnuityContributionPercent := r.wcbAnnuityContributionPercent;
    w.paidFromDate := r.Date_Pd_From_Cheq;
    w.paidToDate := r.Date_Pd_To_Cheq;
    w.employerPaidFlag := r.employerPaidFlag;
    w.collateralTaxableAmt := r.collateralTaxableAmt;
    w.collateralNonTaxableAmt := r.collateralNonTaxableAmt;
    w.paidOver52WeeksFlag := r.paidOver52WeeksFlag;
    w.rejectionReasonDesc := r.rejectionReasonDesc;
    w.reportType := r.reportType;
    w.doNotBatchProcessFlag := r.doNotBatchProcessFlag;
    w.Youthful_Worker := r.Youthful_Worker;
    w.week104EffectiveDate := r.nc_104_Wk_Effective_Date;
    w.payeeId := r.payeeId;
    if (w.reportType <> 'DISQUALIFY') AND (w.reportType <> 'MULTIPLE CLAIMS') THEN
      w := SimpleCalcBenW(w);
  end;

  // query claim info table to get firm number
  w.Prime_Firm_No := r.Prime_Firm_No;
  // load to WLREBDTL record to table
  try
    with dm1.qryWLREBDTL do
    begin
      if Active then Close;
      Open;
      insert;
      fieldByName( 'Claim_No' ).value := w.Claim_No;
      fieldByName( 'Claim_Suffix' ).value := w.Claim_Suffix;
      fieldByName( 'Clmt_Name_Initials' ).value := w.Clmt_Name_Initials;
      fieldByName( 'Tax_Year' ).value := w.Tax_Year;
      fieldByName( 'Marital_Status' ).value := w.Marital_Status;
      fieldByName( 'Spouse_Working' ).value := w.Spouse_Working;
      fieldByName( 'ClaimSpouseForTaxPurposes' ).Value := w.ClaimSpouseForTaxPurposes;
      fieldByName( 'Nbr_Of_Dependants' ).value := w.Nbr_Of_Dependants;
      fieldByName( 'Nbr_Of_Infirm_Deps' ).value := w.Nbr_Of_Infirm_Deps;
      fieldByName( 'Uic_Exempt' ).value := w.Uic_Exempt;
      fieldByName( 'Accum_Wks_Yr_PdCst' ).value := w.Accum_Wks_Yr_PdCst;
      fieldByName( 'Accum_Wks_Yr_90Net' ).value := w.Accum_Wks_Yr_90Net;
      fieldByName( 'Wkly_Sal' ).value := w.Wkly_Sal;
      fieldByName( 'Wkly_Net' ).value := w.Wkly_Net;
      fieldByName( 'Wkly_90' ).value := w.Wkly_90;
      fieldByName( 'Wkly_90_S' ).value := w.Wkly_90_S;
      fieldByName( 'Wkly_80' ).value := w.Wkly_80;
      fieldByName( 'Annual_Gross' ).value := w.Annual_Gross;
      fieldByName( 'Annual_Net' ).value := w.Annual_Net;
      fieldByName( 'Annual_90' ).value := w.Annual_90;
      fieldByName( 'Annual_90_S' ).value := w.Annual_90_S;
      fieldByName( 'Annual_80' ).value := w.Annual_80;
      fieldByName( 'Tax_Exemption' ).value := w.Tax_Exemption;
      fieldByName( 'Inc_Tax_Fed' ).value := w.Inc_Tax_Fed;
      fieldByName( 'Inc_Tax_Prov' ).value := w.Inc_Tax_Prov;
      fieldByName( 'Cpp_Prem' ).value := w.Cpp_Prem;
      fieldByName( 'Cpp2_Prem' ).value := w.Cpp2_Prem;
      fieldByName( 'Uic_Prem' ).value := w.Uic_Prem;
      fieldByName( 'Total_Deds' ).value := w.Total_Deds;
      fieldByName( 'Wkly_Sal_A' ).value := w.Wkly_Sal_A;
      fieldByName( 'Annual_Gross_A' ).value := w.Annual_Gross_A;
      fieldByName( 'Annual_Net_A' ).value := w.Annual_Net_A;
      fieldByName( 'Tax_Exemption_A' ).value := w.Tax_Exemption_A;
      fieldByName( 'Inc_Tax_Fed_A' ).value := w.Inc_Tax_Fed_A;
      fieldByName( 'Inc_Tax_Prov_A' ).value := w.Inc_Tax_Prov_A;
      fieldByName( 'Cpp_Prem_A' ).value := w.Cpp_Prem_A;
      fieldByName( 'Cpp2_Prem_A' ).value := w.Cpp2_Prem_A;
      fieldByName( 'Uic_Prem_A' ).value := w.Uic_Prem_A;
      fieldByName( 'Tax_Shelter_Bnft' ).value := w.Tax_Shelter_Bnft;
      fieldByName( 'Tax_Shelter_Deduct' ).value := w.Tax_Shelter_Deduct;
      fieldByName( 'Rebate_Amount' ).value := w.Rebate_Amount;
      fieldByName( 'Weeks_Worked' ).value := w.Weeks_Worked;
      fieldByName( 'Wkly_Tax_S' ).value := w.Wkly_Tax_S;
      fieldByName( 'Total_Deds_A' ).value := w.Total_Deds_A;
      fieldByName( 'Total_Tax_S' ).value := w.Total_Tax_S;
      fieldByName( 'Total_Deds_P_A' ).value := w.Total_Deds_P_A;
      fieldByName( 'Shelter_Rebate_Year' ).value := w.Shelter_Rebate_Year;
      fieldByName( 'Prime_Firm_No' ).value := w.Prime_Firm_No;
      fieldByName( 'Payment_Issued_Flag' ).value := w.Payment_Issued_Flag;
      fieldByName( 'Logical_Delete_Flag' ).value := w.Logical_Delete_Flag;
      fieldByName( 'accident_date' ).value := w.Accident_Date;
      fieldByName( 'self_employed' ).value := w.Self_Employed;
      fieldByName( 'recurrence' ).value := w.Recurrence;
      fieldByName( 'child_care_expense' ).value := w.Child_Care_Exp;
      fieldByName( 'spousal_support' ).value := w.Spousal_Support;
      fieldByName( 'child_support' ).value := w.Child_Support;
      fieldByName( 'cpp_exempt' ).value := w.CPP_Exempt;
      fieldByName( 'income_tax_exempt' ).value := w.Tax_Exempt;
      fieldByName( 'post_injury_earnings' ).value := w.PostInjuryEarnings;
      fieldByName( 'no_of_actual_shelter_deduc' ).value := w.Nbr_Act_Shelter_Deduct;
      fieldByName( 'Recurrence_Date' ).value := formatdatetime('mmm/dd/yyyy',w.Recurrence_Date);
      fieldByName( 'Youthful_Worker' ).value := w.Youthful_Worker;
      fieldByName( 'Accum_Wks_Yr_90Net_Post' ).value := w.Accum_Wks_Yr_90Net_Post;
      fieldByName( 'workerAnnuityContributionPcnt' ).value := w.workerAnnuityContributionPercent;
      fieldByName( 'wcbAnnuityContributionPercent' ).value := w.wcbAnnuityContributionPercent;
      fieldByName( 'workerShetlerAnnuityContribAmt' ).value := w.workerShetlerAnnuityContribAmt;
      fieldByName( 'wcbShelterAnnuityContribAmt' ).value := w.wcbShelterAnnuityContribAmt;
      fieldByName( 'paidFromDate' ).value := w.paidFromDate;
      fieldByName( 'paidToDate' ).value := w.paidToDate;
      fieldByName( 'employerPaidFlag' ).value := w.employerPaidFlag;
      fieldByName( 'indexedYear' ).value := w.indexationYear;
      fieldByName( 'maximumAdjustmentAmt' ).value := w.Max_Adjustment;
      fieldByName( 'reportType' ).value := w.reportType;
      fieldByName( 'collateralTaxableAmt' ).value := w.collateralTaxableAmt;
      fieldByName( 'collateralNonTaxableAmt' ).value := w.collateralNonTaxableAmt;
      fieldByName( 'paidOver52WeeksFlag' ).value := w.paidOver52WeeksFlag;
      fieldByName( 'rejectionReasonDesc' ).value := w.rejectionReasonDesc;
      fieldByName( 'doNotBatchProcessFlag' ).value := w.doNotBatchProcessFlag;
      fieldByName( 'week104EffectiveDate' ).value := w.week104EffectiveDate;
      fieldByName( 'payeeId' ).value := w.payeeId;
      UpdateBatch(arAll);
      //ApplyUpdates;
    end;
  except
    On e:exception do
    begin
      MessageDlg('Error inserting into Shelter Rebate table for Wageloss System' + ' for claim ' + w.Claim_No + #10#10 + E.message,
        mtError,[mbOk], 0);
    end;
  end;
end;

procedure SimpleCalcBen(r2:RecNCClaim);
begin
	Calc_Ben(r2 ,fWorking);
  r := r2;
end;

function SimpleCalcBenW(w2:recWLREBDTL): recWLREBDTL;
begin
	uglobal.SetUpAndRecalcBen(w2, w2.PostInjuryEarnings > 0, w2.Nbr_Act_Shelter_Deduct);
  result := w2;
end;

end.


