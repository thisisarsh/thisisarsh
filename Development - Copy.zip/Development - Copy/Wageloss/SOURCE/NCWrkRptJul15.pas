unit NCWrkRptJul15;

interface

uses
  Windows, Messages, SysUtils, Variants, Classes, Graphics, Controls, Forms,
  Dialogs, StrUtils, NCWrkRptJan15;
type
  TWrkRptJul15 = class(TWrkRptJan15)
  function getDateHeading():String; Override;
  private
    { Private declarations }
  public
    { Public declarations }
  end;

var
  WrkRptJul15: TWrkRptJul15;

implementation

uses NCWrkRpt;

{$R *.dfm}

{ TWrkRptJul15 }
(******************************************************************************)
(*                                                                            *)
(*  override this function for each class to avoid having to bring in all of  *)
(*    the methods that contain the date in the heading.                       *)
(*   IE:  the jan 09 class should return  2008/2009                           *)
(*        the july 09 class should return 2009                                *)
(*                                                                            *)
(******************************************************************************)

function TWrkRptJul15.getDateHeading: String;
begin
  Result:='2015'
end;

end.
