inherited WrkRptJul09: TWrkRptJul09
  Left = 320
  Top = 160
  Caption = 'WrkRptJul09'
  PixelsPerInch = 96
  TextHeight = 13
end
