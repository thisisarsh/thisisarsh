object WrkRptJul26: TWrkRptJul26
  Left = 0
  Top = 0
  Caption = 'WrkRptJul26'
  ClientHeight = 441
  ClientWidth = 624
  Color = clBtnFace
  Font.Charset = DEFAULT_CHARSET
  Font.Color = clWindowText
  Font.Height = -12
  Font.Name = 'Segoe UI'
  Font.Style = []
  TextHeight = 15
end
