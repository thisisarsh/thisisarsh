object WrkRptJan14: TWrkRptJan14
  Left = 303
  Top = 193
  Width = 1142
  Height = 656
  Caption = 'WrkRptJan14'
  Color = clBtnFace
  Font.Charset = DEFAULT_CHARSET
  Font.Color = clWindowText
  Font.Height = -11
  Font.Name = 'MS Sans Serif'
  Font.Style = []
  OldCreateOrder = False
  PixelsPerInch = 96
  TextHeight = 13
end
