inherited WrkRptJan12: TWrkRptJan12
  Caption = 'WrkRptJan12'
  PixelsPerInch = 96
  TextHeight = 13
end
