inherited WrkRptJan16: TWrkRptJan16
  Caption = 'WrkRptJan16'
  PixelsPerInch = 96
  TextHeight = 13
end
