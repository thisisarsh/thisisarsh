unit NCWrkRptJul02;

interface

uses NCWrkRptJan02;

type
  TWrkRptJul02 = class(TWrkRptJan02)
  private
    { Private declarations }
  public
    { Public declarations }
  end;

var
  WrkRptJul02: TWrkRptJul02;

implementation

{$R *.DFM}

end.
