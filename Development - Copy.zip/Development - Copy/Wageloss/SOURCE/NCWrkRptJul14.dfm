object WrkRptJul14: TWrkRptJul14
  Left = 270
  Top = 193
  Width = 1088
  Height = 625
  Caption = 'WrkRptJul14'
  Color = clBtnFace
  Font.Charset = DEFAULT_CHARSET
  Font.Color = clWindowText
  Font.Height = -11
  Font.Name = 'MS Sans Serif'
  Font.Style = []
  OldCreateOrder = False
  PixelsPerInch = 96
  TextHeight = 13
end
