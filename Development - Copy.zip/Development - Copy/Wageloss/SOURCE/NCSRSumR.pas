(******************************************************************************)
(*  Wageloss System                                                           *)
(*                                                                            *)
(*  Shelter Rebate Summary Reports                                            *)
(*                                                                            *)
(*                                                                            *)
(*  Author: Brad Trupp  / Capella Systems Group, Inc.                         *)
(*  Date:   October 1998                                                      *)
(*                                                                            *)
(******************************************************************************)

unit NCSRSumR;

interface

uses
  Windows, Messages, SysUtils, Classes, Graphics, Controls, Forms, Dialogs,
  Qrctrls, QuickRpt, ExtCtrls, Db, Data.Win.ADODB; //DBTables,

type

  iSRSummaryReportType = ( i2Single, i2BySuffixClaimAllClaims, i2BySuffixClaimRebatesOnly, i2BysuffixClaimNoRebate );

  TShelterRebateSummaryForm = class(TForm)
    QRShelterRebateSummaryReport: TQuickRep;
    QRBand1: TQRBand;
    QRSysData2: TQRSysData;
    QRSysData1: TQRSysData;
    QRSysData3: TQRSysData;
    QRUserID: TQRLabel;
    QRLabel1: TQRLabel;
    QRLabel2: TQRLabel;
    QRSysData4: TQRSysData;
    QRBand2: TQRBand;
    QRlblSuffix: TQRLabel;
    QRlblClaim: TQRLabel;
    QRlblName: TQRLabel;
    QRlblAmount: TQRLabel;
    QRLabel3: TQRLabel;
    QRLabel4: TQRLabel;
    QRLabel5: TQRLabel;
    QRLabel6: TQRLabel;
    QRLabel7: TQRLabel;
    QRLabel8: TQRLabel;
    QRLabel9: TQRLabel;
    QRBand3: TQRBand;
    QRLabel10: TQRLabel;
    QRlblRecCount: TQRLabel;
    QRLabel11: TQRLabel;
    QRlbTotalAmount: TQRLabel;
    QRQuery1: TADOQuery;
    procedure QRShelterRebateSummaryReportBeforePrint(Sender: TCustomQuickRep; var PrintReport: Boolean);
    procedure QRShelterRebateSummaryReportNeedData(Sender: TObject;
  var MoreData: Boolean);
    procedure QRBand2BeforePrint(Sender: TQRCustomBand;
      var PrintBand: Boolean);
  private
    { Private declarations }
    cntr: integer;
    TotalAmount: currency;
    procedure SelectClaimsBySingle;
    procedure SelectClaimsBySuffixClaimAllClaims;
    procedure SelectClaimsBySuffixClaimRebatesOnly;
    procedure SelectClaimsBySuffixClaimNoRebates;
  public
    { Public declarations }
    fSRSummaryReportType: iSRSummaryReportType;
  end;

var
  ShelterRebateSummaryForm: TShelterRebateSummaryForm;

implementation

uses NCDatMod, NCMain, uADOSecurity;

{$R *.DFM}


(******************************************************************************)
(*                                                                            *)
(*    Before Print - get all data for reporting                               *)
(*                                                                            *)
(******************************************************************************)
procedure TShelterRebateSummaryForm.QRShelterRebateSummaryReportBeforePrint(
  Sender: TCustomQuickRep; var PrintReport: Boolean);
begin
    Cntr:=0;
    TotalAmount:=0.0;
    // make additional changes
    QRUserID.caption := userProfile.givenName + ' ' + userProfile.familyName;
    case fSRSummaryReportType of
        i2Single:
        begin
            QRShelterRebateSummaryReport.reportTitle:='Summary Report - Individual';
            QRBand3.Enabled:=false;
            SelectClaimsBySingle;
        end;
        i2BySuffixClaimAllClaims:
        begin
            QRShelterRebateSummaryReport.reportTitle:='Summary Report - by Suffix and Claim - All Claims';
            SelectClaimsBySuffixClaimAllClaims;
        end;
        i2BySuffixClaimRebatesOnly:
        begin
            QRShelterRebateSummaryReport.reportTitle:='Summary Report - by Suffix and Claim - Rebates Only';
            SelectClaimsBySuffixClaimRebatesOnly;
        end;
        i2BySuffixClaimNoRebate:
        begin
            QRShelterRebateSummaryReport.reportTitle:='Summary Report - by Suffix and Claim - Not Receiving Rebates';
            SelectClaimsBySuffixClaimNoRebates;
        end;
    end;
end;

(******************************************************************************)
(*                                                                            *)
(*     Need Data - process individual records                                 *)
(*                                                                            *)
(******************************************************************************)
procedure TShelterRebateSummaryForm.QRShelterRebateSummaryReportNeedData(
  Sender: TObject; var MoreData: Boolean);
begin
    MoreData := not QRQuery1.eof;
    if not MoreData then
    begin
        WagelossMainForm.ShowInfoLine1('Report complete - ' + intToStr( Cntr ) + ' Records.');
        QRlblRecCount.caption:= format('%d', [ Cntr ] );
        QRlbTotalAmount.caption:= format('%.2n', [ TotalAmount ] );
    end
    else
    begin
        inc(Cntr);
        WagelossMainForm.ShowInfoLine1('Records Processed: ' + intToStr( Cntr ) + '.');
        QRlblSuffix.caption := QRQuery1.fieldbyname('Claim_Suffix').asString;
        QRlblClaim.caption := QRQuery1.fieldbyname('Claim_No').asString;
        QRlblName.caption := QRQuery1.fieldbyname('Clmt_Name_Initials').asString;
        QRlblAmount.caption := format('%.2n', [
        QRQuery1.fieldbyname('Rebate_Amount').asFloat
        ] );
        TotalAmount:=TotalAmount + QRQuery1.fieldbyname('Rebate_Amount').asFloat;
    end;
    QRQuery1.next;
end;

(******************************************************************************)
(*                                                                            *)
(*    Select all claims in suffix/claim number order                          *)
(*                                                                            *)
(******************************************************************************)
procedure TShelterRebateSummaryForm.SelectClaimsBySuffixClaimAllClaims;
begin
  try
    with dm1 do
    begin
      if QRQuery1.active then QRQuery1.close;
      QRQuery1.sql.clear;
      QRQuery1.sql.add('SELECT Claim_No, Claim_Suffix, Clmt_Name_Initials, Rebate_Amount ');
      QRQuery1.sql.add('  FROM dbo.WLREBDTL');
      QRQuery1.sql.add('  WHERE Logical_Delete_Flag <> ''Y'' ');
      QRQuery1.sql.add('  AND reportType <> ''DISQUALIFY'' ');
      QRQuery1.sql.add('  ORDER BY Claim_Suffix, Claim_No');
      QRQuery1.open;
      QRQuery1.first;
    end;
  finally
  ;
  end;
end;

(******************************************************************************)
(*                                                                            *)
(*    Select all claims in suffix/claim order - rebates only                  *)
(*                                                                            *)
(******************************************************************************)
procedure TShelterRebateSummaryForm.SelectClaimsBySuffixClaimRebatesOnly;
begin
  try
    with dm1 do
    begin
      if QRQuery1.active then QRQuery1.close;
      QRQuery1.sql.clear;
      QRQuery1.sql.add('SELECT Claim_No, Claim_Suffix, Clmt_Name_Initials, Rebate_Amount ');
      QRQuery1.sql.add('  FROM dbo.WLREBDTL');
      QRQuery1.sql.add('  WHERE Logical_Delete_Flag <> ''Y'' ');
      QRQuery1.sql.add('  AND reportType <> ''DISQUALIFY'' ');
      QRQuery1.sql.add('  AND Rebate_Amount <> 0');
      QRQuery1.sql.add('  ORDER BY Claim_Suffix, Claim_No');
      QRQuery1.open;
      QRQuery1.first;
    end;
  finally
  ;
  end;
end;

(******************************************************************************)
(*                                                                            *)
(*    Select an individual claim                                              *)
(*                                                                            *)
(******************************************************************************)
procedure TShelterRebateSummaryForm.SelectClaimsBySingle;
var
   clm: string;
begin
  try
    with dm1 do
    begin
      clm := query2.fieldbyname('Claim_No').asString;
      if QRQuery1.active then QRQuery1.close;
      QRQuery1.sql.clear;
      QRQuery1.sql.add('SELECT Claim_No, Claim_Suffix, Clmt_Name_Initials, Rebate_Amount ');
      QRQuery1.sql.add('  FROM dbo.WLREBDTL where Claim_No = ''' + clm + '''');
      QRQuery1.open;
      QRQuery1.first;
    end;
  finally
  ;
  end;
end;

(******************************************************************************)
(*                                                                            *)
(*    Select all claims in suffix/claim no order - no rebates                 *)
(*                                                                            *)
(******************************************************************************)
procedure TShelterRebateSummaryForm.SelectClaimsBySuffixClaimNoRebates;
begin
  try
    with dm1 do
    begin
      if QRQuery1.active then QRQuery1.close;
      QRQuery1.sql.clear;
      QRQuery1.sql.add('SELECT Claim_No, Claim_Suffix, Clmt_Name_Initials, Rebate_Amount ');
      QRQuery1.sql.add('  FROM dbo.WLREBDTL');
      QRQuery1.sql.add('  WHERE Logical_Delete_Flag <> ''Y'' ');
      QRQuery1.sql.add('  AND reportType <> ''DISQUALIFY'' ');
      QRQuery1.sql.add('  AND Rebate_Amount = 0');
      QRQuery1.sql.add('  ORDER BY Claim_Suffix, Claim_No');
      QRQuery1.open;
      QRQuery1.first;
    end;
  finally
  ;
  end;
end;

procedure TShelterRebateSummaryForm.QRBand2BeforePrint(
  Sender: TQRCustomBand; var PrintBand: Boolean);
var
  i : Integer;
begin
  with QRBand2 do
  begin
    if Color = $00F0F0F0 then
      Color := $00E0E0E0
    else
      Color := $00F0F0F0;
    for i := 0 to ControlCount-1 do
    begin
       TQRLabel(Controls[i]).Color := Color;
    end;
  end;
end;

end.
