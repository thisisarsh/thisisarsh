// ************************************************************************ //
// The types declared in this file were generated from data read from the
// WSDL File described below:
// WSDL     : http://wcbtap1/emerge/services/PaymentsWebService/wsdl/PaymentsWebService.wsdl
// Encoding : UTF-8
// Codegen  : [wfDebug,wfUseSerializerClassForAttrs]
// Version  : 1.0
// (23/10/2007 11:39:25 AM - 1.33.2.5)
// ************************************************************************ //

unit uPaymentsWebService;

interface

uses InvokeRegistry, SOAPHTTPClient, Types, XSBuiltIns;

type

  // ************************************************************************ //
  // The following types, referred to in the WSDL document are not being represented
  // in this file. They are either aliases[@] of other types represented or were referred
  // to but never[!] declared in the document. The types from the latter category
  // typically map to predefined/known XML or Borland types; however, they could also 
  // indicate incorrect WSDL documents that failed to declare or import a schema type.
  // ************************************************************************ //
  // !:int             - "http://www.w3.org/2001/XMLSchema"
  // !:string          - "http://www.w3.org/2001/XMLSchema"



  // ************************************************************************ //
  // Namespace : http://payments.webservices.ejb.emerge.wcb.mb.ca
  // soapAction: %operationName%
  // transport : http://schemas.xmlsoap.org/soap/http
  // style     : document
  // binding   : PaymentsWebServiceSoapBinding
  // service   : PaymentsWebServiceService
  // port      : PaymentsWebService
  // URL       : http://wcbtap1:80/emerge/services/PaymentsWebService
  // ************************************************************************ //
  PaymentsWebService = interface(IInvokable)
  ['{6B5EB268-2777-5EF8-A467-C99218CEDE77}']
    function  checkWageLossAuthorization(const aClaimNo: Integer; const aRequestedAmt: WideString; const aLoginName: WideString; const aRequestDate: WideString; const aOverpaymentAccountId: Integer; const aTotalOutstandingAmt: WideString): WideString; stdcall;
    function  getStatus: WideString; stdcall;
    function  getWebServiceName: WideString; stdcall;
  end;

function GetPaymentsWebService(UseWSDL: Boolean=System.False; Addr: string=''; HTTPRIO: THTTPRIO = nil): PaymentsWebService;


implementation

function GetPaymentsWebService(UseWSDL: Boolean; Addr: string; HTTPRIO: THTTPRIO): PaymentsWebService;
const
  defWSDL = 'http://wcbtap1/emerge/services/PaymentsWebService/wsdl/PaymentsWebService.wsdl';
  defURL  = 'http://wcbtap1:80/emerge/services/PaymentsWebService';
  defSvc  = 'PaymentsWebServiceService';
  defPrt  = 'PaymentsWebService';
var
  RIO: THTTPRIO;
begin
  Result := nil;
  if (Addr = '') then
  begin
    if UseWSDL then
      Addr := defWSDL
    else
      Addr := defURL;
  end;
  if HTTPRIO = nil then
    RIO := THTTPRIO.Create(nil)
  else
    RIO := HTTPRIO;
  try
    Result := (RIO as PaymentsWebService);
    if UseWSDL then
    begin
      RIO.WSDLLocation := Addr;
      RIO.Service := defSvc;
      RIO.Port := defPrt;
    end else
      RIO.URL := Addr;
  finally
    if (Result = nil) and (HTTPRIO = nil) then
      RIO.Free;
  end;
end;


initialization
  InvRegistry.RegisterInterface(TypeInfo(PaymentsWebService), 'http://payments.webservices.ejb.emerge.wcb.mb.ca', 'UTF-8');
  InvRegistry.RegisterDefaultSOAPAction(TypeInfo(PaymentsWebService), '%operationName%');
  InvRegistry.RegisterInvokeOptions(TypeInfo(PaymentsWebService), ioDocument);

end.