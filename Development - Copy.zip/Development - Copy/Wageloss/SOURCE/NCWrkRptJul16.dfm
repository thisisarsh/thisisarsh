inherited WrkRptJul16: TWrkRptJul16
  Left = 432
  Top = 213
  Caption = 'WrkRptJul16'
  PixelsPerInch = 96
  TextHeight = 13
end
