unit NCWrkRptJan02;

interface

uses NCWrkRptJan01, quickrpt, SysUtils;

type
  TWrkRptJan02 = class(TWrkRptJan01)
  procedure ExcemptionAndCreditAmountBand1; Override;
  procedure TaxCalculationBand1( const income: currency; sIncomeType: shortstring ); Override;
  Function TaxCalculationBand1P3( Nc_Bc_Ann_Sal_Net: currency;
                                   Nc_Bc_Nrtc: currency): currency; Override;
  procedure TaxCalculationBand1P7( Nc_Bc_Ann_Sal_Net: currency;
  																 Nc_Bc_Mb_Tax: currency;
                                   Disp_a: currency;
                                   Disp_b: currency); Override;
  Function TaxCalculationBand1P5b( Nc_Bc_Ann_Sal_Net: currency;
                                               Nc_Bc_Mb_Nrtc: currency;
                                               Nc_Bc_Mbt: currency): currency; Override;
  private
    { Private declarations }
  public
    { Public declarations }
  end;

var
  WrkRptJan02: TWrkRptJan02;

implementation

uses NCIniMod, UtilMod1, NCBencal;

{$R *.DFM}

(******************************************************************************)
(*                                                                            *)
(*  Create Tax Exemption and Credits band                                     *)
(*                                                                            *)
(******************************************************************************)
procedure TWrkRptJan02.ExcemptionAndCreditAmountBand1;
begin
  ExcemptionAndCreditAmountBand1P1;
  ExcemptionAndCreditAmountBand1P2;
end;

(******************************************************************************)
(*                                                                            *)
(*  Create Tax Calculation Band                                               *)
(*                                                                            *)
(******************************************************************************)
procedure TWrkRptJan02.TaxCalculationBand1( const income: currency;
																						sIncomeType: shortstring );
var
  t2: currency;
  a: currency;
  b: currency;
  ws_Work_nc_bc_ann_sal_net:currency;
  ws_Work_nc_bc_bft:currency;
  ws_Work_nc_bc_cpp:currency;
  ws_Work_nc_bc_uic:currency;
  ws_Work_nc_bc_nrtc:currency;
  ws_Work_nc_bc_fst:currency;
  ws_Work_nc_bc_mbt:currency;
  ws_Work_nc_bc_mb_nrtc:currency;
  ws_Work_nc_bc_mb_tax:currency;
  ws_Work_nc_bc_netinc:currency;
  ws_Work_nc_bc_td:currency;
  //federalCanadaEmploymentCredit:currency;
  mbFamilyTaxBenefitRate:currency;
begin
  ws_Work_nc_bc_ann_sal_net := Set_nc_bc_ann_sal_net(sIncomeType);
  ws_Work_nc_bc_bft					:= Set_nc_bc_bft(sIncomeType);
  ws_Work_nc_bc_cpp					:= Set_nc_bc_cpp(sIncomeType);
  ws_Work_nc_bc_uic					:= Set_nc_bc_uic(sIncomeType);
  ws_Work_nc_bc_nrtc				:= Set_nc_bc_nrtc(sIncomeType);
  ws_Work_nc_bc_fst					:= Set_nc_bc_fst(sIncomeType);
  ws_Work_nc_bc_mbt					:= Set_nc_bc_mbt(sIncomeType);
  ws_Work_nc_bc_mb_nrtc			:= Set_nc_bc_mb_nrtc(sIncomeType);
  ws_Work_nc_bc_mb_tax			:= Set_nc_bc_mb_tax(sIncomeType);
  ws_Work_nc_bc_netinc			:= Set_nc_bc_netinc(sIncomeType);
  ws_Work_nc_bc_td					:= Set_nc_bc_td(sIncomeType);
  //federalCanadaEmploymentCredit := Set_federalCanadaEmploymentCredit(sIncomeType);
  mbFamilyTaxBenefitRate    := Set_mbFamilyTaxBenefitAmt(sIncomeType);
  TaxCalculationBand1P1(income, sIncomeType, ws_Work_nc_bc_ann_sal_net);
  //TaxCalculationBand1P2(income, ws_Work_nc_bc_ann_sal_net,
  //                      ws_Work_nc_bc_uic, ws_Work_nc_bc_cpp,
  //                      ws_Work_nc_bc_nrtc, ws_Work_nc_bc_mb_nrtc, federalCanadaEmploymentCredit);
  TaxCalculationBand1P2(income, ws_Work_nc_bc_ann_sal_net,
                        ws_Work_nc_bc_uic, ws_Work_nc_bc_cpp,
                        ws_Work_nc_bc_nrtc, ws_Work_nc_bc_mb_nrtc, mbFamilyTaxBenefitRate);
  t2 := TaxCalculationBand1P3(ws_Work_nc_bc_ann_sal_net, ws_Work_nc_bc_nrtc);
  a := TaxCalculationBand1P5b(ws_Work_nc_bc_ann_sal_net,
                              ws_Work_nc_bc_mb_nrtc,
                              ws_Work_nc_bc_mbt);
  b := TaxCalculationBand1P6(ws_Work_nc_bc_ann_sal_net);
  TaxCalculationBand1P7(ws_Work_nc_bc_ann_sal_net, ws_Work_nc_bc_mb_tax, a, b);
  TaxCalculationBand1P8(ws_Work_nc_bc_cpp, ws_Work_nc_bc_uic, t2);
  TaxCalculationBand1P10(income, sIncomeType, ws_Work_nc_bc_mb_tax, ws_Work_nc_bc_td,
                         ws_Work_nc_bc_cpp, ws_Work_nc_bc_uic, ws_Work_nc_bc_bft,
                         ws_Work_nc_bc_fst, ws_Work_nc_bc_netinc, ws_Work_nc_bc_mbt);
end;

Function TWrkRptJan02.TaxCalculationBand1P3(Nc_Bc_Ann_Sal_Net: currency;
                                             Nc_Bc_Nrtc: currency): currency;
Var
  const1: currency;
  const2: currency;
  const3: currency;
  f1i: currency;
  f2p: currency;
  work: currency;
Begin
  with arrayNCTAXRAT[indexNCTAXRAT] do
    begin
    sRpt.add('    +'+ dash(76) + '+');
    sRpt.add( format('    | %-28s | %-20s | %-20s |', [
      'Taxable Income Amount',
      'Rate',
      'Constant'
      ]));
    sRpt.add('    +'+ dash(76) + '+');
    sRpt.add( format('    | %-28s | %-20s | %-20s |', [
      format('%.0n',[FED_income_level_i]) + ' or less',
      format('%.1n',[(FED_tax_rate_i*100.00)]) + '%',
      format('%.0n',[0.00])
      ]));

    const1 := Round((FED_income_level_i * (FED_tax_rate_ii - FED_tax_rate_i)) * 100) / 100;
    const2 := Round((FED_income_level_ii * (FED_tax_rate_iii - FED_tax_rate_ii)
              + const1)* 100) / 100;
    const3 := Round((FED_income_level_iii * (FED_tax_rate_iiii - FED_tax_rate_iii)
              + const2) * 100) / 100;

    sRpt.add( format('    | %-28s | %-20s | %-20s |', [
      '> ' + format('%.0n',[FED_income_level_i]),
      format('%.1n',[(FED_tax_rate_ii*100.00)]) + '%',
      format('%.0n',[const1])
      ]));

    sRpt.add( format('    | %-28s | %-20s | %-20s |', [
      '> ' + format('%.0n',[FED_income_level_ii]),
      format('%.1n',[(FED_tax_rate_iii*100.00)]) + '%',
      format('%.0n',[const2])
      ]));
    sRpt.add( format('    | %-28s | %-20s | %-20s |', [
      '> ' + format('%.0n',[FED_income_level_iii]),
      format('%.1n',[(FED_tax_rate_iiii*100.00)]) + '%',
      format('%.0n',[const3])
      ]));
    sRpt.add('    +'+ dash(76) + '+');
    sRpt.add(' ');
    sRpt.add('Federal Income Tax:');
    sRpt.add(' ');
    sRpt.add('    For ' + formatF(Nc_Bc_Ann_Sal_Net, 11, 2 ) +' (Amount (LK) above):' );

    if ( Nc_Bc_Ann_Sal_Net > FED_income_level_iii ) then
       begin
       f2p := FED_tax_rate_iiii;
       f1i := const3;
       end
    else if ( Nc_Bc_Ann_Sal_Net > FED_income_level_ii ) then
       begin
       f2p := FED_tax_rate_iii;
       f1i := const2;
       end
    else if ( Nc_Bc_Ann_Sal_Net > FED_income_level_i ) then
       begin
       f2p := FED_tax_rate_ii;
       f1i := const1;
       end
    else
       begin
       f2p := FED_tax_rate_i;
       f1i := 0.00;
       end;
    end;


  if (wrkClaim.Claim_No = '00000000') Then
     begin
     f2p := 0; // set the tax rate to be a blank
     end;

  sRpt.add(' ');
  sRpt.add( format('%-56s %-14s %-14s', [
    '    Multiply by tax rate from above table ' + format('%.2n',[f2p * 100]){FormatF((f2p * 100), 5, 1)} + '%',
    formatF((Nc_Bc_Ann_Sal_Net * f2p), 12, 2 ), ' '
    ] ));
  sRpt.add(' ');
  sRpt.add( format('%-56s %-14s %-14s', [
    '    Less:  Constant from above table',
    formatF(f1i, 12, 2 ), ' '
    ] ));
  work := (Nc_Bc_Ann_Sal_Net * f2p) - f1i;
  if work < 0 then work := 0.00;
  sRpt.add( format('%-56s %-14s %-14s', [ ' ',  dash(12), ' '       ]));
  sRpt.add( format('%-56s %-14s %-14s', [
    '    Federal Income Tax ',
    formatF( work, 12, 2 ),
    ' (N)'
    ] ));
  sRpt.add(' ');
  if (wrkClaim.Claim_No <> '00000000') Then
     sRpt.add( format('%-56s %-14s %-14s', [
         '    Less: Non Refundable Tax Credit (L) above ',
         formatF( Nc_Bc_Nrtc, 12, 2 ),
         ' '
         ] ))
  else
     sRpt.add( format('%-56s %-14s %-14s', [
         '    Less: Non Refundable Tax Credit (L) above ',
         formatF(0.00, 12, 2 ),
         ' '
         ] ));
  result := ((Nc_Bc_Ann_Sal_Net * f2p) - f1i) - Nc_Bc_Nrtc;
  if result < 0 then result := 0;
  sRpt.add( format('%-56s %-14s %-14s', [ ' ',  dash(12), ' '       ]));
  sRpt.add( format('%-56s %-14s %-14s', [
    '    Basic Federal Tax ',
    formatf( result, 12, 2),
    ' (O)'
    ] ));
  sRpt.add( format('%-56s %-14s %-14s', [ ' ', dDash(12), ' '       ]));
  sRpt.add(' ');
End;

procedure TWrkRptJan02.TaxCalculationBand1P7( Nc_Bc_Ann_Sal_Net: currency;
  																 						Nc_Bc_Mb_Tax: currency;
                                   						Disp_a: currency;
                                   						Disp_b: currency);
Var
	t: currency;
Begin
  t:= fworking.Work_nc_iii_credit - Disp_b;
  if t < 0 then t:=0;
  if (wrkClaim.Claim_No <> '00000000') Then
     sRpt.add( format('%-56s %-14s %-14s', [
         'Manitoba Tax Reduction Amount (H)',
         formatF( fworking.Work_nc_iii_credit, 12, 2 ),
         ' '
         ]))
  else
     sRpt.add( format('%-56s %-14s %-14s', [
         'Manitoba Tax Reduction Amount (H)',
         formatF(0.00, 12, 2 ),
         ' '
         ]));
  sRpt.add('Less: ');

  if (wrkClaim.Claim_No <> '00000000') Then
     sRpt.add( format('%-70s  %-14s (T)', [
         'Manitoba Net Income tax (LK) above ' +
         formatF( Nc_Bc_Ann_Sal_Net, 12, 2 ) + ' x ' +
         format( '%.2n', [ ( arrayNCTAXRAT[indexNCTAXRAT].MB_net_tax_rate * 100.00 ) ] ) + '% =' +
         formatF( Disp_b, 12, 2 ),
         formatF( t, 12, 2 )
         ]))
  else
     sRpt.add( format('%-70s  %-14s (T)', [
         'Manitoba Net Income tax (LK) above ' +
         formatF(Nc_Bc_Ann_Sal_Net, 12, 2 ) + ' x ' +
         format('%.2n', [ ( arrayNCTAXRAT[indexNCTAXRAT].MB_net_tax_rate * 100.00 ) ] ) + '% =' +
         formatF(Disp_b, 12, 2 ),
         formatF(0.00, 12, 2 )
         ]));

  sRpt.add( format('%-56s %-14s %-14s', [ ' ',Dash(12) , Dash(12) ]));
  sRpt.add( format('%-56s %-14s %-14s (U)', [
    '    Manitoba Tax ( amount R minus T ) ',
    ' ',
    formatF( Nc_Bc_Mb_Tax, 12, 2 )
    ] ));
End;

Function  TWrkRptJan02.TaxCalculationBand1P5b( Nc_Bc_Ann_Sal_Net: currency;
                                               Nc_Bc_Mb_Nrtc: currency;
                                               Nc_Bc_Mbt: currency): currency;
var
  const1, const2, f2p, f1i, work: currency;
begin
  sRpt.add(' ');
  sRpt.add(formatI(wrkClaim.Tax_Year,4) + ' Manitoba Income Tax Rates (WCB):');
  sRpt.add(' ');
  with arrayNCTAXRAT[indexNCTAXRAT] do
    begin
    sRpt.add('    +'+ dash(76) + '+');
    sRpt.add( format('    | %-28s | %-20s | %-20s |', [
      'Taxable Income Amount',
      'Rate',
      'Constant'
      ]));
    sRpt.add('    +'+ dash(76) + '+');
    sRpt.add( format('    | %-28s | %-20s | %-20s |', [
      format('%.0n',[MB_income_level_i]) + ' or less',
      format('%.1n',[(MB_tax_rate_i*100.00)]) + '%',
      format('%.0n',[0.00])
      ]));
    const1 := Round(MB_income_level_i * (MB_tax_rate_ii - MB_tax_rate_i));
    sRpt.add( format('    | %-28s | %-20s | %-20s |', [
      '> ' + format('%.0n',[MB_income_level_i]),
      format('%.1n',[(MB_tax_rate_ii*100.00)]) + '%',
      format('%.0n',[const1])
      ]));
    const2 := Round(MB_income_level_ii * (MB_tax_rate_iii - MB_tax_rate_ii)
      + const1);
    sRpt.add( format('    | %-28s | %-20s | %-20s |', [
      '> ' + format('%.0n',[MB_income_level_ii]),
      format('%.1n',[(MB_tax_rate_iii*100.00)]) + '%',
      format('%.0n',[const2])
      ]));
    sRpt.add('    +'+ dash(76) + '+');
    sRpt.add(' ');
    sRpt.add('Manitoba Income Tax:');
    sRpt.add(' ');
    sRpt.add('    For ' + formatF(Nc_Bc_Ann_Sal_Net, 11, 2 ) +' (Amount (LK) above):' );

    if ( Nc_Bc_Ann_Sal_Net > MB_income_level_ii ) then
       begin
       f2p:=MB_tax_rate_iii;
       f1i:=const2;
       end
    else if ( Nc_Bc_Ann_Sal_Net > MB_income_level_i ) then
       begin
       f2p:=MB_tax_rate_ii;
       f1i:=const1;
       end
    else
       begin
       f2p:=MB_tax_rate_i;
       f1i:=0.0;
       end;
    end;

  if (wrkClaim.Claim_No = '00000000') Then
     begin
     f2p := 0; // set the tax rate to be a blank
     end;


  sRpt.add(' ');
  sRpt.add( format('%-56s %-14s %-14s', [
    '    Multiply by tax rate from above table ' + format('%.2n',[f2p * 100]){FormatF((f2p * 100), 5, 1)} + '%',
    formatF((Nc_Bc_Ann_Sal_Net * f2p), 12, 2 ), ' '
    ] ));
  sRpt.add(' ');
  sRpt.add( format('%-56s %-14s %-14s', [
    '    Less:  Constant from above table',
    formatF(f1i, 12, 2 ), ' '
    ] ));
  work := (Nc_Bc_Ann_Sal_Net * f2p) - f1i;
  if work < 0 then work := 0;
  sRpt.add( format('%-56s %-14s %-14s', [ ' ', dash(12), ' ']));
  sRpt.add( format('%-56s %-14s %-14s (Q)', [
    '    Manitoba Income Tax ',
    formatF( work, 12, 2 ),
    ' '
    ] ));
  sRpt.add(' ');
  if (wrkClaim.Claim_No <> '00000000') Then
     sRpt.add( format('%-56s %-14s %-14s', [
         '    Less: Non Refundable Tax Credit (M) above ',
         formatF( Nc_Bc_Mb_Nrtc, 12, 2 ),
  	 ' '
         ] ))
  else
     sRpt.add( format('%-56s %-14s %-14s', [
         '    Less: Non Refundable Tax Credit (M) above ',
         formatF(0.00, 12, 2 ),
  	 ' '
         ] ));

  result := Nc_Bc_Mbt;
	sRpt.add( format('%-56s %-14s %-14s', [ ' ', dash(12), ' ' ]));
  sRpt.add( format('%-56s %-14s %-14s (R)', [
  	'    Manitoba Provincial Tax ',
    ' ',
    formatF( result, 12, 2 )
    ] ));
  sRpt.add( format('%-56s %-14s %-14s', [ ' ', ' ', dDash(12)]));
end;


end.
