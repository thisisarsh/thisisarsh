(******************************************************************************)
(*  Wageloss System                                                           *)
(*                                                                            *)
(*  Wageloss Calculation Worksheet                                            *)
(*                                                                            *)
(*                                                                            *)
(*  Author: Brad Trupp  / Capella Systems Group, Inc.                         *)
(*  Date:   September 1997                                                    *)
(******************************************************************************)
(*                                                                            *)
(*  Change Log                                                                *)
(*                                                                            *)
(*  Oct 97 - use WagelossBenefitCalcForm.CalcPartClaim instead                *)
(*           of dataClaim to allow report to be printed before                *)
(*           updating.                                                        *)
(*                                                                            *)
(*  Dec 97  Brad  Change CPP_contrib_rate to float since 1997 amount has 5    *)
(*                decimals when currency only supports 4. Change display to   *)
(*                show extra decimals.                                        *)
(*                                                                            *)
(******************************************************************************)
unit NCWrkRpt;

interface

uses
  Windows, Messages, SysUtils, Classes, Graphics, Controls, Forms, Dialogs,
  ExtCtrls, quickrpt, Qrctrls, NCRecdef, uGlobal, QRPDFFilt;

  type
  TWagelossCalculationWorksheetForm = class(TForm)
    QRCalcWorkSheet: TQuickRep;
    QRBand1: TQRBand;
    QRSysData3: TQRSysData;
    QRSysData2: TQRSysData;
    QRSysData1: TQRSysData;
    QRLabel1: TQRLabel;
    QRLabel2: TQRLabel;
    QRShape1: TQRShape;
    lblClaimInfo: TQRLabel;
    QRBand2: TQRBand;
    lblDetailLine: TQRMemo;
    lblHeaderTaxYear: TQRLabel;
    QRReportYear: TQRLabel;
    QRReportMonth: TQRLabel;
    QRlblReportYear: TQRLabel;
    QRlblReportMonth: TQRLabel;
    QRPDFFilter: TQRPDFFilter;

    procedure QRCalcWorkSheetBeforePrint(Sender: TCustomQuickRep; var PrintReport: Boolean);
    procedure QRCalcWorkSheetNeedData(Sender: TObject; var MoreData: Boolean);
    procedure FormCreate(Sender: TObject); Dynamic;
    procedure FormDestroy(Sender: TObject);
    procedure ExcemptionAndCreditAmountBand1; Dynamic;
    procedure ExcemptionAndCreditAmountBand1P1; Dynamic;
    procedure ExcemptionAndCreditAmountBand1P2; Dynamic;
    function  Set_nc_bc_ann_sal_net(sIncType: shortString): currency;
    function  Set_nc_bc_bft(sIncType: shortString): currency;
    function  Set_nc_bc_cpp(sIncType: shortString): currency;
    function  Set_nc_bc_uic(sIncType: shortString): currency;
    function  Set_nc_bc_nrtc(sIncType: shortString): currency;
    function  Set_nc_bc_fst(sIncType: shortString): currency;
    function  Set_nc_bc_mb_nrtc(sIncType: shortString): currency;
    function  Set_nc_bc_mb_tax(sIncType: shortString): currency;
    function  Set_nc_bc_netinc(sIncType: shortString): currency;
    function  Set_nc_bc_td(sIncType: shortString): currency;
    //function Set_federalCanadaEmploymentCredit(sIncType: shortString): currency;
    function Set_mbFamilyTaxBenefitAmt(sIncType: shortString): currency;
    procedure TaxCalculationBand1( const income: currency; sIncomeType: shortstring ); Dynamic;
    procedure TaxCalculationBand1P1( const income: currency;
                                     sIncType: shortstring;
                                     Nc_Bc_Ann_Sal_Net: currency); Dynamic;
    //procedure TaxCalculationBand1P2( const income: currency;
    //                                 Nc_Bc_Ann_Sal_Net: currency;
    //                                 Nc_Bc_Uic: currency;
    //                                 Nc_Bc_Cpp: currency;
    //                                 Nc_Bc_Nrtc: currency;
    //                                 Nc_Bc_Mb_Nrtc: currency;
    //                                 federalCanadaEmploymentCredit: currency); Dynamic;
    procedure TaxCalculationBand1P2( const income: currency;
                                     Nc_Bc_Ann_Sal_Net: currency;
                                     Nc_Bc_Uic: currency;
                                     Nc_Bc_Cpp: currency;
                                     Nc_Bc_Nrtc: currency;
                                     Nc_Bc_Mb_Nrtc: currency;
                                     nc_mbFamilyTaxBenefitAmt: currency); Dynamic;
    function  TaxCalculationBand1P3( Nc_Bc_Ann_Sal_Net: currency;
                                     Nc_Bc_Nrtc: currency): currency; Dynamic;
    procedure TaxCalculationBand1P4( Nc_Bc_Bft: Currency;
                                     Nc_Bc_Fst: Currency); Dynamic;
    Function  TaxCalculationBand1P5( Nc_Bc_Bft: currency): currency;
    Function  TaxCalculationBand1P6( Nc_Bc_Ann_Sal_Net: currency): currency;
    procedure TaxCalculationBand1P7( Nc_Bc_Ann_Sal_Net: currency;
                                     Nc_Bc_Mb_Tax: currency;
    				                         Disp_a: currency;
                                     Disp_b: currency); Dynamic;
    procedure TaxCalculationBand1P8( Nc_Bc_Cpp: currency;
				                             Nc_Bc_Uic: currency;
                                     Fed_Tax: currency);Dynamic;
    procedure TaxCalculationBand1P9( Nc_Bc_Fst: currency);
    procedure TaxCalculationBand1P10(const income: currency;
                                     sIncType: shortString;
                                     Nc_Bc_Mb_Tax: currency;
                                     Nc_Bc_Td: currency;
                                     Nc_Bc_Cpp: currency;
                                     Nc_Bc_Uic: currency;
                                     Nc_Bc_Bft: Currency;
                                     Nc_Bc_Fst: Currency;
                                     Nc_Bc_Netinc: currency;
                                     Nc_Bc_Mbt: currency);Dynamic;
    procedure FormClose(Sender: TObject; var Action: TCloseAction);
    Function Set_nc_bc_mbt(sIncType: shortString): currency;
    procedure QRCalcWorkSheetExport(Sender: TCustomQuickRep;
      var ExportHandled: Boolean);
  private
    { Private declarations }
  public
    { Public declarations }
    sRpt: tStringList;
    LineCtr: integer;
    wrkClaim:recNCCLAIM;
    fWorking: recConst;
    Undefined: currency;
    SendingForm:TForm;
    bln2006to2021Claim: boolean;
    blnPost2006Claim:boolean;
    weeklyWageGross: shortstring;
    weeklyNet: double;
    cWeeklyShelterBenefitAmount, cWeeklyShelterMinBenAmount: currency;
    function shelteredGrossIncomeCalc : double;
    function dash( i: integer ): shortstring;
    function dDash( i: integer ): shortstring;
    function formatF( f:double; w, d: integer ): shortstring;
    function formatI( i:integer; w: integer ): shortstring;
    procedure BuildReport;
    procedure BuildReport2;
    procedure BuildReport3;
    procedure BuildReport4;
    procedure ClaimInfoHeader1;
    procedure GrossIncomeBand1; Dynamic;
    procedure NetIncomeBand1; Dynamic;
    procedure ShelteredTaxBenefitBand1;
    procedure TaxDeductionsBand1; Dynamic;
    procedure n90NetShelteredTaxBenefitBand1; Dynamic;
    procedure PostInjuryWagelossBand1;
    procedure CollateralBenefitWagelossBand1; Dynamic;
    procedure DisplaySurtax;
  end;

var
  WagelossCalculationWorksheetForm: TWagelossCalculationWorksheetForm;

implementation

uses NCIniMod, UtilMod1, NCBencal, NCMain;

{$R *.DFM}


(******************************************************************************)
(*                                                                            *)
(*  Report Initialization                                                     *)
(*                                                                            *)
(******************************************************************************)
procedure TWagelossCalculationWorksheetForm.QRCalcWorkSheetBeforePrint(
  Sender: TCustomQuickRep; var PrintReport: Boolean);

var
  Child: TWagelossBenefitCalcForm;
  blnFound:Boolean;
begin

  Child := SendingForm as TWagelossBenefitCalcForm;
  blnFound := False;
  if Child <> nil Then
     blnFound := True;

  sRpt.Clear;
  LineCtr := 0;
  Undefined := 9999.99;

  if blnFound Then
     copyNCCLAIM( Child.CalcPartClaim, wrkClaim)
  else
     copyNCClaim(dataClaim, wrkClaim);

  //
  // If we have zero's for the claim number change it to blanks. Having zero's causes
  // incorrect values on the report.
  //
  if wrkClaim.Claim_No = '00000000' then
     begin
     wrkClaim.Claim_No := '';
     wrkClaim.Claim_Suffix := '';
     end;

  Calc_Ben(wrkClaim, fWorking);

  //which report format we use depends on accident date
  if (wrkClaim.Accident_Date >= StrToDate('01/01/06')) AND (wrkClaim.Accident_Date <= StrToDate('31/12/21')) then
    bln2006to2021Claim := true
  else
    bln2006to2021Claim := false;
  if (wrkClaim.Accident_Date >= StrToDate('01/01/06')) then
    blnPost2006Claim := true
  else
    blnPost2006Claim := false;

  with wrkClaim do
     begin
     lblClaimInfo.caption:= 'Claim ' + Claim_No + ' /' + Claim_Suffix +
          '    ' + pdoxTrim(Clmnts_1st_Name) + ' ' + pdoxTrim(Clmnts_Surname);
     lblHeaderTaxYear.caption := 'Wageloss ' + IntToStr(wrkClaim.Tax_Year) + ' Benefit Calculation';
     Calc_Ben(wrkClaim, fWorking);

     //Modified - Jan 07 - bcooper - NR64337
     //original:
     //cWeeklyShelterBenefitAmount:=((Total_Deds * 0.75) - fWorking.Work_nc_bc_td_c)/52.0;
     //new:
     if ( ( ((Total_Deds * 0.75) - fWorking.Work_nc_bc_td_c)/52.0 ) < 0 ) then
     begin
       cWeeklyShelterBenefitAmount := 0;
     end
     else
     begin
       cWeeklyShelterBenefitAmount:=((Total_Deds * 0.75) - fWorking.Work_nc_bc_td_c)/52.0;
     end;
     //end changes - bcooper

     cWeeklyShelterMinBenAmount := Weekly_Shelter_Ben_Amount;

     //
     // Put the accident date into the header to show what tax tables
     // will be used for this calculation
     //
     QRReportYear.Caption := InttoStr(Year(Accident_Date));
     QRReportMonth.Caption := InttoStr(Month(Accident_Date));
     end;

  if (wrkClaim.Tax_Year < 1991) or
     (wrkClaim.Tax_Year > GetCurrentTaxYear) then
     begin
     sRpt.add('Invalid Tax Year ' + formatI(wrkClaim.Tax_Year,4) +
              '. Unable to create worksheet.');
     end
  else
     begin
     BuildReport;
   end;
end;

procedure TWagelossCalculationWorksheetForm.QRCalcWorkSheetExport(
  Sender: TCustomQuickRep; var ExportHandled: Boolean);
var
  aPDF:TQRPDFDocumentFilter;
begin
  aPDF := TQRPDFDocumentFilter.Create('c:\testpdf.pdf');
  WagelossCalculationWorksheetForm.QRCalcWorkSheet.ExportToFilter(aPDF);
  aPDF.Free;
end;

(******************************************************************************)
(*                                                                            *)
(*  Load QRMemo and force write to report.                                    *)
(*                                                                            *)
(******************************************************************************)
procedure TWagelossCalculationWorksheetForm.QRCalcWorkSheetNeedData(
  Sender: TObject; var MoreData: Boolean);
begin
  MoreData := LineCtr < 1;
  if MoreData then lblDetailLine.lines.Assign(sRpt);
  inc( LineCtr );
end;

(******************************************************************************)
(*                                                                            *)
(*   Build the report as a TStringlist first.                                 *)
(*                                                                            *)
(******************************************************************************)
procedure TWagelossCalculationWorksheetForm.BuildReport;
begin
  BuildReport2;

  if ( indexNCEXMAMT < 0 ) then
     begin
     exit;
     end;

  BuildReport3;

  if ( indexNCTAXRAT < 0 ) then
     begin
     exit;
     end;

  BuildReport4;
end;

procedure TWagelossCalculationWorksheetForm.BuildReport2;
var
  iii: integer;
begin
  // Get values in the Exemption Table
  SetTaxYear(wrkClaim.Accident_Date, wrkClaim.RecurrenceDate,
  	     wrkClaim.Tax_Year, wrkClaim.Indexation_Year);

  indexNCEXMAMT:=-1;
  for iii := low(arrayNCEXMAMT) to high(arrayNCEXMAMT) do
    begin
    if ( arrayNCEXMAMT[iii].Tax_Year > 1900 ) and
       ( arrayNCEXMAMT[iii].Tax_Year = GetTaxYear ) then
       begin
       indexNCEXMAMT:=iii;
       break;
       end
    end;
end;

procedure TWagelossCalculationWorksheetForm.BuildReport3;
var
  iii: integer;
begin
  // Load the Tax Rates
  SetTaxYear(wrkClaim.Accident_Date, wrkClaim.RecurrenceDate,
  	wrkClaim.Tax_Year, wrkClaim.Indexation_Year );
  indexNCTAXRAT:=-1;
  for iii := low(arrayNCTAXRAT) to high(arrayNCTAXRAT) do
    begin
    if ( arrayNCTAXRAT[iii].Tax_Year > 1900 ) and
       ( arrayNCTAXRAT[iii].Tax_Year = GetTaxYear ) then
       begin
       indexNCTAXRAT:=iii;
       break;
       end
    end;
end;

procedure TWagelossCalculationWorksheetForm.BuildReport4;
var
  Post_Collateral: currency;
begin
  with wrkClaim do
    begin
      ClaimInfoHeader1;
      n90NetShelteredTaxBenefitBand1;
 
      if ( Post_Injury_Earn <> 0.0 ) or (wrkClaim.Claim_No = '00000000') then
        PostInjuryWagelossBand1;
 
      CollateralBenefitWagelossBand1;
      GrossIncomeBand1;
      NetIncomeBand1;
      ShelteredTaxBenefitBand1;
      TaxDeductionsBand1;
      ExcemptionAndCreditAmountBand1;
      //
      // If we have a blank report (ie. the claim number is all 0's
      // the print out 1 tax calculation
      //
      if (Annual_Gross <> 0.0) or (wrkClaim.Claim_No = '00000000') then
        TaxCalculationBand1( Annual_Gross_A , 'Actual' );

      if ( Annual_Gross_A <> 0.0 ) then
         begin
         if (bln2006to2021Claim OR blnPost2006Claim) and not Pay_At_100_Flag then
            begin
            TaxCalculationBand1( Minimum_wage, 'Minimum Annual Earnings (AA)' );
            TaxCalculationBand1( ( Minimum_wage * 0.75), 'Sheltered (CC)' );
            end;
         end;
 
      if ( Annual_Gross_A <> 0.0 ) then
         if ( Annual_Gross_A > Annual_Gross ) then
            if bln2006to2021Claim then
               begin
               if Self_Employed = 'Y' then
                 TaxCalculationBand1( Annual_Gross , 'Maximum' );
               end
            else
               begin
               TaxCalculationBand1( Annual_Gross , 'Maximum' );
               end;
 
      if ( ( Annual_Gross * 0.75 ) <> 0.0 ) then
         TaxCalculationBand1( ( Annual_Gross * 0.75 ) , 'Sheltered' );
 
      if (Collateral_Ben_Tax <> 0.0) then
         TaxCalculationBand1( Collateral_Ben_Tax * 52, 'Collateral Benefits - Only' );
 
      if Post_Injury_Earn <> 0.0 then
         begin
         Post_Collateral := (Collateral_Ben_Tax + Post_Injury_Earn) * 52.0;
         TaxCalculationBand1(Post_Collateral, 'Post-Injury + Collateral Benefits' );
         end;
    end;
end;


(******************************************************************************)
(*                                                                            *)
(*  Form Create                                                               *)
(*                                                                            *)
(******************************************************************************)
procedure TWagelossCalculationWorksheetForm.FormCreate(Sender: TObject);
begin
  sRpt:=tStringList.create;
end;

(******************************************************************************)
(*                                                                            *)
(*  Form Destroy                                                              *)
(*                                                                            *)
(******************************************************************************)
procedure TWagelossCalculationWorksheetForm.FormDestroy(Sender: TObject);
begin
  sRpt.free;
  if Assigned(QRCalcWorkSheet) Then
     QRCalcWorkSheet := Nil;
end;

(******************************************************************************)
(*                                                                            *)
(*  Print dashes ( as an underline... )                                       *)
(*                                                                            *)
(******************************************************************************)
function TWagelossCalculationWorksheetForm.dash( i: integer ): shortstring;
begin
  result := copy(
  '----------------------------------------------------------------------------------------------------',
  1, i );
end;

(******************************************************************************)
(*                                                                            *)
(*  Print double dashs ( as a double underline... )                           *)
(*                                                                            *)
(******************************************************************************)
function TWagelossCalculationWorksheetForm.dDash( i: integer ): shortstring;
begin
  result := copy(
  '====================================================================================================',
  1, i );
end;

(******************************************************************************)
(*                                                                            *)
(*  format currency with leading $ and spaces                                 *)
(*                                                                            *)
(******************************************************************************)
function TWagelossCalculationWorksheetForm.formatF( f:double; w, d: integer ): shortstring;
var
  ws: shortstring;
begin
  //if (wrkClaim.Claim_No <> '00000000') OR
  //   ((wrkClaim.Claim_No = '00000000') AND (f <> 0))  Then
  //   begin
     ws := format('%*.*n', [ w, d, f ] );
     while length( ws ) < w do
        ws := ' ' + ws;
     ws[1] := '$';
     result := ws;
  //   end;
  //else
  //   result := '____________';
end;

(******************************************************************************)
(*                                                                            *)
(*  format integer with leading spaces                                        *)
(*                                                                            *)
(******************************************************************************)
function TWagelossCalculationWorksheetForm.formatI( i:integer; w: integer ): shortstring;
var
  ws: shortstring;
begin
  ws:=format('%*d', [ w, i ] );
  while length( ws ) < w do ws:=' '+ws;
  result:=ws;
end;


(******************************************************************************)
(*                                                                            *)
(*  Create Claim Header Band                                                  *)
(*                                                                            *)
(******************************************************************************)
procedure TWagelossCalculationWorksheetForm.ClaimInfoHeader1;
begin
  with wrkClaim do
  begin
    sRpt.add(' ');
    sRpt.add(
      format('%-20s %-60s',
        [ 'Worker''s Name:',
          ( pdoxTrim(Clmnts_1st_Name) + ' ' + pdoxTrim(Clmnts_Surname) )
        ] ));
    sRpt.add(' ');
    sRpt.add(
      format('%-23s %-7s %-20s %-10s ',
        [ 'Marital Status:', Marital_Status,
          'Self Employed:', Self_Employed
        ] ));
    sRpt.add(' ');
    sRpt.add(
      format('%-20s %-7s %-20s %-10s ',
        [ 'Spouse/Partner Working:', Spouse_Working,
          'Recurrence:', Recurrence
        ] ));
    sRpt.add(' ');
    if ((UpperCase(Marital_Status) = 'MARRIED') OR (UpperCase(Marital_Status) = 'COMMON-LAW')) AND
       (Spouse_Working = 'N') then
      begin
      sRpt.add(format('%-20s %-7s',
               [ 'Spouse Claimed as a Dependent:', wrkClaim.ClaimSpouseForTaxPurposes
               ] ));
      sRpt.add(' ');
      end;
    sRpt.add(
      format('%-23s %-10s',
        [ '# of Dependents:', inttostr( No_Of_Dependnts )
        ] ));
    sRpt.add(' ');
    sRpt.add(
      format('%-20s %-10s',
        [ '# of Infirm Dependents:', inttostr( No_Infirm )
        ] ));
    sRpt.add(' ');
    sRpt.add(dash(91));

  end;
end;

(******************************************************************************)
(*                                                                            *)
(*  Create Gross Income Band                                                  *)
(*                                                                            *)
(******************************************************************************)
procedure TWagelossCalculationWorksheetForm.GrossIncomeBand1;
var
   iii, ctYear: integer;
begin
  with wrkClaim do
  begin
    sRpt.add(' ');
    sRpt.add('Gross Income Amounts:');
    sRpt.add(' ');

      sRpt.add(
        format('%-14s %-56s %-14s (A)',
          [ formatF(Wkly_Sal_A, 11, 2  ),
          ' x 52 = ( actual annual income )',
          formatF( Annual_Gross_A, 12, 2)
          ] ));
      sRpt.add( format('%-14s %-56s %-14s', [ dash(12), ' ', dDash(12) ] ));
      sRpt.add( format('%-14s %-56s %-14s', [ '  Weekly Wage', ' ', ' ' ] ));
      sRpt.add(' ');
      sRpt.add(' ');

      if Max_Adjustment <> 0 then
        sRpt.add(
          format('%-71s %-14s (B)',
            [ 'Max Adjustment Override', formatF( Max_Adjustment, 12, 2)
            ] ))
      else
        sRpt.add(
          format('%-71s %-14s (B)',
            [ 'Max Adjustment Override', ' '
            ] ));

      sRpt.add( format('%-71s %-14s', [ ' ', dDash(12) ] ));
      sRpt.add(' ');
      sRpt.add(
        format('%-56s %-14s %-14s (B)',
          [ 'WCB Maximum Gross Annual Income',
            ' ',
          formatF(Annual_Gross, 12, 2 )
          ] ));
      sRpt.add( format('%-14s %-56s %-14s', [ ' ', ' ', dDash(12) ] ));

      ctYear:=wrkClaim.Tax_Year;
      for iii := high(arrayNCANNMAX) downto low(arrayNCANNMAX) do
      begin
      if (( arrayNCANNMAX[iii].Accident_Year = ctYear ) and
       ( arrayNCANNMAX[iii].Tax_Year = ctYear )) then
      begin
        sRpt.add(
          '    ' + format ('%-4d Annual Maximum                   %s',
          [
          arrayNCANNMAX[iii].Accident_Year,
          formatF( arrayNCANNMAX[iii].Annual_Maximum, 12, 2 )
          ]));
      end
      else
      if (( arrayNCANNMAX[iii].Accident_Year = ctYear - 1 ) and
          ( arrayNCANNMAX[iii].Tax_Year = ctYear - 1 ) ) then
      begin
        sRpt.add(
          '    ' + format ('%-4d Annual Maximum (not indexed)     %s',
          [
          arrayNCANNMAX[iii].Accident_Year,
          formatF( arrayNCANNMAX[iii].Annual_Maximum, 12, 2 )
          ]));
      end
      else
      if ( arrayNCANNMAX[iii].Accident_Year > 0 ) and
        ( arrayNCANNMAX[iii].Accident_Year < ctYear - 1 ) and
        ( arrayNCANNMAX[iii].Tax_Year = ctYear ) then
      begin
        sRpt.add(
          '    ' + format ('%-4d Annual Maximum indexed to %-4d   %s',
          [
          arrayNCANNMAX[iii].Accident_Year,
          arrayNCANNMAX[iii].Tax_Year,
          formatF( arrayNCANNMAX[iii].Annual_Maximum, 12, 2 )
          ]));
      end;
      end;
      sRpt.add(' ');
      sRpt.add(' ');

      sRpt.add('PRORATING FACTOR FOR TAX DEDUCTIONS (ONLY IF ACTUAL > MAX):');
      sRpt.add(' ');
      if Annual_Gross_A > Annual_Gross then
      begin
        sRpt.add(
          format('%-76s %-.4n%% (FT)',
            [
            ' (Max (B)  ' + formatF(Annual_Gross, 12, 2) +
            ' / Actual (A)  ' + formatF(Annual_Gross_A, 12, 2) + ' =',
            (fWorking.Work_nc_prorate*100.00)
            ] ));
        sRpt.add( format('%-56s %-14s %-14s', [ ' ',  ' ', dDash(12) ] ));
      end
      else
      begin
        sRpt.add(
          format('%-84s (FT)',
            [
            ' (Max (B)             /Actual (A)             ='
            ] ));
        sRpt.add(
          format('%-71s %-14s',
            [
            '         ' + dash(12) + '             ' + dash(12),
            dDash(12)
            ] ));
      end;
      sRpt.add(' ');

      sRpt.add(
        format('%-14s %-56s %-14s (C)',
          [ formatF( Annual_Gross, 12, 2  ),
          ' x 75% = ( annual sheltered income )',
          formatF( ( Annual_Gross * 0.75 ), 12, 2 )
          ] ));
      sRpt.add( format('%-14s %-56s %-14s', [ dash(12), ' ', dDash(12) ] ));
      sRpt.add( format('%-56s %-14s %-14s', [ '  lessor of (A) or (B) above', ' ', ' ' ] ));
      sRpt.add(' ');

      sRpt.add(
        format('%-14s %-56s %-14s',
          [  formatF( Collateral_Ben_Tax, 12, 2 ),
          ' (i)   Weekly Taxable Collateral benefits',
          ' '
          ] ));
      sRpt.add(
        format('%-14s %-56s %-14s',
          [ formatF( Post_Injury_Earn, 12, 2  ),
          ' (ii) + Weekly Post Injury Earnings ',
          ' '
          ] ));

      sRpt.add(
        format('%-14s %-56s %-14s (E)',
          [ formatF( ( Collateral_Ben_Tax + Post_Injury_Earn ), 12, 2 ),
          ' (D)  x 52 =( annual benefits + earnings )',
          formatF( (( Collateral_Ben_Tax + Post_Injury_Earn )* 52), 12, 2 )
          ] ));
      sRpt.add( format('%-14s %-56s %-14s', [ dash(12), ' ', dDash(12) ] ));
      sRpt.add( format('%-56s %-14s %-14s', [ ' total ( i + ii )', ' ', ' ' ] ));

    sRpt.add(' ');

    sRpt.add(dash(91));
  end;
end;

(******************************************************************************)
(*                                                                            *)
(*  Create Net Income Band                                                    *)
(*                                                                            *)
(******************************************************************************)
procedure TWagelossCalculationWorksheetForm.NetIncomeBand1;
begin
  with wrkClaim do
  begin
    sRpt.add(' ');
      sRpt.add('Net Income Amounts: ( from calculation attached for Gross Incomes A,B,E above )');
      sRpt.add(' ');
      sRpt.add( format('%-14s %-56s %-14s',[ 'Type',' Annual Net ', 'Weekly Net  ']));
      sRpt.add( format('%-14s %-56s %-14s',[ '----',' -----------', '------------']));
      sRpt.add(' ');

      sRpt.add(
        format('%-14s %-56s %-14s',
          [ ' (A)',
          formatF(Annual_Net_A, 12, 2  ) + ' / 52 =',
          formatF( ( Annual_Net_A / 52.0 ), 11, 2)
          ] ));
      sRpt.add( format('%-14s %-56s %-14s',[ ' ', 'actual income', dDash(12) ]));
      sRpt.add(' ');

      sRpt.add(
        format('%-14s %-56s %-14s',
          [ ' (B)',
          formatF(Annual_Net, 12, 2  ) + ' / 52 =',
          formatF( ( Annual_Net / 52.0 ), 11, 2)
          ] ));
      sRpt.add( format('%-14s %-56s %-14s',[ ' ', 'limited to annual maximum', dDash(12) ]));
      sRpt.add(' ');

      sRpt.add(
        format('%-14s %-56s %-14s',
          [ ' (E)',
          formatF((Coll_Ben_Tax_Net*52), 12, 2  ) + ' / 52 x (i) / D =',
          formatF( Coll_Ben_Tax_Net, 11, 2)
          ] ));
      sRpt.add( format('%-14s %-56s %-14s',[ ' ', 'taxable collateral benefits', dDash(12) ]));
      sRpt.add(' ');

      sRpt.add(
        format('%-14s %-56s %-14s',
          [ ' (E)',
          formatF((Post_Injury_Earn_Net*52.0), 12, 2  ) + ' / 52 x (ii) / D  =',
          formatF( (Post_Injury_Earn_Net), 11, 2)
          ] ));
      sRpt.add( format('%-14s %-56s %-14s',[ ' ', 'post injury earnings', dDash(12) ]));
      sRpt.add(' ');

    sRpt.add(' ');
    sRpt.add(dash(91));
  end;
end;

(******************************************************************************)
(*                                                                            *)
(*  Create Sheltered Tax Benefit Band                                         *)
(*                                                                            *)
(******************************************************************************)
procedure TWagelossCalculationWorksheetForm.ShelteredTaxBenefitBand1;
Var
  t: currency;
  shelteredTotalDeds : double;
  ws_Work_nc_bc_td:Currency;
begin
  with wrkClaim do
  begin
    if blnPost2006Claim then begin
      sRpt.add(' ');
      sRpt.add('Sheltered Tax Benefit Calculation: ( Amounts from calculations attached )');
      sRpt.add(' ');
      sRpt.add(
        format('%-70s  %-14s', [
          'Total Deductions:  amount (V) ' + formatF( Total_Deds, 12, 2  ) + ' x 75%',
          formatF( ( Total_Deds *0.75 ), 12, 2  )
          ] ));
      sRpt.add(
        format('%-70s  %-14s', [
          '  Lessor of calculated amount (V) for Gross Income (A) or (B)',
          dDash(12)
          ] ));
      sRpt.add(' ');
      sRpt.add(
        format('%-56s %-14s %-14s', [
          'Less Total Deductions: amount (V) ',
          ' ',
          ' '
          ] ));
      sRpt.add(
        format('%-56s %-14s %-14s', [
          '  Calculated amount for gross income (C)',
          ' ',
          formatF( fWorking.Work_nc_bc_td_c, 12, 2  )
          ] ));
      sRpt.add( format('%-56s %-14s %-14s', [ ' ', ' ',  dash(12) ] ));

      //Modified - Jan 07 - bcooper - NR64337
      //original:
      //t:=( Total_Deds *0.75 )-fWorking.Work_nc_bc_td_c;
      //new:
      if ( ( ( Total_Deds *0.75 )-fWorking.Work_nc_bc_td_c ) < 0 ) then
      begin
        t := 0;
      end
      else
      begin
        t := ( Total_Deds *0.75 )-fWorking.Work_nc_bc_td_c;
      end;
      //end changes - bcooper

      cWeeklyShelterBenefitAmount:=t/52.0;

      sRpt.add(
        format('%-56s %-14s %-14s (i)', [
          'Annual Sheltered Tax Benefits Amount',
          ' ',
          formatF( t, 12, 2  )
          ] ));
      sRpt.add( format('%-56s %-14s %-14s', [ ' ',  ' ', dDash(12) ] ));

      sRpt.add(
        format('%-56s %-14s %-14s (W)', [
          'Weekly Shelter Benefit Amount ' + formatF( t, 12, 2  ) + ' / 52 ',
          '@100%',
          formatF( cWeeklyShelterBenefitAmount, 12, 2  )
          ] ));
      sRpt.add( format('%-56s %-14s %-14s', [ '                                    Amount (i) ',  ' ', dDash(12) ] ));
      sRpt.add(' ');
      sRpt.add(
        format('%-56s %-14s %-14s (W)', [
          ' ',
          '@90%',
          formatF( cWeeklyShelterBenefitAmount * 0.90, 12, 2  )
          ] ));
      sRpt.add( format('%-56s %-14s %-14s', [ ' ',  ' ', dDash(12) ] ));

      //suppress following section if wage is less then minimum
      if not Pay_At_100_Flag then
         begin
         ws_Work_nc_bc_td	:= Set_nc_bc_td('Minimum Annual Earnings (AA)');
         sRpt.add(' ');
         sRpt.add(' ');
         sRpt.add('If Actual Wages (A) are greater than Minimum Annual Earnings (AA):');
         sRpt.add('   - complete Income Tax, CPP and EI Calculation for (AA) Minimum Annual Earnings');
         sRpt.add('   - complete Income Tax, CPP and EI Calculation for (CC) Min Annual Sheltered Income');
         sRpt.add('   - complete the following Sheltered Tax Benefit Calculation for (AA)');
         sRpt.add(' ');
         sRpt.add(' ');

         sRpt.add('Sheltered Tax Benefit Calculation: ( Amounts from calculations attached )');
         sRpt.add(' ');
//         sRpt.add(format('%-70s  %-14s', [
//                  'Total Deductions:  amount (V) ' + formatF( Min_Wage_Total_Deds, 12, 2  ) + ' x 75%',
//                  formatF( ( Min_Wage_Total_Deds *0.75 ), 12, 2  )
//                  ] ));
         sRpt.add(format('%-70s  %-14s', [
                  'Total Deductions:  amount (V) ' + formatF( ws_Work_nc_bc_td, 12, 2  ) + ' x 75%',
                  formatF( ( ws_Work_nc_bc_td *0.75 ), 12, 2  )
                  ] ));
         sRpt.add(format('%-70s  %-14s', [
                  '  Calculated amount (V) for Minimum Gross Income(AA)',
                  dDash(12)
                  ] ));
         sRpt.add(' ');

         //get sheltered amount
         shelteredTotalDeds := shelteredGrossIncomeCalc;

         sRpt.add(format('%-56s %-14s %-14s', [
                  'Less Total Deductions: amount (V) ',
                  ' ',
                  ' '
                  ] ));
         sRpt.add(format('%-56s %-14s %-14s', [
                  '  Calculated amount for gross income (CC)',
                  ' ',
                  formatF( shelteredTotalDeds, 12, 2  )
                  ] ));
         sRpt.add( format('%-56s %-14s %-14s', [ ' ', ' ',  dash(12) ] ));

         //t:=( Min_Wage_Total_Deds *0.75 )-shelteredTotalDeds;
         t:=( ws_Work_nc_bc_td *0.75 )-shelteredTotalDeds;
         sRpt.add(format('%-56s %-14s %-14s (i)', [
                  'Annual Sheltered Tax Benefits Amount',
                  ' ',
                  formatF( t, 12, 2  )
                  ] ));
         sRpt.add( format('%-56s %-14s %-14s', [ ' ',  ' ', dDash(12) ] ));

         sRpt.add(format('%-56s %-14s %-14s (W)', [
                  'Weekly Shelter Benefit Amount ' + formatF( t, 12, 2  ) + ' / 52 ',
                  '@100%',
                  formatF( t/52.0, 12, 2  )
                  ] ));
         sRpt.add( format('%-56s %-14s %-14s', [ '                                    Amount (i) ',  ' ', dDash(12) ] ));
         end;

      sRpt.add(' ');
    end else begin
      sRpt.add(' ');
      sRpt.add('Sheltered Tax Benefit Calculation: ( Amounts from calculations attached )');
      sRpt.add(' ');
      sRpt.add(
        format('%-70s  %-14s', [
          'Total Deductions:  amount (V) ' + formatF( Total_Deds, 12, 2  ) + ' x 75%',
          formatF( ( Total_Deds *0.75 ), 12, 2  )
          ] ));
      sRpt.add(
        format('%-70s  %-14s', [
          '  lessor of calculated amount (V) for Gross Income (A) or (B)',
          ' '
          ] ));
      sRpt.add(' ');
      sRpt.add(
        format('%-56s %-14s %-14s', [
          'less Total Deductions: amount (V) ',
          ' ',
          ' '
          ] ));
      sRpt.add(
        format('%-56s %-14s %-14s', [
          '  calculated amount for gross income (C)',
          ' ',
          formatF( fWorking.Work_nc_bc_td_c, 12, 2  )
          ] ));
      sRpt.add( format('%-56s %-14s %-14s', [ ' ', ' ',  dash(12) ] ));

      //Modified - Jan 07 - bcooper - NR64337
      //original:
      //t:=( Total_Deds *0.75 )-fWorking.Work_nc_bc_td_c;
      //new:
      if ( ( ( Total_Deds *0.75 )-fWorking.Work_nc_bc_td_c ) < 0 ) then
      begin
        t := 0;
      end
      else
      begin
        t := ( Total_Deds *0.75 )-fWorking.Work_nc_bc_td_c;
      end;
      //end changes - bcooper

      cWeeklyShelterBenefitAmount:=t/52.0;

      sRpt.add(
        format('%-56s %-14s %-14s (i)', [
          'Annual Sheltered Tax Benefits Amount',
          ' ',
          formatF( t, 12, 2  )
          ] ));
      sRpt.add( format('%-56s %-14s %-14s', [ ' ',  ' ', dDash(12) ] ));

      sRpt.add(
        format('%-71s %-14s (W)', [
          'Weekly Shelter Benefit Amount ( '+ formatF( t, 12, 2  ) +
          ' Amount (i) / 52 )',
          formatF( cWeeklyShelterBenefitAmount, 12, 2  )
          ] ));
      sRpt.add( format('%-56s %-14s %-14s', [ ' ',  ' ', dDash(12) ] ));

      sRpt.add(' ');
    end;

    sRpt.add(dash(91));
  end;
end;

(******************************************************************************)
(*                                                                            *)
(*  Create Tax Deductions Band                                                *)
(*                                                                            *)
(******************************************************************************)
procedure TWagelossCalculationWorksheetForm.TaxDeductionsBand1;
begin
  with wrkClaim do
  begin
    sRpt.add(' ');
    sRpt.add('Tax Deductions:   (These fields will be set to zeros for a pre-2001 claim.');
    sRpt.add(' ');
    sRpt.add(
      format('%-25s %-45s %-14s',
        [
        'Child Care Expenses',
        formatF(Child_Care_Exp, 12, 2) + '  X 52 = ',
        formatF(Child_Care_Exp*52, 12, 2)
        ] ));
//    sRpt.add(
//      format('%-25s %-45s %-14s',
//        [
//        'Child Support',
//        formatF(Child_Support, 12, 2) + '  X 52 = ',
//        formatF(Child_Support*52, 12, 2)
//        ] ));
    sRpt.add(
      format('%-25s %-45s %-14s',
        [
        'Spousal Support',
        formatF(Spousal_Support, 12, 2) + '  X 52 = ',
        formatF(Spousal_Support*52, 12, 2)
        ] ));
    sRpt.add( format('%-71s %-14s', [ ' ',  Dash(12) ] ));
    sRpt.add(
      format('%-71s %-14s (DED)',
        [
        ' ',
        formatF(fWorking.Work_nc_bc_deductions, 12, 2)
        ] ));
    sRpt.add( format('%-71s %-14s', [ ' ',  dDash(12) ] ));

    sRpt.add(' ');
    sRpt.add(dash(91));
  end;
end;

(******************************************************************************)
(*                                                                            *)
(*  Create 90 Net Sheltered Band                                              *)
(*                                                                            *)
(******************************************************************************)
procedure TWagelossCalculationWorksheetForm.n90NetShelteredTaxBenefitBand1;
begin
  with wrkClaim do
  begin
      sRpt.add( '90% Net Sheltered Benefit Calculation:' );

      sRpt.add(' ');

      sRpt.add( format('%-56s %-14s %-14s', [
        'Weekly Net ( lessor of net (A) or (B) )',
        formatF( PDoxRound((Annual_Net / 52.0), 2), 12, 2 ),
        '(i)'
        ] ));
      sRpt.add( format('%-56s %-14s %-14s', [ ' ',  dash(12), ' '       ]));

      sRpt.add( format('%-56s %-14s %-14s', [
        'Weekly Net @ 90%  ( (i) x 90% )',
        ' ',
        formatF( (PDoxRound((Annual_Net / 52.0), 2) * 0.90), 12, 2 )
        ] ));
      sRpt.add( format('%-56s %-14s %-14s', [ ' ',  ' '     , dDash(12) ]));
      sRpt.add( format('%-56s %-14s %-14s', [
        'Weekly Net @ 80%  ( (i) x 80% )',
        ' ',
        formatF( ( PDoxRound((Annual_Net / 52.0), 2) * 0.80 ), 12, 2 )
        ] ));
      sRpt.add( format('%-56s %-14s %-14s', [ ' ',  ' '     , dDash(12) ]));
      sRpt.add( format('%-56s %-14s %-14s', [
        'Less: Weekly Shelter Benefit Amount ( from (W) )',
        formatF( PDoxRound(cWeeklyShelterBenefitAmount, 2), 12, 2 ),
        ' '
        ] ));
      sRpt.add( format('%-56s %-14s %-14s', [ ' ',  dash(12), ' '       ]));
      sRpt.add( format('%-56s %-14s %-14s', [
        'Weekly Net Sheltered Loss of Earnings',
        formatF( (PDoxRound((Annual_Net/ 52.0), 2)-PDoxRound(cWeeklyShelterBenefitAmount, 2)), 12, 2 ),
        ' (ii)'
        ] ));
      sRpt.add( format('%-56s %-14s %-14s', [ ' ', dDash(12), ' '       ]));
      sRpt.add( format('%-56s %-14s %-14s', [
        'Weekly Net Sheltered @ 90% ( (ii) x 90% )',
        ' ',
        formatF(PDoxRound((PDoxRound((Annual_Net / 52.0),2)-PDoxRound(cWeeklyShelterBenefitAmount, 2))*0.90, 2), 12, 2 )
        ] ));
      sRpt.add( format('%-56s %-14s %-14s', [ ' ',  ' '     , dDash(12) ]));
    sRpt.add(' ');
    sRpt.add(dash(91));
  end;
end;

(******************************************************************************)
(*                                                                            *)
(*   Create Post Injury Wageloss band                                         *)
(*                                                                            *)
(******************************************************************************)
procedure TWagelossCalculationWorksheetForm.PostInjuryWagelossBand1;
var
  t, u: currency;
  strTemp: String;
  shelterAmount, shelterCheck, shelterResult : currency;
begin
  with wrkClaim do
  begin
    sRpt.add(' ');
    if blnPost2006Claim then begin
      if Pay_At_100_Flag then
        strTemp := ' '
      else
        strTemp := '        @90%';

      sRpt.add(format('%-56s %-14s %-14s', [ 'Post Injury Wage Loss Calculation:',
                                              '       @100%',
                                              strTemp ]));
      sRpt.add( format('%-56s %-14s %-14s', [ dash(34), ' ', ' ' ]));
      sRpt.add(' ');

      sRpt.add( format('%-56s %-14s %-14s', [
        'Weekly Net ( lessor of net (A) or (AA)-minimum benefit )',
        formatF( ( weeklyNet / 52.0 ), 12, 2 ),
        ' '
        ] ));
      sRpt.add( format('%-56s %-14s %-14s', [ ' ',  dash(12), ' '       ]));

      if not Pay_At_100_Flag then begin
        sRpt.add( format('%-56s %-14s %-14s', [
          'Weekly Net (lessor of net (A) or (B)-regular benefit)',
          ' ',
          formatF( (PDoxRound((Annual_Net / 52.0), 2) * 0.90), 12, 2 )
          ] ));
        sRpt.add( format('%-56s %-14s %-14s', [ ' ',  ' '     , dash(12) ]));
      end;

      if Pay_At_100_Flag then begin
        strTemp := ' ';
      end else begin
        strTemp := formatF( Post_Injury_Earn_Net * 0.90, 12, 2 );
      end;

      sRpt.add( format('%-56s %-14s %-14s', [
        'Less: Net Post Injury Earnings ( from (E) )',
        formatF( Post_Injury_Earn_Net, 12, 2 ),
        strTemp
        ] ));

      if Pay_At_100_Flag then
        strTemp := ' '
      else
        strTemp := dash(12);

      sRpt.add( format('%-56s %-14s %-14s', [ ' ',  dash(12), strTemp      ]));

      if Annual_Net < Min_Wage_Annual_Net_A then
         u:=((Annual_Net / 52.0) - Post_Injury_Earn_Net)
      else
         u:=(Min_Wage_Annual_Net_A / 52.0) - Post_Injury_Earn_Net;

      t:=((PDoxRound(Annual_Net * 0.90, 2) / 52.0) - PDoxRound(Post_Injury_Earn_Net*0.90, 2));

      if Pay_At_100_Flag then
        strTemp := ' '
      else
        strTemp := formatF( t, 12, 2 );

      sRpt.add( format('%-56s %-14s %-14s', [
        'Weekly Net Loss of Earnings',
        formatF( u, 12, 2 ),
        strTemp
        ] ));

      if Pay_At_100_Flag then begin
        strTemp := ' ';
        shelterAmount := cWeeklyShelterBenefitAmount;
      end else begin
        strTemp := dash(12);
        shelterAmount := cWeeklyShelterMinBenAmount;
      end;

      sRpt.add( format('%-56s %-14s %-14s', [ ' ', dash(12), strTemp       ]));

      sRpt.add( format('%-56s %-14s %-14s', [
        'Less: Weekly Shelter Benefit Amount ( from (W)-min ben )',
        formatF( shelterAmount, 12, 2 ),
        ' '
        ] ));
      sRpt.add( format('%-56s %-14s %-14s', [ ' ',  dash(12), ' '       ]));

      if not Pay_At_100_Flag then begin
        sRpt.add( format('%-56s %-14s %-14s', [
          'Less: Weekly Shelter Benefit Amount ( from (W)-reg ben )',
          ' ',
          formatF(PDoxRound(cWeeklyShelterBenefitAmount *0.90, 2), 12, 2 )
          ] ));
        sRpt.add( format('%-56s %-14s %-14s', [ ' ',  ' '     , dash(12) ]));
      end;

      if Pay_At_100_Flag then
        strTemp := ' '
      else
      begin
        if ( ( t - PDoxRound(cWeeklyShelterBenefitAmount * 0.90, 2) ) < 0 ) then
          strTemp := formatF( 0, 12, 2 )
        else
          strTemp := formatF( ((t - PDoxRound(cWeeklyShelterBenefitAmount * 0.90, 2))), 12, 2 );
       end;

      //May 26, 2006 - added check on Partial loss of earnings
      //             - if u - shelterAmount < 0 display 0
      shelterCheck := u - shelterAmount;

      if shelterCheck < 0 then
        shelterResult := 0
      else
        shelterResult := u - shelterAmount;

      sRpt.add( format('%-56s %-14s %-14s', [
        'Weekly Net Sheltered Partial Loss of Earnings',
        formatF( (shelterResult), 12, 2 ),
        strTemp
        ] ));

      if Pay_At_100_Flag then
        strTemp := ' '
      else
        strTemp := dDash(12);

      sRpt.add( format('%-56s %-14s %-14s', [ ' ', dDash(12), strTemp       ]));
    end else begin
      sRpt.add('Post Injury Wage Loss Calculation:');
      sRpt.add(' ');

      sRpt.add( format('%-56s %-14s %-14s', [
        'Weekly Net ( lessor of net (A) or (B) )',
        formatF( ( Annual_Net / 52.0 ), 12, 2 ),
        ' '
        ] ));
      sRpt.add( format('%-56s %-14s %-14s', [ ' ',  dash(12), ' '       ]));

      sRpt.add( format('%-56s %-14s %-14s', [
        'Less: Net Post Injury Earnings ( from (E) )',
        formatF( ( Post_Injury_Earn_Net ), 12, 2 ),
        ' '
        ] ));
      sRpt.add( format('%-56s %-14s %-14s', [ ' ',  dash(12), ' '       ]));

      t:=((Annual_Net / 52.0) - Post_Injury_Earn_Net);
      sRpt.add( format('%-56s %-14s %-14s', [
        'Weekly Net Loss of Earnings',
        formatF( t, 12, 2 ),
        ' (i)'
        ] ));
      sRpt.add( format('%-56s %-14s %-14s', [ ' ', dDash(12), ' '       ]));

      sRpt.add( format('%-56s %-14s %-14s', [
        'Weekly Net @ 90%  ( (i) x 90% )',
        ' ',
        formatF( ( t*0.90 ) , 12, 2 )
        ] ));
      sRpt.add( format('%-56s %-14s %-14s', [ ' ',  ' '     , dDash(12) ]));

      sRpt.add( format('%-56s %-14s %-14s', [
        'Weekly Net @ 80%  ( (i) x 80% )',
        ' ',
        formatF( ( t * 0.80 ), 12, 2 )
        ] ));
      sRpt.add( format('%-56s %-14s %-14s', [ ' ',  ' '     , dDash(12) ]));

      sRpt.add( format('%-56s %-14s %-14s', [
        'Less: Weekly Shelter Benefit Amount ( from (W) )',
        formatF( cWeeklyShelterBenefitAmount, 12, 2 ),
        ' '
        ] ));
      sRpt.add( format('%-56s %-14s %-14s', [ ' ',  dash(12), ' '       ]));

      sRpt.add( format('%-56s %-14s %-14s', [
        'Weekly Net Sheltered Loss of Earnings',
        formatF( (t-cWeeklyShelterBenefitAmount), 12, 2 ),
        ' (ii)'
        ] ));
      sRpt.add( format('%-56s %-14s %-14s', [ ' ', dDash(12), ' '       ]));

      sRpt.add( format('%-56s %-14s %-14s', [
        'Weekly Net Sheltered @ 90% ( (ii) x 90% )',
        ' ',
        formatF( ((t-cWeeklyShelterBenefitAmount)*0.90), 12, 2 )
        ] ));
      sRpt.add( format('%-56s %-14s %-14s', [ ' ',  ' '     , dDash(12) ]));
    end;
    sRpt.add(' ');
    sRpt.add(dash(91));
  end;
end;

(******************************************************************************)
(*                                                                            *)
(*  Create Collateral Benefits Band                                           *)
(*                                                                            *)
(******************************************************************************)
procedure TWagelossCalculationWorksheetForm.CollateralBenefitWagelossBand1;
begin
  with wrkClaim do
  begin
    sRpt.add(' ');
    sRpt.add('Collateral Benefit Wage Loss Calculation:');
    sRpt.add(' ');

    sRpt.add( format('%-56s %-14s %-14s', [
      'Weekly Net ( from (A) )',
      formatF( ( Annual_Net_A / 52.0 ), 12, 2 ),
      ' (i)'
      ] ));
    sRpt.add( format('%-56s %-14s %-14s', [ ' ',  dash(12), ' '       ]));

    sRpt.add( format('%-56s %-14s %-14s', [
      'Weekly Net @ 90%  ( (i) x 90% )',
      ' ',
      formatF( ( ( Annual_Net_A / 52.0 ) *0.90 ), 12, 2 )
      ] ));
    sRpt.add( format('%-56s %-14s %-14s', [ ' ',  ' '     ,  dash(12) ]));

    sRpt.add( format('%-56s %-14s %-14s', [
      'Less: Net Collateral Benefit ( from (E) )',
      ' ',
      formatF( Coll_Ben_Tax_Net, 12, 2 )
      ] ));
    sRpt.add( format('%-56s %-14s %-14s', [ ' ',  ' '     ,  dash(12) ]));

    sRpt.add( format('%-56s %-14s %-14s', [
      'Maximum Weekly Benefit',
      ' ',
      formatF( (( ( Annual_Net_A / 52.0 ) *0.90 ) - Coll_Ben_Tax_Net), 12, 2 )
      ] ));
    sRpt.add( format('%-56s %-14s %-14s', [ ' ',  ' '     , dDash(12) ]));

    sRpt.add(' ');
    sRpt.add(dash(91));
  end;
end;

(******************************************************************************)
(*                                                                            *)
(*  Create Tax Exemption and Credits band                                     *)
(*                                                                            *)
(******************************************************************************)
procedure TWagelossCalculationWorksheetForm.ExcemptionAndCreditAmountBand1;
begin
  ExcemptionAndCreditAmountBand1P1;
  DisplaySurtax;
  ExcemptionAndCreditAmountBand1P2;
end;

procedure TWagelossCalculationWorksheetForm.ExcemptionAndCreditAmountBand1P1;
begin
  sRpt.add(' ');
  sRpt.add('Exemption / Credit Amount:');
  sRpt.add(' ');
  sRpt.add(formatI(wrkClaim.Tax_Year,4) + ' Federal & Provincial Personal Amount:');
  sRpt.add(' ');
  sRpt.add( format('%-56s %-14s %-14s', [
    '    Workers basic personal amount ',
    ' ',
    formatF( fWorking.Work_personal, 12, 2 )
    ] ));
  sRpt.add( format('%-56s %-14s %-14s', [
    '    Married (spouse claimed as a dependent) claim ' +
      formatf(arrayNCEXMAMT[indexNCEXMAMT].Spouse, 10, 2),
    ' ',
    formatF( fWorking.Work_NC_SPOUSE, 12, 2 )
    ] ));
  sRpt.add( format('%-71s %-14s', [
    '    Single ( claim 1 child as equivalent to spouse ) ' +
      formatF(arrayNCEXMAMT[indexNCEXMAMT].ChildSpouse, 10, 2),
    formatF( fWorking.Work_NC_CHILDSPOUSE, 12, 2 )
    ] ));
  sRpt.add( format('%-56s %-14s %-14s', [
    '    Infirm dependents ( age 18+ ) ' + intToStr( fWorking.Work_nc_no_infirm )
      + ' x ' + formatF(arrayNCEXMAMT[indexNCEXMAMT].Infirm_Dep, 10, 2),
    ' ',
    formatF( fWorking.Work_infirm, 12, 2 )
    ] ));
  if ((wrkClaim.Tax_Year = 1992) OR (wrkClaim.Tax_Year = 1993)) Then
     begin
     if (fWorking.Work_nc_no_of_dep > 2) Then
        begin
        sRpt.add( format('%-56s %-14s %-14s', [
            '    1st and 2nd Child ' + intToStr( 2 )
            + ' x ' + formatF(arrayNCEXMAMT[indexNCEXMAMT].Dep_1st, 10, 2),
            ' ',
            formatF( 2 * arrayNCEXMAMT[indexNCEXMAMT].Dep_1st, 12, 2 )
            ] ));
        sRpt.add( format('%-56s %-14s %-14s', [
            '    3rd and each other child ' + intToStr( fWorking.Work_nc_no_of_dep - 2 )
            + ' x ' + formatF(arrayNCEXMAMT[indexNCEXMAMT].Dep_3rd, 10, 2),
            ' ',
            formatF( (fWorking.Work_nc_no_of_dep - 2) * arrayNCEXMAMT[indexNCEXMAMT].Dep_3rd, 12, 2 )
            ] ));
        end
     else
        begin
        sRpt.add( format('%-56s %-14s %-14s', [
            '    1st and 2nd Child ' + intToStr( fWorking.Work_nc_no_of_dep )
            + ' x ' + formatF(arrayNCEXMAMT[indexNCEXMAMT].Dep_1st, 10, 2),
            ' ',
            formatF( fWorking.Work_nc_no_of_dep * arrayNCEXMAMT[indexNCEXMAMT].Dep_1st, 12, 2 )
            ] ));
        sRpt.add( format('%-56s %-14s %-14s', [
            '    3rd and each other child ' + intToStr( 0 )
            + ' x ' + formatF(arrayNCEXMAMT[indexNCEXMAMT].Dep_3rd, 10, 2),
            ' ',
            formatF( 0.00, 12, 2 )
            ] ));
        end;
     end;
  sRpt.add( format('%-56s %-14s %-14s', [ ' ',  ' '     ,  dash(12) ]));
  if (wrkClaim.Claim_No <> '00000000') Then
     sRpt.add( format('%-56s %-14s %-14s (F)', [
         '    Total Personal Amount ',
         ' ',
         formatF(fWorking.Work_NC_EXEMPT_AMOUNT, 12, 2 )
         ] ))
  else
     sRpt.add( format('%-56s %-14s %-14s (F)', [
         '    Total Personal Amount ',
         ' ',
         formatF(0.00, 12, 2 )
         ] ));
  sRpt.add( format('%-56s %-14s %-14s', [ ' ',  ' '     ,  dDash(12) ]));
  sRpt.add(' ');
end;

procedure TWagelossCalculationWorksheetForm.ExcemptionAndCreditAmountBand1P2;
begin
  sRpt.add(formatI(wrkClaim.Tax_Year,4) + ' Manitoba Tax Reduction Amount:');
  sRpt.add(' ');
  sRpt.add( format('%-56s %-14s %-14s', [
    '    Workers basic credit ',
    ' ',
    formatF( fWorking.Work_III_Personal, 12, 2 )
    ] ));
  sRpt.add( format('%-56s %-14s %-14s', [
    '    Married (spouse claimed as a dependent) claim ' +
      formatF(arrayNCEXMAMT[indexNCEXMAMT].III_Spouse, 10, 2),
    ' ',
    formatF( fWorking.Work_NC_III_SPOUSE, 12, 2 )
    ] ));
  sRpt.add( format('%-56s %-14s %-14s', [
    '    Single ( claim 1 child as spouse ) ' +
      formatF(arrayNCEXMAMT[indexNCEXMAMT]. III_ChildSpouse, 10, 2),
    ' ',
    formatF( fworking.Work_NC_III_CHILDSPOUSE, 12, 2 )
    ] ));

  sRpt.add( format('%-56s %-14s %-14s', [
    '    Each additional child  ' + intToStr( fworking.Work_nc_no_of_dep ) + ' x '
      + formatF(arrayNCEXMAMT[indexNCEXMAMT].III_Dep, 10, 2),
    ' ',
    formatF( fworking.Work_NC_III_DEP, 12, 2 )
    ] ));


  sRpt.add( format('%-56s %-14s %-14s', [
    '    Infirm dependents ( age 18+ ) ' + intToStr( fworking.Work_nc_no_infirm ) + ' x '
      + formatF(arrayNCEXMAMT[indexNCEXMAMT].III_Infirm_Dep, 10, 2),
    ' ',
    formatF( fworking.Work_NC_III_INFIRM, 12, 2 )
    ] ));
  sRpt.add( format('%-56s %-14s %-14s', [ ' ',  ' '     ,  dash(12) ]));

  if (wrkClaim.Claim_No <> '00000000') Then
     sRpt.add( format('%-56s %-14s %-14s (H)', [
         '    Manitoba Tax Reduction Amount ',
         ' ',
         formatF( fworking.Work_nc_iii_credit, 12, 2 )
         ] ))
  else
     sRpt.add( format('%-56s %-14s %-14s (H)', [
         '    Manitoba Tax Reduction Amount ',
         ' ',
         formatF(0.00, 12, 2 )
         ] ));
  sRpt.add( format('%-56s %-14s %-14s', [ ' ',  ' '     , dDash(12) ]));

  sRpt.add(' ');
  sRpt.add(dash(91));
end;

procedure TWagelossCalculationWorksheetForm.DisplaySurtax;
Begin
  sRpt.add(formatI(wrkClaim.Tax_Year,4) + ' Manitoba Surtax Credit Amount:');
  sRpt.add(' ');
  sRpt.add( format('%-56s %-14s %-14s', [
    '    Worker''s basic credit ',
    ' ',
    formatF( fWorking.Work_II_Personal, 12, 2 )
    ] ));
  sRpt.add( format('%-56s %-14s %-14s', [
    '    Married (spouse claimed as a dependent) ' +
    formatF(arrayNCEXMAMT[indexNCEXMAMT].II_Spouse, 10, 2),
    ' ',
    formatF( fWorking.Work_NC_II_SPOUSE, 12, 2 )
    ] ));
  sRpt.add( format('%-56s %-14s %-14s', [
    '    Single ( claim 1 child as spouse ) ' +
    formatF(arrayNCEXMAMT[indexNCEXMAMT].II_ChildSpouse, 10, 2),
    ' ',
    formatF( fWorking.Work_NC_II_CHILDSPOUSE, 12, 2 )
    ] ));
  sRpt.add( format('%-56s %-14s %-14s', [
    '    Each additional child  ' + intToStr( fWorking.Work_nc_no_of_dep )
    + ' x ' + formatF(arrayNCEXMAMT[indexNCEXMAMT].II_Dep, 10, 2),
    ' ',
    formatF( fWorking.Work_nc_II_dep, 12, 2 )
    ] ));
  sRpt.add( format('%-56s %-14s %-14s', [
    '    Infirm dependents ( age 18+ ) ' + intToStr( fWorking.Work_nc_no_infirm )
    + ' x ' + formatF(arrayNCEXMAMT[indexNCEXMAMT].II_Infirm_Dep, 10, 2),
    ' ',
    formatF( fWorking.Work_nc_II_infirm, 12, 2 )
    ] ));
  sRpt.add( format('%-56s %-14s %-14s', [ ' ',  ' '     ,  dash(12) ]));
  
  if (wrkClaim.Claim_No <> '00000000') Then
     sRpt.add( format('%-56s %-14s %-14s (G)', [
         '    Manitoba Surtax Credit',
         ' ',
         formatF( fWorking.Work_nc_ii_credit, 12, 2 )
         ] ))
  else
     sRpt.add( format('%-56s %-14s %-14s (G)', [
         '    Manitoba Surtax Credit',
         ' ',
         formatF( 0.00, 12, 2 )
         ] ));

  sRpt.add( format('%-56s %-14s %-14s', [ ' ',  ' '     , dDash(12) ]));
  sRpt.add(' ');
End;
(******************************************************************************)
(*                                                                            *)
(*  Create Tax Calculation Band                                               *)
(*                                                                            *)
(******************************************************************************)
procedure TWagelossCalculationWorksheetForm.TaxCalculationBand1( const income: currency;
                                                                 sIncomeType: shortstring );
var
  t2 : currency;
  a : currency;
  b	: currency;
  ws_Work_nc_bc_ann_sal_net : currency;
  ws_Work_nc_bc_bft	: currency;
  ws_Work_nc_bc_cpp	: currency;
  ws_Work_nc_bc_uic	: currency;
  ws_Work_nc_bc_nrtc : currency;
  ws_Work_nc_bc_fst : currency;
  ws_Work_nc_bc_mb_nrtc	: currency;
  ws_Work_nc_bc_mb_tax : currency;
  ws_Work_nc_bc_netinc : currency;
  ws_Work_nc_bc_td : currency;
  //federalCanadaEmploymentCredit : currency;
  mbFamilyTaxBenefitAmt : currency;
  ws_Work_nc_bc_mbt : currency;
begin
  ws_Work_nc_bc_ann_sal_net := Set_nc_bc_ann_sal_net(sIncomeType);
  ws_Work_nc_bc_bft := Set_nc_bc_bft(sIncomeType);
  ws_Work_nc_bc_cpp	:= Set_nc_bc_cpp(sIncomeType);
  ws_Work_nc_bc_uic	:= Set_nc_bc_uic(sIncomeType);
  ws_Work_nc_bc_nrtc := Set_nc_bc_nrtc(sIncomeType);
  ws_Work_nc_bc_fst := Set_nc_bc_fst(sIncomeType);
  ws_Work_nc_bc_mb_nrtc := Set_nc_bc_mb_nrtc(sIncomeType);
  ws_Work_nc_bc_mb_tax := Set_nc_bc_mb_tax(sIncomeType);
  ws_Work_nc_bc_netinc := Set_nc_bc_netinc(sIncomeType);
  ws_Work_nc_bc_td := Set_nc_bc_td(sIncomeType);
  ws_Work_nc_bc_mbt	:= Set_nc_bc_mbt(sIncomeType);
  //federalCanadaEmploymentCredit := Set_federalCanadaEmploymentCredit(sIncomeType);
  mbFamilyTaxBenefitAmt    := Set_mbFamilyTaxBenefitAmt(sIncomeType);

  TaxCalculationBand1P1(income, sIncomeType, ws_Work_nc_bc_ann_sal_net);
  //TaxCalculationBand1P2(income, ws_Work_nc_bc_ann_sal_net,
  //                      ws_Work_nc_bc_uic, ws_Work_nc_bc_cpp,
  //                      ws_Work_nc_bc_nrtc, ws_Work_nc_bc_mb_nrtc, federalCanadaEmploymentCredit);
  TaxCalculationBand1P2(income, ws_Work_nc_bc_ann_sal_net,
                        ws_Work_nc_bc_uic, ws_Work_nc_bc_cpp,
                        ws_Work_nc_bc_nrtc, ws_Work_nc_bc_mb_nrtc, mbFamilyTaxBenefitAmt);
  t2 := TaxCalculationBand1P3(ws_Work_nc_bc_ann_sal_net, ws_Work_nc_bc_nrtc);
  TaxCalculationBand1P4(ws_Work_nc_bc_bft, ws_Work_nc_bc_fst);
  a := TaxCalculationBand1P5(ws_Work_nc_bc_bft);
  b := TaxCalculationBand1P6(ws_Work_nc_bc_ann_sal_net);
  TaxCalculationBand1P7(ws_Work_nc_bc_ann_sal_net, ws_Work_nc_bc_mb_tax, a, b);
  TaxCalculationBand1P8(ws_Work_nc_bc_cpp, ws_Work_nc_bc_uic, t2);
  TaxCalculationBand1P9(ws_Work_nc_bc_fst);
  TaxCalculationBand1P10(income, sIncomeType, ws_Work_nc_bc_mb_tax, ws_Work_nc_bc_td,
                         ws_Work_nc_bc_cpp, ws_Work_nc_bc_uic, ws_Work_nc_bc_bft,
                         ws_Work_nc_bc_fst, ws_Work_nc_bc_netinc, ws_Work_nc_bc_mbt);
end;

Function TWagelossCalculationWorksheetForm.Set_nc_bc_mbt(sIncType: shortString): currency;
begin
   if sIncType = 'Actual' then
      begin
      result := fWorking.Work_nc_bc_mbt_a;
      end
   else if sIncType = 'Maximum' then
      begin
      result := fWorking.Work_nc_bc_mbt_b;
      end
   else if sIncType = 'Sheltered' then
      begin
      result := fWorking.Work_nc_bc_mbt_c;
      end
   else if sIncType = 'Minimum Annual Earnings (AA)' then
  begin
    result := fWorking.Work_nc_bc_mbt_m;
  end
  else if sIncType = 'Collateral Benefits - Only' then
  begin
    result := fWorking.Work_nc_bc_mbt_d;
  end
  else if sIncType = 'Sheltered (CC)' then
  begin
    result := fWorking.Work_nc_bc_mbt_s;
  end
  else
      begin
      result := fWorking.Work_nc_bc_mbt_e;
      end;
end;

Function TWagelossCalculationWorksheetForm.Set_nc_bc_ann_sal_net(sIncType: shortString): currency;
begin
	if sIncType = 'Actual' then
	begin
  	result := fWorking.Work_nc_bc_ann_sal_net_a;
 	end
 	else if sIncType = 'Maximum' then
 	begin
   	result := fWorking.Work_nc_bc_ann_sal_net_b;
 	end
 	else if sIncType = 'Sheltered' then
 	begin
   	result := fWorking.Work_nc_bc_ann_sal_net_c;
 	end
 	else if sIncType = 'Minimum Annual Earnings (AA)' then
  begin
    result := fWorking.Work_nc_bc_ann_sal_net_m;
  end
  else if sIncType = 'Collateral Benefits - Only' then
  begin
    result := fWorking.Work_nc_bc_ann_sal_net_d;
  end
  else if sIncType = 'Sheltered (CC)' then
  begin
    result := fWorking.Work_nc_bc_ann_sal_net_s;
  end
  else
 	begin
   	result := fWorking.Work_nc_bc_ann_sal_net_e;
 	end;
end;

Function TWagelossCalculationWorksheetForm.Set_nc_bc_bft(sIncType: shortString): currency;
begin
	if sIncType = 'Actual' then
	begin
   	result:=fworking.Work_nc_bc_bft_a;
 	end
 	else if sIncType = 'Maximum' then
 	begin
   	result:=fWorking.Work_nc_bc_bft_b;
 	end
 	else if sIncType = 'Sheltered' then
 	begin
   	result:=fWorking.Work_nc_bc_bft_c;
 	end
 	else if sIncType = 'Minimum Annual Earnings (AA)' then
  begin
    result := fWorking.Work_nc_bc_bft_m;
  end
  else if sIncType = 'Collateral Benefits - Only' then
  begin
    result := fWorking.Work_nc_bc_bft_d;
  end
  else if sIncType = 'Sheltered (CC)' then
  begin
    result := fWorking.Work_nc_bc_bft_s;
  end
  else
 	begin
   	result:=fWorking.Work_nc_bc_bft_e;
 	end;
end;

Function TWagelossCalculationWorksheetForm.Set_nc_bc_cpp(sIncType: shortString): currency;
begin
	if sIncType = 'Actual' then
	begin
 		result:=fWorking.Work_nc_bc_cpp_a;
 	end
 	else if sIncType = 'Maximum' then
 	begin
   	result:=fWorking.Work_nc_bc_cpp_b;
 	end
 	else if sIncType = 'Sheltered' then
 	begin
   	result:=fWorking.Work_nc_bc_cpp_c;
 	end
  else if sIncType = 'Minimum Annual Earnings (AA)' then
  begin
    result := fWorking.Work_nc_bc_cpp_m;
  end
  else if sIncType = 'Collateral Benefits - Only' then
  begin
    result := fWorking.Work_nc_bc_cpp_d;
  end
  else if sIncType = 'Sheltered (CC)' then
  begin
    result := fWorking.Work_nc_bc_cpp_s;
  end
  else
 	begin
  	result:=fWorking.Work_nc_bc_cpp_e;
 	end;
end;

Function TWagelossCalculationWorksheetForm.Set_nc_bc_uic(sIncType: shortString): currency;
begin
	if sIncType = 'Actual' then
	begin
   	result:=fWorking.Work_nc_bc_uic_a;
 	end
 	else if sIncType = 'Maximum' then
 	begin
   	result:=fWorking.Work_nc_bc_uic_b;
 	end
 	else if sIncType = 'Sheltered' then
 	begin
   	result:=fWorking.Work_nc_bc_uic_c;
 	end
 	else if sIncType = 'Minimum Annual Earnings (AA)' then
  begin
    result := fWorking.Work_nc_bc_uic_m;
  end
  else if sIncType = 'Collateral Benefits - Only' then
  begin
    result := fWorking.Work_nc_bc_uic_d;
  end
  else if sIncType = 'Sheltered (CC)' then
  begin
    result := fWorking.Work_nc_bc_uic_s;
  end
  else
 	begin
   	result:=fWorking.Work_nc_bc_uic_e;
 	end;
end;
{
Function TWagelossCalculationWorksheetForm.Set_federalCanadaEmploymentCredit(sIncType: shortString): currency;
begin
  if sIncType = 'Actual' then
	begin
   	result := fWorking.Work_federalCanadaEmploymentCredit_a;
 	end
 	else if sIncType = 'Maximum' then
 	begin
   	result := fWorking.Work_federalCanadaEmploymentCredit_b;
 	end
 	else if sIncType = 'Sheltered' then
 	begin
   	result := fWorking.Work_federalCanadaEmploymentCredit_c;
 	end
 	else if sIncType = 'Minimum Annual Earnings (AA)' then
  begin
    result := fWorking.Work_federalCanadaEmploymentCredit_m;
  end
  else if sIncType = 'Collateral Benefits - Only' then
  begin
    result := fWorking.Work_federalCanadaEmploymentCredit_d;
  end
  else if sIncType = 'Sheltered (CC)' then
  begin
    result := fWorking.Work_federalCanadaEmploymentCredit_s;
  end
  else
 	begin
   	result := fWorking.Work_federalCanadaEmploymentCredit_e;
 	end;
end;
}

Function TWagelossCalculationWorksheetForm.Set_mbFamilyTaxBenefitAmt(sIncType: shortString): currency;
begin
  if sIncType = 'Actual' then
	begin
   	result := fWorking.Work_mbFamilyTaxBenefitRate_a
 	end
 	else if sIncType = 'Maximum' then
 	begin
   	result := fWorking.Work_mbFamilyTaxBenefitRate_b;
 	end
 	else if sIncType = 'Sheltered' then
 	begin
   	result := fWorking.Work_mbFamilyTaxBenefitRate_c;
 	end
 	else if sIncType = 'Minimum Annual Earnings (AA)' then
  begin
    result := fWorking.Work_mbFamilyTaxBenefitRate_m;
  end
  else if sIncType = 'Collateral Benefits - Only' then
  begin
    result := fWorking.Work_mbFamilyTaxBenefitRate_d;
  end
  else if sIncType = 'Sheltered (CC)' then
  begin
    result := fWorking.Work_mbFamilyTaxBenefitRate_s;
  end
  else
 	begin
   	result := fWorking.Work_mbFamilyTaxBenefitRate_e;
 	end;
end;

Function TWagelossCalculationWorksheetForm.Set_nc_bc_nrtc(sIncType: shortString): currency;
begin
	if sIncType = 'Actual' then
	begin
   	result:=fWorking.Work_nc_bc_nrtc_a;
 	end
 	else if sIncType = 'Maximum' then
 	begin
   	result:=fWorking.Work_nc_bc_nrtc_b;
 	end
 	else if sIncType = 'Sheltered' then
 	begin
   	result:=fWorking.Work_nc_bc_nrtc_c;
 	end
 	else if sIncType = 'Minimum Annual Earnings (AA)' then
  begin
    result := fWorking.Work_nc_bc_nrtc_m;
  end
  else if sIncType = 'Collateral Benefits - Only' then
  begin
    result := fWorking.Work_nc_bc_nrtc_d;
  end
  else if sIncType = 'Sheltered (CC)' then
  begin
    result := fWorking.Work_nc_bc_nrtc_s;
  end
  else
 	begin
   	result:=fWorking.Work_nc_bc_nrtc_e;
 	end;
end;

Function TWagelossCalculationWorksheetForm.Set_nc_bc_fst(sIncType: shortString): currency;
begin
    if sIncType = 'Actual' then
       begin
       result := fWorking.Work_nc_bc_fst_a;
       end
    else if sIncType = 'Maximum' then
       begin
       result := fWorking.Work_nc_bc_fst_b;
       end
    else if sIncType = 'Sheltered' then
       begin
       result := fWorking.Work_nc_bc_fst_c;
       end
    else if sIncType = 'Minimum Annual Earnings (AA)' then
  begin
    result := fWorking.Work_nc_bc_fst_m;
  end
  else if sIncType = 'Collateral Benefits - Only' then
  begin
    result := fWorking.Work_nc_bc_fst_d;
  end
  else if sIncType = 'Sheltered (CC)' then
  begin
    result := fWorking.Work_nc_bc_fst_s;
  end
  else
       begin
       result := fWorking.Work_nc_bc_fst_e;
       end;
end;

Function TWagelossCalculationWorksheetForm.Set_nc_bc_mb_nrtc(sIncType: shortString): currency;
begin
   if sIncType = 'Actual' then
      begin
      result:=fWorking.Work_nc_bc_mb_nrtc_a;
      end
   else if sIncType = 'Maximum' then
      begin
      result:=fWorking.Work_nc_bc_mb_nrtc_b;
      end
   else if sIncType = 'Sheltered' then
      begin
      result:=fWorking.Work_nc_bc_mb_nrtc_c;
      end
   else if sIncType = 'Minimum Annual Earnings (AA)' then
  begin
    result := fWorking.Work_nc_bc_mb_nrtc_m;
  end
  else if sIncType = 'Collateral Benefits - Only' then
  begin
    result := fWorking.Work_nc_bc_mb_nrtc_d;
  end
  else if sIncType = 'Sheltered (CC)' then
  begin
    result := fWorking.Work_nc_bc_mb_nrtc_s;
  end
  else
      begin
      result:=fWorking.Work_nc_bc_mb_nrtc_e;
      end;
end;

Function TWagelossCalculationWorksheetForm.Set_nc_bc_mb_tax(sIncType: shortString): currency;
begin
   if sIncType = 'Actual' then
      begin
      result := fWorking.Work_nc_bc_mb_tax_a;
      end
   else if sIncType = 'Maximum' then
      begin
      result := fWorking.Work_nc_bc_mb_tax_b;
      end
   else if sIncType = 'Sheltered' then
      begin
      result := fWorking.Work_nc_bc_mb_tax_c;
      end
   else if sIncType = 'Minimum Annual Earnings (AA)' then
  begin
    result := fWorking.Work_nc_bc_mb_tax_m;
  end
  else if sIncType = 'Collateral Benefits - Only' then
  begin
    result := fWorking.Work_nc_bc_mb_tax_d;
  end
  else if sIncType = 'Sheltered (CC)' then
  begin
    result := fWorking.Work_nc_bc_mb_tax_s;
  end
  else
      begin
      result := fWorking.Work_nc_bc_mb_tax_e;
      end;
end;

Function TWagelossCalculationWorksheetForm.Set_nc_bc_netinc(sIncType: shortString): currency;
begin
	if sIncType = 'Actual' then
	begin
   	result:=fWorking.Work_nc_bc_netinc_a;
 	end
 	else if sIncType = 'Maximum' then
 	begin
   	result:=fWorking.Work_nc_bc_netinc_b;
 	end
 	else if sIncType = 'Sheltered' then
 	begin
   	result:=fWorking.Work_nc_bc_netinc_c;
 	end
 	else if sIncType = 'Minimum Annual Earnings (AA)' then
  begin
    result := fWorking.Work_nc_bc_netinc_m;
  end
  else if sIncType = 'Collateral Benefits - Only' then
  begin
    result := fWorking.Work_nc_bc_netinc_d;
  end
  else if sIncType = 'Sheltered (CC)' then
  begin
    result := fWorking.Work_nc_bc_netinc_s;
  end
  else
 	begin
   	result:=fWorking.Work_nc_bc_netinc_e;
 	end;
end;

Function TWagelossCalculationWorksheetForm.Set_nc_bc_td(sIncType: shortString): currency;
begin
	if sIncType = 'Actual' then
	begin
   	result:=fWorking.Work_nc_bc_td_a;
 	end
 	else if sIncType = 'Maximum' then
 	begin
   	result:=fWorking.Work_nc_bc_td_b;
 	end
 	else if sIncType = 'Sheltered' then
 	begin
   	result:=fWorking.Work_nc_bc_td_c;
 	end
 	else if sIncType = 'Minimum Annual Earnings (AA)' then
  begin
    result := fWorking.Work_nc_bc_td_m;
  end
  else if sIncType = 'Collateral Benefits - Only' then
  begin
    result := fWorking.Work_nc_bc_td_d;
  end
  else if sIncType = 'Sheltered (CC)' then
  begin
    result := fWorking.Work_nc_bc_td_s;
  end
  else
 	begin
   	result:=fWorking.Work_nc_bc_td_e;
 	end;
end;

procedure TWagelossCalculationWorksheetForm.TaxCalculationBand1P1( const income: currency;
                                     															 sIncType: shortstring;
                                                                   Nc_Bc_Ann_Sal_Net: currency);
Begin
  sRpt.add(' ');
  sRpt.add(formatI(wrkClaim.Tax_Year,4) + ' Income Tax Calculation');
  sRpt.add(' ');
  sRpt.add( format('%-56s %-14s %-14s (I)', [
    'Gross Income ( "' + sIncType + '" ) ',
    ' ',
    formatF( income, 12, 2 )
    ]));
  sRpt.add( format('%-56s %-14s %-14s', [ ' ',  ' ', dDash(12)  ]));
  sRpt.add(' ');
  sRpt.add('Net Income: ');
  sRpt.add( format('%-14s %8.4n%% %-40s %-14s (LK)', [
    formatF(income, 11, 2) + '      - (',
    (fWorking.Work_nc_prorate*100.00),
    ' X ' + formatF(fWorking.Work_nc_bc_deductions, 11, 2) + ')=',
    formatF(Nc_Bc_Ann_Sal_Net, 12, 2 )
    ]));
  sRpt.add( format('%-56s %-14s %-14s', [
     'Amount (I) above - (    FT      X       DED    )',
     ' ',
     dash(12)
     ]));
  sRpt.add('   * FT applies only if type of income not ''Actual'' ');
  sRpt.add(' ');
  sRpt.add('CPP Contribution & EI premiums Calculation:');
  sRpt.add(' ');
End;

//procedure TWagelossCalculationWorksheetForm.TaxCalculationBand1P2( const income: currency;
//                                                                   Nc_Bc_Ann_Sal_Net: currency;
//                                                                   Nc_Bc_Uic: currency;
//                                                                   Nc_Bc_Cpp: currency;
//                                                                   Nc_Bc_Nrtc: currency;
//                                                                   Nc_Bc_Mb_Nrtc: currency;
//                                                                   federalCanadaEmploymentCredit: currency);
procedure TWagelossCalculationWorksheetForm.TaxCalculationBand1P2( const income: currency;
                                                                   Nc_Bc_Ann_Sal_Net: currency;
                                                                   Nc_Bc_Uic: currency;
                                                                   Nc_Bc_Cpp: currency;
                                                                   Nc_Bc_Nrtc: currency;
                                                                   Nc_Bc_Mb_Nrtc: currency;
                                                                   nc_mbFamilyTaxBenefitAmt: currency);
Var
  t: Currency;
  ws: String;
Begin
  sRpt.add('    CPP: ');
  ws:=format('    ( $%.2n - $%.2n ) x %.4n%% = ( Maximum $%.2n )',
    [
    income,
    arrayNCTAXRAT[indexNCTAXRAT].CPP_basic_exemption,
    ( arrayNCTAXRAT[indexNCTAXRAT].CPP_contrib_rate *100.00 ),
    arrayNCTAXRAT[indexNCTAXRAT].CPP_max_annual_contrib
    ]
    );
  sRpt.add( format('%-70s  %-14s (J)', [ ws, formatF( Nc_Bc_Cpp, 12, 2 ) ] ));
  sRpt.add( format('%-56s %-14s %-14s', [ '     Amount (I) above',  ' ', dash(12)  ]));
  sRpt.add(' ');
  sRpt.add('    EI: ');
  ws:=format('    $%.2n  x %.2n%% = ( Maximum $%.2n )',
    [
    income,
    (arrayNCTAXRAT[indexNCTAXRAT].UIC_premium_rate * 100.00),
    arrayNCTAXRAT[indexNCTAXRAT].UIC_max_annual_premium
    ] );
  sRpt.add( format('%-70s  %-14s (K)', [ ws, formatF( Nc_Bc_Uic, 12, 2 ) ] ));
  sRpt.add( format('%-56s %-14s %-14s', [ '     Amount (I) above',  ' ', dash(12) ]));
  sRpt.add(' ');
  sRpt.add('Non Refundable Tax Credit:');
  sRpt.add(' ');
  sRpt.add( format('%-56s %-14s %-14s', [
    '    CPP amount (J) above',
  formatF( Nc_Bc_Cpp, 12, 2 ),
    ' '
    ] ));
  sRpt.add(' ');
  sRpt.add( format('%-56s %-14s %-14s', [
    '    EI amount (K) above',
    formatF( Nc_Bc_Uic, 12, 2 ),
    ' '
    ] ));
  sRpt.add(' ');

  if (wrkClaim.Claim_No <> '00000000') Then
     Begin
     sRpt.add( format('%-56s %-14s %-14s', [
         '    Tax Personal Amts (F)',
         formatF( fworking.Work_nc_tax_exmp, 12, 2 ),
         ' '
         ] ));
     sRpt.add( format('%-56s %-14s %-14s', [ ' ',  dash(12),  ' '      ]));
     t:=Nc_Bc_Cpp+Nc_Bc_Uic+fworking.Work_nc_tax_exmp;
     sRpt.add( format('%-56s %-14s %-14s (L)', [
         '    Total x '+
         format( '%.1n', [(arrayNCTAXRAT[indexNCTAXRAT].FED_tax_rate_i*100.00) ] ) +
         '%' + ' (Federal)',
         formatF( t, 12, 2 ),
         formatF( Nc_Bc_Nrtc, 12, 2 )
         ] ));
     sRpt.add( format('%-56s %-14s %-14s', [ ' ', dDash(12), dDash(12) ]));
     sRpt.add( format('%-56s %-14s %-14s (M)', [
         '    Total x '+
         format( '%.1n', [(arrayNCTAXRAT[indexNCTAXRAT].MB_tax_rate_i*100.00) ] ) +
         '%' + ' (Manitoba Tax Rate)',
         formatF( t, 12, 2 ),
         formatF( Nc_Bc_Mb_Nrtc, 12, 2 )
         ] ));
     end
  else
     Begin
     sRpt.add( format('%-56s %-14s %-14s', [
         '    Tax Personal Amts (F)',
         formatF(0.00, 12, 2 ),
         ' '
         ] ));
     sRpt.add( format('%-56s %-14s %-14s', [ ' ',  dash(12),  ' '      ]));
     sRpt.add( format('%-56s %-14s %-14s (L)', [
         '    Total x '+
         format( '%.1n', [(arrayNCTAXRAT[indexNCTAXRAT].FED_tax_rate_i*100.00) ] ) +
         '%' + ' (Federal)',
         formatF(0.00, 12, 2 ),
         formatF(0.00, 12, 2 )
         ] ));
     sRpt.add( format('%-56s %-14s %-14s', [ ' ', dDash(12), dDash(12) ]));
     sRpt.add( format('%-56s %-14s %-14s (M)', [
         '    Total x '+
         format( '%.1n', [(arrayNCTAXRAT[indexNCTAXRAT].MB_tax_rate_i*100.00) ] ) +
         '%' + ' (Manitoba Tax Rate)',
         formatF(0.00, 12, 2 ),
         formatF(0.00, 12, 2 )
         ] ));
     end;

  sRpt.add( format('%-56s %-14s %-14s', [ ' ', dDash(12), dDash(12) ]));
  sRpt.add(' ');
  sRpt.add(formatI(wrkClaim.Tax_Year,4) + ' Federal Income Tax Rates (WCB):');
  sRpt.add(' ');
End;

Function  TWagelossCalculationWorksheetForm.TaxCalculationBand1P3(Nc_Bc_Ann_Sal_Net: currency;
                                                                  Nc_Bc_Nrtc: currency): currency;
Var
  const1, const2, f1i, f2p, work: currency;
Begin
  with arrayNCTAXRAT[indexNCTAXRAT] do
     begin
     sRpt.add('    +'+ dash(76) + '+');
     sRpt.add( format('    | %-28s | %-20s | %-20s |', [
         'Taxable Income Amount',
         'Federal Tax Rate',
         'Constant'
         ]));
     sRpt.add('    +'+ dash(76) + '+');
     sRpt.add( format('    | %-28s | %-20s | %-20s |', [
         format('%.0n',[FED_income_level_i]) + ' or less',
         format('%.2n',[(FED_tax_rate_i*100.00)]) + '%',
         format('%.0n',[0.00])
         ]));

     const1 := Round(FED_income_level_i * (FED_tax_rate_ii - FED_tax_rate_i));
     const2 := Round(FED_income_level_ii * (FED_tax_rate_iii - FED_tax_rate_ii) + const1);

     sRpt.add( format('    | %-28s | %-20s | %-20s |', [
         '> ' + format('%.0n',[FED_income_level_i]),
         format('%.1n',[(FED_tax_rate_ii*100.00)]) + '%',
         format('%.0n',[const1])
         ]));

     sRpt.add( format('    | %-28s | %-20s | %-20s |', [
         '> ' + format('%.0n',[FED_income_level_ii]),
         format('%.1n',[(FED_tax_rate_iii*100.00)]) + '%',
         format('%.0n',[const2])
         ]));
     sRpt.add('    +'+ dash(76) + '+');
     sRpt.add(' ');
     sRpt.add('Federal Income Tax:');
     sRpt.add(' ');
     sRpt.add('    For ' + formatF(Nc_Bc_Ann_Sal_Net, 11, 2 ) +' (Amount (LK) above):' );

     if ( Nc_Bc_Ann_Sal_Net > FED_income_level_ii ) then
        begin
        f2p := FED_tax_rate_iii;
        f1i := const2;
        end
     else if ( Nc_Bc_Ann_Sal_Net > FED_income_level_i ) then
        begin
        f2p := FED_tax_rate_ii;
        f1i := const1;
        end
     else
        begin
        f2p := FED_tax_rate_i;
        f1i := 0.00;
        end;
     end;

  if (wrkClaim.Claim_No = '00000000') Then
     begin
     f2p := 0; // set the tax rate to be a blank
     end;

  sRpt.add(' ');
  sRpt.add( format('%-56s %-14s %-14s', [
    '    Multiply by tax rate from above table ' + format('%.2n',[f2p * 100]) + '%',
    formatF(PDoxRound((Nc_Bc_Ann_Sal_Net * f2p), 2), 12, 2 ), ' '
    ] ));
  sRpt.add(' ');
  sRpt.add( format('%-56s %-14s %-14s', [
    '    Less:  Constant from above table',
    formatF(f1i, 12, 2 ), ' '
    ] ));
  work := PDoxRound((Nc_Bc_Ann_Sal_Net * f2p) - f1i, 2);

  if work < 0 then
     work := 0.00;

  sRpt.add( format('%-56s %-14s %-14s', [ ' ',  dash(12), ' '       ]));
  sRpt.add( format('%-56s %-14s %-14s', [
      '    Federal Income Tax ',
      formatF( work, 12, 2 ),
      ' (N)'
      ] ));
  sRpt.add(' ');

  if (wrkClaim.Claim_No <> '00000000') Then
     sRpt.add( format('%-56s %-14s %-14s', [
         '    Less: Non Refundable Tax Credit (L) above ',
         formatF( Nc_Bc_Nrtc, 12, 2 ),
         ' '
         ] ))
  else
     sRpt.add( format('%-56s %-14s %-14s', [
         '    Less: Non Refundable Tax Credit (L) above ',
         formatF(0.00, 12, 2 ),
         ' '
         ] ));

  Result := PDoxRound((((Nc_Bc_Ann_Sal_Net * f2p) - f1i) - Nc_Bc_Nrtc), 2);

  if Result < 0 then
     Result := 0;

  sRpt.add( format('%-56s %-14s %-14s', [ ' ',  dash(12), ' '       ]));
  sRpt.add( format('%-56s %-14s %-14s', [
    '    Basic Federal Tax ',
    formatf( result, 12, 2),
    ' (O)'
    ] ));
  sRpt.add( format('%-56s %-14s %-14s', [ ' ', dDash(12), ' '       ]));
  sRpt.add(' ');
End;

procedure TWagelossCalculationWorksheetForm.TaxCalculationBand1P4(Nc_Bc_Bft: Currency;
                                                                  Nc_Bc_Fst: Currency);
var
  t: currency;
begin
  sRpt.add('Federal Surtax:');
  sRpt.add(' ');
  with arrayNCTAXRAT[indexNCTAXRAT] do
  begin
    t:=Nc_Bc_Bft * FED_surtax_rate_i;
    sRpt.add( format('%-56s %-14s %-14s', [
      'Basic Federal Tax: (O) ' +
      formatF( Nc_Bc_Bft, 12, 2 ) + ' x ' +
      format( '%.2n', [ ( FED_surtax_rate_i * 100.00 ) ] ) + '%',
      formatF( t, 12, 2 ),
      ' '
      ]));
    t:=( Nc_Bc_Bft - FED_surtax_limit_ii ) * FED_surtax_rate_ii;
    if t < 0 then t := 0;
    sRpt.add( format('%-56s %-14s %-14s', [
      'add: Amount(O) (' +
      formatF( Nc_Bc_Bft, 12, 2 ) + ' - ' +
      formatF( FED_surtax_limit_ii, 12, 2 ) + ') x ' +
      format( '%.2n', [ ( FED_surtax_rate_Ii * 100.00 ) ] ) + '%',
      formatF( t, 12, 2 ),
      ' '
      ]));
  end;
  sRpt.add( format('%-56s %-14s %-14s', [ ' ',  dash(12), ' '       ]));
  sRpt.add( format('%-56s %-14s %-14s', [
    '    Federal Surtax ',
    formatF( Nc_Bc_Fst, 12, 2 ),
    ' (P1)'
    ] ));
  sRpt.add( format('%-56s %-14s %-14s', [ ' ', dDash(12), ' '       ]));
  sRpt.add(' ');
End;

Function TWagelossCalculationWorksheetForm.TaxCalculationBand1P5(Nc_Bc_Bft: currency): currency;
begin
  sRpt.add('Manitoba Income Tax:');
  sRpt.add(' ');
  with arrayNCTAXRAT[indexNCTAXRAT] do
     begin
     result :=Nc_Bc_Bft * MB_tax_rate;
     sRpt.add( format('%-70s  %-14s (a)', [
         'Basic Manitoba Income tax (O) above ' +
         formatF( Nc_Bc_Bft, 12, 2 ) + ' x ' +
         format( '%.2n', [ ( MB_tax_rate * 100.00 ) ] ) + '% =',
         formatF( result , 12, 2 )
         ]));
     end;
end;

Function TWagelossCalculationWorksheetForm.TaxCalculationBand1P6(Nc_Bc_Ann_Sal_Net: currency): currency;
begin
  result:=Nc_Bc_Ann_Sal_Net * arrayNCTAXRAT[indexNCTAXRAT].MB_net_tax_rate;
end;

Procedure TWagelossCalculationWorksheetForm.TaxCalculationBand1P7(Nc_Bc_Ann_Sal_Net: currency;
                                                                  Nc_Bc_Mb_Tax: currency;
                                                                  Disp_a: currency;
                                                                  Disp_b: currency);
Var
  c, t: currency;
begin
  sRpt.add( format('%-70s  %-14s (b)', [
    'Manitoba Net Income tax (LK) above ' +
    formatF( Nc_Bc_Ann_Sal_Net, 12, 2 ) + ' x ' +
    format( '%.2n', [ ( arrayNCTAXRAT[indexNCTAXRAT].MB_net_tax_rate * 100.00 ) ] ) + '% =',
    formatF( Disp_b, 12, 2 )
    ]));
  sRpt.add( format('%-56s %-14s %-14s', [
    'Manitoba Surtax: amount (b) above',
    formatF( Disp_b, 12, 2 ),
    ' '
    ]));
  c := Disp_b - fworking.Work_nc_ii_credit;
  if c < 0 then
     c := 0;

  if (wrkClaim.Claim_No <> '00000000') Then
     begin
     sRpt.add( format('%-56s %-14s %-14s (c)', [
         'Less: Manitoba Surtax credit (G)',
         formatF( fworking.Work_nc_ii_credit, 12, 2 ),
         formatF( c, 12, 2 )
         ]));
     t := Disp_a + Disp_b + c;
     sRpt.add( format('%-56s %-14s %-14s (P)', [
         '    Total Manitoba Tax ( add amounts a, b, c )',
         ' ',
         formatF( t, 12, 2 )
         ]));
     sRpt.add( format('%-56s %-14s %-14s', [
         'Manitoba Tax Reduction Amount (H)',
         formatF( fworking.Work_nc_iii_credit, 12, 2 ),
         ' '
         ]));
     t:= fworking.Work_nc_iii_credit - Disp_b;

     if t < 0 then
        t := 0;

     sRpt.add( format('%-56s %-14s %-14s (Q)', [
         'Less: amount (b) above',
         formatF( Disp_b, 12, 2 ),
         formatF( t, 12, 2 )
         ]));
     end
  else
     begin
     sRpt.add( format('%-56s %-14s %-14s (c)', [
         'Less: Manitoba Surtax credit (G)',
         formatF(0.00, 12, 2 ),
         formatF(0.00, 12, 2 )
         ]));
     sRpt.add( format('%-56s %-14s %-14s (P)', [
         '    Total Manitoba Tax ( add amounts a, b, c )',
         ' ',
         formatF(0.00, 12, 2 )
         ]));
     sRpt.add( format('%-56s %-14s %-14s', [
         'Manitoba Tax Reduction Amount (H)',
         formatF(0.00, 12, 2 ),
         ' '
         ]));

     sRpt.add( format('%-56s %-14s %-14s (Q)', [
         'Less: amount (b) above',
         formatF( Disp_b, 12, 2 ),
         formatF(0.00, 12, 2 )
         ]));
     end;


  sRpt.add( format('%-56s %-14s %-14s', [ ' ',  ' ', dash(12) ]));
  sRpt.add( format('%-56s %-14s %-14s (U)', [
    '    Manitoba Tax ( amount P minus Q ) ',
    ' ',
    formatF( Nc_Bc_Mb_Tax, 12, 2 )
    ] ));
  sRpt.add( format('%-56s %-14s %-14s', [ ' ', ' ', dDash(12) ]));
end;

Procedure TWagelossCalculationWorksheetForm.TaxCalculationBand1P8(Nc_Bc_Cpp: currency;
																																	Nc_Bc_Uic: currency;
                                                                  Fed_Tax: currency);
begin
  sRpt.add( format('%-56s %-14s %-14s', [ ' ',' ' , dDash(12) ]));
  sRpt.add(' ');
  sRpt.add('Total Deductions ');
  sRpt.add(' ');
  sRpt.add( format('%-56s %-14s %-14s', [
    '    CPP: amount (J) above',
    formatF( Nc_Bc_Cpp, 12, 2 ),
    ' '
    ] ));
  sRpt.add(' ');
  sRpt.add( format('%-56s %-14s %-14s', [
    '    EI: amount (K) above',
    formatF( Nc_Bc_Uic, 12, 2 ),
    ' '
    ] ));
  sRpt.add(' ');
  sRpt.add( format('%-56s %-14s %-14s', [
    '    Basic Federal Tax: amount (O) above',
    formatF( Fed_Tax, 12, 2 ),
    ' '
    ] ));
end;

Procedure TWagelossCalculationWorksheetForm.TaxCalculationBand1P9(Nc_Bc_Fst: currency);
begin
  sRpt.add(' ');
  sRpt.add( format('%-56s %-14s %-14s', [
    '    Federal Surtax: amount (P1) above',
    formatF( Nc_Bc_Fst, 12, 2 ),
    ' '
    ] ));
end;

Procedure TWagelossCalculationWorksheetForm.TaxCalculationBand1P10(const income: currency;
                                                                   sIncType: shortString;
																																	 Nc_Bc_Mb_Tax: currency;
                                                                   Nc_Bc_Td: currency;
                                                                   Nc_Bc_Cpp: currency;
																																	 Nc_Bc_Uic: currency;
                                                                   Nc_Bc_Bft: Currency;
                                                                   Nc_Bc_Fst: Currency;
                                                                   Nc_Bc_Netinc: currency;
                                                                   Nc_Bc_Mbt: currency);
begin
  sRpt.add(' ');
  sRpt.add( format('%-56s %-14s %-14s', [
    '    Manitoba Tax: amount (U) above',
    formatF( Nc_Bc_Mb_Tax, 12, 2 ),
    ' '
    ] ));
  sRpt.add( format('%-56s %-14s %-14s', [ ' ',  dash(12),  ' '      ]));
  sRpt.add( format('%-56s %-14s %-14s (V)', [
    '    Total Deductions',
    ' ',
    formatF( Nc_Bc_Td, 12, 2 )
    ] ));
  sRpt.add( format('%-56s %-14s %-14s', [ ' ',  ' ', dash(12)]));
  sRpt.add(' ');
  sRpt.add( format('%-56s %-14s %-14s', [
    '    Annual Income: amount (I) above',
    formatF( income, 12, 2 ),
    ' '
    ] ));
  sRpt.add(' ');
  sRpt.add( format('%-56s %-14s %-14s', [
    '    Less: Total Deductions: Amount (V) above',
    formatF( Nc_Bc_Td, 12, 2 ),
    ' '
    ] ));
  sRpt.add( format('%-56s %-14s %-14s', [ ' ',  dash(12),  ' '      ]));
  sRpt.add( format('%-56s %-14s %-14s', [
    '    Annual Net Income',
    ' ',
    formatF( Nc_Bc_Netinc, 12, 2 )
    ] ));
  sRpt.add( format('%-56s %-14s %-14s', [ ' ', ' ', dDash(12)  ]));
  sRpt.add(' ');
  sRpt.add('Carry this amount forward for "' + sIncType +
           '"');
  sRpt.add('under Calculated Net Income amounts.' );
  sRpt.add(' ');
  sRpt.add(dash(91));
end;

procedure TWagelossCalculationWorksheetForm.FormClose(Sender: TObject;
  var Action: TCloseAction);
begin
  Action := caFree;
end;

function TWagelossCalculationWorksheetForm.shelteredGrossIncomeCalc : double;
var
  wrkShelterClaim:recNCCLAIM;
  fShelter : recConst;
begin
  //need to put through the min wage shelter through tax calculator
  copyNCClaim(wrkClaim, wrkShelterClaim);
  wrkShelterClaim.Wkly_Sal_A := wrkClaim.Minimum_wage / 52 * 0.75;
  Calc_ben(wrkShelterClaim, fShelter);
  Result := wrkShelterClaim.Total_Deds;
end;

end.


