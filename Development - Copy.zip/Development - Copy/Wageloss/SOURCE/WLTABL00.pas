(******************************************************************************)
(*  Wageloss System                                                           *)
(*                                                                            *)
(*  Debug Display Form                                                        *)
(*                                                                            *)
(*                                                                            *)
(*  Author: Brad Trupp  / Capella Systems Group, Inc.                         *)
(*  Date:   July 1997                                                         *)
(******************************************************************************)

unit WLTABL00;

interface

uses
  Windows, Messages, SysUtils, Classes, Graphics, Controls, Forms, Dialogs,
  ExtCtrls, StdCtrls, WLTABL01;

type
  TDLLAboutForm = class(TForm)
    Panel1: TPanel;
    Memo1: TMemo;
    procedure FormCreate(Sender: TObject);
    procedure FormCloseQuery(Sender: TObject; var CanClose: Boolean);
  private
    { Private declarations }
  public
    { Public declarations }
    AllowCanClose: boolean;
    procedure updateStatus( s: string );
  end;

var
  DLLAboutForm: TDLLAboutForm;

implementation

{$R *.DFM}

(******************************************************************************)
(*                                                                            *)
(*                                                                            *)
(*                                                                            *)
(******************************************************************************)
procedure TDLLAboutForm.FormCreate(Sender: TObject);
begin
  AllowCanClose:=false;
  Memo1.lines.add( 'WLTABLES DLL Information Window');
  Memo1.lines.add( 'Version=' + WLTABL01VersionNumber );
end;

(******************************************************************************)
(*                                                                            *)
(*                                                                            *)
(*                                                                            *)
(******************************************************************************)
procedure TDLLAboutForm.updateStatus( s: string );
begin
  Memo1.lines.add( s );
end;

(******************************************************************************)
(*                                                                            *)
(*                                                                            *)
(*                                                                            *)
(******************************************************************************)
procedure TDLLAboutForm.FormCloseQuery(Sender: TObject;
  var CanClose: Boolean);
begin
  CanClose:=AllowCanClose;
end;

end.


