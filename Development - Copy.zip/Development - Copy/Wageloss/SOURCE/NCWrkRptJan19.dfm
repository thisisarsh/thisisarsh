inherited WrkRptJan19: TWrkRptJan19
  Caption = 'WrkRptJan19'
  PixelsPerInch = 96
  TextHeight = 13
end
