inherited WrkRptJul19: TWrkRptJul19
  Caption = 'WrkRptJul19'
  PixelsPerInch = 96
  TextHeight = 13
end
