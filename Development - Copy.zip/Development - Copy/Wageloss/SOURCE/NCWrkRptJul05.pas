unit NCWrkRptJul05;

interface

uses
  Windows, Messages, SysUtils, Variants, Classes, Graphics, Controls, Forms,
  Dialogs, quickrpt, NCIniMod, UtilMod1, NCRecDef, NCWrkRptJul04;

type
  TWrkRptJul05 = class(TWrkRptJul04)
  procedure ExcemptionAndCreditAmountBand1P1; Override;
  procedure ExcemptionAndCreditAmountBand1P2; Override;
  procedure ExcemptionAndCreditAmountBand1Man1; Override;
  //procedure TaxCalculationBand1P2( const income: currency;
  //                                 Nc_Bc_Ann_Sal_Net: currency;
  //                                 Nc_Bc_Uic: currency;
  //                                 Nc_Bc_Cpp: currency;
  //                                 Nc_Bc_Nrtc: currency;
  //                                 Nc_Bc_Mb_Nrtc: currency;
  //                                 federalCanadaEmploymentCredit: currency); Override;
  procedure TaxCalculationBand1P2( const income: currency;
                                   Nc_Bc_Ann_Sal_Net: currency;
                                   Nc_Bc_Uic: currency;
                                   Nc_Bc_Cpp: currency;
                                   Nc_Bc_Nrtc: currency;
                                   Nc_Bc_Mb_Nrtc: currency;
                                   nc_mbFamilyTaxBenefitAmt: currency); Override;
  procedure TaxCalculationBand1P1( const income: currency;
                                   sIncType: shortstring;
                                   Nc_Bc_Ann_Sal_Net: currency); Override;
  Function TaxCalculationBand1P5b( Nc_Bc_Ann_Sal_Net: currency;
                                   Nc_Bc_Mb_Nrtc: currency;
                                   Nc_Bc_Mbt: currency): currency; Override;
  procedure CollateralBenefitWagelossBand1; Override;
  private
    { Private declarations }
  public
    { Public declarations }
  end;

var
  WrkRptJul05: TWrkRptJul05;

implementation

{$R *.dfm}

procedure TWrkRptJul05.ExcemptionAndCreditAmountBand1P1;
begin
  sRpt.add(' ');
  sRpt.add('Tax Credit and Reduction Amounts:');
  sRpt.add(' ');
  sRpt.add('2005 Federal Non-Refundable Personal Tax Amounts:');
  sRpt.add(' ');
  sRpt.add( format('%-56s %-14s %-14s', [
    '    Workers basic personal amount ',
    ' ',
    formatF( fWorking.Work_personal, 12, 2 )
    ] ));
  sRpt.add( format('%-56s %-11s %-14s', [
    '    Dependent Spouse or common law partner claim ' +
      formatf(arrayNCEXMAMT[indexNCEXMAMT].Spouse, 10, 2),
    ' ',
    formatF( fWorking.Work_NC_SPOUSE, 12, 2 )
    ] ));
  sRpt.add('    ie: Married (spouse claimed as a dependent) ');
  sRpt.add( format('%-71s %-14s', [
    '    Single ( claim 1 child as equivalent to spouse ) ' +
      formatF(arrayNCEXMAMT[indexNCEXMAMT].ChildSpouse, 10, 2),
    formatF( fWorking.Work_NC_CHILDSPOUSE, 12, 2 )
    ] ));
  sRpt.add( format('%-56s %-14s %-14s', [
    '    Infirm dependents ( age 18+ ) ' + intToStr( fWorking.Work_nc_no_infirm )
      + ' x ' + formatF(arrayNCEXMAMT[indexNCEXMAMT].Infirm_Dep, 10, 2),
    ' ',
    formatF( fWorking.Work_infirm, 12, 2 )
    ] ));
  sRpt.add( format('%-56s %-14s %-14s', [ ' ',  ' '     ,  dash(12) ]));
  if (wrkClaim.Claim_No <> '00000000') Then
     sRpt.add( format('%-56s %-14s %-14s (F)', [
         '    Total Federal Personal Amount ',
         ' ',
         formatF( fWorking.Work_NC_EXEMPT_AMOUNT, 12, 2 )
         ] ))
  else
     sRpt.add( format('%-56s %-14s %-14s (F)', [
         '    Total Federal Personal Amount ',
         ' ',
         formatF(0.00, 12, 2 )
         ] ));

  sRpt.add( format('%-56s %-14s %-14s', [ ' ',  ' '     ,  dDash(12) ]));
  sRpt.add(' ');
end;

procedure TWrkRptJul05.ExcemptionAndCreditAmountBand1Man1;
begin
  sRpt.add(' ');
  sRpt.add('2005 Provincial Non-Refundable Personal Tax Amounts:');
  sRpt.add(' ');
  sRpt.add( format('%-56s %-14s %-14s', [
    '    Workers basic personal amount ',
    ' ',
    formatF( fWorking.Work_Prov_personal, 12, 2 )
    ] ));
  sRpt.add( format('%-56s %-11s %-14s', [
    '    Dependent Spouse or common law partner claim ' +
      formatf(arrayNCEXMAMT[indexNCEXMAMT].Prov_Spouse, 10, 2),
    ' ',
    formatF( fWorking.Work_NC_Prov_Spouse, 12, 2 )
    ] ));
  sRpt.add('    ie: Married (spouse claimed as a dependent) ');
  sRpt.add( format('%-71s %-14s', [
    '    Single ( claim 1 child as equivalent to spouse ) ' +
      formatF(arrayNCEXMAMT[indexNCEXMAMT].Prov_ChildSpouse, 10, 2),
    formatF( fWorking.Work_NC_Prov_ChildSpouse, 12, 2 )
    ] ));
  sRpt.add( format('%-56s %-14s %-14s', [
    '    Infirm dependents ( age 18+ ) ' + intToStr( fWorking.Work_nc_no_infirm )
      + ' x ' + formatF(arrayNCEXMAMT[indexNCEXMAMT].Prov_Infirm_Dep, 10, 2),
    ' ',
    formatF( fWorking.Work_Prov_Infirm, 12, 2 )
    ] ));
  sRpt.add( format('%-56s %-14s %-14s', [ ' ',  ' '     ,  dash(12) ]));

  if (wrkClaim.Claim_No <> '00000000') Then
     sRpt.add( format('%-56s %-14s %-14s (G)', [
         '    Total Provincial Personal Amount ',
         ' ',
         formatF( fWorking.Work_NC_MB_Exempt_Amount, 12, 2 )
         ] ))
  else
     sRpt.add( format('%-56s %-14s %-14s (G)', [
         '    Total Provincial Personal Amount ',
         ' ',
         formatF(0.00, 12, 2 )
         ] ));
  sRpt.add( format('%-56s %-14s %-14s', [ ' ',  ' '     ,  dDash(12) ]));
  sRpt.add(' ');
end;

procedure TWrkRptJul05.ExcemptionAndCreditAmountBand1P2;
begin
  sRpt.add('2005 Manitoba Family Tax Reduction Amounts:');
  sRpt.add(' ');
  sRpt.add( format('%-56s %-14s %-14s', [
    '    Workers basic reduction ',
    ' ',
    formatF( fWorking.Work_III_Personal, 12, 2 )
    ] ));
  sRpt.add( format('%-56s %-11s %-14s', [
    '    Dependent Spouse or common law partner claim ' +
      formatF(arrayNCEXMAMT[indexNCEXMAMT].III_Spouse, 10, 2),
    ' ',
    formatF( fWorking.Work_NC_III_SPOUSE, 12, 2 )
    ] ));
  sRpt.add('    ie: Married (spouse claimed as a dependent) ');
  sRpt.add( format('%-56s %-7s %-14s', [
    '    Single ( claim 1 child as equivalent to spouse ) ' +
      formatF(arrayNCEXMAMT[indexNCEXMAMT]. III_ChildSpouse, 10, 2),
    ' ',
    formatF( fworking.Work_NC_III_CHILDSPOUSE, 12, 2 )
    ] ));
  sRpt.add( format('%-56s %-14s %-14s', [
    '    Each additional child  ' + intToStr( fworking.Work_nc_no_of_dep ) + ' x '
      + formatF(arrayNCEXMAMT[indexNCEXMAMT].III_Dep, 10, 2),
    ' ',
    formatF( fworking.Work_NC_III_DEP, 12, 2 )
    ] ));
  sRpt.add( format('%-56s %-14s %-14s', [
    '    Infirm dependents ( age 18+ ) ' + intToStr( fworking.Work_nc_no_infirm ) + ' x '
      + formatF(arrayNCEXMAMT[indexNCEXMAMT].III_Infirm_Dep, 10, 2),
    ' ',
    formatF( fworking.Work_NC_III_INFIRM, 12, 2 )
    ] ));
  sRpt.add( format('%-56s %-14s %-14s', [ ' ',  ' '     ,  dash(12) ]));

  if (wrkClaim.Claim_No <> '00000000') Then
     sRpt.add( format('%-56s %-14s %-14s (H)', [
         '    Manitoba Family Tax Reduction Amount ',
         ' ',
         formatF( fworking.Work_nc_iii_credit, 12, 2 )
         ] ))
  else
     sRpt.add( format('%-56s %-14s %-14s (H)', [
         '    Manitoba Family Tax Reduction Amount ',
         ' ',
         formatF(0.00, 12, 2 )
         ] ));
  sRpt.add( format('%-56s %-14s %-14s', [ ' ',  ' '     , dDash(12) ]));

  sRpt.add(' ');
  sRpt.add(dash(91));
end;

//procedure TWrkRptJul05.TaxCalculationBand1P2(const income: currency;
//                                             Nc_Bc_Ann_Sal_Net: currency;
//                                             Nc_Bc_Uic: currency;
//                                             Nc_Bc_Cpp: currency;
//                                             Nc_Bc_Nrtc: currency;
//                                             Nc_Bc_Mb_Nrtc: currency;
//                                             federalCanadaEmploymentCredit: currency);
procedure TWrkRptJul05.TaxCalculationBand1P2(const income: currency;
                                             Nc_Bc_Ann_Sal_Net: currency;
                                             Nc_Bc_Uic: currency;
                                             Nc_Bc_Cpp: currency;
                                             Nc_Bc_Nrtc: currency;
                                             Nc_Bc_Mb_Nrtc: currency;
                                             nc_mbFamilyTaxBenefitAmt: currency);
Var
  t: currency;
  ws: string;
Begin
  sRpt.add('    CPP: ');
  ws:=format('    ( $%.2n - $%.2n ) x %.4n%% = ( Maximum $%.2n )',
    [
    income,
    arrayNCTAXRAT[indexNCTAXRAT].CPP_basic_exemption,
    ( arrayNCTAXRAT[indexNCTAXRAT].CPP_contrib_rate *100.00 ),
    arrayNCTAXRAT[indexNCTAXRAT].CPP_max_annual_contrib
    ]
    );
  sRpt.add( format('%-70s  %-14s (J)', [ ws, formatF( Nc_Bc_Cpp, 12, 2 ) ] ));
  sRpt.add( format('%-56s %-14s %-14s', [ '     Amount (I) above',  ' ', dash(12)  ]));
  sRpt.add(' ');
  sRpt.add('    EI: ');
  ws:=format('    $%.2n  x %.2n%% = ( Maximum $%.2n )',
    [
    income,
    (arrayNCTAXRAT[indexNCTAXRAT].UIC_premium_rate * 100.00),
    arrayNCTAXRAT[indexNCTAXRAT].UIC_max_annual_premium
    ] );
  sRpt.add( format('%-70s  %-14s (K)', [ ws, formatF( Nc_Bc_Uic, 12, 2 ) ] ));
  sRpt.add( format('%-56s %-14s %-14s', [ '     Amount (I) above',  ' ', dash(12) ]));
  sRpt.add(' ');
  sRpt.add('Non Refundable Tax Credit:');
  sRpt.add(' ');
  //
  sRpt.add('(i) Federal');
  sRpt.add( format('%-56s %-14s %-14s', [
    '    CPP amount (J) above',
  formatF( Nc_Bc_Cpp, 12, 2 ),
    ' '
    ] ));
  sRpt.add(' ');
  sRpt.add( format('%-56s %-14s %-14s', [
    '    EI amount (K) above',
    formatF( Nc_Bc_Uic, 12, 2 ),
    ' '
    ] ));
  sRpt.add(' ');

  if (wrkClaim.Claim_No <> '00000000') Then
     Begin
     sRpt.add( format('%-56s %-14s %-14s', [
         '    Total Federal Personal Amounts (F) from pg. 4',
         formatF( fworking.Work_nc_tax_exmp, 12, 2 ),
         ' '
         ] ));
     sRpt.add( format('%-56s %-14s %-14s', [ ' ',  dash(12),  ' '      ]));
     t := Nc_Bc_Cpp+Nc_Bc_Uic+fworking.Work_nc_tax_exmp;
     sRpt.add( format('%-56s %-14s %-14s (L)', [
         '    Total x '+
         format( '%.1n', [(arrayNCTAXRAT[indexNCTAXRAT].FED_tax_rate_i*100.00) ] ) +
         '%' + ' (Federal)',
         formatF( t, 12, 2 ),
         formatF( Nc_Bc_Nrtc, 12, 2 )
         ] ));
     end
  else
     Begin
     sRpt.add( format('%-56s %-14s %-14s', [
         '    Total Federal Personal Amounts (F) from pg. 4',
         formatF(0.00, 12, 2 ),
         ' '
         ] ));
     sRpt.add( format('%-56s %-14s %-14s', [ ' ',  dash(12),  ' '      ]));
     sRpt.add( format('%-56s %-14s %-14s (L)', [
         '    Total x '+
         format( '%.1n', [(arrayNCTAXRAT[indexNCTAXRAT].FED_tax_rate_i*100.00) ] ) +
         '%' + ' (Federal)',
         formatF( 0.00, 12, 2 ),
         formatF( 0.00, 12, 2 )
         ] ));
     end;
  sRpt.add( format('%-56s %-14s %-14s', [ ' ', dDash(12), dDash(12) ]));

  //
  sRpt.add(' ');
  sRpt.add('(ii) Provincial');
  sRpt.add( format('%-56s %-14s %-14s', [
    '    CPP amount (J) above',
  formatF( Nc_Bc_Cpp, 12, 2 ),
    ' '
    ] ));
  sRpt.add(' ');
  sRpt.add( format('%-56s %-14s %-14s', [
    '    EI amount (K) above',
    formatF( Nc_Bc_Uic, 12, 2 ),
    ' '
    ] ));
  sRpt.add(' ');
  if (wrkClaim.Claim_No <> '00000000') Then
     begin
     sRpt.add( format('%-56s %-14s %-14s', [
         '    Total Provincial Personal Amounts (G) from pg. 4',
         formatF( fworking.Work_nc_mb_tax_exmp, 12, 2 ),
         ' '
         ] ));
     sRpt.add( format('%-56s %-14s %-14s', [ ' ',  dash(12),  ' '      ]));
     t:=Nc_Bc_Cpp+Nc_Bc_Uic+fworking.Work_nc_mb_tax_exmp;
     sRpt.add( format('%-56s %-14s %-14s (M)', [
         '    Total x '+
         format( '%.1n', [(arrayNCTAXRAT[indexNCTAXRAT].MB_tax_rate_i*100.00) ] ) +
         '%' + ' (Manitoba Tax Rate)',
         formatF( t, 12, 2 ),
         formatF( Nc_Bc_Mb_Nrtc, 12, 2 )
         ] ));
     end
  else
     begin
     sRpt.add( format('%-56s %-14s %-14s', [
         '    Total Provincial Personal Amounts (G) from pg. 4',
         formatF(0.00, 12, 2 ),
         ' '
         ] ));
     sRpt.add( format('%-56s %-14s %-14s', [ ' ',  dash(12),  ' '      ]));
     sRpt.add( format('%-56s %-14s %-14s (M)', [
         '    Total x '+
         format( '%.1n', [(arrayNCTAXRAT[indexNCTAXRAT].MB_tax_rate_i*100.00) ] ) +
         '%' + ' (Manitoba Tax Rate)',
         formatF( 0.00, 12, 2 ),
         formatF( 0.00, 12, 2 )
         ] ));
     end;


  //
  sRpt.add( format('%-56s %-14s %-14s', [ ' ', dDash(12), dDash(12) ]));
  //sRpt.add( format('%-56s %-14s %-14s (M)', [
  //  '    Total x '+
  //  format( '%.1n', [(arrayNCTAXRAT[indexNCTAXRAT].MB_tax_rate_i*100.00) ] ) +
  //  '%' + ' (Manitoba Tax Rate)',
  //  formatF( t, 12, 2 ),
  //  formatF( Nc_Bc_Mb_Nrtc, 12, 2 )
  //  ] ));
  //sRpt.add( format('%-56s %-14s %-14s', [ ' ', dDash(12), dDash(12) ]));
  sRpt.add(' ');
  sRpt.add('2004/2005 Federal Tax Rates and Income Thresholds (WCB):');
  sRpt.add(' ');
End;

procedure TWrkRptJul05.TaxCalculationBand1P1( const income: currency;
                                     	      sIncType: shortstring;
                                              Nc_Bc_Ann_Sal_Net: currency);
Begin
  sRpt.add(' ');
  sRpt.add('2005 Income Tax, CPP and EI Calculation');
  sRpt.add(' ');
  sRpt.add( format('%-56s %-14s %-14s (I)', [
    'Gross Income ( "' + sIncType + '" ) ',
    ' ',
    formatF( income, 12, 2 )
    ]));
  sRpt.add( format('%-56s %-14s %-14s', [ ' ',  ' ', dDash(12)  ]));
  sRpt.add(' ');
  sRpt.add('Net Income: ');
  sRpt.add( format('%-14s %8.4n%% %-40s %-14s (LK)', [
    formatF(income, 11, 2) + '      - (',
    (fWorking.Work_nc_prorate*100.00),
    ' X ' + formatF(fWorking.Work_nc_bc_deductions, 11, 2) + ')=',
    formatF(Nc_Bc_Ann_Sal_Net, 12, 2 )
    ]));
  sRpt.add( format('%-56s %-14s %-14s', [
     'Amount (I) above - (    FT      X       DED    )',
     ' ',
     dash(12)
     ]));
  sRpt.add('   * FT applies only if type of income not ''Actual'' ');
  sRpt.add(' ');
  sRpt.add('CPP Contribution & EI premiums Calculation:');
  sRpt.add(' ');
End;

(******************************************************************************)
(*                                                                            *)
(*  Create Collateral Benefits Band                                           *)
(*                                                                            *)
(******************************************************************************)
procedure TWrkRptJul05.CollateralBenefitWagelossBand1;
var
   CollBenClaim:recNCClaim;
   CollBenWorking:recConst;
begin
  with wrkClaim do
     begin
     CopyNCClaim(wrkClaim, CollBenClaim);
     CollBenClaim.Post_Injury_Earn := 0;
     Calc_Ben(CollBenClaim, CollBenWorking);

     sRpt.add(' ');
     sRpt.add('Collateral Benefit Wage Loss Calculation:                     Full           Partial');
     sRpt.add(' ');

     sRpt.add( format('%-56s %-14s %-14s', [
         'Weekly Net ( from (A) )',
         formatF( ( Annual_Net_A / 52.0 ), 12, 2 ),
         formatF( ( Annual_Net_A / 52.0 ), 12, 2 )
         ] ));
     sRpt.add( format('%-56s %-14s %-14s', [ ' ',  dash(12), dash(12)]));

     sRpt.add( format('%-56s %-14s %-14s', [
         'Weekly Net @ 90%  ( (i) x 90% )',
         formatF( ( ( Annual_Net_A / 52.0 ) *0.90 ), 12, 2 ),
         formatF( ( ( Annual_Net_A / 52.0 ) *0.90 ), 12, 2 )
         ] ));
     sRpt.add( format('%-56s %-14s %-14s', [ ' ',  dash(12) ,  dash(12) ]));

     sRpt.add( format('%-56s %-14s %-14s', [
         'Less: Net Collateral Benefit ( from (E) )',
         formatF(CollBenClaim.Coll_Ben_Tax_Net, 12, 2),
         formatF( Coll_Ben_Tax_Net, 12, 2 )
         ] ));
     sRpt.add( format('%-56s %-14s %-14s', [
         '      Non Taxable Collateral Benefit ',
         formatF(CollBenClaim.Collateral_Ben_Non_Tax, 12, 2),
         formatF(CollBenClaim.Collateral_Ben_Non_Tax, 12, 2 )
         ] ));
     sRpt.add( format('%-56s %-14s %-14s', [
         '      Net Post Injury Earnings @ 90% ',
         ' ',
         formatF((wrkClaim.Post_Injury_Earn_Net * 0.90), 12, 2 )
         ] ));
     sRpt.add( format('%-56s %-14s %-14s', [ ' ', dash(12), dash(12) ]));

     sRpt.add( format('%-56s %-14s %-14s', [
         'Maximum Weekly Benefit',
         formatF( (( ( Annual_Net_A / 52.0 ) * 0.90 ) - CollBenClaim.Coll_Ben_Tax_Net
                                                      - CollBenClaim.Collateral_Ben_Non_Tax), 12, 2 ),
         formatF( (( ( Annual_Net_A / 52.0 ) * 0.90 ) - Coll_Ben_Tax_Net
                                                      - Collateral_Ben_Non_Tax
                                                      - (wrkClaim.Post_Injury_Earn_Net * 0.90)), 12, 2 )
         ] ));
     sRpt.add( format('%-56s %-14s %-14s', [ ' ',  dDash(12) , dDash(12) ]));

     sRpt.add(' ');
     sRpt.add(dash(91));
     end;
end;

Function  TWrkRptJul05.TaxCalculationBand1P5b( Nc_Bc_Ann_Sal_Net: currency;
                                               Nc_Bc_Mb_Nrtc: currency;
                                               Nc_Bc_Mbt: currency): currency;
var
  const1, const2, f2p, f1i, work: currency;
begin
  sRpt.add(' ');
  sRpt.add('2005 Manitoba Tax Rates and Income Thresholds (WCB):');
  sRpt.add(' ');
  with arrayNCTAXRAT[indexNCTAXRAT] do
    begin
    sRpt.add('    +'+ dash(76) + '+');
    sRpt.add( format('    | %-28s | %-20s | %-20s |', [
      'Taxable Income Amount',
      'Rate',
      'Constant'
      ]));
    sRpt.add('    +'+ dash(76) + '+');
    sRpt.add( format('    | %-28s | %-20s | %-20s |', [
      format('%.0n',[MB_income_level_i]) + ' or less',
      format('%.1n',[(MB_tax_rate_i*100.00)]) + '%',
      format('%.0n',[0.00])
      ]));
    const1 := Round(MB_income_level_i * (MB_tax_rate_ii - MB_tax_rate_i));
    sRpt.add( format('    | %-28s | %-20s | %-20s |', [
      '> ' + format('%.0n',[MB_income_level_i]),
      format('%.1n',[(MB_tax_rate_ii*100.00)]) + '%',
      format('%.0n',[const1])
      ]));
    const2 := Round(MB_income_level_ii * (MB_tax_rate_iii - MB_tax_rate_ii)
      + const1);
    sRpt.add( format('    | %-28s | %-20s | %-20s |', [
      '> ' + format('%.0n',[MB_income_level_ii]),
      format('%.1n',[(MB_tax_rate_iii*100.00)]) + '%',
      format('%.0n',[const2])
      ]));
    sRpt.add('    +'+ dash(76) + '+');
    sRpt.add(' ');
    sRpt.add('Manitoba Tax:');
    sRpt.add(' ');
    sRpt.add('    For ' + formatF(Nc_Bc_Ann_Sal_Net, 11, 2 ) +' (Amount (LK) above):' );

    if ( Nc_Bc_Ann_Sal_Net > MB_income_level_ii ) then
      begin
      f2p := MB_tax_rate_iii;
      f1i := const2;
      end
    else if ( Nc_Bc_Ann_Sal_Net > MB_income_level_i ) then
      begin
      f2p := MB_tax_rate_ii;
      f1i := const1;
      end
    else
      begin
      f2p := MB_tax_rate_i;
      f1i := 0.0;
      end;
    end;

  if (wrkClaim.Claim_No = '00000000') Then
     begin
     f2p := 0; // set the tax rate to be a blank
     end;

  sRpt.add(' ');
  sRpt.add( format('%-56s %-14s %-14s', [
    '    Multiply by tax rate from above table ' + format('%.2n',[f2p * 100]){FormatF((f2p * 100), 5, 1)} + '%',
    formatF((Nc_Bc_Ann_Sal_Net * f2p), 12, 2 ), ' '
    ] ));
  sRpt.add(' ');
  sRpt.add( format('%-56s %-14s %-14s', [
    '    Less:  Constant from above table',
    formatF(f1i, 12, 2 ), ' '
    ] ));
  work := (Nc_Bc_Ann_Sal_Net * f2p) - f1i;

  if work < 0 then
     work := 0;

  sRpt.add( format('%-56s %-14s %-14s', [ ' ', dash(12), ' ']));
  sRpt.add( format('%-56s %-14s %-14s (Q)', [
    '    Manitoba Tax ',
    formatF( work, 12, 2 ),
    ' '
    ] ));
  sRpt.add(' ');
  if (wrkClaim.Claim_No <> '00000000') Then
     sRpt.add( format('%-56s %-14s %-14s', [
         '    Less: Non Refundable Tax Credit (M) above ',
         formatF( Nc_Bc_Mb_Nrtc, 12, 2 ),
  	 ' '
         ] ))
  else
     sRpt.add( format('%-56s %-14s %-14s', [
         '    Less: Non Refundable Tax Credit (M) above ',
         formatF(0.00, 12, 2 ),
  	 ' '
         ] ));
  result := Nc_Bc_Mbt;
  sRpt.add( format('%-56s %-14s %-14s', [ ' ', dash(12), ' ' ]));
  sRpt.add( format('%-56s %-14s %-14s (R)', [
  	'    Manitoba Provincial Tax ',
    ' ',
    formatF( result, 12, 2 )
    ] ));
  sRpt.add( format('%-56s %-14s %-14s', [ ' ', ' ', dDash(12)]));
end;

end.
