(*****************************************************************)
(*  Wageloss System                                              *)
(*                                                               *)
(*  Project File                                                 *)
(*                                                               *)
(*  Note: Module WLDebug must be the first module executed after *)
(*  system units like 'Forms' in order to do initialization      *)
(*  section and create the debug window first.                   *)
(*                                                               *)
(*  Author: Brad Trupp  / Capella Systems Group, Inc.            *)
(*  Date:   July 1997                                            *)
(*****************************************************************)
program Wageloss;



uses
  SysUtils,
  Forms,
  WLInfo1 in 'WLInfo1.pas' {Info_Window},
  NCMain in 'NCMain.PAS' {WagelossMainForm},
  WLAbout in 'WLAbout.pas' {frmAboutDlg},
  NCClmWL0 in 'NCClmWL0.pas' {SelectClaimForm},
  Utilmod1 in 'Utilmod1.pas',
  NCBencal in 'NCBencal.pas' {WagelossBenefitCalcForm},
  NCBENIDX in 'NCBENIDX.PAS' {WagelossIndexationForm},
  NCBenpay in 'NCBenpay.pas' {WagelossPaymentForm},
  NCIniMod in 'NCIniMod.pas',
  NCRecdef in 'NCRecdef.pas',
  NCExpRpt in 'NCExpRpt.pas' {PrintExpenseCodesForm},
  NCExmRpt in 'NCExmRpt.pas' {PrintExemptionAmountsForm},
  NCIDXRPT in 'NCIDXRPT.PAS' {PrintIndexationFactorsForm},
  NCChqRpt in 'NCChqRpt.pas' {PrintChequeMessagesForm},
  NCOvrPay in 'NCOvrPay.pas' {BenefitsOverpaymentSearchForm},
  NCRevClm in 'NCRevClm.pas' {ReviewBenefitLevelForm},
  NCChoice in 'NCChoice.pas' {GetChoiceForm},
  NCDATMOD in 'NCDATMOD.PAS' {dm1: TDataModule},
  NCIdxClm in 'NCIdxClm.pas' {PrintClaimIndexationForm},
  NCCINRPT in 'NCCINRPT.PAS' {PrintClaimInfoForm},
  NCBenRpt in 'NCBenRpt.pas' {PrintBenCalForm},
  NCWrkRpt in 'NCWrkRpt.pas' {WagelossCalculationWorksheetForm},
  NCOvrRpt in 'NCOvrRpt.pas' {PrintOverpayForm},
  QPREVIEW in 'QPREVIEW.PAS' {QRCustomPreviewForm},
  ncselbin in 'ncselbin.pas' {PrintOverridePrintForm},
  onlyone in 'onlyone.pas',
  NCSREdit in 'NCSREdit.pas' {ShelterRebateEditForm},
  NCSRLoad in 'NCSRLoad.pas' {ShelterRebateLoadForm},
  NCSRSumR in 'NCSRSumR.pas' {ShelterRebateSummaryForm},
  NCSRDtlR in 'NCSRDtlR.pas' {ShelterRebateDetailForm},
  NCSRLtr1 in 'NCSRLtr1.pas' {ShelterRebateLetterForm},
  NCSRCalc in 'NCSRCalc.pas' {ShelterRebateCalculatorForm},
  uGlobal in 'uGlobal.pas',
  Utils in '..\..\Repository\Delphi\Utils.pas',
  uADOLogin in '..\..\Repository\Delphi\ADO\uADOLogin.pas',
  uADOSecurity in '..\..\Repository\Delphi\ADO\uADOSecurity.pas',
  uTriggerEvent in '..\..\Repository\Delphi\uTriggerEvent.pas',
  uHttpEventPublisher in '..\..\Repository\Delphi\uHttpEventPublisher.pas',
  uUserMaint in 'uUserMaint.pas' {fUserMaint},
  NCWrkRptJan00 in 'NCWrkRptJan00.pas' {WrkRptJan00},
  NCWrkRptJan01 in 'NCWrkRptJan01.pas' {WrkRptJan01},
  NCWrkRptJan02 in 'NCWrkRptJan02.pas' {WrkRptJan02},
  NCWrkRptJul02 in 'NCWrkRptJul02.pas' {WrkRptJul02},
  NCWrkRptJan04 in 'NCWrkRptJan04.pas' {WrkRptJan04},
  NCWrkRptBase in 'NCWrkRptBase.pas',
  NCNonExRpt in 'NCNonExRpt.pas' {PrintTopUpNonExemptionForm},
  NCStartDate in 'NCStartDate.pas' {SelectDateForm},
  uSavePrint in 'uSavePrint.pas',
  NCWrkRptJul04 in 'NCWrkRptJul04.pas' {WrkRptJul04},
  NCSelectYear in 'NCSelectYear.pas' {SelectYearForm},
  Upswdlg in '..\..\Repository\Delphi\Dialogs\Upswdlg.pas' {fPasswDlg},
  uDmGener in '..\..\Repository\Delphi\uDmGener.pas' {dmGeneric: TDataModule},
  CrystalPrev in 'CrystalPrev.pas' {fCrystalPrev},
  NCWrkRptJul05 in 'NCWrkRptJul05.pas' {WrkRptJul05},
  NCTaxableCollateral in 'NCTaxableCollateral.pas' {TaxableCollateral},
  NCWrkRptJan06 in 'NCWrkRptJan06.pas' {WrkRptJan06},
  NCPrintMinWageReport in 'NCPrintMinWageReport.pas' {PrintMinWageReport},
  uSaveWageLossCalcFactors in 'uSaveWageLossCalcFactors.pas',
  uSaveIndexReport in 'uSaveIndexReport.pas',
  NCWagelossOverpaymentRecoveryForm in 'NCWagelossOverpaymentRecoveryForm.pas' {WagelossOverpaymentRecoveryForm},
  NCWrkRptJul06 in 'NCWrkRptJul06.pas' {WrkRptJul06},
  NCWrkRptJan07 in 'NCWrkRptJan07.pas' {WrkRptJan07},
  NCWrkRptJul07 in 'NCWrkRptJul07.pas' {WrkRptJul07},
  NCWrkRptJan08 in 'NCWrkRptJan08.pas' {WrkRptJan08},
  rsFileVersion in '..\..\Repository\Delphi\Version\rsFileVersion.pas',
  Usplash in '..\..\Repository\Delphi\Dialogs\Usplash.pas' {fSplash},
  uPaymentsWebService in 'uPaymentsWebService.pas',
  NCWrkRptJul08 in 'NCWrkRptJul08.pas' {WrkRptJul08},
  NCNonTaxableCollateral in 'NCNonTaxableCollateral.pas' {NonTaxableCollateral},
  NCSelfEmpMinMaxRpt in 'NCSelfEmpMinMaxRpt.pas' {SelfEmpMinMaxForm},
  NCIAWRpt in 'NCIAWRpt.pas' {IAWRptForm},
  NCWrkRptJan09 in 'NCWrkRptJan09.pas' {WrkRptJan09},
  NCWrkRptJul09 in 'NCWrkRptJul09.pas' {WrkRptJul09},
  NCWrkRptJan10 in 'NCWrkRptJan10.pas' {WrkRptJan10},
  NCWrkRptJul10 in 'NCWrkRptJul10.pas' {WrkRptJul10},
  NCWrkRptJan11 in 'NCWrkRptJan11.pas' {WrkRptJan11},
  NCWrkRptJul11 in 'NCWrkRptJul11.pas' {WrkRptJul11},
  NCWrkRptJan12 in 'NCWrkRptJan12.pas' {WrkRptJan12},
  NCWrkRptJul12 in 'NCWrkRptJul12.pas' {WrkRptJul12},
  NCWrkRptJan13 in 'NCWrkRptJan13.pas' {WrkRptJan13},
  NCWrkRptJul13 in 'NCWrkRptJul13.pas' {WrkRptJul13},
  NCWrkRptJan14 in 'NCWrkRptJan14.pas' {WrkRptJan14},
  NCWrkRptJul14 in 'NCWrkRptJul14.pas' {WrkRptJul14},
  NCWrkRptJan15 in 'NCWrkRptJan15.pas' {WrkRptJan15},
  NCIndexFactorRpt in 'NCIndexFactorRpt.pas' {PrintIndexForm},
  ufrmQATestList in 'ufrmQATestList.pas' {frmQATestList},
  NCWrkRptJul15 in 'NCWrkRptJul15.pas' {WrkRptJul15},
  NCWrkRptJan16 in 'NCWrkRptJan16.pas' {WrkRptJan16},
  NCWrkRptJan17 in 'NCWrkRptJan17.pas' {WrkRptJan17},
  NCWrkRptJul16 in 'NCWrkRptJul16.pas' {WrkRptJul16},
  NCWrkRptJul17 in 'NCWrkRptJul17.pas' {WrkRptJul17},
  NCWrkRptJan18 in 'NCWrkRptJan18.pas' {WrkRptJan18},
  NCWrkRptJul18 in 'NCWrkRptJul18.pas' {WrkRptJul18},
  NCWrkRptJan19 in 'NCWrkRptJan19.pas' {WrkRptJan19},
  NCWrkRptJul19 in 'NCWrkRptJul19.pas' {WrkRptJul19},
  NCWrkRptJan20 in 'NCWrkRptJan20.pas' {WrkRptJan20},
  ConvertDate in '..\..\Repository\Delphi\ConvertDate.pas',
  ValidateDate in '..\..\Repository\Delphi\ValidateDate.pas',
  NCWrkRptJul20 in 'NCWrkRptJul20.pas' {WrkRptJul20},
  NCWrkRptJan21 in 'NCWrkRptJan21.pas' {WrkRptJan21},
  NCWrkRptJul21 in 'NCWrkRptJul21.pas' {WrkRptJul21},
  NCWrkRptJan22 in 'NCWrkRptJan22.pas' {WrkRptJan22},
  NCWrkRptJul22 in 'NCWrkRptJul22.pas' {WrkRptJul22},
  NCWrkRptJan23 in 'NCWrkRptJan23.pas' {WrkRptJan23},
  NCWrkRptJul23 in 'NCWrkRptJul23.pas' {WrkRptJul23},
  NCWrkRptJan24 in 'NCWrkRptJan24.pas' {WrkRptJan24},
  NCWrkRptJul24 in 'NCWrkRptJul24.pas' {WrkRptJul24},
  NCWrkRptJan25 in 'NCWrkRptJan25.pas' {WrkRptJan25},
  NCWrkRptJul25 in 'NCWrkRptJul25.pas' {WrkRptJul25},
  NCWrkRptJan26 in 'NCWrkRptJan26.pas' {WrkRptJan26},
  NCWrkRptJul26 in 'NCWrkRptJul26.pas' {WrkRptJul26};

{$R *.RES}

begin
  Application.Initialize;
  Application.Title := 'Benefits Wageloss System';
  Application.HelpFile := 'WAGELOSS.HLP';
//  shortDateFormat := 'dd/mm/yyyy';
//  longDateFormat := 'mmmm dd, yyyy';
  fSplash := TfSplash.Create(Application);
  fSplash.Update;
  Application.CreateForm(TWagelossMainForm, WagelossMainForm);
  if OnlyOne.IsFirstInstance then
    Application.Run
  else
    Application.terminate;
end.

