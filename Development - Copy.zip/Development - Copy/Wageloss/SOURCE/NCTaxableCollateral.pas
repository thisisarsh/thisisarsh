unit NCTaxableCollateral;

interface

uses
  Windows, Messages, SysUtils, Variants, Classes, Graphics, Controls, Forms,
  Dialogs, StdCtrls;

type
  TTaxableCollateral = class(TForm)
    Label1: TLabel;
    edCPPQPP: TEdit;
    Label2: TLabel;
    edEI: TEdit;
    Label3: TLabel;
    edDisabilityInsurance: TEdit;
    Label4: TLabel;
    btnOK: TButton;
    brnCancel: TButton;
    edCombination: TEdit;
    Label6: TLabel;
    procedure btnOKClick(Sender: TObject);
    procedure brnCancelClick(Sender: TObject);
    procedure edCPPQPPExit(Sender: TObject);
    procedure edEIExit(Sender: TObject);
    procedure edDisabilityInsuranceExit(Sender: TObject);
    procedure edCombinationExit(Sender: TObject);
  private
    { Private declarations }
    globalEditError : boolean;
  public
    { Public declarations }
  end;

var
  TaxableCollateral: TTaxableCollateral;

implementation

uses Utils, NCMain, Utilmod1;

{$R *.dfm}

procedure TTaxableCollateral.btnOKClick(Sender: TObject);
begin
ModalResult := mrOK;
end;

procedure TTaxableCollateral.brnCancelClick(Sender: TObject);
begin
ModalResult := mrCancel;
end;

procedure TTaxableCollateral.edCPPQPPExit(Sender: TObject);
begin
  if not ValidateAsCurrency(edCPPQPP) then
  begin
    globalEditError := displayError( '*Invalid CPP/QPP Amount.', edCPPQPP );
    Exit;
  end;

  If Not (TextAsCurrency(edCPPQPP) >= 0) Then
  Begin
    globalEditError := displayError( '*CPP/QPP must be greater than or equal to $0.00', edCPPQPP );
    Exit;
  end;

  edCPPQPP.Text := Format('%.2n',[textAsCurrency(edCPPQPP)]);
end;

procedure TTaxableCollateral.edEIExit(Sender: TObject);
begin
  if not ValidateAsCurrency(edEI) then
  begin
    globalEditError := displayError( '*Invalid EI Amount.', edEI );
    Exit;
  end;

  If Not (TextAsCurrency(edEI) >= 0) Then
  Begin
    globalEditError := displayError( '*EI must be greater than or equal to $0.00', edEI );
    Exit;
  end;

  edEI.Text := Format('%.2n',[textAsCurrency(edEI)]);
end;

procedure TTaxableCollateral.edDisabilityInsuranceExit(Sender: TObject);
begin
  if not ValidateAsCurrency(edDisabilityInsurance) then
  begin
    globalEditError := displayError( '*Invalid Disability Insurance Amount.', edDisabilityInsurance );
    Exit;
  end;

  If Not (TextAsCurrency(edDisabilityInsurance) >= 0) Then
  Begin
    globalEditError := displayError( '*Disability Insurance must be greater than or equal to $0.00', edDisabilityInsurance );
    Exit;
  end;

  edDisabilityInsurance.Text := Format('%.2n',[textAsCurrency(edDisabilityInsurance)]);
end;

procedure TTaxableCollateral.edCombinationExit(Sender: TObject);
begin
  if not ValidateAsCurrency(edCombination) then
  begin
    globalEditError := displayError( '*Invalid Combination Amount.', edCombination );
    Exit;
  end;

  If Not (TextAsCurrency(edCombination) >= 0) Then
  Begin
    globalEditError := displayError( '*Combination must be greater than or equal to $0.00', edCombination );
    Exit;
  end;

  edCombination.Text := Format('%.2n',[textAsCurrency(edCombination)]);
end;

end.
