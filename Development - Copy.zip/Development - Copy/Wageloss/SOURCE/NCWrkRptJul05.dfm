object WrkRptJul05: TWrkRptJul05
  Left = 321
  Top = 195
  Caption = 'WrkRptJul05'
  ClientHeight = 501
  ClientWidth = 767
  Color = clBtnFace
  Font.Charset = DEFAULT_CHARSET
  Font.Color = clWindowText
  Font.Height = -11
  Font.Name = 'MS Sans Serif'
  Font.Style = []
  OldCreateOrder = False
  PixelsPerInch = 96
  TextHeight = 13
end
