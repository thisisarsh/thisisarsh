
(*****************************************************************
Wageloss System, Indexation Factors Report for Annual Minimums

As this report is modeled on NCIdxRpt, most of the same methods and attributes
will be needed.  One key difference; while NCIdxRpt relies on two arrays
available through WLTABLES.DLL ( arrayNCINDEXF & arrayNCANNMAX ), and simply
iterates through those arrays to dump the contents out, this report must read
the contents of the existing WAGELOSS_DB..minimumWage table into an array, and
create and populate a new array using minimumWage and the arrayNCINDEXF array.

An algorithm will be followed to loop through minimumWage and arrayNCINDEXF.
This algorithm was proofed using SQL, but cannot be implemented using SQL due to
arrayNCINDEXF not being in the database.  Placing it there would entail changing
much more than just this report.

Linda Penner (requestor) has specified that the 'Effective Date' column show the
full effective date, not just the year.  She has further requested that each
indexed value is rounded to two decimal places before that value is used to
calculate subsequent years indexation.  Finally, she outlines the primary use of
the report; to view what the system would calculate as a minimum.  This must
reflect what would be the case if the government changed the Effective date of
the minimum wage value in mid-year, i.e. changed the value more than once per
year.  This will require some investigation, and may change the algoritm used to
generate the results array.

Finally, the results and index factor arrays are copied into output arrays,
eliminating records that the requestors don't wish to see.

The actual steps of the process are as follows:

procedure QRIndexationFactorsBeforePrint is called when the report is requested.
It calls the following procedures:

convertMinWageQueryToArray queries the database for the contents of the
  WAGELOSS_DB..minimumWage table, and populates the array minWageArray with the
  results.

redefineIndexFactorsArray iterates through the original arrayNCINDEXF array, and
  creates the indexFactorsArray as a zero-based array.  This is for clarity; I
  didn't want to deal with a mixture of array types.

populateResultsArray creates and populates the indexedMinimumResultsArray array
  with raw data.  There are some business rules involved, such as not to index
  on the year after the incident, nor the second year if the incident was in
  December.

alterArraysForOutput - this method removes unwanted rows from
  indexedMinimumResultsArray and indexFactorsArray.  These are to satisfy
  formatting requirements from the requestor.  They involve populating the
  outputIndexedMinimumResultsArray and outputIndexFactorsArray.  Some of the
  alterations include removing all indexation factors from before 2008, and not
  showing the tax year after the incident year.

QRIndexationFactorsNeedData iterates through the outputIndexedMinimumResultsArray
  and outputIndexFactorsArray line by line and populates captions on the page.
  Some final formatting is done here, by setting the caption to be '-' for the
  December value two years after the incident.

Yes I know that I could've combined some of the above procedures, but let's keep
 it this way for clarity.

Revisions
When        Who         What
******************************************************************
Sept 2005   dmadill     Initial Creation.
Dec 3 2007  bcooper     2007 Year-End Changes.
Jan 2008    RLloyd      Redo this report to be in a similar format as the
                        NCIdxRpt, including indexation.  For NR79053
Jan 29 2008 RLloyd      Added procedure call to alterArraysForOutput to format
                        for output as per Linda Penner's instructions.
Feb 5, 2008 RLloyd      Round indexed minimum to two decimal places before
                        subsequent calculation.
*****************************************************************)

unit NCPrintMinWageReport;

interface

uses
  Windows, Messages, SysUtils, Variants, Classes, Graphics, Controls, Forms,
  Dialogs, QuickRpt, ExtCtrls, QRCtrls, Math;

type
  TPrintMinWageReport = class(TForm)
    MinWageReport: TQuickRep;
    QRBand1: TQRBand;
    QRBand2: TQRBand;
    QRBand3: TQRBand;
    QRLabel1: TQRLabel;
    QRLabel7: TQRLabel;
    QRLabel2: TQRLabel;
    QRSysData3: TQRSysData;
    QRSysData4: TQRSysData;
    QRUserID: TQRLabel;
    QRSysData5: TQRSysData;
    QRBand5: TQRBand;
    QRLabel9: TQRLabel;
    QRLabel10: TQRLabel;
    QRLabel11: TQRLabel;
    QRTaxYear: TQRLabel;
    QRAnnualMinDec: TQRLabel;
    QRAnnualMin: TQRLabel;
    QRLabel3: TQRLabel;
    QREffectiveDate: TQRLabel;
    QRLabel12: TQRLabel;
    QRLabel4: TQRLabel;
    procedure QRIndexationFactorsBeforePrint(Sender: TCustomQuickRep;
      var PrintReport: Boolean);
    procedure QRIndexationFactorsNeedData(Sender: TObject;
      var MoreData: Boolean);
    procedure QRBand2BeforePrint(Sender: TQRCustomBand;
      var PrintBand: Boolean);

  private
    { Private declarations }
    iii, jjj: integer;
    efYear : TDateTime;
  public
    { Public declarations }
  end;

  {record for array populated from wageloss_db..minimumWage}
  type
  MinimumWage = record
    effectiveDate: TDateTime; //Added to present effective year as date
    effectiveYear: Integer;
    minWage: double;
  end;

  {record for array to hold values for eventual output on to report}
  type
    recNCANNMIN = record
    effectiveDate: TDateTime;    //Added to present effective year as date
    Accident_Year:Integer;
    Tax_Year:Integer;
    Annual_Minimum:double;
    Annual_Minimum_Dec:double;
  end;

  {record for array that redefines arrayNCINDEXF as dynamic length array}
  type
    recNCINDEXF = record
    Indexation_Year:integer;
    Indexing_Factor:double;
  end;

var
  PrintMinWageReport: TPrintMinWageReport;
  minWageArray: array of MinimumWage;
  indexFactorsArray: array of recNCINDEXF;
  indexedMinimumResultsArray: array of recNCANNMIN;
  outputIndexFactorsArray: array of recNCINDEXF;
  outputIndexedMinimumResultsArray: array of recNCANNMIN;

implementation

uses NCIniMod, NCMain, uADOSecurity, NCDatMod, Utils;

{$R *.dfm}

{********************************************************************
function getIndexFactorForYear, added to get an indexation value from
indexFactorsArray for a specific year
RLloyd, Jan 23, 2008
********************************************************************}
function  getIndexFactorForYear(year: Integer): Real;
var
    x, arrayLength, arrayStart: Integer;
begin
  Result := 1.0;
  arrayStart := Low(indexFactorsArray);
  arrayLength := Length(indexFactorsArray) - 1;
  for x := arrayStart to arrayLength do
  begin
    if indexFactorsArray[x].Indexation_Year = year then
    begin
      Result := indexFactorsArray[x].Indexing_Factor;
      break ;
    end;
  end;
end;

{********************************************************************
procedure redefineIndexFactorsArray, added to redefine arrayNCINDEXF
as dynamic length (and zero based) array.
RLloyd, Jan 23, 2008
********************************************************************}
procedure redefineIndexFactorsArray();

var
  originalArrayLength, x, test :Integer;

begin
  originalArrayLength  :=  Length(arrayNCINDEXF);
  SetLength(indexFactorsArray, 0);

  for x:= 0 to originalArrayLength - 1 do
  begin
    test := arrayNCINDEXF[x+1].Indexation_Year;
    if test >= 0  then
    begin
      SetLength(indexFactorsArray, Length(indexFactorsArray)+1);
      indexFactorsArray[x].Indexation_Year :=  arrayNCINDEXF[x+1].Indexation_Year;
      indexFactorsArray[x].Indexing_Factor :=  arrayNCINDEXF[x+1].Indexing_Factor;
    end;
  end;
end;

{********************************************************************
procedure populateResultsArray, added to parse a dataset into an array.
RLloyd, Jan 23, 2008
********************************************************************}
procedure populateResultsArray();

var   effectiveYear,
      taxYear,
      endYear,
      saveYear,
      x,
      resultsArraySize  : Integer;

      saveEffectiveDate : Tdatetime;

      minWage,
      annualMinJanNov,
      annualMinDec : Real;

begin

  endYear :=  minWageArray[High(minWageArray)].effectiveYear;
  resultsArraySize :=1;
  saveYear := 0;
  saveEffectiveDate := 0;

  for x := 0 to ( Length(minWageArray) - 1 ) do
  {outer loop; for every minimum wage record}
  begin
    {populate vars for this iteration of the outer loop}
    effectiveYear := minWageArray[x].effectiveYear;
    minWage :=  minWageArray[x].minWage;

    {populate vars for writing into results array (indexedMinimumResultsArray)}
	  taxYear := effectiveYear;

	  //for all tax years for this accident year, reset the annual values
	  annualMinJanNov := minWage;
	  annualMinDec := minWage;

    while  taxYear <= endYear do
    begin

      if taxYear > effectiveYear + 1 then
      {for the first two tax years (effectiveYear & effectiveYear +1), do not
      apply factors to the MinWage for Jan - Nov  }
      begin
        annualMinJanNov := SimpleRoundTo((annualMinJanNov * getIndexFactorForYear(taxYear)),-2);
      end;

      if taxYear > effectiveYear + 2 then
      {for the first three tax years (effectiveYear to effectiveYear +2), do
      not apply factors to the MinWage for Jan - Nov  }
      begin
        annualMinDec := SimpleRoundTo((annualMinDec * getIndexFactorForYear(taxYear)),-2);
      end;

      {make sure that the array has enough space for the next record}
      SetLength(indexedMinimumResultsArray, resultsArraySize);
      {populate values on the array}
      indexedMinimumResultsArray[resultsArraySize - 1].effectiveDate :=      minWageArray[x].effectiveDate;
      indexedMinimumResultsArray[resultsArraySize - 1].Accident_Year :=      effectiveYear;
      indexedMinimumResultsArray[resultsArraySize - 1].Tax_Year :=           taxYear;
      indexedMinimumResultsArray[resultsArraySize - 1].Annual_Minimum :=     annualMinJanNov;
      indexedMinimumResultsArray[resultsArraySize - 1].Annual_Minimum_Dec := annualMinDec;

      inc( resultsArraySize );  //increment results array size
      inc( taxYear );

    end;
  end;

  saveYear := year(indexedMinimumResultsArray[Length(indexedMinimumResultsArray) - 1].effectiveDate);
  for x := ( Length(indexedMinimumResultsArray) - 1 ) downto 0 do
  begin
    if saveYear <> year(indexedMinimumResultsArray[x].effectiveDate) then
    begin
      saveYear := year(indexedMinimumResultsArray[x].effectiveDate);
      saveEffectiveDate := indexedMinimumResultsArray[x].effectiveDate;
    end
    else if saveEffectiveDate <> indexedMinimumResultsArray[x].effectiveDate then
    begin
      indexedMinimumResultsArray[x].Annual_Minimum_Dec := 0;
    end;
  end;

end;

{********************************************************************
procedure convertMinWageQueryToArray, added to parse a dataset into an array.
RLloyd, Jan 23, 2008
********************************************************************}
procedure convertMinWageQueryToArray();

var   minWageCount, x :Integer;

begin

  with dm1 do
  begin
    if qryMinWageforReport.active then
    begin
      qryMinWageforReport.close; //clean up before using this again
    end;
    qryMinWageforReport.sql.clear;
    qryMinWageforReport.sql.add('SELECT effectiveDate, DATEPART(yyyy, effectiveDate) AS effectiveYear, minWage FROM minimumWage ');

    qryMinWageforReport.open;
    if qryMinWageforReport.recordcount > 0 then
    begin
      minWageCount := qryMinWageforReport.recordcount;
      SetLength(minWageArray, minWageCount);  //minWageArray zero-based array
      qryMinWageforReport.First;
      for x := 0 to ( minWageCount - 1 ) do
        begin
          {for each record in the result set}
          minWageArray[x].effectiveDate:=qryMinWageforReport.fieldByName('effectiveDate').AsDateTime;
          minWageArray[x].effectiveYear:=qryMinWageforReport.fieldByName('effectiveYear').asInteger;
          minWageArray[x].minWage:=qryMinWageforReport.fieldByName('minWage').asFloat;
          qryMinWageforReport.Next;
        end;

      query1.close;
    end;
  end;
end;


{********************************************************************
procedure alterArraysForOutput; this method removes unwanted rows from
indexedMinimumResultsArray and indexFactorsArray.  These unwanted rows
are those years in the indexFactorsArray before 2008, and in the
indexedMinimumResultsArray, rows where the Tax_Year is one year greater
than the Accident_Year.  Also in the indexedMinimumResultsArray, set the
Annual_Minimum_Dec to be 0.00 when the Tax_Year is two years greater
than the Accident_Year.
All this alteration of the output of the report is per Linda Penner's
request.  
in NCIDXRPT.  RLloyd, Jan 23, 2008
********************************************************************}
procedure alterArraysForOutput();

var  x, y, start, ending: Integer;

begin

  {do the indexFactorsArray array for output}
  start :=  Low(indexFactorsArray);
  ending := High(indexFactorsArray);
  y := 0;

  for x:= start to ending do
  begin
    if indexFactorsArray[x].Indexation_Year >= 2008 then
    begin
      SetLength(outputIndexFactorsArray,y+1);
      outputIndexFactorsArray[y].Indexation_Year := indexFactorsArray[x].Indexation_Year;
      outputIndexFactorsArray[y].Indexing_Factor := indexFactorsArray[x].Indexing_Factor;
      inc(y);
    end;
  end;

  {do the indexedMinimumResultsArray array for output}
  start :=  Low(indexedMinimumResultsArray);
  ending := High(indexedMinimumResultsArray);
  y := 0;

  for x:= start to ending do
  begin
    {eliminate rows where the tax year is only one year greater than the accident
     year; Linda Penner does not want to see these rows}
    if indexedMinimumResultsArray[x].Tax_Year <> indexedMinimumResultsArray[x].Accident_Year + 1 then
    begin
      SetLength(outputIndexedMinimumResultsArray,y+1);
      outputIndexedMinimumResultsArray[y].effectiveDate := indexedMinimumResultsArray[x].effectiveDate;
      outputIndexedMinimumResultsArray[y].Accident_Year := indexedMinimumResultsArray[x].Accident_Year;
      outputIndexedMinimumResultsArray[y].Tax_Year := indexedMinimumResultsArray[x].Tax_Year;
      outputIndexedMinimumResultsArray[y].Annual_Minimum := indexedMinimumResultsArray[x].Annual_Minimum;

      {set the 'december' value to be 0.00 where the tax year is two years
      greater than the accident year; Linda Penner does not want to see this value}
      if indexedMinimumResultsArray[x].Tax_Year = indexedMinimumResultsArray[x].Accident_Year + 2 then
      begin
        outputIndexedMinimumResultsArray[y].Annual_Minimum_Dec := 0.00;
      end
      else
      begin
        outputIndexedMinimumResultsArray[y].Annual_Minimum_Dec := indexedMinimumResultsArray[x].Annual_Minimum_Dec;
      end;

      inc(y);
    end;
  end;
end;

{********************************************************************
procedure QRIndexationFactorsBeforePrint, added based on similar procedure
in NCIDXRPT.  RLloyd, Jan 23, 2008
********************************************************************}
procedure TPrintMinWageReport.QRIndexationFactorsBeforePrint(
  Sender: TCustomQuickRep; var PrintReport: Boolean);
begin
  {Call new procedures to setup arrays}
  convertMinWageQueryToArray;  //populates array minWageArray
  redefineIndexFactorsArray;  //populates array indexFactorsArray
  populateResultsArray;     //populates array indexedMinimumResultsArray

  {this method removes unwanted rows from indexedMinimumResultsArray and
  indexFactorsArray.}
  alterArraysForOutput;

  {Set starting point for both indexation factor and new annual minimum arrays.}
  iii := low(outputIndexFactorsArray);
  jjj := low(outputIndexedMinimumResultsArray);
  QRUserID.caption := UserProfile.givenName + ' ' + userProfile.familyName;
  efYear := year( outputIndexedMinimumResultsArray[jjj].effectiveDate ); //***

end;

{********************************************************************
procedure QRIndexationFactorsNeedData, added based on similar procedure
in NCIDXRPT.  RLloyd, Jan 23, 2008
********************************************************************}
procedure TPrintMinWageReport.QRIndexationFactorsNeedData(
  Sender: TObject; var MoreData: Boolean);
begin

  If //(iii > high(outputIndexFactorsArray)) and
     (jjj > high(outputIndexedMinimumResultsArray))then
     MoreData := False {the end of the array has been reached}
  Else
  If //(length(IntToStr(outputIndexFactorsArray[iii].Indexation_Year)) <= 1) and
     (length(IntToStr(outputIndexedMinimumResultsArray[jjj].Accident_Year)) <= 1) then
     MoreData := False {lengths of 1 indicate blank array values}
  Else
     MoreData := True;

  // Print values from Indexation Factors Array
{
  If (iii <= high(outputIndexFactorsArray)) and
     (length(IntToStr(outputIndexFactorsArray[iii].Indexation_Year)) > 1) then
  Begin
    QRIndexYear.caption  := IntToStr(outputIndexFactorsArray[iii].Indexation_Year);
    QRIndexFactor.caption := Format('%.7n', [outputIndexFactorsArray[iii].Indexing_Factor]);
    Inc(iii);
  End
  Else
  Begin
    QRIndexYear.Caption  := '';
    QRIndexFactor.Caption := '';
    Inc(iii);
  End;
}
  // Print values from Annual Maximums Array
  If (jjj <= high(outputIndexedMinimumResultsArray)) and
     (length(IntToStr(outputIndexedMinimumResultsArray[iii].Accident_Year)) > 1) then
  Begin

    QREffectiveDate.Caption := FormatDateTime('MMM d, yyyy', outputIndexedMinimumResultsArray[jjj].effectiveDate );
    //QRAccidentYear.caption  := IntToStr(outputIndexedMinimumResultsArray[jjj].Accident_Year);
    QRTaxYear.caption  := IntToStr(outputIndexedMinimumResultsArray[jjj].Tax_Year);
    QRAnnualMin.caption := Format('%.2n', [outputIndexedMinimumResultsArray[jjj].Annual_Minimum]);

    {Lind's team is used to seeing a '-' instead of 0.00}
    if outputIndexedMinimumResultsArray[jjj].Annual_Minimum_Dec = 0.00 then
    begin
      QRAnnualMinDec.caption := '-'
    end
    else
    begin
      QRAnnualMinDec.caption := Format('%.2n', [outputIndexedMinimumResultsArray[jjj].Annual_Minimum_Dec]);
    end;
    //***
    if jjj <= high(outputIndexedMinimumResultsArray) then
    begin
      efYear := year( outputIndexedMinimumResultsArray[jjj].effectiveDate );
      if jjj > Low(outputIndexedMinimumResultsArray) then
         QRBand2.Frame.DrawTop := efYear <> year( outputIndexedMinimumResultsArray[jjj-1].effectiveDate );
    end;
    //***

    Inc(jjj);

  End
  Else
  Begin
    QREffectiveDate.Caption  := '';
    QRTaxYear.Caption  := '';
    QRAnnualMin.Caption := '';
    QRAnnualMinDec.Caption := '';
  End;
end;

procedure TPrintMinWageReport.QRBand2BeforePrint(Sender: TQRCustomBand;
  var PrintBand: Boolean);
var
  i : Integer;
begin
  with QRBand2 do
  begin
    if Color = $00F0F0F0 then
      Color := $00E0E0E0
    else
      Color := $00F0F0F0;
    for i := 0 to ControlCount-1 do
    begin
       TQRLabel(Controls[i]).Color := Color;
    end;
  end;

end;

end.
