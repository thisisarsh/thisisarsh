
(*****************************************************************)
(*  Wageloss System                                              *)
(*                                                               *)
(*  Initialization Module                                        *)
(*                                                               *)
(*  This module stores global data records and arrays. Some of   *)
(*  the arrays are populated at startup from WLTABLES.DLL.       *)
(*                                                               *)
(*  Author: Brad Trupp  / Capella Systems Group, Inc.            *)
(*  Date:   July 1997                                            *)
(*****************************************************************)

unit NCIniMod;

interface

uses Windows, Registry, NCRecdef, SysUtils, Printers;
     //WLDEBUG;

const

  UW_RegKeyRoot: string = '\Software\WCB\WagelossSystem';

(**********************************************)
(*  Ensure these arrays are initialized to at *)
(*  least one element larger than the arrays  *)
(*  as declared in the *.in2 files            *)
(**********************************************)
var
  arrayNCANNMAX: array[1..596] of recNCANNMAX;
  arrayNCANNMAXB18: array[1..11] of recNCANNMAXB18;
  //arrayNCCHQMSG: array[1..35] of recNCCHQMSG;
  arrayNCCODEXP: array[1..20] of recNCCODEXP;

  arrayNCEXMAMT: array[1..36] of recNCEXMAMT;

  arrayNCINDEXF: array[1..33] of recNCINDEXF;

  arrayNCTAXRAT: array[1..36] of recNCTAXRAT;

  arrayNC_CFIO:  array[1..18] of recNC_CFIO;
  arrayNCIAWMAX: array[1..26] of recNCIAWMAX;

  indexNCANNMAX: integer;
  indexNCANNMAXB18: integer;
  indexNCCHQMSG: integer;
  indexNCCODEXP: integer;
  indexNCEXMAMT: integer;
  indexNCINDEXF: integer;
  indexNCTAXRAT: integer;
  indexNC_CFIO: integer;
  indexNCIAWMAX: Integer;

  dataClaim: recNCCLAIM;
  dataForm: recNCFORM;
  dataLogin: recNCLOGIN;
  w:recConst;
  
  QRPrinterDefault, QRBinDefault: integer;
  QRPrinterDefaultName: string;

procedure GetWagelossRegistryData;
procedure PutWagelossRegistryData;

function  GetCurrentTaxYear: integer; stdcall; external 'WLTABLES.DLL';
procedure GetNCANNMAX(var tb: array of recNCANNMAX); stdcall; external 'WLTABLES.DLL';
procedure GetNCANNMAXB18(var tb: array of recNCANNMAXB18); stdcall; external 'WLTABLES.DLL';
procedure GetNCCODEXP(var tb: array of recNCCODEXP); stdcall; external 'WLTABLES.DLL';
procedure GetNCEXMAMT(var tb: array of recNCEXMAMT); stdcall; external 'WLTABLES.DLL';
procedure GetNCINDEXF(var tb: array of recNCINDEXF); stdcall; external 'WLTABLES.DLL';
procedure GetNCTAXRAT(var tb: array of recNCTAXRAT); stdcall; external 'WLTABLES.DLL';
procedure GetNC_CFIO(var tb: array of recNC_CFIO);   stdcall; external 'WLTABLES.DLL';
procedure GetNCIAWMAX(var tb: array of recNCIAWMAX);   stdcall; external 'WLTABLES.DLL';
procedure Calc_Annuity( var r: recNCCLAIM ); stdcall; external 'TaxCalculator.DLL';
procedure Calc_Ben( var r: recNCCLAIM; w: recConst); stdcall; external 'TaxCalculator.DLL';
function Check_Self_Assurer(  var firmno: Shortstring ): boolean; stdcall; external 'TaxCalculator.DLL';
function Find_Firm_Name( var firmNo: shortstring): string; stdcall; external 'TaxCalculator.DLL';

implementation


(******************************************************************************)
(*                                                                            *)
(*                                                                            *)
(*                                                                            *)
(******************************************************************************)
procedure GetWagelossRegistryData;
var
  reg: TRegistry;
begin
  reg := TRegistry.Create;
  try
    reg.RootKey := HKEY_CURRENT_USER;
    if reg.OpenKey( UW_RegKeyRoot, true ) then
      begin

      if reg.ValueExists( 'QRPrinterDefault' ) then
        QRPrinterDefault := reg.ReadInteger( 'QRPrinterDefault' );
      if reg.ValueExists( 'QRPrinterDefaultName' ) then
        QRPrinterDefaultName := reg.ReadString( 'QRPrinterDefaultName' );
      if reg.ValueExists( 'QRBinDefault' ) then
        QRBinDefault := reg.ReadInteger( 'QRBinDefault' );

      reg.CloseKey;
      end;
  finally
    reg.Free;
end;
end;
(******************************************************************************)
(*                                                                            *)
(*                                                                            *)
(*                                                                            *)
(******************************************************************************)
procedure PutWagelossRegistryData;
var
  reg: TRegistry;
begin
  reg := TRegistry.Create;
  try
    reg.RootKey := HKEY_CURRENT_USER;
    if reg.OpenKey( UW_RegKeyRoot, true ) then
      begin
      reg.WriteInteger( 'QRPrinterDefault', QRPrinterDefault);
      reg.WriteString( 'QRPrinterDefaultName', QRPrinterDefaultName);
      reg.WriteInteger( 'QRBinDefault', QRBinDefault);
      reg.CloseKey;
      end;
  finally
    reg.Free;
    end;
end;


(******************************************************************************)
(*                                                                            *)
(*  At startup / initialization the in-memory arrays will be loaded from      *)
(*  the WLTABLES DLL.                                                         *)
(*                                                                            *)
(******************************************************************************)
Initialization
begin
  //{$IFDEF DEBUG}
  //ShowDebugLine( 'WLINIT00 started.');
  //{$ENDIF}
  GetNCANNMAX(arrayNCANNMAX);
  GetNCANNMAXB18(arrayNCANNMAXB18);
  GetNCCODEXP(arrayNCCODEXP);
  GetNCEXMAMT(arrayNCEXMAMT);
  GetNCINDEXF(arrayNCINDEXF);
  GetNCTAXRAT(arrayNCTAXRAT);
  GetNC_CFIO(arrayNC_CFIO);
  GetNCIAWMAX(arrayNCIAWMAX);
  indexNCANNMAX := -1;
  indexNCANNMAXB18 := -1;
  indexNCCHQMSG:= -1;
  indexNCCODEXP:= -1;
  indexNCEXMAMT:= -1;
  indexNCINDEXF:= -1;
  indexNCTAXRAT:= -1;
  indexNC_CFIO:= -1;
  indexNCIAWMAX := -1;
  ClearNCCLAIM( dataClaim );
  QRPrinterDefault:= -1;
  QRPrinterDefaultName:='';
  QRBinDefault:= -1;
  GetWagelossRegistryData;
  //{$IFDEF DEBUG}
  //ShowDebugLine( 'WLINIT00 complete.');
  //{$ENDIF}
end;


end.
