object NonTaxableCollateral: TNonTaxableCollateral
  Left = 368
  Top = 415
  Width = 297
  Height = 173
  AutoSize = True
  Caption = 'NonTaxableCollateral'
  Color = clBtnFace
  Font.Charset = DEFAULT_CHARSET
  Font.Color = clWindowText
  Font.Height = -11
  Font.Name = 'MS Sans Serif'
  Font.Style = []
  OldCreateOrder = False
  Position = poMainFormCenter
  PixelsPerInch = 96
  TextHeight = 13
  object Label1: TLabel
    Left = 0
    Top = 0
    Width = 253
    Height = 20
    Caption = 'Non Taxable Collateral Benefits'
    Font.Charset = DEFAULT_CHARSET
    Font.Color = clWindowText
    Font.Height = -16
    Font.Name = 'MS Sans Serif'
    Font.Style = [fsBold]
    ParentFont = False
  end
  object Label2: TLabel
    Left = 0
    Top = 40
    Width = 143
    Height = 20
    Caption = 'Employer Top Up:'
    Font.Charset = DEFAULT_CHARSET
    Font.Color = clWindowText
    Font.Height = -16
    Font.Name = 'MS Sans Serif'
    Font.Style = [fsBold]
    ParentFont = False
  end
  object Label3: TLabel
    Left = 0
    Top = 72
    Width = 146
    Height = 20
    Caption = 'Private Insurance:'
    Font.Charset = DEFAULT_CHARSET
    Font.Color = clWindowText
    Font.Height = -16
    Font.Name = 'MS Sans Serif'
    Font.Style = [fsBold]
    ParentFont = False
  end
  object edEmpTopUp: TEdit
    Left = 168
    Top = 40
    Width = 121
    Height = 24
    Color = clAqua
    Ctl3D = False
    Font.Charset = ANSI_CHARSET
    Font.Color = clWindowText
    Font.Height = -16
    Font.Name = 'Arial'
    Font.Style = []
    MaxLength = 12
    ParentCtl3D = False
    ParentFont = False
    TabOrder = 0
    OnExit = edEmpTopUpExit
  end
  object edPrivateIns: TEdit
    Left = 168
    Top = 72
    Width = 121
    Height = 24
    Color = clAqua
    Ctl3D = False
    Font.Charset = ANSI_CHARSET
    Font.Color = clWindowText
    Font.Height = -16
    Font.Name = 'Arial'
    Font.Style = []
    MaxLength = 12
    ParentCtl3D = False
    ParentFont = False
    TabOrder = 1
    OnExit = edPrivateInsExit
  end
  object btnOK: TButton
    Left = 56
    Top = 121
    Width = 75
    Height = 25
    Caption = 'OK'
    TabOrder = 2
    OnClick = btnOKClick
  end
  object btnCancel: TButton
    Left = 160
    Top = 121
    Width = 75
    Height = 25
    Caption = 'Cancel'
    TabOrder = 3
    OnClick = btnCancelClick
  end
end
