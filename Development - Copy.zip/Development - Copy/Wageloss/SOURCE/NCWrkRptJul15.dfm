inherited WrkRptJul15: TWrkRptJul15
  Caption = 'WrkRptJul15'
  PixelsPerInch = 96
  TextHeight = 13
end
