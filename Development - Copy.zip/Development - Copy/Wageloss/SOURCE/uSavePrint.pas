unit uSavePrint;

interface

Uses SysUtils, Forms, Inifiles, Messages, Dialogs, Windows, Utils, ncrecdef,
     Math, uTriggerEvent, Classes, Variants;

var
  wrpt: recReport;
  CalcFullClaim, CalcPartClaim: recNCCLAIM;
  formId: String;

  procedure SetRecReport(FormId: String; cc, cp: recNCCLAIM);
  procedure SavePrint;
  procedure SetrecNCCLAIM(acc, acp: recNCCLAIM);
  procedure SetFormId(aFormId: String);
  function GetFormId(): String;
  procedure FullClaim;
  procedure CheckForPartial;
  function UpdateReport: boolean;
  procedure TriggerReport;
  function SQLDouble( dd:double ): shortstring;
  //***
  function NewQADataRecord(cDescript : String; nClaimYear : Integer; var nextQATestID : Integer  ): boolean;
  function UpdateQADataRecord(cDescript : String; nClaimYear, intQADataID, intQATestID, intQATestIndexID : Integer  ): boolean;
  function GetNextQATestID(nYear : Integer): Integer  ;
//  function IndxYearRecExist():Boolean;
  //***

implementation

uses uADOSecurity, NCDatMod, uGlobal, uUserMaint, NCBenCal, utilmod1;

procedure SavePrint;
begin
  FullClaim;
  CheckForPartial;
  If UpdateReport then
    TriggerReport;
end;

procedure FullClaim;
var
   Acc_Year, Acc_Month, Acc_Day, Idx_Month:Word;
   WorkDate:TDateTime;
   collBenefits, NonTaxCollBenefits:String;
begin
  with CalcFullClaim do
  begin
    DecodeDate(Accident_Date, Acc_Year, Acc_Month, Acc_Day);
    if ((Indexation_Year > 0) AND (Tax_Year <> Acc_Year)) Then
      Idx_Month := Max(((Acc_Month+1) Mod 13),1)
    else
      Idx_Month := Acc_Month;
    WorkDate := EncodeDate(Min(Max(Indexation_Year,Acc_Year), Tax_Year), Idx_Month, 1);
    wrpt.Claim_No := pdoxTrim(Claim_No);
    wrpt.ReportId := GetFormId();
    wrpt.Report_Date := FormatDateTime('dd/mm/yyyy', Now());
    wrpt.Report_Time :=  FormatDateTime('hh:mm:ss.zzz', Now());
    wrpt.Reporting_User := UserProfile.givenName + ' ' + userProfile.familyName;
    wrpt.Claim_Suffix := pdoxTrim(Claim_Suffix);
    wrpt.Clmt_Name := pdoxTrim(Clmnts_1st_Name) + ' ' + pdoxTrim(Clmnts_Surname);
    wrpt.Clmt_Address_1 := Clmnts_Add_No_1;
    wrpt.Clmt_Address_2 := Clmnts_Add_No_2;
    wrpt.Clmt_Address_3 := Clmnts_Add_No_3;
    wrpt.Clmt_Postal_Code := Clmnts_Post_Code;
    wrpt.Clmt_SIN  := SIN;
    if Birth_Date > 0 then
      wrpt.Clmt_DOB  := FormatDateTime('d-mmm-yyyy', Birth_Date)
    else
      wrpt.Clmt_DOB  := '';
    wrpt.Clmt_Home_Phone  := Clmnts_Home_Phone;
    wrpt.Clmt_Work_Phone  := Clmnts_Work_Phone;
    if Accident_Date > 0 then
      wrpt.Accident_Date := FormatDateTime('d-mmm-yyyy', Accident_Date)
    else
      wrpt.Accident_Date := '';
    wrpt.Weekly_Wage := Wkly_Sal_A;
    wrpt.Tax_Year := Tax_Year;
    wrpt.Indexed_Year := Indexation_Year;
    wrpt.Indexed_Date := FormatDateTime('d-mmm-yyyy', WorkDate);
    wrpt.Recurence := copy(Recurrence,1,1);
    if RecurrenceDate > 0 then
      wrpt.Recurrence_Date := FormatDateTime('d-mmm-yyyy', RecurrenceDate)
    else
      wrpt.Recurrence_Date := '';
    wrpt.Days_Week := Days_Worked_per_Week;
    if Loss_Earn_Date > 0 then
      wrpt.Loss_Of_Earnings_Date := FormatDateTime('d-mmm-yyyy', Loss_Earn_Date)
    else
      wrpt.Loss_Of_Earnings_Date := '';
    wrpt.Youthful_Worker := Youthful_Worker;
    wrpt.Self_Employed := copy(Self_Employed,1,1);
    wrpt.Marital_Status := Marital_Status;
    wrpt.Spouse_Working := Spouse_Working;
    wrpt.ClaimSpouseForTaxPurposes := ClaimSpouseForTaxPurposes;
    wrpt.Nbr_Of_Dependants := No_Of_Dependnts;
    wrpt.Nbr_Of_Infirm_Deps := No_Infirm;
    wrpt.Uic_Exempt := copy(EI_Exempt,1,1);
    wrpt.CPP_Exempt := copy(CPP_Exempt,1,1);
    wrpt.Income_Tax_Exempt := copy(Tax_Exempt,1,1);
    wrpt.Child_Care_Expense := Child_Care_Exp;
    wrpt.Spousal_Support := Spousal_Support;
    wrpt.Child_Support := Child_Support;
    wrpt.Inc_Tax_Fed := Inc_Tax_Fed;
    wrpt.Inc_Tax_Prov := Inc_Tax_Man;
    wrpt.Cpp_Prem := CPP_Prem;
    wrpt.Cpp2_Prem := CPP2_Prem;
    wrpt.Uic_Prem := EI_Prem;
    wrpt.Total_Deds := Total_Deds;
    wrpt.Weekly_Deds := PdoxRound(Total_Deds / 52.0, 2 );
    wrpt.Collateral_Taxable := Collateral_Ben_Tax;
    wrpt.Collateral_Taxable_Net := CalcPartClaim.Coll_Ben_Tax_Net;
    wrpt.Collateral_Non_Taxable := Collateral_Ben_Non_Tax;
    wrpt.Post_Earn_Weekly_Gross := Post_Injury_Earn;
    wrpt.Post_Earn_Weekly_Net := Post_Injury_Earn_Net;
    if nc_104_Wk_Effective_Date > 0 then
      wrpt.Effective_Date_80 := FormatDateTime('d-mmm-yyyy', nc_104_Wk_Effective_Date)
    else
      wrpt.Effective_Date_80 := '';
    if nc_104_Wk_Clmt_P_Eff_Date > 0 then
      wrpt.Clmnt_Contrib_Effective_Date := FormatDateTime('d-mmm-yyyy', nc_104_Wk_Clmt_P_Eff_Date)
    else
      wrpt.Clmnt_Contrib_Effective_Date := '';
    wrpt.Full_Weekly_Gross := Wkly_Sal_A;
    wrpt.Full_Annual_Gross := Annual_Gross;
    wrpt.Full_Weekly_Net_Loss_Earn := Weekly_Net;
    wrpt.Full_Annual_Net_Loss_Earn := Annual_Net;
    //
    // Modified for Lev Review Ammendment 2006
    // Changed to display 100% net actual
    //
    if Year(CalcFullClaim.Accident_Date) >= 2006 Then
       wrpt.Full_Weekly_90_Net_Actual := PdoxRound((Weekly_Net_A), 2)
    else
       wrpt.Full_Weekly_90_Net_Actual := PdoxRound((Weekly_Net_A * 0.90 ), 2);
    //
    //
    wrpt.Full_Weekly_90_Net_Loss := Weekly_90;
    wrpt.Full_Annual_90_Net_Loss := Annual_90;
    wrpt.Full_Weekly_Tax_Sheltering := pdoxround( ( Weekly_90 - Weekly_90_S ) , 2);
    wrpt.Full_Weekly_90_Net_Sheltered := Weekly_90_S;
    wrpt.Full_Annual_90_Net_Sheltered := Annual_90_S;
    wrpt.Full_Weekly_Daily_Comp_Rate := (Weekly_90_S / Days_Worked_per_Week);
    wrpt.Full_Weekly_80_Net_Loss := Weekly_80;
    wrpt.Full_Annual_80_Net_Loss := Annual_80;
    wrpt.Full_Weekly_80_Net_Sheltered := Weekly_80_S;
    wrpt.Full_Annual_80_Net_Sheltered := Annual_80_S;
    wrpt.Full_Clmnt_Percent_Contrib := NC_104_Wk_Clmt_P_Contrib;
    wrpt.Full_Clmnt_Contrib := Wkly_Clmt_Anty_Con_Amt;

    if Year(Accident_Date) >= 2006 then begin
      wrpt.Full_Weekly_80_Clmnt_Net_Contrib := pdoxround( ( Weekly_90_S  - Wkly_Clmt_Anty_Con_Amt), 2);
      wrpt.Full_WCB_Contrib := pdoxround( ( (((nc_104_Wk_WCB_p_Contrib)*Weekly_90_S)/100.00) ), 2);
      wrpt.Full_Weekly_Adjusted_Daily_Comp_Rate := pdoxround( ( Weekly_90_S  - Wkly_Clmt_Anty_Con_Amt), 2) / Days_Worked_per_Week;
      wrpt.Full_WCB_Percent_Contrib := nc_104_Wk_WCB_p_Contrib;
    end else begin
      wrpt.Full_Weekly_80_Clmnt_Net_Contrib := pdoxround( ( Weekly_80  - Wkly_Clmt_Anty_Con_Amt), 2);
      wrpt.Full_WCB_Contrib := pdoxround( ( (((5 - nc_104_Wk_WCB_p_Contrib_Red)*Weekly_80)/100.00) ), 2);
      wrpt.Full_Weekly_Adjusted_Daily_Comp_Rate := pdoxround( ( Weekly_80  - Wkly_Clmt_Anty_Con_Amt), 2) / Days_Worked_per_Week;
      wrpt.Full_WCB_Percent_Contrib := ( 5.00 - nc_104_Wk_WCB_p_Contrib_Red );
    end;

    wrpt.Full_Annual_80_Clmnt_Net_Contrib := pdoxround( ( Annual_80 - ( 52* Wkly_Clmt_Anty_Con_Amt ) ), 2);
    wrpt.Apprentice := pdoxTrim(Apprentice);
    wrpt.Deemed := pdoxTrim(Deemed_Earnings);
    wrpt.AverageEarningsBasedOn := pdoxTrim(AverageEarningsBasedOn);
    wrpt.annual_net_a := Annual_Net_A;

    //EC Dec 14/05 - Fix for Max Adj. Override bug that was discovered in last round of testing
    //we will use the same value that the detailed worksheet is using...but we have to set it first!!!
    wrpt.Wkly_Sal := Wkly_Sal;

    if Pay_At_100_Flag then begin
      wrpt.weekly_shelter_benefit :=  PDoxRound( Weekly_Shelter_Ben_Amount_90 * 1.11111, 2 );
    end else begin
      wrpt.weekly_shelter_benefit := Weekly_Shelter_Ben_Amount;
    end;
    wrpt.weekly_shelter_benefit_90 := Weekly_Shelter_Ben_Amount_90;
    wrpt.weekly_min_wage_net := (Min_Wage_Annual_Net_A / 52.0);
    wrpt.weekly_min_wage := (Minimum_wage / 52.0);
    wrpt.net_coll_ben := Tax_Coll_Ben_Only;

    collBenefits := ' ';
    if TaxCollBen_CPPQPP > 0 then
      collBenefits := 'CPP/QPP ';
    if TaxCollBen_EI > 0 then
      collBenefits := collBenefits + 'EI ';
    if TaxCollBen_DisabilityIns > 0 then
      collBenefits := collBenefits + 'Disb Ins ';
    if TaxCollBen_Combination > 0 then
      collBenefits := collBenefits + 'Other';
    wrpt.coll_ben_type := collBenefits;

    NonTaxCollBenefits := ' ';
    if CalcFullClaim.NonTaxCollBen_EmpTopUp > 0 Then
       NonTaxCollBenefits := NonTaxCollBenefits + 'Emp TopUp ';
    if CalcFullClaim.NonTaxCollBen_PrivateIns > 0 Then
       NonTaxCollBenefits := NonTaxCollBenefits + 'Priv Ins';
    NonTaxCollBenefits := Trim(NonTaxCollBenefits);
    wrpt.NonTaxCollBenefits := NonTaxCollBenefits;

    if Minimum_wage_Flag then
      wrpt.MinimumWageIndicator := 'Y'
    else if Pay_At_100_Flag then
      wrpt.MinimumWageIndicator := 'R'
    else
      wrpt.MinimumWageIndicator := 'N';
    wrpt.DeathBenefit := DeathBenefit;

    if effectiveDate > 0 then
      wrpt.effectiveDate := FormatDateTime('d-mmm-yyyy', effectiveDate)
    else
      wrpt.effectiveDate := '';
  end;
end;

procedure CheckForPartial;
begin
  if ( CalcFullClaim.Post_Injury_Earn = 0.0 ) then
  begin
    wrpt.Partial_Net_Pre_Injury := 0;
    wrpt.Partial_Net_Post_Injury := 0;
    wrpt.Partial_Net_Loss_Earn := 0;
    wrpt.Partial_90_Net_Loss_Earn := 0;
    wrpt.Partial_Tax_Sheltering := 0;
    wrpt.Partial_90_Net_Sheltered := 0;
    wrpt.Partial_Daily_Comp_Rate := 0;
    wrpt.Partial_80_Net_Loss := 0;
    wrpt.Partial_80_Net_Sheltered := 0;
    wrpt.Partial_Clmnt_Percent_Contrib := 0;
    wrpt.Partial_Clmnt_Contrib := 0;
    wrpt.Partial_80_Net_Contrib := 0;
    wrpt.Partial_WCB_Percent_Contrib := 0;
    wrpt.Partial_WCB_Contrib := 0;
    wrpt.Partial_80_Daily_Comp_Rate := 0;
  end
  else
  begin
    with CalcPartClaim do
    begin
      wrpt.Partial_Net_Pre_Injury := Weekly_Net;
      wrpt.Partial_Net_Post_Injury := Post_Injury_Earn_Net;
      wrpt.Post_Earn_Weekly_Net := Post_Injury_Earn_Net;
      wrpt.Partial_Net_Loss_Earn := Weekly_Net;

      if ( Weekly_90 < 0 ) then
        wrpt.Partial_90_Net_Loss_Earn := 0
      else
        wrpt.Partial_90_Net_Loss_Earn := Weekly_90;

      //showmessage('Weekly_90 = ' + format('%.2n', [ Weekly_90 ] ) + '  Weekly_90_S = ' + format('%.2n', [ Weekly_90_S ] ));

      if ( Weekly_90_S <= 0 ) then
      begin
        if ( ( pdoxround( ( Weekly_90 + Weekly_90_S ) , 2) <= 0 ) or ( Weekly_90 <= 0 ) ) then
          //wrpt.Partial_Tax_Sheltering := 0
          wrpt.Partial_Tax_Sheltering := wrpt.Full_Weekly_Tax_Sheltering
        else
          if wrpt.Collateral_Taxable > 0.00 then
            wrpt.Partial_Tax_Sheltering := pdoxround( ( Weekly_90 + Weekly_90_S ) , 2)
          else
            wrpt.Partial_Tax_Sheltering := wrpt.Full_Weekly_Tax_Sheltering
      end
      else
      begin
        if ( ( pdoxround( ( Weekly_90 - Weekly_90_S ) , 2) <= 0 ) or ( Weekly_90 <= 0 ) ) then
          wrpt.Partial_Tax_Sheltering := 0
        else
          if wrpt.Collateral_Taxable > 0.00 then
            wrpt.Partial_Tax_Sheltering := pdoxround( ( Weekly_90 - Weekly_90_S ) , 2)
          else
            wrpt.Partial_Tax_Sheltering := wrpt.Full_Weekly_Tax_Sheltering
      end;

      if ( Weekly_90_S < 0 ) then
      begin
        wrpt.Partial_90_Net_Sheltered := 0;
      end
      else
      begin
        wrpt.Partial_90_Net_Sheltered := Weekly_90_S;
      end;

      if ( Weekly_90_S / Days_Worked_per_Week < 0 ) then
      begin
        wrpt.Partial_Daily_Comp_Rate := 0;
      end
      else
      begin
        wrpt.Partial_Daily_Comp_Rate := Weekly_90_S / Days_Worked_per_Week;
      end;

      if ( Weekly_80 < 0 ) then
        wrpt.Partial_80_Net_Loss := 0
      else
        wrpt.Partial_80_Net_Loss := Weekly_80;

      if ( Weekly_80_S < 0 ) then
        wrpt.Partial_80_Net_Sheltered := 0
      else
        wrpt.Partial_80_Net_Sheltered := Weekly_80_S;

      if ( NC_104_Wk_Clmt_P_Contrib < 0 ) then
        wrpt.Partial_Clmnt_Percent_Contrib := 0
      else
        wrpt.Partial_Clmnt_Percent_Contrib := NC_104_Wk_Clmt_P_Contrib;

      if ( Wkly_Clmt_Anty_Con_Amt < 0 ) then
        wrpt.Partial_Clmnt_Contrib := 0
      else
        wrpt.Partial_Clmnt_Contrib := Wkly_Clmt_Anty_Con_Amt;

      if Year(Accident_Date) >= 2006 then begin

        if ( pdoxround( ( Weekly_90_S  - Wkly_Clmt_Anty_Con_Amt), 2) < 0 ) then
        begin
          wrpt.Partial_80_Net_Contrib := 0;
        end
        else
        begin
          wrpt.Partial_80_Net_Contrib := pdoxround( ( Weekly_90_S  - Wkly_Clmt_Anty_Con_Amt), 2);
        end;

        if ( pdoxround( ( (((nc_104_Wk_WCB_p_Contrib)*Weekly_90_S)/100.00) ), 2) < 0 ) then
        begin
          wrpt.Partial_WCB_Contrib := 0;
        end
        else
        begin
          wrpt.Partial_WCB_Contrib := pdoxround( ( (((nc_104_Wk_WCB_p_Contrib)*Weekly_90_S)/100.00) ), 2);
        end;

        if ( pdoxround( ( Weekly_90_S  - Wkly_Clmt_Anty_Con_Amt), 2) / Days_Worked_per_Week < 0 ) then
        begin
          wrpt.Partial_80_Daily_Comp_Rate := 0;
        end
        else
        begin
          wrpt.Partial_80_Daily_Comp_Rate := pdoxround( ( Weekly_90_S  - Wkly_Clmt_Anty_Con_Amt), 2) / Days_Worked_per_Week;
        end;

        if ( nc_104_Wk_WCB_p_Contrib < 0 ) then
          wrpt.Partial_WCB_Percent_Contrib := 0
        else
          wrpt.Partial_WCB_Percent_Contrib := nc_104_Wk_WCB_p_Contrib;
      end else begin
        wrpt.Partial_80_Net_Contrib := pdoxround( ( Weekly_80  - Wkly_Clmt_Anty_Con_Amt), 2);
        wrpt.Partial_WCB_Contrib := pdoxround( ( (((5 - nc_104_Wk_WCB_p_Contrib_Red)*Weekly_80)/100.00) ), 2);
        wrpt.Partial_80_Daily_Comp_Rate := pdoxround( ( Weekly_80  - Wkly_Clmt_Anty_Con_Amt), 2) / Days_Worked_per_Week;
        wrpt.Partial_WCB_Percent_Contrib := ( 5.00 - nc_104_Wk_WCB_p_Contrib_Red );
      end;

      if Minimum_Wage_Flag_Partial then
        wrpt.MinimumWageIndicatorPartial := 'Y'
      else if Pay_At_100_Flag_Partial then
        wrpt.MinimumWageIndicatorPartial := 'R'
      else
        wrpt.MinimumWageIndicatorPartial := 'N';
    end;
  end;
end;

procedure SetRecReport(FormId: String; cc, cp: recNCCLAIM);
Begin
  SetrecNCCLAIM(cc, cp);
  SetFormId(FormId);
  SavePrint;
end;

procedure SetFormId(aFormId: String);
begin
  formId := aFormId;
end;

function GetFormId(): String;
begin
  Result := formId;
end;

procedure SetrecNCCLAIM(acc, acp: recNCCLAIM);
begin
  CalcFullClaim := acc;
  CalcPartClaim := acp;
end;

function UpdateReport: boolean;
var
  s, t: string;
  bReturn: boolean;
begin

  bReturn := True;
  try
    with dm1.qWageLossReport do
    begin
      close;
      SQL.Clear;
      //Changed Dec. 2006 - bcooper
      //original  removed the delete clause
      //SQL.Add ('DELETE WageLossReports WHERE Claim_No = ' + wrpt.Claim_No );
      //s := SQLstring( wrpt.Reporting_User ) ;
      //s:=copy(s,1,length(s)-1);
      //SQL.Add( ' And Reporting_User = ' + s );
      //execSQL;
      //SQL.Clear;
      //new - just commented out the DELETE clause
      SQL.add('INSERT INTO WageLossReports ');
      SQL.Add('( ');
      SQL.Add('Claim_No,');
      SQL.Add('ReportId,');
      SQL.Add('Reporting_User,');
      SQL.Add('Report_Time,');
      SQL.Add('Report_Date,');
      SQL.Add('Claim_Suffix,');
      SQL.Add('Clmt_Name,');
      SQL.Add('Clmt_Address_1,');
      SQL.Add('Clmt_Address_2,');
      SQL.Add('Clmt_Address_3,');
      SQL.Add('Clmt_Postal_Code,');
      SQL.Add('Clmt_SIN,');
      SQL.Add('Clmt_DOB,');
      SQL.Add('Clmt_Home_Phone,');
      SQL.Add('Clmt_Work_Phone,');
      SQL.Add('Accident_Date,');
      SQL.Add('Weekly_Wage,');
      SQL.Add('Tax_Year,');
      SQL.Add('Indexed_Year,');
      SQL.Add('Indexed_Date,');
      SQL.Add('Recurence,');
      SQL.Add('Recurrence_Date,');
      SQL.Add('Days_Week,');
      SQL.Add('Loss_Of_Earnings_Date,');
      SQL.Add('Youthful_Worker,');
      SQL.Add('Self_Employed,');
      SQL.Add('Marital_Status,');
      SQL.Add('Spouse_Working,');
      SQL.Add('Nbr_Of_Dependants,');
      SQL.Add('Nbr_Of_Infirm_Deps,');
      SQL.Add('Uic_Exempt,');
      SQL.Add('CPP_Exempt,');
      SQL.Add('Income_Tax_Exempt,');
      SQL.Add('Child_Care_Expense,');
      SQL.Add('Spousal_Support,');
      SQL.Add('Child_Support,');
      SQL.Add('Inc_Tax_Fed,');
      SQL.Add('Inc_Tax_Prov,');
      SQL.Add('Cpp_Prem,');
      SQL.Add('Cpp2_Prem,');
      SQL.Add('Uic_Prem,');
      SQL.Add('Total_Deds,');
      SQL.Add('Weekly_Deds,');
      SQL.Add('Collateral_Taxable,');
      SQL.Add('Collateral_Taxable_Net,');
      SQL.Add('Collateral_Non_Taxable,');
      SQL.Add('Post_Earn_Weekly_Gross,');
      SQL.Add('Post_Earn_Weekly_Net,');
      SQL.Add('[80_Effective_Date],');
      SQL.Add('Clmnt_Contrib_Effective_Date,');
      SQL.Add('Full_Weekly_Gross,');
      SQL.Add('Full_Annual_Gross,');
      SQL.Add('Full_Weekly_Net_Loss_Earn,');
      SQL.Add('Full_Annual_Net_Loss_Earn,');
      SQL.Add('Full_Weekly_90_Net_Actual,');
      SQL.Add('Full_Weekly_90_Net_Loss,');
      SQL.Add('Full_Annual_90_Net_Loss,');
      SQL.Add('Full_Weekly_Tax_Sheltering,');
      SQL.Add('Full_Weekly_90_Net_Sheltered,');
      SQL.Add('Full_Annual_90_Net_Sheltered,');
      SQL.Add('Full_Weekly_Daily_Comp_Rate,');
      SQL.Add('Full_Weekly_80_Net_Loss,');
      SQL.Add('Full_Annual_80_Net_Loss,');
      SQL.Add('Full_Weekly_80_Net_Sheltered,');
      SQL.Add('Full_Annual_80_Net_Sheltered,');
      SQL.Add('Full_Clmnt_Percent_Contrib,');
      SQL.Add('Full_Clmnt_Contrib,');
      SQL.Add('Full_Weekly_80_Clmnt_Net_Contrib,');
      SQL.Add('Full_Annual_80_Clmnt_Net_Contrib,');
      SQL.Add('Full_WCB_Percent_Contrib,');
      SQL.Add('Full_WCB_Contrib,');
      SQL.Add('Full_Weekly_Adjusted_Daily_Comp_Rate,');
      SQL.Add('Partial_Net_Pre_Injury,');
      SQL.Add('Partial_Net_Post_Injury,');
      SQL.Add('Partial_Net_Loss_Earn,');
      SQL.Add('Partial_90_Net_Loss_Earn,');
      SQL.Add('Partial_Tax_Sheltering,');
      SQL.Add('Partial_90_Net_Sheltered,');
      SQL.Add('Partial_Daily_Comp_Rate,');
      SQL.Add('Partial_80_Net_Loss,');
      SQL.Add('Partial_80_Net_Sheltered,');
      SQL.Add('Partial_Clmnt_Percent_Contrib,');
      SQL.Add('Partial_Clmnt_Contrib,');
      SQL.Add('Partial_80_Net_Contrib,');
      SQL.Add('Partial_WCB_Percent_Contrib,');
      SQL.Add('Partial_WCB_Contrib,');
      SQL.Add('Partial_80_Daily_Comp_Rate,');
      SQL.Add('Apprentice,');
      SQL.Add('Deemed,');
      SQL.Add('AvgEarningsBasedOn,');
      SQL.Add('EmergeIndicator,');
      SQL.Add('weekly_min_wage,');
      SQL.Add('weekly_shelter_benefit,');
      SQL.Add('min_wage_indicator,');
      SQL.Add('coll_ben_type,');
      SQL.Add('weekly_shelter_ben_90,');
      SQL.Add('annual_net_a,');
      SQL.Add('net_coll_ben,');
      SQL.Add('Weekly_Sal,');
      SQL.Add('weekly_min_wage_net,');
      SQL.Add('min_wage_ind_partial,');
      SQL.Add('DeathBenefit,');
      SQL.Add('NonTaxable_Coll_Ben_Type,');
      SQL.Add('effectiveDate,');
      SQL.Add('ClaimSpouseForTaxPurposes');
      SQL.Add(' )');
      SQL.add('VALUES(');
      //SQL.Add(wrpt.Claim_No + ',');
      SQL.Add( SQLstring( wrpt.Claim_No ) );
      //SQL.Add(wrpt.ReportId + ',');
      SQL.Add( SQLstring( wrpt.ReportId ) );
      SQL.Add( SQLstring( wrpt.Reporting_User ) );
      SQL.Add( SQLstring( wrpt.Report_Time ) );
      SQL.Add( SQLstring( wrpt.Report_Date ) );
      SQL.Add( SQLstring( wrpt.Claim_Suffix ) );
      SQL.Add( SQLstring( wrpt.Clmt_Name ) );
      SQL.Add( SQLstring( wrpt.Clmt_Address_1 ) );
      SQL.Add( SQLstring( wrpt.Clmt_Address_2 ) );
      SQL.Add( SQLstring( wrpt.Clmt_Address_3 ) );
      SQL.Add( SQLstring( wrpt.Clmt_Postal_Code ) );
      SQL.Add( SQLstring( wrpt.Clmt_SIN ) );
      SQL.Add( SQLstring( wrpt.Clmt_DOB ) );
      SQL.Add( SQLstring( wrpt.Clmt_Home_Phone ) );
      SQL.Add( SQLstring( wrpt.Clmt_Work_Phone ) );
      SQL.Add( SQLstring( wrpt.Accident_Date ) );
      SQL.Add( SQLcurrency( wrpt.Weekly_Wage ) );
      SQL.Add( SQLinteger( wrpt.Tax_Year ) );
      SQL.Add( SQLinteger( wrpt.Indexed_Year ) );
      SQL.Add( SQLstring( wrpt.Indexed_Date ) );
      SQL.Add( SQLstring( wrpt.Recurence ) );
      SQL.Add( SQLstring( wrpt.Recurrence_Date ) );
      SQL.Add( SQLdouble ( wrpt.Days_Week ) );
      SQL.Add( SQLstring( wrpt.Loss_Of_Earnings_Date ) );
      SQL.Add( SQLstring( wrpt.Youthful_Worker ) );
      SQL.Add( SQLstring( wrpt.Self_Employed ) );
      SQL.Add( SQLstring( wrpt.Marital_Status ) );
      SQL.Add( SQLstring( wrpt.Spouse_Working ) );
      SQL.Add( SQLinteger( wrpt.Nbr_Of_Dependants ) );
      SQL.Add( SQLinteger( wrpt.Nbr_Of_Infirm_Deps ) );
      SQL.Add( SQLstring( wrpt.Uic_Exempt ) );
      SQL.Add( SQLstring( wrpt.CPP_Exempt ) );
      SQL.Add( SQLstring( wrpt.Income_Tax_Exempt ) );
      SQL.Add( SQLcurrency( wrpt.Child_Care_Expense ) );
      SQL.Add( SQLcurrency( wrpt.Spousal_Support ) );
      SQL.Add( SQLcurrency( wrpt.Child_Support ) );
      SQL.Add( SQLcurrency( wrpt.Inc_Tax_Fed ) );
      SQL.Add( SQLcurrency( wrpt.Inc_Tax_Prov ) );
      SQL.Add( SQLcurrency( wrpt.Cpp_Prem ) );
      SQL.Add( SQLcurrency( wrpt.Cpp2_Prem ) );
      SQL.Add( SQLcurrency( wrpt.Uic_Prem ) );
      SQL.Add( SQLcurrency( wrpt.Total_Deds ) );
      SQL.Add( SQLcurrency( wrpt.Weekly_Deds ) );
      SQL.Add( SQLcurrency( wrpt.Collateral_Taxable ) );
      SQL.Add( SQLcurrency( wrpt.Collateral_Taxable_Net ) );
      SQL.Add( SQLcurrency( wrpt.Collateral_Non_Taxable ) );
      SQL.Add( SQLcurrency( wrpt.Post_Earn_Weekly_Gross ) );
      SQL.Add( SQLcurrency( wrpt.Post_Earn_Weekly_Net ) );
      SQL.Add( SQLstring( wrpt.Effective_Date_80 ) );
      SQL.Add( SQLstring( wrpt.Clmnt_Contrib_Effective_Date ) );
      SQL.Add( SQLcurrency( wrpt.Full_Weekly_Gross ) );
      SQL.Add( SQLcurrency( wrpt.Full_Annual_Gross ) );
      SQL.Add( SQLcurrency( wrpt.Full_Weekly_Net_Loss_Earn ) );
      SQL.Add( SQLcurrency( wrpt.Full_Annual_Net_Loss_Earn ) );
      SQL.Add( SQLcurrency( wrpt.Full_Weekly_90_Net_Actual ) );
      SQL.Add( SQLcurrency( wrpt.Full_Weekly_90_Net_Loss ) );
      SQL.Add( SQLcurrency( wrpt.Full_Annual_90_Net_Loss ) );
      SQL.Add( SQLcurrency( wrpt.Full_Weekly_Tax_Sheltering ) );
      SQL.Add( SQLcurrency( wrpt.Full_Weekly_90_Net_Sheltered ) );
      SQL.Add( SQLcurrency( wrpt.Full_Annual_90_Net_Sheltered ) );
      SQL.Add( SQLcurrency( wrpt.Full_Weekly_Daily_Comp_Rate ) );
      SQL.Add( SQLcurrency( wrpt.Full_Weekly_80_Net_Loss ) );
      SQL.Add( SQLcurrency( wrpt.Full_Annual_80_Net_Loss ) );
      SQL.Add( SQLcurrency( wrpt.Full_Weekly_80_Net_Sheltered ) );
      SQL.Add( SQLcurrency( wrpt.Full_Annual_80_Net_Sheltered ) );
      SQL.Add( SQLdouble( wrpt.Full_Clmnt_Percent_Contrib ) );
      SQL.Add( SQLcurrency( wrpt.Full_Clmnt_Contrib ) );
      SQL.Add( SQLcurrency( wrpt.Full_Weekly_80_Clmnt_Net_Contrib ) );
      SQL.Add( SQLcurrency( wrpt.Full_Annual_80_Clmnt_Net_Contrib ) );
      SQL.Add( SQLdouble( wrpt.Full_WCB_Percent_Contrib ) );
      SQL.Add( SQLcurrency( wrpt.Full_WCB_Contrib ) );
      SQL.Add( SQLcurrency( wrpt.Full_Weekly_Adjusted_Daily_Comp_Rate ) );
      SQL.Add( SQLcurrency( wrpt.Partial_Net_Pre_Injury ) );
      SQL.Add( SQLcurrency( wrpt.Partial_Net_Post_Injury ) );
      SQL.Add( SQLcurrency( wrpt.Partial_Net_Loss_Earn ) );
      SQL.Add( SQLcurrency( wrpt.Partial_90_Net_Loss_Earn ) );
      SQL.Add( SQLcurrency( wrpt.Partial_Tax_Sheltering ) );
      SQL.Add( SQLcurrency( wrpt.Partial_90_Net_Sheltered ) );
      SQL.Add( SQLcurrency( wrpt.Partial_Daily_Comp_Rate ) );
      SQL.Add( SQLcurrency( wrpt.Partial_80_Net_Loss ) );
      SQL.Add( SQLcurrency( wrpt.Partial_80_Net_Sheltered ) );
      SQL.Add( SQLdouble( wrpt.Partial_Clmnt_Percent_Contrib ) );
      SQL.Add( SQLcurrency( wrpt.Partial_Clmnt_Contrib ) );
      SQL.Add( SQLcurrency( wrpt.Partial_80_Net_Contrib ) );
      SQL.Add( SQLdouble( wrpt.Partial_WCB_Percent_Contrib ) );
      SQL.Add( SQLcurrency( wrpt.Partial_WCB_Contrib ) );
      SQL.Add( SQLcurrency( wrpt.Partial_80_Daily_Comp_Rate ) );
      SQL.Add( SQLstring( wrpt.Apprentice ) );
      SQL.Add( SQLstring( wrpt.Deemed ) );
      SQL.Add( SQLstring( wrpt.AverageEarningsBasedOn ) );
      if WagelossBenefitCalcForm.isClaimEmerge(wrpt.Claim_No) then
         s := SQLstring('E')
      else
         s := SQLString('');
      SQL.add(s);
      //new fields for leg. review
      SQL.Add( SQLcurrency( wrpt.weekly_min_wage ) );
      SQL.Add( SQLcurrency( wrpt.weekly_shelter_benefit ) );
      SQL.Add( SQLstring( wrpt.MinimumWageIndicator ) );
      SQL.Add( SQLstring( wrpt.coll_ben_type ) );
      SQL.Add( SQLcurrency( wrpt.weekly_shelter_benefit_90 ) );
      SQL.Add( SQLcurrency( wrpt.annual_net_a ) );
      SQL.Add( SQLcurrency( wrpt.net_coll_ben ) );
      SQL.Add( SQLCurrency( wrpt.Wkly_Sal ) );
      SQL.Add( SQLcurrency( wrpt.weekly_min_wage_net ) );
      SQL.Add( SQLstring( wrpt.MinimumWageIndicatorPartial) );
      SQL.Add( SQLString( wrpt.DeathBenefit ));
      SQL.Add( SQLstring( wrpt.NonTaxCollBenefits ) );
      SQL.Add(SQLstring( wrpt.effectiveDate ));
      //t := SQLstring( wrpt.effectiveDate );
      //t:=copy(t,1,length(t)-1);
      //SQL.Add( t );
      t := SQLstring( wrpt.ClaimSpouseForTaxPurposes );
      t:=copy(t,1,length(t)-1);
      SQL.Add(t);
      SQL.add(')');
      execSQL;
    end;
  except
    on E:Exception do
      begin
      MessageDlg('Report File Creation Failed.  Please notify help desk at 4573.', mtError, [mbOK], 0 );
      bReturn := false;
      end;
  end;
  Result := bReturn;
end;

(******************************************************************************)
(*                                                                            *)
(*  Convert a double to SQL friendly format                                  *)
(*                                                                            *)
(******************************************************************************)
function SQLDouble( dd:double ): shortstring;
begin
  result := format('%.3g', [ dd ] ) + ',';
end;

procedure TriggerReport;
var
  ep:TEventPublisher;
  strString:String;
  paramList: TStringList;
begin
  paramList := TStringList.Create;
  strString := 'ReportId=' + wrpt.ReportId;
  paramList.Add(strString);
  strString := 'Reporting_User=' + wrpt.Reporting_User;
  paramList.Add(strString);
  strString := 'Report_Time=' + wrpt.Report_Time;
  paramList.Add(strString);
  strString := 'Report_Date=' + wrpt.Report_Date;
  paramList.Add(strString);
  try
    ep := TEventPublisher.create(dm1.dbSharedLookup, dm1.dbEmerge, HTTPHOST, 'WAGELOSS', userProfile.loginName, '');
    ep.publishFileDocumentEvent(MQMANAGERNAME, 'WageLossCalcReport', uTriggerEvent.METHOD_OTHER, wrpt.Claim_No, utilmod1.getEmergeBusinessDate(), paramList);
	except
    on e:Exception do
    begin
		  showAppMessage(e.Message, 2);
    end;
	end;
  paramList.Free;

end;

function GetNextQATestID(nYear: Integer): Integer;
var
  SQLText : String;
begin
  SQLText := Format('select max(QATestID) from QAData where left(QATestID,4) = %d',[nYear]);
  Result  := nYear * 100000 + 1;
  try
    with dm1.Query1 do
    begin
      if Active then Close;
      SQL.Clear;
      SQL.Add(SQLText);
      Open;
      if Fields[0].AsInteger > 0 then
         Result := Fields[0].AsInteger + 1;
      Close;
    end;
  except
    Raise Exception.CreateFmt('Unable to new ID value for year %d',[nYear]);
  end;
end;


function NewQADataRecord(cDescript : String; nClaimYear : Integer; var nextQATestID : Integer ): boolean;
var
  s : String;
  nQATestID, nQADataID : Integer;
  WagelossCalcForm: TWagelossBenefitCalcForm;
begin
  WagelossCalcForm :=  Application.FindComponent('WagelossBenefitCalcForm') as TWagelossBenefitCalcForm;
  Result := False;
  try
    //
    // First determine the new QADataID field value.
    //

//    dm1.qryMaxQADataID.Close;
//    dm1.qryMaxQADataID.Open;
//    if not dm1.qryMaxQADataID.Eof then
//       begin
//       nQADataID := dm1.qryMaxQADataID.FieldByName('NextQADataID').Value;
//       end
//    else
//       begin
//       nQADataID := 1;
//       end;
//    dm1.qryMaxQADataID.Close;

    //
    // Now perform the insert
    //

    with dm1.qWageLossReport do
    begin
      close;
      SQL.Clear;
      SQL.add('INSERT INTO QAData ');

      SQL.Add('( ');
      //SQL.Add('QADataID, ');
      SQL.Add('QADataDescription, ');
      SQL.Add('Claim_Year, ');
      SQL.Add('Claim_No, ');
      SQL.Add('Claim_Suffix, ');
      SQL.Add('Clmt_Name, ');
      SQL.Add('Clmt_Address_1, ');
      SQL.Add('Clmt_Address_2, ');
      SQL.Add('Clmt_Address_3, ');
      SQL.Add('Clmt_Postal_Code, ');
      SQL.Add('Clmt_SIN, ');
      SQL.Add('Clmt_DOB, ');
      SQL.Add('Clmt_Home_Phone, ');
      SQL.Add('Clmt_Work_Phone, ');
      SQL.Add('Accident_Date, ');
      SQL.Add('Weekly_Wage, ');
      SQL.Add('Tax_Year, ');
      SQL.Add('Indexed_Year, ');
      SQL.Add('Indexed_Date, ');
      SQL.Add('Recurence, ');
      SQL.Add('Recurrence_Date, ');
      SQL.Add('Days_Week, ');
      SQL.Add('Loss_Of_Earnings_Date, ');
      SQL.Add('Youthful_Worker, ');
      SQL.Add('Self_Employed, ');
      SQL.Add('Marital_Status, ');
      SQL.Add('Spouse_Working, ');
      SQL.Add('ClaimSpouseForTaxPurposes, ');
      SQL.Add('Nbr_Of_Dependants, ');
      SQL.Add('Nbr_Of_Infirm_Deps, ');
      SQL.Add('Uic_Exempt, ');
      SQL.Add('CPP_Exempt, ');
      SQL.Add('Income_Tax_Exempt, ');
      SQL.Add('Child_Care_Expense, ');
      SQL.Add('Spousal_Support, ');
      SQL.Add('Child_Support, ');
      SQL.Add('Inc_Tax_Fed, ');
      SQL.Add('Inc_Tax_Prov, ');
      SQL.Add('Cpp_Prem, ');
      SQL.Add('Cpp2_Prem, ');
      SQL.Add('Uic_Prem, ');
      SQL.Add('Total_Deds, ');
      SQL.Add('Weekly_Deds, ');
      SQL.Add('Collateral_Taxable, ');
      SQL.Add('Collateral_Taxable_Net, ');
      SQL.Add('Collateral_Non_Taxable, ');
      SQL.Add('Post_Earn_Weekly_Gross, ');
      SQL.Add('Post_Earn_Weekly_Net, ');
      SQL.Add('[80_Effective_Date], ');
      SQL.Add('Clmnt_Contrib_Effective_Date, ');
      SQL.Add('Full_Weekly_Gross, ');
      SQL.Add('Full_Annual_Gross, ');
      SQL.Add('Full_Weekly_Net_Loss_Earn, ');
      SQL.Add('Full_Annual_Net_Loss_Earn, ');
      SQL.Add('Full_Weekly_90_Net_Actual, ');
      SQL.Add('Full_Weekly_90_Net_Loss, ');
      SQL.Add('Full_Annual_90_Net_Loss, ');
      SQL.Add('Full_Weekly_Tax_Sheltering, ');
      SQL.Add('Full_Weekly_90_Net_Sheltered, ');
      SQL.Add('Full_Annual_90_Net_Sheltered, ');
      SQL.Add('Full_Weekly_Daily_Comp_Rate, ');
      SQL.Add('Full_Weekly_80_Net_Loss, ');
      SQL.Add('Full_Annual_80_Net_Loss, ');
      SQL.Add('Full_Weekly_80_Net_Sheltered, ');
      SQL.Add('Full_Annual_80_Net_Sheltered, ');
      SQL.Add('Full_Clmnt_Percent_Contrib, ');
      SQL.Add('Full_Clmnt_Contrib, ');
      SQL.Add('Full_Weekly_80_Clmnt_Net_Contrib, ');
      SQL.Add('Full_Annual_80_Clmnt_Net_Contrib, ');
      SQL.Add('Full_WCB_Percent_Contrib, ');
      SQL.Add('Full_WCB_Contrib, ');
      SQL.Add('Full_Weekly_Adjusted_Daily_Comp_Rate, ');
      SQL.Add('Partial_Net_Pre_Injury, ');
      SQL.Add('Partial_Net_Post_Injury, ');
      SQL.Add('Partial_Net_Loss_Earn, ');
      SQL.Add('Partial_90_Net_Loss_Earn, ');
      SQL.Add('Partial_Tax_Sheltering, ');
      SQL.Add('Partial_90_Net_Sheltered, ');
      SQL.Add('Partial_Daily_Comp_Rate, ');
      SQL.Add('Partial_80_Net_Loss, ');
      SQL.Add('Partial_80_Net_Sheltered, ');
      SQL.Add('Partial_Clmnt_Percent_Contrib, ');
      SQL.Add('Partial_Clmnt_Contrib, ');
      SQL.Add('Partial_80_Net_Contrib, ');
      SQL.Add('Partial_WCB_Percent_Contrib, ');
      SQL.Add('Partial_WCB_Contrib, ');
      SQL.Add('Partial_80_Daily_Comp_Rate, ');
      SQL.Add('Apprentice, ');
      SQL.Add('Deemed, ');
      SQL.Add('AvgEarningsBasedOn, ');
      SQL.Add('EmergeIndicator, ');
      SQL.Add('weekly_min_wage, ');
      SQL.Add('weekly_shelter_benefit, ');
      SQL.Add('min_wage_indicator, ');
      SQL.Add('coll_ben_type, ');
      SQL.Add('weekly_shelter_ben_90, ');
      SQL.Add('annual_net_a, ');
      SQL.Add('net_coll_ben, ');
      SQL.Add('Weekly_Sal, ');
      SQL.Add('weekly_min_wage_net, ');
      SQL.Add('min_wage_ind_partial, ');
      SQL.Add('DeathBenefit, ');
      SQL.Add('NonTaxable_Coll_Ben_Type, ');
      SQL.Add('effectiveDate, ');
      SQL.Add('QATestID, ');
      SQL.Add('QATestIndexID, ');
      SQL.Add('creationDatetime, ');
      SQL.Add('creationLoginName, ');
      SQL.Add('modificationDatetime, ');
      SQL.Add('modificationLoginName ');

      SQL.Add(') ');


      SQL.add('VALUES(');

      //SQL.Add( SQLInteger(nQADataID));
      SQL.Add( SQLstring( cDescript ) );
      SQL.Add( SQLinteger( nClaimYear ) );

      SQL.Add( SQLstring( wrpt.Claim_No ) );
      SQL.Add( SQLstring( wrpt.Claim_Suffix ) );
      SQL.Add( SQLstring( wrpt.Clmt_Name ) );
      SQL.Add( SQLstring( wrpt.Clmt_Address_1 ) );
      SQL.Add( SQLstring( wrpt.Clmt_Address_2 ) );
      SQL.Add( SQLstring( wrpt.Clmt_Address_3 ) );
      SQL.Add( SQLstring( wrpt.Clmt_Postal_Code ) );
      SQL.Add( SQLstring( wrpt.Clmt_SIN ) );
      SQL.Add( SQLstring( wrpt.Clmt_DOB ) );
      SQL.Add( SQLstring( wrpt.Clmt_Home_Phone ) );
      SQL.Add( SQLstring( wrpt.Clmt_Work_Phone ) );
      SQL.Add( SQLstring( wrpt.Accident_Date ) );
      SQL.Add( SQLcurrency( wrpt.Weekly_Wage ) );
      SQL.Add( SQLinteger( wrpt.Tax_Year ) );
      SQL.Add( SQLinteger( wrpt.Indexed_Year ) );
      SQL.Add( SQLstring( wrpt.Indexed_Date ) );
      SQL.Add( SQLstring( wrpt.Recurence ) );
      SQL.Add( SQLstring( wrpt.Recurrence_Date ) );
      SQL.Add( SQLdouble ( wrpt.Days_Week ) );
      SQL.Add( SQLstring( wrpt.Loss_Of_Earnings_Date ) );
      SQL.Add( SQLstring( wrpt.Youthful_Worker ) );
      SQL.Add( SQLstring( wrpt.Self_Employed ) );
      SQL.Add( SQLstring( wrpt.Marital_Status ) );
      SQL.Add( SQLstring( wrpt.Spouse_Working ) );
      SQL.Add( SQLString( wrpt.ClaimSpouseForTaxPurposes ));
      SQL.Add( SQLinteger( wrpt.Nbr_Of_Dependants ) );
      SQL.Add( SQLinteger( wrpt.Nbr_Of_Infirm_Deps ) );
      SQL.Add( SQLstring( wrpt.Uic_Exempt ) );
      SQL.Add( SQLstring( wrpt.CPP_Exempt ) );
      SQL.Add( SQLstring( wrpt.Income_Tax_Exempt ) );
      SQL.Add( SQLcurrency( wrpt.Child_Care_Expense ) );
      SQL.Add( SQLcurrency( wrpt.Spousal_Support ) );
      SQL.Add( SQLcurrency( wrpt.Child_Support ) );
      SQL.Add( SQLcurrency( wrpt.Inc_Tax_Fed ) );
      SQL.Add( SQLcurrency( wrpt.Inc_Tax_Prov ) );
      SQL.Add( SQLcurrency( wrpt.Cpp_Prem ) );
      SQL.Add( SQLcurrency( wrpt.Cpp2_Prem ) );
      SQL.Add( SQLcurrency( wrpt.Uic_Prem ) );
      SQL.Add( SQLcurrency( wrpt.Total_Deds ) );
      SQL.Add( SQLcurrency( wrpt.Weekly_Deds ) );
      SQL.Add( SQLcurrency( wrpt.Collateral_Taxable ) );
      SQL.Add( SQLcurrency( wrpt.Collateral_Taxable_Net ) );
      SQL.Add( SQLcurrency( wrpt.Collateral_Non_Taxable ) );
      SQL.Add( SQLcurrency( wrpt.Post_Earn_Weekly_Gross ) );
      SQL.Add( SQLcurrency( wrpt.Post_Earn_Weekly_Net ) );
      SQL.Add( SQLstring( wrpt.Effective_Date_80 ) );
      SQL.Add( SQLstring( wrpt.Clmnt_Contrib_Effective_Date ) );

{
      SQL.Add( 'Full_Weekly_Gross = ' + SQLcurrency( safeFloat( WagelossCalcForm.lblWkly_Sal_A.Caption ) ) );
      SQL.Add( 'Full_Weekly_Net_Loss_Earn = ' + SQLcurrency( safeFloat( WagelossCalcForm.lblWeekly_Net.Caption ) ) );
      SQL.Add( 'Full_Weekly_90_Net_Actual = ' + SQLcurrency( safeFloat( WagelossCalcForm.lbCalc90p_Wkly_Net_A.Caption ) ) );

      SQL.Add( 'Full_Annual_Gross = ' + SQLcurrency( safeFloat( WagelossCalcForm.lblAnnual_Gross.Caption ) ) );
      SQL.Add( 'Full_Annual_Net_Loss_Earn = ' + SQLcurrency( safeFloat( WagelossCalcForm.lblAnnual_Net.Caption ) ) );
}

      //SQL.Add( SQLcurrency( wrpt.Full_Weekly_Gross ) );
      //SQL.Add( SQLcurrency( wrpt.Full_Annual_Gross ) );
      //SQL.Add( SQLcurrency( wrpt.Full_Weekly_Net_Loss_Earn ) );
      //SQL.Add( SQLcurrency( wrpt.Full_Annual_Net_Loss_Earn ) );
      //SQL.Add( SQLcurrency( wrpt.Full_Weekly_90_Net_Actual ) );

      SQL.Add( SQLcurrency( safeFloat( WagelossCalcForm.lblWkly_Sal_A.Caption ) ) );
      SQL.Add( SQLcurrency( safeFloat( WagelossCalcForm.lblAnnual_Gross.Caption ) ) );
      SQL.Add( SQLcurrency( safeFloat( WagelossCalcForm.lblWeekly_Net.Caption ) ) );
      SQL.Add( SQLcurrency( safeFloat( WagelossCalcForm.lblAnnual_Net.Caption ) ) );
      SQL.Add( SQLcurrency( safeFloat( WagelossCalcForm.lbCalc90p_Wkly_Net_A.Caption ) ) );

      SQL.Add( SQLcurrency( wrpt.Full_Weekly_90_Net_Loss ) );
      SQL.Add( SQLcurrency( wrpt.Full_Annual_90_Net_Loss ) );
      SQL.Add( SQLcurrency( wrpt.Full_Weekly_Tax_Sheltering ) );
      SQL.Add( SQLcurrency( wrpt.Full_Weekly_90_Net_Sheltered ) );
      SQL.Add( SQLcurrency( wrpt.Full_Annual_90_Net_Sheltered ) );
      SQL.Add( SQLcurrency( wrpt.Full_Weekly_Daily_Comp_Rate ) );
      SQL.Add( SQLcurrency( wrpt.Full_Weekly_80_Net_Loss ) );
      SQL.Add( SQLcurrency( wrpt.Full_Annual_80_Net_Loss ) );
      SQL.Add( SQLcurrency( wrpt.Full_Weekly_80_Net_Sheltered ) );
      SQL.Add( SQLcurrency( wrpt.Full_Annual_80_Net_Sheltered ) );
      SQL.Add( SQLdouble( wrpt.Full_Clmnt_Percent_Contrib ) );
      SQL.Add( SQLcurrency( wrpt.Full_Clmnt_Contrib ) );
      SQL.Add( SQLcurrency( wrpt.Full_Weekly_80_Clmnt_Net_Contrib ) );
      SQL.Add( SQLcurrency( wrpt.Full_Annual_80_Clmnt_Net_Contrib ) );
      SQL.Add( SQLdouble( wrpt.Full_WCB_Percent_Contrib ) );
      SQL.Add( SQLcurrency( wrpt.Full_WCB_Contrib ) );
      SQL.Add( SQLcurrency( wrpt.Full_Weekly_Adjusted_Daily_Comp_Rate ) );
      SQL.Add( SQLcurrency( wrpt.Partial_Net_Pre_Injury ) );
      SQL.Add( SQLcurrency( wrpt.Partial_Net_Post_Injury ) );
      SQL.Add( SQLcurrency( wrpt.Partial_Net_Loss_Earn ) );
      SQL.Add( SQLcurrency( wrpt.Partial_90_Net_Loss_Earn ) );
      SQL.Add( SQLcurrency( wrpt.Partial_Tax_Sheltering ) );
      SQL.Add( SQLcurrency( wrpt.Partial_90_Net_Sheltered ) );
      SQL.Add( SQLcurrency( wrpt.Partial_Daily_Comp_Rate ) );
      SQL.Add( SQLcurrency( wrpt.Partial_80_Net_Loss ) );
      SQL.Add( SQLcurrency( wrpt.Partial_80_Net_Sheltered ) );
      SQL.Add( SQLdouble( wrpt.Partial_Clmnt_Percent_Contrib ) );
      SQL.Add( SQLcurrency( wrpt.Partial_Clmnt_Contrib ) );
      SQL.Add( SQLcurrency( wrpt.Partial_80_Net_Contrib ) );
      SQL.Add( SQLdouble( wrpt.Partial_WCB_Percent_Contrib ) );
      SQL.Add( SQLcurrency( wrpt.Partial_WCB_Contrib ) );
      SQL.Add( SQLcurrency( wrpt.Partial_80_Daily_Comp_Rate ) );
      SQL.Add( SQLstring( wrpt.Apprentice ) );
      SQL.Add( SQLstring( wrpt.Deemed ) );
      SQL.Add( SQLstring( wrpt.AverageEarningsBasedOn ) );

      //if WagelossBenefitCalcForm.isClaimEmerge(wrpt.Claim_No) then
      //   s := SQLstring('E')
      //else
         s := SQLString('');

      SQL.add(s);
      //new fields for leg. review
      SQL.Add( SQLcurrency( wrpt.weekly_min_wage ) );
      SQL.Add( SQLcurrency( wrpt.weekly_shelter_benefit ) );
      SQL.Add( SQLstring( wrpt.MinimumWageIndicator ) );
      SQL.Add( SQLstring( wrpt.coll_ben_type ) );
      SQL.Add( SQLcurrency( wrpt.weekly_shelter_benefit_90 ) );
      SQL.Add( SQLcurrency( wrpt.annual_net_a ) );
      SQL.Add( SQLcurrency( wrpt.net_coll_ben ) );
      SQL.Add( SQLCurrency( wrpt.Wkly_Sal ) );
      SQL.Add( SQLcurrency( wrpt.weekly_min_wage_net ) );
      SQL.Add( SQLstring( wrpt.MinimumWageIndicatorPartial) );
      SQL.Add( SQLString( wrpt.DeathBenefit ));
      SQL.Add( SQLstring( wrpt.NonTaxCollBenefits ) );
      SQL.Add( SQLstring( wrpt.effectiveDate ) );
      if nextQATestID > 0 then
         nQATestID := nextQATestID
      else
         nQATestID := GetNextQATestID(StrToInt( RightStr(Trim(wrpt.Accident_Date),4))) ;
      SQL.Add( SQLinteger( nQATestID ) );

      nextQATestID := nQATestID;

      SQL.Add( SQLinteger( wrpt.Indexed_Year ) );    //  QATestIndexID
      SQL.Add( SQLString( FormatDateTime( 'yyyy/mm/dd HH:mm:ss', Now() ) ) ); //creationDatetime
      SQL.Add( SQLString( UserProfile.loginName ) ); //creationLoginName
      SQL.Add('NULL, NULL)');
      execSQL;
      Result := True;
    end;
  except
    on E:Exception do
    begin
      MessageDlg('QAData record create / update failed.'+#13#10+E.Message, mtError, [mbOK], 0 );
    end;
  end;
end;


function UpdateQADataRecord(cDescript : String; nClaimYear, intQADataID, intQATestID, intQATestIndexID : Integer  ): boolean;
var
  s, t : String;
  nQATestID : Integer;
  WagelossCalcForm: TWagelossBenefitCalcForm;
begin
  WagelossCalcForm :=  Application.FindComponent('WagelossBenefitCalcForm') as TWagelossBenefitCalcForm;
  Result := False;
  try
    with dm1.qWageLossReport do
    begin
      close;
      SQL.Clear;
      SQL.add('UPDATE QAData SET ');
      SQL.Add( 'QADataDescription = ' +SQLstring( cDescript ) );
      SQL.Add( 'Claim_Year = ' + SQLinteger( nClaimYear ) );

      SQL.Add( 'Claim_No = ' + SQLstring( wrpt.Claim_No ) );
      SQL.Add( 'Claim_Suffix = ' + SQLstring( wrpt.Claim_Suffix ) );
      SQL.Add( 'Clmt_Name = ' + SQLstring( wrpt.Clmt_Name ) );
      SQL.Add( 'Clmt_Address_1 = ' + SQLstring( wrpt.Clmt_Address_1 ) );
      SQL.Add( 'Clmt_Address_2 = ' + SQLstring( wrpt.Clmt_Address_2 ) );
      SQL.Add( 'Clmt_Address_3 = ' + SQLstring( wrpt.Clmt_Address_3 ) );
      SQL.Add( 'Clmt_Postal_Code = ' + SQLstring( wrpt.Clmt_Postal_Code ) );
      SQL.Add( 'Clmt_SIN = ' + SQLstring( wrpt.Clmt_SIN ) );
      SQL.Add( 'Clmt_DOB = ' + SQLstring( wrpt.Clmt_DOB ) );
      SQL.Add( 'Clmt_Home_Phone = ' + SQLstring( wrpt.Clmt_Home_Phone ) );
      SQL.Add( 'Clmt_Work_Phone = ' + SQLstring( wrpt.Clmt_Work_Phone ) );
      SQL.Add( 'Accident_Date = ' + SQLstring( wrpt.Accident_Date ) );
      SQL.Add( 'Weekly_Wage = ' + SQLcurrency( wrpt.Weekly_Wage ) );
      SQL.Add( 'Tax_Year = ' + SQLinteger(wrpt.Tax_Year) );

      //      SQL.Add( 'Indexed_Year = ' + SQLinteger( wrpt.Indexed_Year ) );
      SQL.Add( 'Indexed_Year = ' + SQLinteger( intQATestIndexID ) );


      SQL.Add( 'Indexed_Date = ' + SQLstring( wrpt.Indexed_Date ) );
      SQL.Add( 'Recurence = ' + SQLstring( wrpt.Recurence ) );
      SQL.Add( 'Recurrence_Date = ' + SQLstring( wrpt.Recurrence_Date ) );
      SQL.Add( 'Days_Week = '+ SQLdouble ( wrpt.Days_Week ) );
      SQL.Add( 'Loss_Of_Earnings_Date = ' + SQLstring( wrpt.Loss_Of_Earnings_Date ) );
      SQL.Add( 'Youthful_Worker = ' + SQLstring( wrpt.Youthful_Worker ) );
      SQL.Add( 'Self_Employed = ' + SQLstring( wrpt.Self_Employed ) );
      SQL.Add( 'Marital_Status = ' + SQLstring( wrpt.Marital_Status ) );
      SQL.Add( 'Spouse_Working = ' + SQLstring( wrpt.Spouse_Working ) );
      SQL.Add( 'ClaimSpouseForTaxPurposes = ' + SQLString(wrpt.ClaimSpouseForTaxPurposes));
      SQL.Add( 'Nbr_Of_Dependants = '+ SQLinteger( wrpt.Nbr_Of_Dependants ) );
      SQL.Add( 'Nbr_Of_Infirm_Deps = ' + SQLinteger( wrpt.Nbr_Of_Infirm_Deps ) );
      SQL.Add( 'Uic_Exempt = ' + SQLstring( wrpt.Uic_Exempt ) );
      SQL.Add( 'CPP_Exempt = ' + SQLstring( wrpt.CPP_Exempt ) );
      SQL.Add( 'Income_Tax_Exempt = ' + SQLstring( wrpt.Income_Tax_Exempt ) );
      SQL.Add( 'Child_Care_Expense = ' + SQLcurrency( wrpt.Child_Care_Expense ) );
      SQL.Add( 'Spousal_Support = ' + SQLcurrency( wrpt.Spousal_Support ) );
      SQL.Add( 'Child_Support = ' + SQLcurrency( wrpt.Child_Support ) );
      SQL.Add( 'Inc_Tax_Fed = ' + SQLcurrency( wrpt.Inc_Tax_Fed ) );
      SQL.Add( 'Inc_Tax_Prov = ' + SQLcurrency( wrpt.Inc_Tax_Prov ) );
      SQL.Add( 'Cpp_Prem = ' + SQLcurrency( wrpt.Cpp_Prem ) );
      SQL.Add( 'Cpp2_Prem = ' + SQLcurrency( wrpt.Cpp2_Prem ) );
      SQL.Add( 'Uic_Prem = ' + SQLcurrency( wrpt.Uic_Prem ) );
      SQL.Add( 'Total_Deds = ' + SQLcurrency( wrpt.Total_Deds ) );
      SQL.Add( 'Weekly_Deds = ' + SQLcurrency( wrpt.Weekly_Deds ) );
      SQL.Add( 'Collateral_Taxable = ' + SQLcurrency( wrpt.Collateral_Taxable ) );
      SQL.Add( 'Collateral_Taxable_Net = ' + SQLcurrency( wrpt.Collateral_Taxable_Net ) );
      SQL.Add( 'Collateral_Non_Taxable = ' + SQLcurrency( wrpt.Collateral_Non_Taxable ) );
      SQL.Add( 'Post_Earn_Weekly_Gross = ' + SQLcurrency( wrpt.Post_Earn_Weekly_Gross ) );
      SQL.Add( 'Post_Earn_Weekly_Net = ' + SQLcurrency( wrpt.Post_Earn_Weekly_Net ) );

      SQL.Add( '[80_Effective_Date] = ' + SQLstring( wrpt.Effective_Date_80 ) );
      SQL.Add( 'Clmnt_Contrib_Effective_Date = ' + SQLstring( wrpt.Clmnt_Contrib_Effective_Date ) );

      //SQL.Add( 'Full_Weekly_Gross = ' + SQLcurrency( wrpt.Full_Weekly_Gross ) );
      //SQL.Add( 'Full_Annual_Gross = ' + SQLcurrency( wrpt.Full_Annual_Gross ) );
      //SQL.Add( 'Full_Weekly_Net_Loss_Earn = ' + SQLcurrency( wrpt.Full_Weekly_Net_Loss_Earn ) );
      //SQL.Add( 'Full_Weekly_90_Net_Actual = ' + SQLcurrency( wrpt.Full_Weekly_90_Net_Actual ) );
      SQL.Add( 'Full_Weekly_Gross = ' + SQLcurrency( safeFloat( WagelossCalcForm.lblWkly_Sal_A.Caption ) ) );
      SQL.Add( 'Full_Weekly_Net_Loss_Earn = ' + SQLcurrency( safeFloat( WagelossCalcForm.lblWeekly_Net.Caption ) ) );
      SQL.Add( 'Full_Weekly_90_Net_Actual = ' + SQLcurrency( safeFloat( WagelossCalcForm.lbCalc90p_Wkly_Net_A.Caption ) ) );

      SQL.Add( 'Full_Annual_Gross = ' + SQLcurrency( safeFloat( WagelossCalcForm.lblAnnual_Gross.Caption ) ) );
      SQL.Add( 'Full_Annual_Net_Loss_Earn = ' + SQLcurrency( safeFloat( WagelossCalcForm.lblAnnual_Net.Caption ) ) );

      SQL.Add( 'Full_Weekly_90_Net_Loss = ' + SQLcurrency( wrpt.Full_Weekly_90_Net_Loss ) );
      SQL.Add( 'Full_Annual_90_Net_Loss = ' + SQLcurrency( wrpt.Full_Annual_90_Net_Loss ) );

      SQL.Add( 'Full_Weekly_Tax_Sheltering = ' + SQLcurrency( wrpt.Full_Weekly_Tax_Sheltering ) );
      SQL.Add( 'Full_Weekly_90_Net_Sheltered = ' + SQLcurrency( wrpt.Full_Weekly_90_Net_Sheltered ) );
      SQL.Add( 'Full_Annual_90_Net_Sheltered = ' + SQLcurrency( wrpt.Full_Annual_90_Net_Sheltered ) );
      SQL.Add( 'Full_Weekly_Daily_Comp_Rate = ' + SQLcurrency( wrpt.Full_Weekly_Daily_Comp_Rate ) );
      SQL.Add( 'Full_Weekly_80_Net_Loss = ' + SQLcurrency( wrpt.Full_Weekly_80_Net_Loss ) );
      SQL.Add( 'Full_Annual_80_Net_Loss = ' + SQLcurrency( wrpt.Full_Annual_80_Net_Loss ) );
      SQL.Add( 'Full_Weekly_80_Net_Sheltered = ' + SQLcurrency( wrpt.Full_Weekly_80_Net_Sheltered ) );
      SQL.Add( 'Full_Annual_80_Net_Sheltered = ' + SQLcurrency( wrpt.Full_Annual_80_Net_Sheltered ) );
      SQL.Add( 'Full_Clmnt_Percent_Contrib = ' + SQLcurrency( wrpt.Full_Clmnt_Percent_Contrib ) );
      SQL.Add( 'Full_Clmnt_Contrib = ' + SQLcurrency( wrpt.Full_Clmnt_Contrib ) );
      SQL.Add( 'Full_Weekly_80_Clmnt_Net_Contrib = ' + SQLcurrency( wrpt.Full_Weekly_80_Clmnt_Net_Contrib ) );
      SQL.Add( 'Full_Annual_80_Clmnt_Net_Contrib = ' + SQLcurrency( wrpt.Full_Annual_80_Clmnt_Net_Contrib ) );

      SQL.Add( 'Full_WCB_Percent_Contrib = ' + SQLdouble( wrpt.Full_WCB_Percent_Contrib ) );

      SQL.Add( 'Full_WCB_Contrib = ' + SQLcurrency( wrpt.Full_WCB_Contrib ) );
      SQL.Add( 'Full_Weekly_Adjusted_Daily_Comp_Rate = ' + SQLcurrency( wrpt.Full_Weekly_Adjusted_Daily_Comp_Rate ) );
      SQL.Add( 'Partial_Net_Pre_Injury = ' + SQLcurrency( wrpt.Partial_Net_Pre_Injury ) );
      SQL.Add( 'Partial_Net_Post_Injury = ' + SQLcurrency( wrpt.Partial_Net_Post_Injury ) );
      SQL.Add( 'Partial_Net_Loss_Earn = ' + SQLcurrency( wrpt.Partial_Net_Loss_Earn ) );
      SQL.Add( 'Partial_90_Net_Loss_Earn = ' + SQLcurrency( wrpt.Partial_90_Net_Loss_Earn ) );
      SQL.Add( 'Partial_Tax_Sheltering = ' + SQLcurrency( wrpt.Partial_Tax_Sheltering ) );
      SQL.Add( 'Partial_90_Net_Sheltered = ' + SQLcurrency( wrpt.Partial_90_Net_Sheltered ) );
      SQL.Add( 'Partial_Daily_Comp_Rate = ' + SQLcurrency( wrpt.Partial_Daily_Comp_Rate ) );
      SQL.Add( 'Partial_80_Net_Loss = ' + SQLcurrency( wrpt.Partial_80_Net_Loss ) );
      SQL.Add( 'Partial_80_Net_Sheltered = ' + SQLcurrency( wrpt.Partial_80_Net_Sheltered ) );

      SQL.Add( 'Partial_Clmnt_Percent_Contrib = ' + SQLdouble( wrpt.Partial_Clmnt_Percent_Contrib ) );

      SQL.Add( 'Partial_Clmnt_Contrib = ' + SQLcurrency( wrpt.Partial_Clmnt_Contrib ) );
      SQL.Add( 'Partial_80_Net_Contrib = ' + SQLcurrency( wrpt.Partial_80_Net_Contrib ) );

      SQL.Add( 'Partial_WCB_Percent_Contrib = ' + SQLdouble( wrpt.Partial_WCB_Percent_Contrib ) );

      SQL.Add( 'Partial_WCB_Contrib = ' + SQLcurrency( wrpt.Partial_WCB_Contrib ) );
      SQL.Add( 'Partial_80_Daily_Comp_Rate = ' + SQLcurrency( wrpt.Partial_80_Daily_Comp_Rate ) );

      SQL.Add( 'Apprentice = ' + SQLstring( wrpt.Apprentice ) );
      SQL.Add( 'Deemed = ' + SQLstring( wrpt.Deemed ) );
      SQL.Add( 'AvgEarningsBasedOn = ' + SQLstring( wrpt.AverageEarningsBasedOn ) );

      if WagelossBenefitCalcForm.isClaimEmerge(wrpt.Claim_No) then
         s := SQLstring('E')
      else
         s := SQLString('');


      SQL.Add( 'EmergeIndicator = ' + s );

      SQL.Add( 'weekly_min_wage = ' + SQLcurrency( wrpt.weekly_min_wage ) );
      SQL.Add( 'weekly_shelter_benefit = ' + SQLcurrency( wrpt.weekly_shelter_benefit ) );

      SQL.Add( 'min_wage_indicator = ' + SQLstring( wrpt.MinimumWageIndicator ) );
      SQL.Add( 'coll_ben_type = ' + SQLstring( wrpt.coll_ben_type ) );

      SQL.Add( 'weekly_shelter_ben_90 = ' + SQLcurrency( wrpt.weekly_shelter_benefit_90 ) );
      SQL.Add( 'annual_net_a = ' + SQLcurrency( wrpt.annual_net_a ) );
      SQL.Add( 'net_coll_ben = ' + SQLcurrency( wrpt.net_coll_ben ) );
      SQL.Add( 'Weekly_Sal = ' + SQLcurrency( wrpt.Wkly_Sal ) );
      SQL.Add( 'weekly_min_wage_net = ' + SQLcurrency( wrpt.weekly_min_wage_net ) );

      SQL.Add( 'min_wage_ind_partial = ' + SQLstring( wrpt.MinimumWageIndicatorPartial ) );
      SQL.Add( 'DeathBenefit = ' + SQLstring( wrpt.DeathBenefit ) );
      SQL.Add( 'NonTaxable_Coll_Ben_Type = ' + SQLstring( wrpt.NonTaxCollBenefits ) );
      SQL.Add( 'effectiveDate = ' + SQLstring( wrpt.effectiveDate ) );

      if intQATestID > 0 then
         nQATestID := intQATestID
      else
         nQATestID := GetNextQATestID(StrToInt( RightStr(Trim(wrpt.Accident_Date),4))) ;

      SQL.Add( 'QATestID = '+SQLinteger( nQATestID ) );
      SQL.Add( 'QATestIndexID = '+SQLinteger( intQATestIndexID ) );

      SQL.Add( 'modificationDatetime = ' + SQLString( FormatDateTime( 'yyyy/mm/dd HH:mm:ss', Now() ) ) ); //modificationDatetime
      t := SQLString( UserProfile.loginName ); //modificationLoginName
      t :=copy(t,1,length(t)-1);
      SQL.Add( 'modificationLoginName = '+ t );
      SQL.add(Format('WHERE QADataID = %d',[intQADataID]));
      execSQL;
      Result := True;
    end;
  except
    on E:Exception do
    begin
      MessageDlg('QAData record update failed.'+#13#10+E.Message, mtError, [mbOK], 0 );
    end;
  end;
end;

end.
