inherited WrkRptJul12: TWrkRptJul12
  Top = 167
  Caption = 'WrkRptJul12'
  PixelsPerInch = 96
  TextHeight = 13
end
