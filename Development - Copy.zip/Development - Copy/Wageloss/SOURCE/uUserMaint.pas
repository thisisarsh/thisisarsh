unit uUserMaint;

interface

uses
  Windows, Messages, SysUtils, Classes, Graphics, Controls, Forms, Dialogs,
  Grids, DBGrids, Db, StdCtrls, Buttons, ADODB; //DBTables,

type
  TfUserMaint = class(TForm)
    dsUserMaint: TDataSource;
    dbUserMaint: TDBGrid;
    bbtnClose: TBitBtn;
    btnDelete: TButton;
    btnAdd: TButton;
    btnRefresh: TButton;
    qryUserMaint: TADOQuery;
    qryUserMaintuser_login: TStringField;
    qryUserMaintlast_name: TStringField;
    qryUserMaintfirst_name: TStringField;
    qryUserMaintphone_no: TStringField;
    qryUserMaintposition: TStringField;
    procedure FormCreate(Sender: TObject);
    procedure btnAddClick(Sender: TObject);
    procedure btnDeleteClick(Sender: TObject);
    procedure btnRefreshClick(Sender: TObject);
    procedure FormDestroy(Sender: TObject);
    Procedure CommitTheUpdate();
    procedure FormClose(Sender: TObject; var Action: TCloseAction);
  private
    { Private declarations }
  public
    { Public declarations }
  end;

var
  fUserMaint: TfUserMaint;

implementation

uses NCDatMod, Utils;

{$R *.DFM}

procedure TfUserMaint.FormCreate(Sender: TObject);
begin
   qryUserMaint.open;
   SetFont(Self);
end;

procedure TfUserMaint.btnAddClick(Sender: TObject);
begin
	qryUserMaint.Insert;
end;


procedure TfUserMaint.btnDeleteClick(Sender: TObject);
begin
	qryUserMaint.Delete;
  CommitTheUpdate;
end;

procedure TfUserMaint.btnRefreshClick(Sender: TObject);
begin
	CommitTheUpdate;
  qryUserMaint.Requery;
end;

procedure TfUserMaint.FormDestroy(Sender: TObject);
begin
	CommitTheUpdate;
	qryUserMaint.close;
end;

procedure TfUserMaint.CommitTheUpdate;
begin
  if ((qryUserMaint.State = dsInsert)  OR
      (qryUserMaint.State = dsEdit))    Then
     begin
	   try
        qryUserMaint.Post;
     except
        ShowMessage('A duplicate login ID was entered. Please try again.');
        qryUserMaint.Cancel;
     end;
     end;
end;

procedure TfUserMaint.FormClose(Sender: TObject; var Action: TCloseAction);
begin
	CommitTheUpdate;
end;

end.
