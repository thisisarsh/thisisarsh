object WrkRptJul08: TWrkRptJul08
  Left = 285
  Top = 106
  Caption = 'WrkRptJul08'
  ClientHeight = 617
  ClientWidth = 1126
  Color = clBtnFace
  Font.Charset = DEFAULT_CHARSET
  Font.Color = clWindowText
  Font.Height = -11
  Font.Name = 'MS Sans Serif'
  Font.Style = []
  OldCreateOrder = False
  PixelsPerInch = 96
  TextHeight = 13
end
