unit NCWrkRptJan18;

interface

uses
  Windows, Messages, SysUtils, Variants, Classes, Graphics, Controls, Forms,
  Dialogs, NCWrkRptJul17;

type
  TWrkRptJan18 = class(TWrkRptJul17)
  function getDateHeading():String; Override;
  private
    { Private declarations }
  public
    { Public declarations }
  end;

var
  WrkRptJan18: TWrkRptJan18;

implementation

{$R *.dfm}

function TWrkRptJan18.getDateHeading: String;
begin
  result:='2017/2018'
end;


end.
