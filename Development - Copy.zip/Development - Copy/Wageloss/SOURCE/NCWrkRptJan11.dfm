inherited WrkRptJan11: TWrkRptJan11
  Caption = 'WrkRptJan11'
  PixelsPerInch = 96
  TextHeight = 13
end
