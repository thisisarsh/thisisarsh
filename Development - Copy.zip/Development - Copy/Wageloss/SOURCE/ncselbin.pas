(*****************************************************************)
(*  Wageloss System                                              *)
(*                                                               *)
(*  Quick Reports Default Printer Form                           *)
(*                                                               *)
(*                                                               *)
(*  Author: Brad Trupp  / Capella Systems Group, Inc.            *)
(*  Date:   Nov. 1997                                            *)
(*****************************************************************)

unit ncselbin;

interface

uses
  Windows, Messages, SysUtils, Classes, Graphics, Controls, Forms, Dialogs,
  StdCtrls, qrprntr, quickrpt;

type
  TPrintOverridePrintForm = class(TForm)
    cbBin: TComboBox;
    Label1: TLabel;
    Label3: TLabel;
    btnOK: TButton;
    btnCancel: TButton;
    cbPrinter: TComboBox;
    btnReset: TButton;
    procedure FormCreate(Sender: TObject);
    procedure cbBinChange(Sender: TObject);
    procedure btnResetClick(Sender: TObject);
    procedure btnOKClick(Sender: TObject);
    procedure btnCancelClick(Sender: TObject);
  private
    { Private declarations }
    fBinSelected: integer;
    fQuickRep: TQuickRep;
    function getFBinSelected: integer;
    procedure setFBinSelected( i: integer );
  public
    { Public declarations }
    constructor CreateExtended(aQuickRep: TQuickRep; AOwner: TComponent); virtual;
    property ParentQuickReport:TQuickRep read fQuickRep write fQuickRep;
    property BinSelected: integer read getFBinSelected write setFBinSelected;
  end;

var
  PrintOverridePrintForm: TPrintOverridePrintForm;

implementation

{$R *.DFM}

uses NCIniMod, TypInfo;

(******************************************************************************)
(*                                                                            *)
(*  Create constructor function                                               *)
(*                                                                            *)
(******************************************************************************)
constructor TPrintOverridePrintForm.CreateExtended(aQuickRep: TQuickRep; AOwner: TComponent);
begin
  fQuickRep:=aQuickRep;
  // call inherited create which calls Form Create
  inherited create(AOwner);
end;

(******************************************************************************)
(*                                                                            *)
(*                                                                            *)
(*                                                                            *)
(******************************************************************************)
function TPrintOverridePrintForm.getFBinSelected: integer;
begin
  result:=fBinSelected;
end;

(******************************************************************************)
(*                                                                            *)
(*                                                                            *)
(*                                                                            *)
(******************************************************************************)
procedure TPrintOverridePrintForm.setFBinSelected( i: integer );
begin
  fBinSelected:=i;
  cbBin.itemIndex:=fBinSelected + 1;
end;

(******************************************************************************)
(*                                                                            *)
(*                                                                            *)
(*                                                                            *)
(******************************************************************************)
procedure TPrintOverridePrintForm.FormCreate(Sender: TObject);
var
  iii: integer;
  i_Auto:Integer;
begin
	i_Auto := 0;
  cbPrinter.items.add('Use Windows Default');
  try
  for iii:= 0 to fQuickRep.qrprinter.printers.count -1  do
    cbPrinter.items.add(
      fQuickRep.qrprinter.printers[iii]
      );
  finally
  cbPrinter.itemIndex:=0;
  end;

  cbBin.items.add('None');
  for iii:= ord(low(TQRBin)) to ord(high(TQRBin)) do
  begin
    cbBin.items.add( GetEnumName(TypeInfo(TQRBin), iii ) );
    if (UpperCase(GetEnumName(TypeInfo(TQRBin), iii )) = 'AUTO') then
    begin
		  i_Auto:=iii+1;		//Auto
    end;
	end;
  try
  cbPrinter.itemIndex:= NCIniMod.QRPrinterDefault + 1;
	if NCIniMod.QRBinDefault >= 0 then
		cbBin.itemIndex:= NCIniMod.QRBinDefault+1
	else
    cbBin.itemIndex:=i_Auto;
  finally
  ;
  end;

end;

(******************************************************************************)
(*                                                                            *)
(*                                                                            *)
(*                                                                            *)
(******************************************************************************)
procedure TPrintOverridePrintForm.cbBinChange(Sender: TObject);
begin
  fBinSelected:= cbBin.itemIndex - 1;
end;

(******************************************************************************)
(*                                                                            *)
(*                                                                            *)
(*                                                                            *)
(******************************************************************************)
procedure TPrintOverridePrintForm.btnResetClick(Sender: TObject);
begin
   NCIniMod.QRPrinterDefault:=-1;
   NCIniMod.QRPrinterDefaultName:='';
   NCIniMod.QRBinDefault:= -1;
   NCIniMod.PutWagelossRegistryData;
   modalResult:=mrOK;
end;

(******************************************************************************)
(*                                                                            *)
(*                                                                            *)
(*                                                                            *)
(******************************************************************************)
procedure TPrintOverridePrintForm.btnOKClick(Sender: TObject);
begin
   NCIniMod.QRPrinterDefault:=cbPrinter.itemIndex - 1;
   NCIniMod.QRPrinterDefaultName:=cbPrinter.items[cbPrinter.itemIndex];
   NCIniMod.QRBinDefault:= BinSelected;
   NCIniMod.PutWagelossRegistryData;
   modalResult:=mrOK;
end;

(******************************************************************************)
(*                                                                            *)
(*                                                                            *)
(*                                                                            *)
(******************************************************************************)
procedure TPrintOverridePrintForm.btnCancelClick(Sender: TObject);
begin
   modalResult:=mrCancel;
end;

end.
