object WrkRptJan23: TWrkRptJan23
  Left = 0
  Top = 0
  Caption = 'WrkRptJan23'
  ClientHeight = 441
  ClientWidth = 624
  Color = clBtnFace
  Font.Charset = DEFAULT_CHARSET
  Font.Color = clWindowText
  Font.Height = -12
  Font.Name = 'Segoe UI'
  Font.Style = []
  TextHeight = 15
end
