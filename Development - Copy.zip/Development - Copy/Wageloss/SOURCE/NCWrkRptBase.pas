unit NCWrkRptBase;

interface

Uses QPreview, NCWrkRpt, Forms, Controls, ncrecdef, SysUtils,
     NCWrkRptJan00, NCWrkRptJan01, NCWrkRptJan02, NCWrkRptJul02,
     NCWrkRptJan04, NCWrkRptJul04, NCWrkRptJul05, NCWrkRptJan06,
     NCWrkRptJul06, NCWrkRptJan07, NCWrkRptJul07, NCWrkRptJan08,
     NCWrkRptJul08, NCWrkRptJan09, NCWrkRptJul09, Dialogs, Utils,
     uGlobal, Math, NCWrkRptJan10, NCWrkRptJul10, NCWrkRptJan11,
     NCWrkRptJul11, NCWrkRptJan12, NCWrkRptJul12, NCWrkRptJan13,
     NCWrkRptJul13, NCWrkRptJan14, NCWrkRptJul14, NCWrkRptJan15,
     NCWrkRptJul15, NCWrkRptJan16, NCWrkRptJul16, NCWrkRptJan17,
     NCWrkRptJul17, NCWrkRptJan18, NCWrkRptJul18, NCWrkRptJan19,
     NCWrkRptJul19, NCWrkRptJan20, NCWrkRptJul20, NCWrkRptJan21,
     NCWrkRptJul21, NCWrkRptJan22, NCWrkRptJul22, NCWrkRptJan23,
     NCWrkRptJul23, NCWrkRptJan24, NCWrkRptJul24, NCWrkRptJan25,
     NCWrkRptJul25, NCWrkRptJan26, NCWrkRptJul26;

  Procedure OpenWrkSheet(var r: recNCCLAIM; SendingForm:TForm);
  Procedure CheckDate( var r: recNCCLAIM );
  Procedure getWrkSheet(Year, Month: integer);

implementation

var
  MyReport: TWagelossCalculationWorksheetForm;

procedure CloseAllReportPreviews;
var
   i:Integer;
begin
try
  for i := Screen.FormCount - 1 DownTo 0 do
    begin
    if Screen.Forms[i].ClassName = 'TQRCustomPreviewForm' Then
       Screen.Forms[i].Close;
    end;
  except
    ShowMessage('Please close any existing reports.');
  end; // end try except
end;

Procedure OpenWrkSheet;
var
  MyPreview: TQRCustomPreviewForm;
Begin
  try
    CloseAllReportPreviews;
    MyPreview := TQRCustomPreviewForm.Create(Nil);
    MyReport := nil;
    CheckDate(r);
    MyReport.SendingForm := SendingForm;
    MyPreview.ParentQuickReportForm := MyReport;
    MyPreview.ParentQuickReport := MyReport.QRCalcWorkSheet;
    MyPreview.caption := 'Wageloss Calculation Worksheet';
    Screen.Cursor := crDefault;
    try
      MyReport.QRCalcWorkSheet.OnPreview := MyPreview.CustomPreview;
      MyReport.QRCalcWorkSheet.Preview;
    finally
      screen.cursor := crDefault;
    end;
  finally
    screen.cursor := crDefault;
    MyPreview := Nil;
    //Commented out the following line as it was causing access
    //violation errors.  I don't know if it needs to be there or
    //not, but I'm removing it for now:
    //MyReport.Free;
    MyReport := Nil;
  end;
End;
//
// Get the date to use for the report calculation
//
Procedure CheckDate( var r: recNCCLAIM );
var
  WorkDate: TdateTime;
  Year, Month, Day, Acc_Year, Acc_Month, Acc_Day: Word;
begin
  try
    DecodeDate(r.Accident_Date, Acc_Year, Acc_Month, Acc_Day);
    if ((r.Indexation_Year > 0) AND (r.Tax_Year <> Acc_Year)) Then
      Month := Max(((Acc_Month+1) Mod 13),1)
    else
      Month := Acc_Month;
    WorkDate := Max(r.RecurrenceDate, EncodeDate(Min(Max(r.Indexation_Year,Acc_Year), r.Tax_Year), Month, 1));
    DecodeDate(WorkDate, Year, Month, Day);
    getWrkSheet(r.tax_Year, Month);
  except
    exit;
  end;
end;
//
// Get the worksheet to use depending on the year and month we are processing
//
//
Procedure getWrkSheet(Year, Month: integer);
begin
   try
      if Year < 2000 then
         begin
         if MyReport = nil then
      	    MyReport := TWagelossCalculationWorksheetForm.Create(Nil);
         end
      else if Year = 2000 then
         begin
         if MyReport = nil then
      	    MyReport :=  TWrkRptJan00.Create(Nil);
         end
      else if Year = 2001 then
  	     begin
    	   if MyReport = nil then
    	      MyReport := TWrkRptJan01.Create(Nil);
	       end
      else if (Year = 2002) and (month < 7) then
  	     begin
    	   if MyReport = nil then
    	      MyReport := TWrkRptJan02.Create(Nil);
  	     end
      else if ((Year = 2002) and (month > 6)) or
              ((Year = 2003) and (month < 7)) then
  	     begin
         if MyReport = nil then
    	      MyReport := TWrkRptJul02.Create(Nil);
  	     end
      else if ((Year = 2003) and (month > 6)) or
              ((Year = 2004) and (month < 7)) then
  	     begin
         if MyReport = nil then
    	      MyReport := TWrkRptJan04.Create(Nil);
         end
      else if ((Year = 2004) and (month > 6))  or
              ((Year = 2005) and (month < 7)) then
  	     begin
         if MyReport = nil then
    	      MyReport := TWrkRptJul04.Create(Nil);
         end
      else if ((Year = 2005) and (month > 6))  or
              ((Year = 2005) and (month <= 12)) then
  	     begin
         if MyReport = nil then
    	      MyReport := TWrkRptJul05.Create(Nil);
         end
      else if ((Year = 2006) and (month <= 6)) then
  	     begin
         if MyReport = nil then
    	      MyReport := TWrkRptJan06.Create(Nil);
         end
      else if ((Year = 2006) and (month >= 7)) then
  	     begin
         if MyReport = nil then
    	      MyReport := TWrkRptJul06.Create(Nil);
         end
      else if ((Year = 2007) and (month <= 6)) then
  	     begin
         if MyReport = nil then
    	      MyReport := TWrkRptJan07.Create(Nil);
         end
      else if ((Year = 2007) and (month >= 7)) then
  	    begin
         if MyReport = nil then
    	      MyReport := TWrkRptJul07.Create(Nil);
         end
      else if ((Year = 2008) and (month <= 6)) then
  	     begin
         if MyReport = nil then
    	      MyReport := TWrkRptJan08.Create(Nil);
         end
      else if ((Year = 2008) and (month >= 7)) then
  	     begin
         if MyReport = nil then
    	      MyReport := TWrkRptJul08.Create(Nil);
         end
      else if ((Year = 2009) and (month <= 6)) then
  	     begin
         if MyReport = nil then
    	      MyReport := TWrkRptJan09.Create(Nil);
         end
      else if ((Year = 2009) and (month >= 7)) then
  	     begin
         if MyReport = nil then
    	      MyReport := TWrkRptJul09.Create(Nil);
         end
      else if ((Year = 2010) and (month <= 6)) then
  	     begin
         if MyReport = nil then
    	      MyReport := TWrkRptJan10.Create(Nil);
         end
      else if ((Year = 2010) and (month >= 7)) then
  	     begin
         if MyReport = nil then
    	      MyReport := TWrkRptJul10.Create(Nil);
         end
      else if ((Year = 2011) and (month <= 6)) then
  	     begin
         if MyReport = nil then
    	      MyReport := TWrkRptJan11.Create(Nil);
         end
      else if ((Year = 2011) and (month >= 7)) then
  	     begin
         if MyReport = nil then
    	      MyReport := TWrkRptJul11.Create(Nil);
         end
      else if ((Year = 2012) and (month <= 6)) then
  	     begin
         if MyReport = nil then
    	      MyReport := TWrkRptJan12.Create(Nil);
         end
      else if ((Year = 2012) and (month >= 7)) then
  	     begin
         if MyReport = nil then
    	      MyReport := TWrkRptJul12.Create(Nil);
         end
      else if ((Year = 2013) and (month <= 6)) then
  	     begin
         if MyReport = nil then
    	      MyReport := TWrkRptJan13.Create(Nil);
         end
      else if ((Year = 2013) and (month >= 7)) then
  	     begin
         if MyReport = nil then
    	      MyReport := TWrkRptJul13.Create(Nil);
         end
      else if ((Year = 2014) and (month <= 6)) then
  	     begin
         if MyReport = nil then
    	      MyReport := TWrkRptJan14.Create(Nil);
         end
      else if ((Year = 2014) and (month >= 7)) then
  	     begin
         if MyReport = nil then
    	      MyReport := TWrkRptJul14.Create(Nil);
         end
      else if ((Year = 2015) and (month <= 6)) then
  	     begin
         if MyReport = nil then
    	      MyReport := TWrkRptJan15.Create(Nil);
         end
      else if ((Year = 2015) and (month >= 7)) then
  	     begin
         if MyReport = nil then
    	      MyReport := TWrkRptJul15.Create(Nil);
         end
      else if ((Year = 2016) and (month <= 6)) then
  	     begin
         if MyReport = nil then
    	      MyReport := TWrkRptJan16.Create(Nil);
         end
      else if ((Year = 2016) and (month >= 7)) then
  	     begin
         if MyReport = nil then
    	      MyReport := TWrkRptJul16.Create(Nil);
         end
      else if ((Year = 2017) and (month <= 6)) then
  	     begin
         if MyReport = nil then
    	      MyReport := TWrkRptJan17.Create(Nil);
         end
      else if ((Year = 2017) and (month >= 7)) then
  	     begin
         if MyReport = nil then
    	      MyReport := TWrkRptJul17.Create(Nil);
         end
      else if ((Year = 2018) and (month <= 6)) then
  	     begin
         if MyReport = nil then
    	      MyReport := TWrkRptJan18.Create(Nil);
         end
      else if ((Year = 2018) and (month >= 7)) then
  	     begin
         if MyReport = nil then
    	      MyReport := TWrkRptJul18.Create(Nil);
         end
      else if ((Year = 2019) and (month <= 6)) then
  	     begin
         if MyReport = nil then
    	      MyReport := TWrkRptJan19.Create(Nil);
         end
      else if ((Year = 2019) and (month >= 7)) then
  	     begin
         if MyReport = nil then
    	      MyReport := TWrkRptJul19.Create(Nil);
         end
      else if ((Year = 2020) and (month <= 6)) then
  	     begin
         if MyReport = nil then
    	      MyReport := TWrkRptJan20.Create(Nil);
         end
      else if ((Year = 2020) and (month >= 7)) then
         begin
         if MyReport = nil then
            MyReport := TWrkRptJul20.Create(Nil);
         end
      else if ((Year = 2021) and (month <= 6)) then
  	     begin
         if MyReport = nil then
    	      MyReport := TWrkRptJan21.Create(Nil);
         end
      else if ((Year = 2021) and (month >= 7)) then
         begin
         if MyReport = nil then
            MyReport := TWrkRptJul21.Create(Nil);
         end
      else if ((Year = 2022) and (month <= 6)) then
  	     begin
         if MyReport = nil then
    	      MyReport := TWrkRptJan22.Create(Nil);
         end
      else if ((Year = 2022) and (month >= 7)) then
  	     begin
         if MyReport = nil then
    	      MyReport := TWrkRptJul22.Create(Nil);
         end
      else if ((Year = 2023) and (month <= 6)) then
  	     begin
         if MyReport = nil then
    	      MyReport := TWrkRptJan23.Create(Nil);
         end
      else if ((Year = 2023) and (month >= 7)) then
  	     begin
         if MyReport = nil then
    	      MyReport := TWrkRptJul23.Create(Nil);
         end
      else if ((Year = 2024) and (month <= 6)) then
  	     begin
         if MyReport = nil then
    	      MyReport := TWrkRptJan24.Create(Nil);
         end
      else if ((Year = 2024) and (month >= 7)) then
  	     begin
         if MyReport = nil then
    	      MyReport := TWrkRptJul24.Create(Nil);
         end
      else if ((Year = 2025) and (month <= 6)) then
  	     begin
         if MyReport = nil then
    	      MyReport := TWrkRptJan25.Create(Nil);
         end
      else if ((Year = 2025) and (month >= 7)) then
  	     begin
         if MyReport = nil then
    	      MyReport := TWrkRptJul25.Create(Nil);
         end
      else if ((Year = 2026) and (month <= 6)) then
  	     begin
         if MyReport = nil then
    	      MyReport := TWrkRptJan26.Create(Nil);
         end
      else if ((Year = 2026) and (month >= 7)) then
  	     begin
         if MyReport = nil then
    	      MyReport := TWrkRptJul26.Create(Nil);
         end;

      if MyReport = nil then
         MyReport := TWrkRptJul26.Create(Nil);

  except
   	on e:Exception do
     begin
     	messageDlg('.'+CRLF+'Error message: '+ e.Message,
       mtError,[mbCancel],0);
       raise;
     end;
   end;
end;

end.
