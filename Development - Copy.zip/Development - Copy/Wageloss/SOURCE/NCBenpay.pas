(*****************************************************************)
(*  Wageloss System                                              *)
(*                                                               *)
(*  Benefits Payment Form                                        *)
(*                                                               *)
(*                                                               *)
(*  Author: Brad Trupp  / Capella Systems Group, Inc.            *)
(*  Date:   August 1997                                          *)
(*  02/03/2001  jdyck  allow editing of # of days and weeks      *)
(*                                                               *)
(*  2007 - Emerge R4                                             *)
(*                                                               *)
(*****************************************************************)

unit NCBenpay;

interface

uses                                                     
  Windows, Messages, SysUtils, Classes, Graphics, Controls, Forms, Dialogs,
  StdCtrls, Menus, ncrecdef, Math, NCSREdit, DBCtrls,
  SOAPHTTPTrans, DBClient, SOAPConn, DateUtils,
  InvokeRegistry, Rio, SOAPHTTPClient, uPaymentsWebService, uTriggerEvent,
  ComCtrls, ADODB, Data.DB, Datasnap.Provider, MidasLib;

const
  WAGELOSS_PENDING_PAYMENT_THRESHOLD_AMOUNT_EVENT_NAME = 'Wage Loss Pending Payment - Threshold Amount';
  WAGELOSS_PENDING_PAYMENT_THRESHOLD_DATE_EVENT_NAME = 'Wage Loss Pending Payment - Threshold Date';
  DEFAULT_DAYS_DUE_DATE_IN_ADVANCE_OF_TO_DATE = 3;
type

  iPaymentType = ( i90Sheltered, i90Net, i80Sheltered, i80Net,
                   i80Override, i90Override, iSearchOvrPay, iShelterRebate );

  TWagelossPaymentForm = class(TForm)
    textClaim_No: TLabel;
    lblClaim_No: TLabel;
    lblClaim_Suffix: TLabel;
    lblClmnts_Name: TLabel;
    textBenefit_Type: TLabel;
    lblBenefit_Type: TLabel;
    textCI05_Balance: TLabel;
    lblCI05_Balance: TLabel;
    textCI05_Rate: TLabel;
    lblCI05_Rate: TLabel;
    textWeekly_80: TLabel;
    lblWeekly_80: TLabel;
    textWkly_Clmt_Anty_Con_Amt: TLabel;
    lblWkly_Clmt_Anty_Con_Amt: TLabel;
    textWkly_WCB_Anty_Con_Amt: TLabel;
    lblCalcWeekly_80: TLabel;
    textWkly_Sal_A: TLabel;
    lblWkly_Sal_A: TLabel;
    textDays_Worked_per_Week: TLabel;
    lblDays_Worked_per_Week: TLabel;
    textWeekly_Benefit: TLabel;
    lblWeekly_Benefit: TLabel;
    lblnc_104_Wk_Clmt_p_Contrib: TLabel;
    lblCalcNc_104_Wk_WCB_p_Contrib_Red: TLabel;
    textNum_of_Payments: TLabel;
    textDate_Pd_From_Cheq: TLabel;
    textDate_Pd_To_Cheq: TLabel;
    textNo_Days_Paid: TLabel;
    textNo_Weeks_Paid: TLabel;
    edNum_of_Payments: TEdit;
    edDate_Pd_From_Cheq: TEdit;
    edDate_Pd_To_Cheq: TEdit;
    edNo_Days_Paid: TEdit;
    edNo_Weeks_Paid: TEdit;
    textFirst_Pay_Date: TLabel;
    textPay_Frequency: TLabel;
    textLoss_Earn_Date: TLabel;
    edDueDate: TEdit;
    edLoss_Earn_Date: TEdit;
    textPayee_Code: TLabel;
    textPayment_Type_Code: TLabel;
    textClaim_Exp_Code: TLabel;                                   
    textMessage_Code: TLabel;
    edMessage_Code_A: TEdit;
    textPayment_Anty_Earn: TLabel;
    textPayment_Clmt_Contrib: TLabel;
    textedPayment_WCB_Contrib: TLabel;
    textAmount_Paid: TLabel;
    textOK_to_Process: TLabel;
    edPayment_Anty_Earn: TEdit;
    edPayment_Clmt_Contrib: TEdit;
    edPayment_WCB_Contrib: TEdit;
    edAmount_Paid: TEdit;
    edOK_to_Process: TEdit;
    lblTitle: TLabel;
    btnPayMe: TButton;
    cboRsnForPayChng2: TComboBox;
    edMessage_Code_B: TEdit;
    edMessage_Code_C: TEdit;
    Label1: TLabel;
    cboFrequency: TComboBox;
    cboPayeeCode: TComboBox;
    lblOutstandingReceivableAmt: TLabel;
    lblOutstandingReceivableAmtDesc: TLabel;
    lblOutstandingSuspendedAmt: TLabel;
    lblOutstandingSuspendedAmtDesc: TLabel;
    cboPaymentType: TComboBox;
    Label2: TLabel;
    cboExpenseCategories: TDBLookupComboBox;
    cboExpenseTypes: TDBLookupComboBox;
    edReducedNoWeeksToPay: TEdit;
    edReducedNoDaysToPay: TEdit;
    lblReducedNoWeeksToPay: TLabel;
    lblReducedNoDaysToPay: TLabel;
    cdsChequeMessages: TClientDataSet;
    cdsChequeMessageslegacyCode: TStringField;
    cdsChequeMessagesremittanceMessageId: TIntegerField;
    edMessage_ID_A: TEdit;
    edMessage_ID_B: TEdit;
    edMessage_ID_C: TEdit;
    procedure FormClose(Sender: TObject; var Action: TCloseAction);
    procedure FormDestroy(Sender: TObject);
    procedure FormKeyDown(Sender: TObject; var Key: Word; Shift: TShiftState);
    procedure FormCreate(Sender: TObject);
    procedure IntegerKeyPress(Sender: TObject; var Key: Char);
    procedure DoubleKeyPress(Sender: TObject; var Key: Char);
    procedure DateKeyPress(Sender: TObject; var Key: Char);
    procedure edNum_of_PaymentsExit(Sender: TObject);
    procedure edDate_Pd_From_CheqExit(Sender: TObject);
    procedure edDate_Pd_To_CheqExit(Sender: TObject);
    procedure edNo_Days_PaidExit(Sender: TObject);
    procedure edNo_Weeks_PaidExit(Sender: TObject);
    procedure edDueDateExit(Sender: TObject);
    procedure edLoss_Earn_DateExit(Sender: TObject);
    procedure edMessage_Code_AExit(Sender: TObject);
    procedure edPayment_Anty_EarnExit(Sender: TObject);
    procedure edPayment_Clmt_ContribExit(Sender: TObject);
    procedure edPayment_WCB_ContribExit(Sender: TObject);
    procedure edAmount_PaidExit(Sender: TObject);
    procedure edOK_to_ProcessExit(Sender: TObject);
    procedure edOK_to_ProcessKeyPress(Sender: TObject; var Key: Char);
    procedure FormKeyPress(Sender: TObject; var Key: Char);
    procedure btnPayMeClick(Sender: TObject);
    procedure edMessage_Code_BExit(Sender: TObject);
    procedure edMessage_Code_CExit(Sender: TObject);
    procedure FormActivate(Sender: TObject);
    procedure cboFrequencyExit(Sender: TObject);
    procedure cboPayeeCodeExit(Sender: TObject);
    procedure cboPayeeCodeChange(Sender: TObject);
    procedure cboFrequencyChange(Sender: TObject);
    procedure cboExpenseCategoriesExit(Sender: TObject);
    procedure edReducedNoDaysToPayExit(Sender: TObject);
    procedure edReducedNoWeeksToPayExit(Sender: TObject);
  private
    { Private declarations }
    payClaim: recNCCLAIM;
    fPaymentType:iPaymentType;
    nc_firsttime, NC_OVERRIDE, NC_OVERRIDE_NO_SHELTER, nc_is_80: boolean;
    globalEditError:boolean;
    procedure createPaymentRequest( aPayeeId : Integer );
    procedure fillInForm;
    procedure ResetInfoLine2;
    procedure NCFRMCDE;
    procedure NCCALHAS;
    function validatePayment: boolean;
    function validateS7Dates: boolean;
    function CrossesOverIndexationDate: boolean;
    procedure recalcAmountsToPay;
    procedure savePaymentInfo( aPayeeId : Integer );
    procedure updateEmergeWagelossType;
    procedure updateCISCaseType;
    function validateDuplicatePayment: boolean;
    function validateAcceptedCompRehabPayment: boolean;
    function validateActualDaysToPay: boolean;
    function validateDurationDaysToPay: boolean;
    function validateAmountToPay: boolean;
    procedure PopulatePayeeCodeDropDown;
    procedure PopulateExpenseCategoriesDropDown;
    procedure PopulateExpenseTypesDropDown;
    procedure GetOverpaymentBalanceValue;
    function checkPayeeClaimant : Integer;
    function checkPayeeFirm : Integer;
    function checkPayeeAlternatePayee : Integer;
    function getFirmSuffix : String;
    function getIndustryCode : String;
    function getCoverageType : String;
    function stripThousandSeparators( aString : String ) : String;
    function searchOverpaymentAccount( aPayeeId : Integer; aPayeeType : String): boolean;
    procedure GetFirmValues;
    procedure GetAlternatePayeeValues;
    procedure GetPaymentTypeValues;
    procedure triggerCreateTaskEvent(const aTaskName, aPropertyExtension: String);overload;
    function calculateDueDate( aToDate : TDateTime ): TDateTime;
    function createPaymentRequestRecord( aPayeeId, aNumberOfPayments : Integer; aStatus : string ): Integer;
    function createPaymentItemRecord( fromDate, toDate : TDateTime; aPaymentRequestId : Integer; aPaymentRequestStatus : string; addPlannedRecoveryAmt : boolean ): Integer;
    function createWageLossPaymentRequestRecord ( aPaymentRequestId : Integer ): boolean;
    function createPaymentItemMessages ( aPaymentItemId : Integer ): boolean;
    function updateLossOfEarnings (  ): boolean;
    function updateWagelossCalcFactor (  ): boolean;
    function updateClaimPaymentSummary( aRequestAmount : double ): boolean;
    procedure UpdateShelterProcessDate;
    function ValidateMessageCode(LegacyMessageBox, RemittanceMessageID: TEdit):Boolean;
  public
    { Public declarations }
    FullClaim: recNCCLAIM;
    dataBenCalc:recNCCLAIM;
    shelterRebateClaim:TShelterRebateEditForm;
    constructor CreateExtended(paymentType:iPaymentType; AOwner: TComponent); virtual;
    procedure Loaded; override;
  end;

var
  WagelossPaymentForm: TWagelossPaymentForm;
  alternatePayeeType, organizationName, plannedRecoveryAmt, alternatePayeeDisplay, savedPaymentRequestStatus : String;
  savePendingPaymentRequestId, saveApprovedPaymentRequestId, saveOtherPaymentRequestId : Integer;

implementation

uses NCMain, NCClmWL0, ncinimod, utilmod1, NCOvrPay, NCChoice,
  NCDatMod, uDmGener, uADOSecurity, uGlobal, NCBencal, Utils,
  uSaveWageLossCalcFactors, NCWagelossOverpaymentRecoveryForm,
  ValidateDate, ConvertDate;

{$R *.DFM}

(******************************************************************************)
(*                                                                            *)
(*  Create Constructor                                                        *)
(*                                                                            *)
(*  Payment type is specified in order to customize form appropriately.       *)
(*                                                                            *)
(******************************************************************************)
constructor TWagelossPaymentForm.CreateExtended(paymentType:iPaymentType; AOwner: TComponent);
begin
  appLog('Creating Payment Screen for Claim:  ' + dataclaim.Claim_No);
  // store payment type
  fPaymentType := paymentType;

  NC_OVERRIDE := fPaymentType in [ i80Override, i90Override, iShelterRebate ];
  NC_OVERRIDE_NO_SHELTER := fPaymentType in [ i80Override, i90Override ];
  nc_is_80 :=  fPaymentType in [ i80Sheltered, i80Net, i80Override ];
  nc_firsttime := true; // used in "NUM_OF_PAYMENTS" crossedit

  // call inherited create which calls Form Create
  inherited create(AOwner);

  // hide 80% fields if 90%
  case fPaymentType of
    i90Sheltered, i90Net, i90Override, iShelterRebate:
    begin
        hideLabel(textWeekly_80);
        hideLabel(lblWeekly_80);
        hideLabel(lblnc_104_Wk_Clmt_p_Contrib);
        hideLabel(lblWkly_Clmt_Anty_Con_Amt);
        hideLabel(lblCalcNc_104_Wk_WCB_p_Contrib_Red);
        hideLabel(lblCalcWeekly_80);
        hideLabel(textWkly_Clmt_Anty_Con_Amt);
        hideLabel(textWkly_WCB_Anty_Con_Amt);
        if ((Year(dataClaim.Accident_Date) < 2006) and (fPaymentType = iShelterRebate))
          OR (fPaymentType <> iShelterRebate) then
        begin
          hideEdit(edPayment_Anty_Earn);
          hideLabel(textPayment_Anty_Earn);
          hideEdit(edPayment_Clmt_Contrib);
          hideLabel(textPayment_Clmt_Contrib);
          hideEdit(edPayment_WCB_Contrib);
          hideLabel(textedPayment_WCB_Contrib);
         end;

        //hideEdit( edReducedNoDaysToPay );
        //hideLabel( lblReducedNoDaysToPay );
        //hideEdit( edReducedNoWeeksToPay );
        //hideLabel( lblReducedNoWeeksToPay );
    end;
  end;

  //
  // Copy the claim prior to setting the title caption so we can see if this
  // is a bill 25 claim
  //
  copyNCCLAIM( dataClaim, payClaim);

  case fPaymentType of
    i90Sheltered:
      begin
        appLog('Payment type is : i90Sheltered');
        if Year(payClaim.Accident_Date) >= 2006 then
           lblTitle.caption:='Pre 104 Weeks Sheltered'
        else
           lblTitle.caption:='90% Sheltered';

        setEditToRead(edNo_Weeks_Paid);
        setEditToRead(edAmount_Paid);
        setEditToRead( edReducedNoDaysToPay );
        setEditToRead( edReducedNoWeeksToPay );
        edAmount_Paid.Color := clYellow;
      end;
    i90Net:
      begin
        appLog('Payment type is : i90Net');
        if Year(payClaim.Accident_Date) >= 2006 then
           lblTitle.caption := 'Pre 104 Weeks Net'
        else
           lblTitle.caption := '90% of Net';

        setEditToRead(edNo_Weeks_Paid);
        setEditToRead(edAmount_Paid);
        setEditToRead( edReducedNoDaysToPay );
        setEditToRead( edReducedNoWeeksToPay );
        edAmount_Paid.Color := clYellow;
      end;
    i80Sheltered:
      begin
        appLog('Payment type is : i80Sheltered');
        if Year(payClaim.Accident_Date) >= 2006 then
           lblTitle.caption := 'Post 104 Weeks Sheltered'
        else
           lblTitle.caption := '80% Sheltered';
        setEditToRead(edNo_Weeks_Paid);
        setEditToRead(edPayment_Anty_Earn);
        setEditToRead(edPayment_Clmt_Contrib);
        setEditToRead(edPayment_WCB_Contrib);
        setEditToRead(edAmount_Paid);
        setEditToRead( edReducedNoDaysToPay );
        setEditToRead( edReducedNoWeeksToPay );
        edAmount_Paid.Color := clYellow;
      end;
    i80Net:
      begin
        appLog('Payment type is : i80Net');
        if Year(payClaim.Accident_Date) >= 2006 then
           lblTitle.caption := 'Post 104 Weeks Net'
        else
           lblTitle.caption := '80% of Net';
        setEditToRead(edNo_Weeks_Paid);
        setEditToRead(edPayment_Anty_Earn);
        setEditToRead(edPayment_Clmt_Contrib);
        setEditToRead(edPayment_WCB_Contrib);
        setEditToRead(edAmount_Paid);
        setEditToRead( edReducedNoDaysToPay );
        setEditToRead( edReducedNoWeeksToPay );
        edAmount_Paid.Color := clYellow;
      end;
    i80Override:
      begin
        appLog('Payment type is : i80Override');
        lblTitle.caption := 'Override';  // 80% Net
      end;
    i90Override:
      begin
        appLog('Payment type is : i90Override');
        lblTitle.caption := 'Override'; // 90% of Net / Sheltered
      end;
    iSearchOvrPay:
      begin
        appLog('Payment type is : iSearchOvrPay');
        lblTitle.caption := 'Search Overpayments';
      end;
    iShelterRebate:
      begin
        appLog('Payment type is : iShelterRebate');
        lblTitle.caption := 'Shelter Rebate';
        setEditToRead(edNo_Weeks_Paid);
        setEditToRead(edAmount_Paid);
        setEditToRead( edReducedNoDaysToPay );
        setEditToRead( edReducedNoWeeksToPay );
        setEditToRead( edPayment_Anty_Earn );
        setEditToRead( edPayment_Clmt_Contrib );
        setEditToRead( edPayment_WCB_Contrib );
        edAmount_Paid.Color := clYellow;
      end;
  end;

  // set up payClaim
  with payClaim do
  begin
    Benefit_Type_Code := dataClaim.Benefit_Type_Code; // - set in NCBenCal
    Benefit_Type := dataClaim.Benefit_Type; // - set in NCBenCal
    Weekly_Benefit := dataClaim.Weekly_Benefit; // - set in NCBenCal
    Num_of_Payments := 1;
    Date_Pd_From_Cheq := 0;
    Date_Pd_To_Cheq := 0;
    No_Days_Paid := 0;
    No_Weeks_Paid := 0;
    Payee_Code := '';
    Alt_Mail_Add_code := '';
    Payment_Type_Code := '';
    Claim_Exp_Code := '';
    Message_Code_A := '';
    Message_Code_B := '';
    Message_Code_C := '';
    CFIO := dataClaim.CFIO; // - set in NCBenCal
    First_Pay_Date := 0;
    Pay_Frequency := '';

    //Get current loss of earnings date
    //Purpose, to re-load loss of earnings date after a payment has been made
    try
      with dm1 do
      begin
        if qryGeneralEmerge.active then
          qryGeneralEmerge.close;
        qryGeneralEmerge.sql.clear;
        qryGeneralEmerge.sql.add( 'SELECT lossOfEarningsDate ' );
        qryGeneralEmerge.sql.add( 'FROM Claim ' );
        qryGeneralEmerge.sql.add( 'WHERE claimNo = ' +  dataClaim.Claim_No );
        qryGeneralEmerge.open;
        qryGeneralEmerge.first;

        Loss_Earn_Date := qryGeneralEmerge.FieldByName( 'lossOfEarningsDate' ).AsDateTime;
        qryGeneralEmerge.close;
      end;
    finally
      ;
    end;

    //Loss_Earn_Date := dataClaim.Loss_Earn_Date;
    
    Payment_Anty_Earn := 0;
    Payment_Clmt_Contrib := 0;
    Payment_WCB_Contrib := 0;
    Amount_Paid := 0;
    OK_to_Process:='N';
    reducedNoDaysToPay := 0;
    reducedNoWeeksToPay := 0;
      end;

  if ( fPaymentType = iShelterRebate ) then
  begin
    with payClaim do
    begin
      Payee_Code := 'C';
      Date_Pd_From_Cheq := dataClaim.Date_Pd_From_Cheq;
      Date_Pd_To_Cheq := dataClaim.Date_Pd_To_Cheq;
      Payment_Type_Code := '6';
      Claim_Exp_Code := 'C30';
      Amount_Paid := dataclaim.Amount_Paid;
      Payment_Anty_Earn := dataclaim.Payment_Anty_Earn;
      Payment_Clmt_Contrib := dataclaim.Payment_Clmt_Contrib;
      Payment_WCB_Contrib := dataclaim.Payment_WCB_Contrib;
    end;
  end;
  //
  // if the claim is set to be paid at min then set the default cheque message code to
  // be V
  //
//  if payClaim.Pay_At_100_Flag_Partial Then
//     payClaim.Message_Code_A := 'V';
  fillInForm;
  ResetInfoLine2;
end;

(******************************************************************************)
(*                                                                            *)
(*  Form Close                                                                *)
(*                                                                            *)
(******************************************************************************)
procedure TWagelossPaymentForm.FormClose(Sender: TObject;
  var Action: TCloseAction);
begin
  action := caFree;
end;

(******************************************************************************)
(*                                                                            *)
(*  Form Destroy                                                              *)
(*                                                                            *)
(******************************************************************************)
procedure TWagelossPaymentForm.FormDestroy(Sender: TObject);
begin
  WagelossPaymentForm := nil;
  WagelossMainForm.ShowInfoLine1( '' );
  WagelossMainForm.ShowInfoLine2( '' );
end;

(******************************************************************************)
(*                                                                            *)
(*  Key Down - preview and process keypresses on form.                        *)
(*                                                                            *)
(******************************************************************************)
procedure TWagelossPaymentForm.FormKeyDown(Sender: TObject; var Key: Word;
  Shift: TShiftState);
begin
  case Key of
    VK_F1: begin
           Key := 0;
           Application.HelpCommand(HELP_CONTENTS, 0);
           end;
    VK_F7: begin
           Key := 0;
           close;
           end;
    VK_F10: begin
           Key := 0;
           //if validatePayment then createPaymentRequest;
           btnPayMeClick(application);
           end;
  end;
end;

(******************************************************************************)
(*                                                                            *)
(*  Key Press - preview and process keypresses on form.                       *)
(*                                                                            *)
(******************************************************************************)
procedure TWagelossPaymentForm.FormKeyPress(Sender: TObject;
  var Key: Char);
begin
  case Key of
    Chr(VK_RETURN):
      begin
        Key := #0;
        selectNext(ActiveControl as tWinControl, true, true );
      end;
  end;
end;


(******************************************************************************)
(*                                                                            *)
(*  Key press edit for integers                                               *)
(*                                                                            *)
(******************************************************************************)
procedure TWagelossPaymentForm.IntegerKeyPress(Sender: TObject;
  var Key: Char);
begin
  case Key of
  #0..#31,'0'..'9':
  else
    Key := #0;
  end;
end;

(******************************************************************************)
(*                                                                            *)
(*  Key press edit for doubles, floats, currencies                            *)
(*                                                                            *)
(******************************************************************************)
procedure TWagelossPaymentForm.DoubleKeyPress(Sender: TObject;
  var Key: Char);
begin
  case Key of
  #0..#31,'-','0'..'9','.','+':
  else
    Key := #0;
  end;
end;

(******************************************************************************)
(*                                                                            *)
(*  Key press edit for dates                                                  *)
(*                                                                            *)
(******************************************************************************)
procedure TWagelossPaymentForm.DateKeyPress(Sender: TObject;
  var Key: Char);
begin
  case Key of
  #0..#31,'0'..'9','/','.':
  else
    Key := #0;
  end;
end;

(******************************************************************************)
(*                                                                            *)
(*  Process to create a New Payment Request                                   *)
(*                                                                            *)
(******************************************************************************)
procedure TWagelossPaymentForm.createPaymentRequest( aPayeeId : Integer );
var
  isEmerge : boolean;
  payeeId : Integer;
begin
  appLog('Entering createPaymentRequest(' + format( '%d', [ aPayeeId ] ) + ')');
  globalEditError := false;
  try
     payeeId := aPayeeId;
     //
     //If the claim has been calculated then we have to use
     //the new uniqueness id that was created during the calc
     //
    if dataClaim.claimCalculated then
       begin
       payClaim.Uniqueness := StrToInt( wr.Uniquness );
       end;
    //
    //if not dm1.dbEmerge.InTransaction then
    //
    appLog('STARTING A DELPHI TRANSACTION:  dm1.dbEmerge');
    dm1.dbEmerge.BeginTrans;
    savePaymentInfo( payeeId );
  except
    on E:Exception do
       Begin
       appLog('Error message:  ' + e.Message);
       MessageDlg( 'Payment Was NOT Successful.  Please call help desk at 4573 for assistance. ' + e.Message, mtError	,[mbOk], 0);
       appLog('STOPPING A DELPHI TRANSACTION:  dm1.dbEmerge');
       if  dm1.dbEmerge.InTransaction then
          dm1.dbEmerge.RollbackTrans;
       Exit;
       End;
  end;

    //bcooper - Changes made for Shelter Rebate process
    //Do not save to WageLossCalcFactors
    if ( ( FullClaim.Claim_No = '') ) then
    begin
      ;
    end
    else
    begin

      //
      // Changes for claims on-line
      //
      copyNCCLAIM( FullClaim, uSaveWageLossCalcFactors.CalcFullClaim );
      copyNCCLAIM( payClaim, uSaveWageLossCalcFactors.CalcPartClaim );
      //
      // end changes for claims on-line
      //
    end;

    if IsEmergeUp then
      isEmerge := WagelossBenefitCalcForm.isClaimEmerge(lblClaim_No.Caption)
    else
      isEmerge := false;

    if isEmerge then
      updateEmergeWagelossType;

    if not globalEditError then
    begin
      try
        updateCISCaseType;
        appLog('COMMITTING A DELPHI TRANSACTION:  dm1.dbEmerge');
        dm1.dbEmerge.CommitTrans;
        MessageDlg( 'Payment Creation Successful for Claim Number ' + payClaim.Claim_No, mtInformation, [mbOK], 0 );
        UpdateShelterProcessDate;
      except
        on E:Exception do
        begin
          appLog('Error message:  ' + e.Message);
          MessageDlg( 'Exception Occurred.  Please call Help Desk at 4573.  Detailed Message: ' + e.Message, mtError, [mbOK], 0 );
          globalEditError := true;
        end;
      end;
    end;

    if globalEditError then
    begin
      appLog('STOPPING A DELPHI TRANSACTION:  dm1.dbEmerge');
      if  dm1.dbEmerge.InTransaction then
        dm1.dbEmerge.RollbackTrans;
      MessageDlg( 'Payment Creation Not Successful for Claim Number ' + payClaim.Claim_No, mtInformation, [mbOK], 0 );
      exit;
    end;

    //updateCISCaseType;

    close;
    appLog('Leaving createPaymentRequest');
end;

procedure TWagelossPaymentForm.UpdateShelterProcessDate;
begin
  appLog('Entering UpdateShelterProcessDate');
  if ( fPaymentType = iShelterRebate ) then
  try
    with dm1 do
    begin
      if query1.active then query1.close;
      query1.sql.clear;
      query1.sql.add('update dbo.WLREBDTL' );
      query1.sql.add('  set processDateTime = getDate()');
      query1.sql.add('  where Claim_No = ''' + payClaim.Claim_No + '''');
      query1.execSQL;
    end;
    finally;
    ;
  end;
  appLog('Leaving UpdateShelterProcessDate');
end;

(******************************************************************************)
(*                                                                            *)
(*  Form Create                                                               *)
(*                                                                            *)
(******************************************************************************)
procedure TWagelossPaymentForm.FormCreate(Sender: TObject);
begin
  SetFont(Self);
end;

(******************************************************************************)
(*                                                                            *)
(*  Set active control after form create                                      *)
(*                                                                            *)
(******************************************************************************)
procedure TWagelossPaymentForm.Loaded;
begin
  inherited;
  ActiveControl := edNum_of_Payments;
end;

(******************************************************************************)
(*                                                                            *)
(*  Fill in form from claim record                                            *)
(*                                                                            *)
(******************************************************************************)
procedure TWagelossPaymentForm.fillInForm;
var weeklyBenefit:Currency;
begin
  appLog('Entering fillInForm');
  with payClaim do
  begin
    lblClaim_No.caption := Claim_No;
    lblClaim_Suffix.caption := Claim_Suffix;
    lblClmnts_Name.caption := pdoxTrim(Clmnts_1st_Name) + ' ' + pdoxTrim(Clmnts_Surname);
    lblBenefit_Type.caption := Benefit_Type;
    lblCI05_Balance.caption := format( '%.2n', [ CI05_Balance ] );
    lblCI05_Rate.caption := format( '%.2n', [ CI05_Rate ] );
    lblWeekly_80.caption := format( '%.2n', [ Weekly_Benefit ] );
    lblWkly_Clmt_Anty_Con_Amt.caption := format( '%.2n', [ Wkly_Clmt_Anty_Con_Amt ] );
    if Year(Accident_Date) >= 2006 then
    begin
      lblCalcWeekly_80.caption:=format('%.2n',
        [ pdoxround( ( (((nc_104_Wk_WCB_p_Contrib)*Weekly_90_S)/100.00) ), 2) ] );
      lblCalcNc_104_Wk_WCB_p_Contrib_Red.caption := format( '%.2n',
        [ pdoxround( ( nc_104_Wk_WCB_p_Contrib ), 2) ] );
      edPayment_Anty_Earn.text := format( '%.2n', [ Payment_Anty_Earn ] );
      edPayment_Clmt_Contrib.text := format( '%.2n', [ Payment_Clmt_Contrib ] );
      edPayment_WCB_Contrib.text := format( '%.2n', [ Payment_WCB_Contrib ] );
    end
    else
    begin
      lblCalcWeekly_80.caption := format( '%.2n',
        [ pdoxround( ( (((5 - nc_104_Wk_WCB_p_Contrib_Red)*Weekly_80)/100.00) ), 2) ] );
      lblCalcNc_104_Wk_WCB_p_Contrib_Red.caption := format( '%.2n',
      [ pdoxround( ( 5 - nc_104_Wk_WCB_p_Contrib_Red ), 2) ] );
      edPayment_Anty_Earn.text := '0.00';
      edPayment_Clmt_Contrib.text := '0.00';
      edPayment_WCB_Contrib.text := '0.00';
    end;

    lblWkly_Sal_A.caption := format( '%.2n', [ Wkly_Sal_A ] );
    lblDays_Worked_per_Week.caption := format( '%.2n', [ Days_Worked_per_Week ] );

    // display calculated weekly benefit rather than internal weekly benefit
    if ( ( lblBenefit_Type.caption = 'Post 104 Weeks' )
          OR ( lblBenefit_Type.caption = 'Manual Calculation' )
          OR ( lblBenefit_Type.caption = '80% of Net' ) )then
    begin
      //lblWeekly_Benefit.caption:=format('%.2n', [ ( Weekly_Benefit - Wkly_Clmt_Anty_Con_Amt ) ] );
      weeklyBenefit := Weekly_Benefit - Wkly_Clmt_Anty_Con_Amt;
      if weeklyBenefit < 0 then
        lblWeekly_Benefit.caption := '0.00' 
      else
        lblWeekly_Benefit.caption:=format('%.2n', [ ( Weekly_Benefit - Wkly_Clmt_Anty_Con_Amt ) ] );
    end
    else
    begin
      lblWeekly_Benefit.caption:=format('%.2n', [ Weekly_Benefit ] );
    end;

    lblnc_104_Wk_Clmt_p_Contrib.caption := format( '%.2n', [ nc_104_Wk_Clmt_p_Contrib ] );
    edNum_of_Payments.text := format( '%d', [ Num_of_Payments ] );

    if Date_Pd_From_Cheq > 0 then
      edDate_Pd_From_Cheq.text := formatdatetime( 'c',Date_Pd_From_Cheq)
    else
      edDate_Pd_From_Cheq.text := '';
    if Date_Pd_To_Cheq > 0 then
      edDate_Pd_To_Cheq.text := formatdatetime( 'c',Date_Pd_To_Cheq)
    else
      edDate_Pd_To_Cheq.text := '';

    edNo_Days_Paid.text := format( '%.2n', [ No_Days_Paid ] );
    edNo_Weeks_Paid.text := format( '%.2n', [ No_Weeks_Paid ] );
    edReducedNoDaysToPay.Text := format( '%.2n', [ reducedNoDaysToPay ] );
    edReducedNoWeeksToPay.Text := format( '%.2n', [ reducedNoWeeksToPay ] );

    if First_Pay_Date > 0 then
      edDueDate.text := formatdatetime( 'c',First_Pay_Date)
    else
      edDueDate.text := '';

    cboFrequency.Text := Pay_Frequency;

    if Loss_Earn_Date > 0 then
      edLoss_Earn_Date.text := formatdatetime( 'c',Loss_Earn_Date)
    else
      edLoss_Earn_Date.text := '';

    cboPayeeCode.Text := Payee_Code;
    edMessage_Code_A.text := Message_Code_A;
    ValidateMessageCode(edMessage_Code_A, edMessage_ID_A);
    edMessage_Code_B.text := Message_Code_B;
    ValidateMessageCode(edMessage_Code_B, edMessage_ID_B);
    edMessage_Code_C.text := Message_Code_C;
    ValidateMessageCode(edMessage_Code_C, edMessage_ID_C);

    edPayment_Anty_Earn.text := format( '%.2n', [ Payment_Anty_Earn ] );
    edPayment_Clmt_Contrib.text := format( '%.2n', [ Payment_Clmt_Contrib ] );
    edPayment_WCB_Contrib.text := format( '%.2n', [ Payment_WCB_Contrib ] );
    edAmount_Paid.text := format( '%.2n', [ Amount_Paid ] );
    edOK_to_Process.text := OK_to_Process;
  end; //with payClaim
  appLog('Leaving fillInForm');
end;

(******************************************************************************)
(*                                                                            *)
(*  display default info line                                                 *)
(*                                                                            *)
(******************************************************************************)
procedure TWagelossPaymentForm.ResetInfoLine2;
begin
  WagelossMainForm.ShowInfoLine2( 'F7 - Exit  F10 - Pay' );
end;

(******************************************************************************)
(*                                                                            *)
(*  Validate Num_Of_Payments                                                  *)
(*                                                                            *)
(******************************************************************************)
procedure TWagelossPaymentForm.edNum_of_PaymentsExit(Sender: TObject);
var
   lngDays:Integer;
   dteCurrentDate:TDateTime;
begin
  if not validateAsInteger( edNum_of_Payments ) then
  begin
    globalEditError := displayError( '*Invalid Number of Payments', edNum_of_Payments );
    exit;
  end;

  if not ( textAsInteger( edNum_of_Payments ) in [1..26] ) then
  begin
    globalEditError := displayError( '*Invalid Number of Payments. Range 1 to 26 allowed.', edNum_of_Payments );
    exit;
  end;

  with payClaim do
  begin
    if ( textAsInteger( edNum_of_Payments ) <= 1 ) then
    begin
      //;Update first Time flag
      nc_firsttime := true;
      //edDueDate.text := FormatDateTime( 'dd/mm/yyyy', utilmod1.getEmergeBusinessDate() );
      cboFrequency.ItemIndex := 2;

      if ( CFIO = 'Y' ) then
      begin
        //;Compute for Information only set Payee Code
        cboPayeeCode.ItemIndex := 1;
      end;
    end;

    if ( ( textAsInteger( edNum_of_Payments ) = 1 ) and ( edDueDate.Text = '' ) ) then
    begin
      edDueDate.text := FormatDateTime( 'dd/mm/yyyy', utilmod1.getEmergeBusinessDate() );
    end;

    if ( textAsInteger( edNum_of_Payments ) > 1 ) then
    begin
      //edDueDate.text := FormatDateTime( 'dd/mm/yyyy', utilmod1.getEmergeBusinessDate() );
      edDueDate.text := '';

      // check for missing birth date
      if ( Birth_Date < 1 ) then
      begin
        globalEditError := displayError( '*Missing Birth Date - Cyclical Comp payments are not allowed.', edNum_of_Payments );
        edNum_of_Payments.text := '1';
        exit;
      end;

      if nc_firsttime then
      begin
        nc_firsttime := false;
        cboFrequency.ItemIndex := 0;
      end
      else
      begin
      if ( textAsInteger( edNum_of_Payments ) > 12 ) then
        cboFrequency.ItemIndex := 0;
      end;

      //
      // ;Blank out fields not used for multiple payments
      //
      edDate_Pd_From_Cheq.text := '';
      edDate_Pd_To_Cheq.text := '';

      if ( Length(pdoxTrim(edDueDate.Text)) > 1 ) then
      begin
        lngDays := 0;
        dteCurrentDate := utilmod1.getEmergeBusinessDate();

        While lngDays <= 3 do
        begin
          if (DayOfWeek(dteCurrentDate) <> 1) And
             (DayOfWeek(dteCurrentDate) <> 7) Then
          begin
            lngDays := lngDays + 1;
          end;

          dteCurrentDate := dteCurrentDate + 1;
        end;
      end;

    end;  //  if ( textAsInteger( edNum_of_Payments ) > 1 ) then...  (Cyclicals)
  end; //  with payClaim do...

  if ( textAsInteger( edNum_of_Payments ) > 1 ) then
  begin
    setEditToNormal(edDueDate);
    setEditToNormal(edDate_Pd_From_Cheq);
    setEditToNormal(edDate_Pd_To_Cheq);
    cboFrequency.Color := clAqua;
    cboFrequency.Enabled := True;
    if not( fPaymentType = iShelterRebate ) then
      selectNext(Sender as tWinControl, true, true );
  end
  else
  begin
    setEditToNormal(edDate_Pd_From_Cheq);
    setEditToNormal(edDate_Pd_To_Cheq);
    setEditToNormal(edNo_Days_Paid);
    if not NC_OVERRIDE then setEditToRead(edNo_Weeks_Paid);
    cboFrequency.Color := clBtnFace;
    cboFrequency.Enabled := False;
    if not( fPaymentType = iShelterRebate ) then
      selectNext(Sender as tWinControl, true, true );
  end;
  edNum_of_Payments.text := format( '%d',[ textAsInteger(edNum_of_Payments) ] );
  ResetInfoLine2;
end;

(******************************************************************************)
(*                                                                            *)
(*  Validate Date Paid From Cheque                                            *)
(*                                                                            *)
(******************************************************************************)
procedure TWagelossPaymentForm.edDate_Pd_From_CheqExit(Sender: TObject);
var
  toDate, fromDate : TDateTime;
begin
  if not validateAsDate( edDate_Pd_From_Cheq ) then
  begin
    globalEditError := displayError( '*Invalid Date Paid From', edDate_Pd_From_Cheq );
    exit;
  end;

  if ( textAsDate( edDate_Pd_From_Cheq ) > 0 ) then
    edDate_Pd_From_Cheq.text := formatdatetime( 'c',textAsDate( edDate_Pd_From_Cheq ))
  else
    edDate_Pd_From_Cheq.text := '';

  if ( textAsDate( edLoss_Earn_Date ) > 0 ) and
     ( textAsDate( edDate_Pd_From_Cheq ) > 0 ) then
  begin
    if ( textAsDate( edLoss_Earn_Date ) > textAsDate( edDate_Pd_From_Cheq ) ) then
    begin
      globalEditError := displayError( '*Date Paid From can not be before Loss of Earnings Date.', edDate_Pd_From_Cheq );
      edDate_Pd_From_Cheq.Text := '';
      edDate_Pd_From_Cheq.SetFocus;
      exit;
    end;
  end;

//  emergeBusinessDate := utilmod1.getEmergeBusinessDate();

  //add six weeks to emergeBusinessDate
//  testBusinessDate := IncWeek( emergeBusinessDate, 6 );

//  if ( TextAsDate( edDate_Pd_From_Cheq ) > testBusinessDate ) then
//  begin
//    globalEditError := displayError( '*From Date cannot be more than six weeks into the future', edDate_Pd_From_Cheq );
//    exit;
//  end;

  if ( fPaymentType <> iShelterRebate ) then
  begin
    // default Loss of Earnings date for first payment if blank
    if ( textAsDate( edLoss_Earn_Date ) = 0 ) and
       ( dataClaim.No_Days_Of_Comp_Bnfts = 0 ) then
    begin
      edLoss_Earn_Date.text := edDate_Pd_From_Cheq.text;
    end;
  end;

  if ( ( cboFrequency.Text = 'Bi-weekly' ) and ( edDate_Pd_From_Cheq.Text <> '' ) ) then
  begin
    fromDate := TextAsDate( edDate_Pd_From_Cheq );
    edDate_Pd_To_Cheq.Text := formatDateTime( 'dd/mm/yyyy', fromDate + 13 );
    //get date input on screen
    toDate := TextAsDate( edDate_Pd_To_Cheq );

    if ( ( toDate - fromDate ) <> 13 )  then
    begin
      globalEditError := displayError( '*To Date must be 14 days after From Date for Bi-weekly payments.', edDate_Pd_From_Cheq );
      exit;
    end;
  end;

  if cboFrequency.Text = 'Monthly' then
  begin
    if ( formatdatetime( 'dd', textAsDate( edDate_Pd_From_Cheq )) <> '01' )  then
    begin
      globalEditError := displayError( '*Date Paid From must be on first of the month for Monthly payments.', edDate_Pd_From_Cheq );
      exit;
    end;
  end;

  ResetInfoLine2;
end;

(******************************************************************************)
(*                                                                            *)
(*  Validate Date Paid To Cheque                                              *)
(*                                                                            *)
(******************************************************************************)
procedure TWagelossPaymentForm.edDate_Pd_To_CheqExit(Sender: TObject);
var
   IndexationDate, toDate, fromDate : TDateTime;
   iYear, iMonth, iDay : Word;
   tYear, tMonth, tDay : Word;
   strDay : String;
   numberOfPayments, i, fromMonth, toMonth : Integer;
begin
  numberOfPayments := StrToInt( edNum_of_Payments.Text );
  toDate := 0;
  fromDate := 0;

  if not validateAsDate( edDate_Pd_To_Cheq ) then
  begin
    globalEditError := displayError( '*Invalid Date Paid To', edDate_Pd_To_Cheq );
    exit;
  end;

  if ( textAsDate( edDate_Pd_To_Cheq ) > 0 ) then
    edDate_Pd_To_Cheq.text := formatdatetime( 'c',textAsDate( edDate_Pd_To_Cheq ))
  else
    edDate_Pd_To_Cheq.text := '';

  if ( textAsDate( edDate_Pd_From_Cheq ) > 0 ) then
    if ( textAsDate( edDate_Pd_To_Cheq ) < textAsDate( edDate_Pd_From_Cheq ) ) then
    begin
      globalEditError := displayError( '*PAID TO DATE must be after PAID FROM DATE.', edDate_Pd_To_Cheq );
      exit;
    end;

//  emergeBusinessDate := utilmod1.getEmergeBusinessDate();

  //add six weeks to emergeBusinessDate
//  testBusinessDate := IncWeek( emergeBusinessDate, 6 );

//  if ( TextAsDate( edDate_Pd_To_Cheq ) > testBusinessDate ) then
//  begin
//    globalEditError := displayError( '*To Date cannot be more than six weeks into the future', edDate_Pd_To_Cheq );
//    exit;
//  end;

  // Determine the indexation date for this claim
  IndexationDate := DataClaim.Accident_Date;
  DecodeDate(IndexationDate, iYear, iMonth, iDay);
  iDay := 1;
  iMonth := Max(((iMonth + 1) Mod 13), 1);
  if iMonth = 1 Then
     iYear := Max((iYear + 3), (DataClaim.Indexation_Year + 1))
  else
     iYear := Max((iYear + 2), (DataClaim.Indexation_Year + 1));

  IndexationDate := EncodeDate(iYear, iMonth, iDay);

  //
  // Check to see if we have exceeded the indexation date on the paid to
  // field
  //
  if (textAsDate(edDate_Pd_From_Cheq) > 0) And
     (textAsDate(edDate_Pd_To_Cheq) > 0) then
  Begin


    For i := 0 to numberOfPayments - 1 do
    Begin
      //if it's the first time through set values to screen
      if i = 0 then
      begin
        fromDate := StrToDateTime( edDate_Pd_From_Cheq.Text );
        toDate := StrToDateTime( edDate_Pd_To_Cheq.Text );
      end
      else //if there is more than one payment, then calculate
      begin
        if cboFrequency.Text = 'Bi-weekly' then
        begin
          //getFromDate
          //for Bi-Weekly payments, fromDate will always be 14 days in the future
          fromDate := fromDate + 14; //fromDate
          //getToDate
          //for Bi-Weekly payments, toDate will always be 14 days in the future
          toDate := toDate + 14; //toDate
        end
        else
        if cboFrequency.Text = 'Monthly' then
        begin
          //getFromDate
          fromDate := IncMonth( fromDate, 1 ); //fromDate
          //getToDate
          toDate := IncMonth( toDate, 1 );
          DecodeDate(toDate, tYear, tMonth, tDay);
          toDate := encodeDate( tYear, tMonth, MonthDays[IsLeapYear(tYear), tMonth] ); //toDate
        end;
      end;

      if ( ( fromDate < IndexationDate) and ( toDate >= IndexationDate) and ( fPaymentType <> iShelterRebate )) then
      begin
        globalEditError := displayError( '*Pay From/To dates cross over indexation date.', edDate_Pd_To_Cheq );
        Exit;
      End;
    end;
  End;

  if ( ( cboFrequency.Text = 'Bi-weekly' ) and ( edDate_Pd_From_Cheq.Text <> '' ) ) then
  begin
    fromDate := TextAsDate( edDate_Pd_From_Cheq );
    edDate_Pd_To_Cheq.Text := formatDateTime( 'dd/mm/yyyy', fromDate + 13 );
    //get date input on screen
    toDate := TextAsDate( edDate_Pd_To_Cheq );

    if ( ( toDate - fromDate ) <> 13 )  then
    begin
      globalEditError := displayError( '*To Date must be 14 days after From Date for Bi-weekly payments.', edDate_Pd_To_Cheq );
      exit;
    end;
  end;


  if cboFrequency.Text = 'Monthly' then
  begin
    //get date input on screen
    toDate := TextAsDate( edDate_Pd_To_Cheq );
    DecodeDate(toDate, tYear, tMonth, tDay);
    //determine what the last day of the month should be
    toDate := EncodeDate( tYear, tMonth, MonthDays[IsLeapYear(tYear), tMonth] );
    strDay := FormatDateTime( 'dd', toDate );

    if ( FormatDateTime( 'dd', textAsDate( edDate_Pd_To_Cheq )) <> strDay )  then
    begin
      globalEditError := displayError( '*Pay To Date must be on the last of the month for Monthly payments.', edDate_Pd_To_Cheq );
      exit;
    end;
  end;

  //from and to date month need to be in same month on Monthly payments
  if cboFrequency.Text = 'Monthly' then
  begin
    //get date input on screen
    fromMonth := Month( TextAsDate( edDate_Pd_From_Cheq ) );
    toMonth := Month( TextAsDate( edDate_Pd_To_Cheq ) );

    if ( fromMonth <> toMonth )  then
    begin
      globalEditError := displayError( '*From Date and To Date must be first and end of a calendar month for monthly payments.', edDate_Pd_From_Cheq );
      exit;
    end;
  end;

  ResetInfoLine2;
end;

(******************************************************************************)
(*                                                                            *)
(*  Validate Number of Days Paid                                              *)
(*                                                                            *)
(******************************************************************************)
procedure TWagelossPaymentForm.edNo_Days_PaidExit(Sender: TObject);
var
  //nc_age_message: shortstring;
  //nc_age_weeks: integer;
  monthlyDaysToPayMax : currency;
  actualNumberOfDaysToPay, reducedNumberOfDaysToPay, wholeNumber : double;
  decimalMonthlyDaysToPayMax, wholeMonthlyDaysToPayMax : String;
  testMonthlyDaysToPayMax : String;
begin
  if not validateAsCurrency( edNo_Days_Paid ) then
  begin
    globalEditError := displayError( '*Invalid Days Paid', edNo_Days_Paid );
    exit;
  end;

  if ( StrToFloat(cleanNumber(edNo_Days_Paid.Text)) < 0  ) then
  begin
    globalEditError := displayError( '*Actual # of Days to Pay cannot be negative.', edNo_Days_Paid );
    exit;
  end;

  if ( textAsCurrency( edNo_Days_Paid ) < 0 ) and ( payClaim.CFIO <> 'Y' ) then
  begin
    globalEditError := displayError( '*Reverse Days to pay not allowed for non-CFIO.', edNo_Days_Paid );
    exit;
  end;

  //;On Monthly payments days must be daysWorkedPerWeek x 52 (weeks) /12 (months)
  if ( cboFrequency.text = 'Monthly' ) then
  begin
    //formula: monthlyDaysToPayMax
    //daysWorkedPerWeek x 52 (weeks) /12 (months) ~~~always rounded up to the  next half day
    actualNumberOfDaysToPay := StrToFloat( edNo_Days_Paid.Text );
    reducedNumberOfDaysToPay := StrToFloat( edReducedNoDaysToPay.Text );
    monthlyDaysToPayMax :=  PdoxRound( dataClaim.Days_Worked_per_Week * 52 / 12, 2 );
    testMonthlyDaysToPayMax := format( '%.2n',[ monthlyDaysToPayMax ] );

    //get decimal and whole number values of monthlyDaysToPayMax
    //if decimal is greater than .00 and less than .5 then set the decimal value to .5
    decimalMonthlyDaysToPayMax := RightStr( testMonthlyDaysToPayMax, 2 );
    wholeMonthlyDaysToPayMax := LeftStr( testMonthlyDaysToPayMax, 2);

    if RightStr( wholeMonthlyDaysToPayMax, 1 ) = '.' then
    begin
      wholeMonthlyDaysToPayMax := LeftStr( wholeMonthlyDaysToPayMax, 1 );
    end;

    //if decimal is equal to .00 then set the decimal value to .00
    if ( ( StrToFloat( decimalMonthlyDaysToPayMax ) = 0 ) ) then
    begin
      decimalMonthlyDaysToPayMax := '.00';
    end
    else
    //if decimal is greater than .00 and less than .5 then set the decimal value to .5
    if ( ( StrToFloat( decimalMonthlyDaysToPayMax ) > 0 ) and ( StrToFloat( decimalMonthlyDaysToPayMax ) < 50 ) ) then
    begin
      decimalMonthlyDaysToPayMax := '.50';
    end
    else
    //if decimal is greater than .5 and less than or equal to .99 and the whole number is not equal to 30 then set the decimal value to .00 and add one to whole number
    if ( ( ( StrToFloat( decimalMonthlyDaysToPayMax ) > 50 ) and ( StrToFloat( decimalMonthlyDaysToPayMax ) <= 99 ) ) and ( StrToFloat( wholeMonthlyDaysToPayMax ) <> 30 ) ) then
    begin
      //set the decimal value to .00 and add one to whole number
      decimalMonthlyDaysToPayMax := '.00';
      wholeNumber := StrToFloat( wholeMonthlyDaysToPayMax );
      wholeNumber := wholeNumber + 1;
      wholeMonthlyDaysToPayMax := FloatToStr( wholeNumber );
    end;

    //monthlyDaysToPayMax = whole number plus decimal number
    monthlyDaysToPayMax := StrToFloat( wholeMonthlyDaysToPayMax + decimalMonthlyDaysToPayMax );

    if ( actualNumberOfDaysToPay > monthlyDaysToPayMax ) then
    begin
      globalEditError := displayError( '*Actual # of days to pay must be ' +  FloatToStr( monthlyDaysToPayMax )
                                       + ' or less for monthly.', edNo_Days_Paid );
      exit;
    end;

    if ( reducedNumberOfDaysToPay > monthlyDaysToPayMax ) then
    begin
      globalEditError := displayError( '* Duration(days) must be ' +  FloatToStr( monthlyDaysToPayMax )
                                       + ' or less for monthly.', edNo_Days_Paid );
      exit;
    end;
  end
  else
  begin
    setEditToNormal(edNo_Days_Paid);
    if ( cboFrequency.text = 'Bi-weekly' ) and (  abs(textAsCurrency(edNo_Days_Paid)) > (dataClaim.Days_Worked_per_Week * 2) ) then
    begin
      globalEditError := displayError( '*DAYS TO PAY must be less than or equal to 2 x days worked per week for bi-weekly payments.', edNo_Days_Paid );
      exit;
    end;
  end;

  if not validateActualDaysToPay then exit;

  //if ( abs(textAsCurrency( edNum_of_Payments )) = 1 ) then
  //begin
  //  if ( abs( textAsCurrency( edNo_Days_Paid ) ) >
  //      ( textAsDate( edDate_Pd_To_Cheq ) - textAsDate( edDate_Pd_From_Cheq ) + 1 ) ) then
  //  begin
  //    //;Set cross edit to failed
  //    globalEditError := displayError( '*Actual # of Days to pay cannot be greater than From/To dates.', edDate_Pd_From_Cheq );
  //    exit;
  //  end;
  //end;

  recalcAmountsToPay;

  edNo_Days_Paid.text := format( '%.2n',[ textAsCurrency(edNo_Days_Paid) ] );
  ResetInfoLine2;
end;

(******************************************************************************)
(*                                                                            *)
(*  Validate Number of Weeks Paid                                             *)
(*                                                                            *)
(******************************************************************************)
procedure TWagelossPaymentForm.edNo_Weeks_PaidExit(Sender: TObject);
begin
  if not validateAsCurrency( edNo_Weeks_Paid ) then
  begin
    globalEditError := displayError( '*Invalid Weeks Paid', edNo_Weeks_Paid );
    exit;
  end;

  if ( StrToFloat( edNo_Weeks_Paid.Text ) < 0 ) then
  begin
    globalEditError := displayError( '*Actual # of Weeks to Pay cannot be negative.', edNo_Weeks_Paid );
    exit;
  end;

  if ( textAsCurrency( edNo_Weeks_Paid ) < 0 ) and ( payClaim.CFIO <> 'Y' ) then
  begin
    globalEditError := displayError( '*Reverse Weeks to pay not allowed for non-CFIO.', edNo_Weeks_Paid );
    exit;
  end;

  edNo_Weeks_Paid.text := format( '%.2n',[ textAsCurrency(edNo_Weeks_Paid) ] );
  ResetInfoLine2;
end;

(******************************************************************************)
(*                                                                            *)
(*  Validate Due Date                                                         *)
(*                                                                            *)
(******************************************************************************)
procedure TWagelossPaymentForm.edDueDateExit(Sender: TObject);
var
  dteCurrentDate: tDateTime;
  lngDays:Integer;
begin
  if not validateAsDate( edDueDate ) then
  begin
    globalEditError := displayError( '*Invalid Due Date', edDueDate );
    exit;
  end;

  if ( textAsDate( edDueDate ) > 0 ) then
    edDueDate.text := formatdatetime( 'c',textAsDate( edDueDate ))
  else
    edDueDate.text := '';

  if ( textAsDate( edDueDate ) = 0 ) then
  begin
    ResetInfoLine2;
    exit;
  end;

  if ( textAsDate( edDueDate ) < utilmod1.getEmergeBusinessDate() ) then
  begin
    globalEditError := displayError( '*DUE DATE must not be before today.', edDueDate );
    exit;
  end;

  //
  // Check to see if we are issuing a cheque with less than three days to go before the first issue
  // and it is a cyclical.
  //
  if ( textAsinteger(edNum_of_Payments) > 1 ) then
  begin
    lngDays := 0;
    dteCurrentDate := utilmod1.getEmergeBusinessDate();

    While lngDays <= 3 do
    begin
      if (DayOfWeek(dteCurrentDate) <> 1) And
         (DayOfWeek(dteCurrentDate) <> 7) Then
      begin
        lngDays := lngDays + 1;
      end;

      dteCurrentDate := dteCurrentDate + 1;
    end;
  end;

  ResetInfoLine2;
end;

(******************************************************************************)
(*                                                                            *)
(*  Validate Loss of Earnings Date                                            *)
(*                                                                            *)
(******************************************************************************)
procedure TWagelossPaymentForm.edLoss_Earn_DateExit(Sender: TObject);
begin
  if not validateAsDate( edLoss_Earn_Date ) then
  begin
    globalEditError := displayError( '*Invalid Loss of Earnings Date', edLoss_Earn_Date );
    exit;
  end;

  if ( textAsDate( edLoss_Earn_Date ) > 0 ) then
    edLoss_Earn_Date.text := formatdatetime( 'c',textAsDate( edLoss_Earn_Date ))
  else
    edLoss_Earn_Date.text := '';

  if ( textAsDate( edLoss_Earn_Date ) > 0 ) and
     ( textAsDate( edDate_Pd_From_Cheq ) > 0 ) then
  begin
    if ( textAsDate( edLoss_Earn_Date ) > textAsDate( edDate_Pd_From_Cheq ) ) then
    begin
      edDate_Pd_From_Cheq.Text := '';
      edDate_Pd_To_Cheq.Text := '';
      edLoss_Earn_Date.Text := '';
      edDate_Pd_From_Cheq.SetFocus;
      globalEditError := displayError( '*Date Paid From can not be before Loss of Earnings Date.', edDate_Pd_From_Cheq );
      exit;
    end;
  end;

  if ( textAsDate( edLoss_Earn_Date ) > 0 ) then
    if ( textAsDate( edLoss_Earn_Date ) <= payClaim.Accident_Date ) then
    begin
      edDate_Pd_From_Cheq.Text := '';
      edDate_Pd_To_Cheq.Text := '';
      edDate_Pd_From_Cheq.SetFocus;
      globalEditError := displayError( '*Loss of Earnings Date must be greater than incident date.', edLoss_Earn_Date );
      exit;
    end;

  if ( textAsDate( edLoss_Earn_Date ) <= 0 ) then
  begin
    globalEditError := displayError( '*Loss of Earnings Date is a required field.', edLoss_Earn_Date );
    exit;
  end;

  ResetInfoLine2;
end;

(******************************************************************************)
(*                                                                            *)
(*  Validate Message Code                                                     *)
(*                                                                            *)
(******************************************************************************)
procedure TWagelossPaymentForm.edMessage_Code_AExit(Sender: TObject);
begin
  if Not (Trim(edMessage_Code_A.Text) = '') then
     begin
     if not ValidateMessageCode(edMessage_Code_A, edMessage_ID_A) then
        begin
        globalEditError := displayError( '*Please enter a valid cheque message code', edMessage_Code_A);
        exit;
        end;
     end;

  ResetInfoLine2;
end;

(******************************************************************************)
(*                                                                            *)
(*  Validate Payment Annuity Earnings                                         *)
(*                                                                            *)
(******************************************************************************)
procedure TWagelossPaymentForm.edPayment_Anty_EarnExit(Sender: TObject);
begin
  if not validateAsCurrency( edPayment_Anty_Earn ) then
  begin
    globalEditError := displayError( '*Invalid Annuity Earnings Amount', edPayment_Anty_Earn);
    exit;
  end;
  edPayment_Anty_Earn.text := format( '%.2n',[ textAsCurrency(edPayment_Anty_Earn) ] );
  ResetInfoLine2;
end;

(******************************************************************************)
(*                                                                            *)
(*  Validate Payment Claimant Contribution                                    *)
(*                                                                            *)
(******************************************************************************)
procedure TWagelossPaymentForm.edPayment_Clmt_ContribExit(Sender: TObject);
begin
  if not validateAsCurrency( edPayment_Clmt_Contrib ) then
  begin
    globalEditError := displayError( '*Invalid Worker Contribution Amount', edPayment_Clmt_Contrib );
    exit;
  end;
  edPayment_Clmt_Contrib.text := format( '%.2n',[ textAsCurrency(edPayment_Clmt_Contrib) ] );
  ResetInfoLine2;
end;

(******************************************************************************)
(*                                                                            *)
(*  Validate Payment WCB Contribution                                         *)
(*                                                                            *)
(******************************************************************************)
procedure TWagelossPaymentForm.edPayment_WCB_ContribExit(Sender: TObject);
begin
  if not validateAsCurrency( edPayment_WCB_Contrib ) then
  begin
    globalEditError := displayError( '*Invalid WCB Contribution Amount', edPayment_WCB_Contrib );
    exit;
  end;
  edPayment_WCB_Contrib.text := format( '%.2n',[ textAsCurrency(edPayment_WCB_Contrib) ] );
  ResetInfoLine2;
end;

(******************************************************************************)
(*                                                                            *)
(*  Validate Amount Paid                                                      *)
(*                                                                            *)
(******************************************************************************)
procedure TWagelossPaymentForm.edAmount_PaidExit(Sender: TObject);
begin
  if not validateAsCurrency( edAmount_Paid ) then
  begin
    globalEditError := displayError( '*Invalid Amount Paid', edAmount_Paid );
    exit;
  end;

  if ( StrToFloat( stripThousandSeparators( edAmount_Paid.Text ) ) < 0 ) then
  begin
    globalEditError := displayError( '*Amount Paid Cannot be negative', edAmount_Paid );
    exit;
  end;

  if StrToFloat( stripThousandSeparators( edAmount_Paid.Text ) ) <= 0 then
  begin
    globalEditError := displayError( '*Amount Paid Cannot be ''0.00''', edAmount_Paid );
    exit;
  end;

  edAmount_Paid.text := format( '%.2n',[ textAsCurrency(edAmount_Paid) ] );
  ResetInfoLine2;
end;

(******************************************************************************)
(*                                                                            *)
(*  Validate OK to Pay                                                        *)
(*                                                                            *)
(******************************************************************************)
procedure TWagelossPaymentForm.edOK_to_ProcessExit(Sender: TObject);
begin
  edOK_to_Process.text := uppercase(edOK_to_Process.text);
  if edOK_to_Process.text='' then edOK_to_Process.text := 'N';
  ResetInfoLine2;
end;

(******************************************************************************)
(*                                                                            *)
(*  Ket press edit for OK to Process                                          *)
(*                                                                            *)
(******************************************************************************)
procedure TWagelossPaymentForm.edOK_to_ProcessKeyPress(Sender: TObject;
  var Key: Char);
begin
  case Key of
  #0..#31,'y','Y','n','N':
  else
    Key := #0;
    WagelossMainForm.ShowInfoLine2( '*Valid values for OK to Process are Y N' );
  end;
end;

(******************************************************************************)
(*                                                                            *)
(* ;+ This script determines the formula code to use based on fields entered  *)
(*                                                                            *)
(*                                                                            *)
(* ;+ nc_code_prefix - Formula code prefix "S" - CFIO ; "F" - non CFIO        *)
(* ;+ nc_code_suffix - Formula code suffix "3" - 1 Payment                    *)
(* ;+                                      "7" - Cyclical Comp Payment        *)
(*                                                                            *)
(******************************************************************************)
procedure TWagelossPaymentForm.NCFRMCDE;
var
  nc_code_prefix, nc_code_suffix: shortstring;
begin
  with payClaim do
  begin
    //;Set the prefix
    if CFIO = 'Y' then
      nc_code_prefix := 'S'
    else
      nc_code_prefix := 'F';

    //;Set the suffix
    if Num_of_Payments = 1 then
      nc_code_suffix := '3'
   else
      nc_code_suffix := '7';

    Formula_Code := nc_code_prefix + nc_code_suffix;
  end;
end;

(******************************************************************************)
(*                                                                            *)
(* ;+ This script calculates the hash total for payment transactions and      *)
(* ;+ stores the result in the field [NCCLMINF ->Hash_Total].                 *)
(*                                                                            *)
(*                                                                            *)
(* ;+ Variable Dictionary                                                     *)
(* ;+ PAID_FROM           A numeric variable containing the value of the var  *)
(* ;+                     DATE_PD_FROM_CHEQ converted to a number.            *)
(* ;+                     (eg. 13.02.92 would be 130292)                      *)
(* ;+ PAID_TO             A numeric variable containing the value of the var  *)
(* ;                     DATE_PD_TO_CHEQ converted to a number.               *)
(* ;+                     (eg. 13.02.92 would be 130292)                      *)
(* ;+ FIRST_PAID          A numeric variable containing the value of the var  *)
(* ;                     FIRST_PAY_DATE converted to a number.                *)
(* ;+                     (eg. 13.02.92 would be 130292)                      *)
(*                                                                            *)
(******************************************************************************)
procedure TWagelossPaymentForm.NCCALHAS;
var
  PAID_FROM, PAID_TO, FIRST_PAID: integer;
begin
  with payClaim do
  begin
    if Date_Pd_From_Cheq > 0 then
      PAID_FROM := strtoint( formatdatetime( 'ddmmyy',Date_Pd_From_Cheq) )
    else
      PAID_FROM := 0;

    if Date_Pd_To_Cheq > 0 then
      PAID_TO := strtoint( formatdatetime( 'ddmmyy',Date_Pd_To_Cheq) )
    else
      PAID_TO := 0;

    if FIRST_PAY_DATE > 0 then
      FIRST_PAID := strtoint( formatdatetime( 'ddmmyy',FIRST_PAY_DATE) )
    else
      FIRST_PAID := 0;

    HASH_TOTAL :=  strToInt(CLAIM_NO)
               + ( AMOUNT_PAID * 100)
               + ( NO_DAYS_PAID * 10)
               + PAID_FROM
               + PAID_TO
               + FIRST_PAID;
  end;
end;

(******************************************************************************)
(*                                                                            *)
(*  Validates edit fields for payment and if valid calculates hash totals too.*)
(*                                                                            *)
(******************************************************************************)
function TWagelossPaymentForm.validatePayment: boolean;
var
  res: boolean;
  daysWorked, daysToPay, weeksToPay:double;
  wagelossStatus, severityStatus : String;
  deceasedDate, fromDate, toDate, newYearsDate, newBusinessDate, testBusinessDate, emergeBusinessDate : TDateTime;
  tYear, tMonth, tDay : Word;
  wYear, wMonth, wDay : Word;
  numberOfPayments : Integer;
  focusField : TWinControl;
begin
  appLog('Entering validatePayment');
  result := false;
  globalEditError := false;
  edOK_to_Process.setfocus; // forces exit processing on previous control
  edOK_to_ProcessExit( edOK_to_Process );
  focusField := edNo_Days_Paid;
  
  { make sure system date format hasn't changed }
  res := validateSystemDateFormat;
  if not res then exit;

  res := validateAsInteger( edNum_of_Payments );
  if not res then exit;
  res := validateAsDate( edDate_Pd_From_Cheq );
  if not res then exit;
  res := validateAsDate( edDate_Pd_To_Cheq );
  if not res then exit;
  res := validateAsCurrency( edNo_Days_Paid );
  if not res then exit;
  res := validateAsCurrency( edNo_Weeks_Paid );
  if not res then exit;
  res := validateAsDate( edDueDate);
  if not res then exit;
  res := validateAsDate( edLoss_Earn_Date );
  if not res then exit;
  res := validateAsCurrency( edPayment_Anty_Earn );
  if not res then exit;
  res := validateAsCurrency( edPayment_Clmt_Contrib );
  if not res then exit;
  res := validateAsCurrency( edPayment_WCB_Contrib );
  if not res then exit;
  res := validateAsCurrency( edAmount_Paid );
  if not res then exit;

  //enforce manditory fields and edits...

  // problem with edit - days must be 0 for C30
  if ( textAsCurrency( edNo_Days_Paid ) = 0 ) and not NC_OVERRIDE then
  begin
    globalEditError := displayError( '*Days cannot be zero except for override payments.', edNo_Days_Paid );
    exit;
  end;

  if cboPayeeCode.Text = '' then
  begin
    globalEditError := displayError( '*Please enter a Payee.', cboPayeeCode );
    exit;
  end;

  if ( textAsInteger( edNum_of_Payments ) = 1 ) then
  begin
    if length( edDate_Pd_From_Cheq.text ) < 1 then
    begin
      globalEditError := displayError( '*Please enter a Pay From Date.', edDate_Pd_From_Cheq );
      exit;
    end;
    if length( edDate_Pd_To_Cheq.text ) < 1 then
    begin
      globalEditError := displayError( '*Please enter a Pay To Date.', edDate_Pd_To_Cheq );
      exit;
    end;
  end;

  if length( edDueDate.text ) < 1 then
  begin
    globalEditError := displayError( '*Please enter a Due Date.', edDueDate );
    exit;
  end;

  //rule removed for Emerge R4
//  if ( abs( textAsCurrency( edAmount_Paid ) ) > 20000  ) then
//  begin
//    globalEditError := displayError( '*Amount to pay must less than $20,000.00', edOK_to_Process );
//    exit;
//  end;

  if cboPaymentType.Text = '' then
  begin
    globalEditError := displayError( '*Please enter a valid Payment Type', cboPaymentType );
    exit;
  end;

  if cboExpenseCategories.Text = '' then
  begin
    globalEditError := displayError( '*Please enter a valid Expense Category', cboExpenseCategories );
    exit;
  end;

  if cboExpenseTypes.text = '' then
  begin
    globalEditError := displayError( '*Please enter a valid Expense Type', cboExpenseTypes );
    exit;
  end;

  //bcooper 13/02/2006
  if ( payClaim.CFIO = 'Y' ) and ( cboPayeeCode.Text = 'Employer' ) And
     ((textAsCurrency(edPayment_Clmt_Contrib) > 0) Or
      (textAsCurrency(edPayment_WCB_Contrib) > 0)) Then
  begin
    globalEditError := displayError( '*Annuity Contributions not allowed on Information Only payment', edOK_to_Process );
    exit;
  end;

  with payClaim do
  begin
    Num_of_Payments := textAsInteger( edNum_of_Payments );
    Date_Pd_From_Cheq := textAsDate( edDate_Pd_From_Cheq );
    Date_Pd_To_Cheq := textAsDate( edDate_Pd_To_Cheq );
    No_Days_Paid := textAsCurrency( edNo_Days_Paid );
    No_Weeks_Paid := textAsCurrency( edNo_Weeks_Paid );
    reducedNoDaysToPay := textAsCurrency( edReducedNoDaysToPay );
    reducedNoWeeksToPay := textAsCurrency( edReducedNoWeeksToPay );
    First_Pay_Date := textAsDate( edDueDate);
    Pay_Frequency := cboFrequency.Text;
    Loss_Earn_Date := textAsDate( edLoss_Earn_Date );
    Payee_Code := cboPayeeCode.Text;
    Payment_Type_Code := cboPaymentType.Text;
    Claim_Exp_Code := cboExpenseCategories.Text;
    Message_Code_A := edMessage_Code_A.text;
    Message_Code_B := edMessage_Code_B.text;
    Message_Code_C := edMessage_Code_C.text;
    Payment_Anty_Earn := textAsCurrency( edPayment_Anty_Earn );
    Payment_Clmt_Contrib := textAsCurrency( edPayment_Clmt_Contrib );
    Payment_WCB_Contrib := textAsCurrency( edPayment_WCB_Contrib );
    Amount_Paid := textAsCurrency( edAmount_Paid );
    OK_to_Process := edOK_to_Process.text;

    if ( Date_Pd_From_Cheq > 0 ) and ( Date_Pd_To_Cheq > 0 ) then
      if ( Date_Pd_From_Cheq > Date_Pd_To_Cheq  ) then
      begin
        globalEditError := displayError( '*Pay From date can not be greater than Pay to date.', edDate_Pd_From_Cheq );
        exit;
      end;

    // Emerge R4 - Adjustments
    if ( ( NC_OVERRIDE ) and
       ( ( edNo_Days_Paid.Text = '0.00' ) or ( edReducedNoDaysToPay.Text = '0.00' ) ) and
       ( ( edNo_Weeks_Paid.Text = '0.00' ) or ( edReducedNoWeeksToPay.Text = '0.00' ) ) and
       ( edAmount_Paid.Text = '0.00' ) ) then
    begin
      if ( ( edPayment_Anty_Earn.Text <> '0.00' ) or
           ( edPayment_Clmt_Contrib.Text <> '0.00' ) or
           ( edPayment_WCB_Contrib.Text <> '0.00' ) ) then
      begin
        globalEditError := displayError( '*Please use Emerge for annuity adjustments.', edNo_Days_Paid );
        exit;
      end;
    end;

    // Emerge R4 - Adjustments
    if ( NC_OVERRIDE_NO_SHELTER ) then
    begin
      if ( ( edPayment_Anty_Earn.Text <> '0.00' ) and
           ( edPayment_WCB_Contrib.Text = '0.00' ) ) then
      begin
        globalEditError := displayError( '*WCB Contribution Amount must be greater than zero if Annuity Earnings are greater than zero.', edPayment_WCB_Contrib );
        exit;
      end;
    end;
//********************************************************************************************************************//
//********************************************************************************************************************//
//********************************************************************************************************************//

//For post 1991 claims if the number of weeks of comp from the compensible  injury plus the number of
//weeks of comp being paid in this transaction exceeds 104 then there must be a value in annuity earnings,
//WCB contribution and claim contribution.  0.00 is a valid entry
//    if ( ( payClaim.No_Weeks_of_Comp_Bnfts + payClaim.No_Weeks_Paid ) > 104 ) then
//    begin
//      //There must be a value in annuity earnings, WCB contribution and claim contribution.  0.00 is a valid entry
//
//    end;

//Override payments - For all payment types if the "Weeks Paid"  plus "Duration (Weeks)"
//( including all cyclical runs) > 104 then there must be a value in annuity earnings, WCB
//contribution and claim contribution.  0.00 is a valid entry
//    if ( NC_OVERRIDE ) then
//    begin
//      if ( ( ( payClaim.reducedNoWeeksToPay * payClaim.Num_of_Payments ) + payClaim.No_Weeks_Paid ) > 104 ) then
//      begin
//        //There must be a value in annuity earnings, WCB contribution and claim contribution.  0.00 is a valid entry
//
//      end;
//    end;

//********************************************************************************************************************//

    // Emerge R4 - Adjustments
    //if ( ( NC_OVERRIDE ) and
    if ( ( edNo_Days_Paid.Text <> '0.00' ) and
         ( edNo_Weeks_Paid.Text <> '0.00' ) ) then
    begin
      daysToPay := StrToFloat( cleanNumber(edNo_Days_Paid.Text) );
      weeksToPay := StrToFloat( edNo_Weeks_Paid.Text );
      daysWorked := PdoxRound( daysToPay / dataClaim.Days_Worked_per_Week , 2 );
      if weeksToPay <> daysWorked then
      begin
        globalEditError := displayError( '*Actual (days)/Actual (weeks) do not match for days worked per week. ' +
                                       'Adjustments to be done in Emerge.', edNo_Days_Paid );
         exit;
      end;
    end;

    // Emerge R4 - Adjustments
    //if ( ( NC_OVERRIDE ) and
    if ( ( edReducedNoDaysToPay.Text <> '0.00' ) and
         ( edReducedNoWeeksToPay.Text <> '0.00' ) ) then
    begin
      daysToPay := StrToFloat( cleanNumber(edReducedNoDaysToPay.Text) );
      weeksToPay := StrToFloat( edReducedNoWeeksToPay.Text );
      daysWorked := PdoxRound( daysToPay / dataClaim.Days_Worked_per_Week , 2 );
      if weeksToPay <> daysWorked then
      begin
        globalEditError := displayError( '*Duration (days)/Duration (weeks) do not match for days worked per week. ' +
                                       'Adjustments to be done in Emerge.', edReducedNoDaysToPay );
        exit;
      end;
    end;

    // Emerge R4 - Adjustments
    if ( ( NC_OVERRIDE ) and
         ( edReducedNoWeeksToPay.Text = '0.00' ) and
         ( edReducedNoDaysToPay.Text <> '0.00' ) ) then
    begin
      globalEditError := displayError( '*Duration (Weeks) must not be zero if Duration (Days) are greater than zero.', edReducedNoWeeksToPay );
      exit;
    end;

    // Emerge R4 - Adjustments
    if ( ( NC_OVERRIDE ) and
         ( edReducedNoDaysToPay.Text = '0.00' ) and
         ( edReducedNoWeeksToPay.Text <> '0.00' ) ) then
    begin
      globalEditError := displayError( '*Duration (Days) must not be zero if Duration (Weeks) are greater than zero.', edReducedNoDaysToPay );
      exit;
    end;


    if ( ( NC_OVERRIDE ) and
         ( edNo_Days_Paid.Text <> '0.00' ) and
         ( edNo_Weeks_Paid.Text = '0.00' ) ) then
    begin
      daysToPay := StrToFloat( cleanNumber(edNo_Days_Paid.Text) );
      weeksToPay := StrToFloat( edNo_Weeks_Paid.Text );
      daysWorked := PDoxRound( ( daysToPay / dataClaim.Days_Worked_per_Week ), 2 );
      if  ( daysWorked <> weeksToPay ) then
      begin
        globalEditError := displayError( '*Number of Days to Pay does not match Days To Pay/Days Worked.'
                                        , edNo_Days_Paid );
        exit;
      end;
    end;

    if ( ( NC_OVERRIDE ) and
         ( edNo_Weeks_Paid.Text <> '0.00' ) and
         ( edNo_Days_Paid.Text = '0.00' ) ) then
    begin
      daysToPay := StrToFloat( cleanNumber(edNo_Days_Paid.Text) );
      weeksToPay := StrToFloat( edNo_Weeks_Paid.Text );
      daysWorked := PDoxRound( ( daysToPay / dataClaim.Days_Worked_per_Week ), 2 );
      if  ( daysWorked <> weeksToPay ) then
      begin
        globalEditError := displayError( '*Number of Weeks to Pay does not match Days To Pay/Days Worked.'
                                        , edNo_Weeks_Paid );
        exit;
      end;
    end;

//*********************************************************************************************************************//
//*********************************************************************************************************************//
//revise current
//For all payment types-
//Expense Category=Full Wage Loss & Expense Type= Compensation   "Actual # of Days to Pay" cannot equal zero unless the payee type ="Alternate"
//Error message: "Actual # of Days to Pay cannot be zero for Full wage loss - Compensation."
//add to current
//For all payment types-
//Expense Category=Full Wage Loss & Expense Type= Compensation   "Duration (Days)" cannot equal zero
//Error message: "Duration (Days) cannot be zero cannot be zero for Full wage loss - Compensation"

    // Emerge R4
    //ORIGINAL:
    //if not NC_OVERRIDE then
    //begin
    //  if ( ( cboExpenseCategories.Text = 'Full Wage Loss' ) and
    //       ( cboExpenseTypes.Text = 'Compensation' ) and
    //       ( edNo_Days_Paid.Text = '0.00' ) ) then
    //  begin
    //    globalEditError := displayError( '*Full Wage Loss Compensation cannot have zero days.', edNo_Days_Paid );
    //    exit;
    //  end;
    //end;

    // Emerge R4
    //Revised:
    if NC_OVERRIDE then
    begin
      if ( ( cboExpenseCategories.Text = 'Full Wage Loss' ) and
           ( cboExpenseTypes.Text = 'Compensation' ) and
           ( edNo_Days_Paid.Text = '0.00' ) ) then
      begin
        if ( ( LeftStr( cboPayeeCode.Text, 6 ) <> 'Garnis' ) AND
             ( LeftStr( cboPayeeCode.Text, 6 ) <> 'Assign' ) //Or
             //( LeftStr( cboPayeeCode.Text, 6 ) <> 'Estate' )
           ) then //payeeType
        begin
          globalEditError := displayError( '*Actual # of Days to Pay cannot be zero for Full Wage Loss - Compensation.', edNo_Days_Paid );
          exit;
        end;
      end;
    end;
    // Emerge R4
    //New:
    if NC_OVERRIDE then
    begin
      if ( ( cboExpenseCategories.Text = 'Full Wage Loss' ) and
           ( cboExpenseTypes.Text = 'Compensation' ) and
           ( edReducedNoDaysToPay .Text = '0.00' ) ) then
      begin
        if ( ( LeftStr( cboPayeeCode.Text, 6 ) <> 'Garnis' ) AND
             ( LeftStr( cboPayeeCode.Text, 6 ) <> 'Assign' ) //Or
             //( LeftStr( cboPayeeCode.Text, 6 ) <> 'Estate' )
           ) then //payeeType
        begin
          globalEditError := displayError( '*Duration (Days) cannot be zero for Full Wage Loss - Compensation.', edReducedNoDaysToPay );
          exit;
        end;
      end;
    end;

//*********************************************************************************************************************//

    // Emerge R4
    if NC_OVERRIDE then
    begin
      if ( ( LeftStr( cboPayeeCode.Text, 6 ) = 'Garnis' ) and
           (( edNo_Days_Paid.Text <> '0.00' ) or
            ( edNo_Weeks_Paid.Text <> '0.00' ) or
            ( edReducedNoDaysToPay.Text <> '0.00' ) or
            ( edReducedNoWeeksToPay.Text <> '0.00' ) ) ) then
      begin
        if ( StrToFloat( edNo_Days_Paid.Text ) <> 0 ) then
        begin
          focusField := edNo_Days_Paid;
        end
        else
        if ( StrToFloat( edNo_Weeks_Paid.Text ) <> 0 ) then
        begin
          focusField := edNo_Weeks_Paid;
        end
        else
        if ( StrToFloat( edReducedNoDaysToPay.Text ) <> 0 ) then
        begin
          focusField := edReducedNoDaysToPay;
        end
        else
        if ( StrToFloat( edReducedNoWeeksToPay.Text ) <> 0 ) then
        begin
          focusField := edReducedNoWeeksToPay;
        end;

        globalEditError := displayError( '*Days and Weeks must be equal to zero if payee is a garnishee for an override payment.', focusField );
        exit;
      end;
    end;

    // Emerge R4
    if ( ( dataClaim.DeathBenefit = 'Y' ) and
         ( cboPayeeCode.Text = 'Worker' ) ) then
    begin
      globalEditError := displayError( '*Worker cannot be a payee for a fatality.', cboPayeeCode );
      exit;
    end;

    try
      with dm1 do
      begin
        if qryWageLossType.Active then
          qryWageLossType.Close;
        qryWageLossType.SQL.Clear;
        qryWageLossType.SQL.add( 'SELECT wageLossType, injurySeverityType' );
        qryWageLossType.SQL.add( 'FROM Claim ' );
        qryWageLossType.SQL.add( 'WHERE claimNo = ' + dataClaim.Claim_No );
        qryWageLossType.Open;
        wagelossStatus := qryWageLossType.FieldByName( 'wageLossType').AsString;
        severityStatus := qryWageLossType.FieldByName( 'injurySeverityType').AsString;
        qryWageLossType.Close;
      end;
    finally
      ;
    end;

    // Emerge R4
    if wagelossStatus <> 'Time Loss' then
    begin
      globalEditError := displayError( '*Claim must be time loss in order to allow payment.', cboPayeeCode );
      exit;
    end;

    // Emerge R4
    if ( cboPaymentType.Text = 'Advance' ) then
    begin
      if ( cboExpenseCategories.Text <> 'Adjustment' ) then
      begin
        globalEditError := displayError( '*Expense Category must be ''Adjustment'' if the Payment Type is ''Advance''.', edNo_Days_Paid );
        exit;
      end
      else
      if ( edNo_Days_Paid.Text <> '0.00' ) then
      begin
        globalEditError := displayError( '*''Actual # of Days to Pay'' must be equal to zero ''0.00'' if the Payment Type is ''Advance''.', edNo_Days_Paid );
        exit;
      end
      else
      if ( edNo_Weeks_Paid.Text <> '0.00' ) then
      begin
        globalEditError := displayError( '*''Actual # of Weeks to Pay'' must be equal to zero ''0.00'' if the Payment Type is ''Advance''.', edNo_Days_Paid );
        exit;
      end
      else
      if ( edReducedNoDaysToPay.Text <> '0.00' ) then
      begin
        globalEditError := displayError( '*''Duration (Days)'' must be equal to zero ''0.00'' if the Payment Type is ''Advance''.', edNo_Days_Paid );
        exit;
      end
      else
      if ( edReducedNoWeeksToPay.Text <> '0.00' ) then
      begin
        globalEditError := displayError( '*''Duration (Weeks)'' must be equal to zero ''0.00'' if the Payment Type is ''Advance''.', edNo_Days_Paid );
        exit;
      end;
    end;

    //get Deceased Date
    try
      with dm1.qryGeneralEmerge do
      begin
        if Active then
          Close;
        SQL.Clear;
        SQL.add( 'SELECT claimant.deceasedDate, claim.injurySeverityType ' );
        SQL.add( 'FROM emerge_db.dbo.Claimant claimant ' );
        SQL.add( '	INNER JOIN Claim claim ON claim.claimantId = claimant.claimantId ' );
        SQL.add( 'WHERE claim.claimNo = ' + dataClaim.Claim_No );
        Open;
        deceasedDate := FieldByName( 'deceasedDate').AsDateTime;
        Close;
      end;
    finally
      ;
    end;

    // Emerge R4
    if ( ( severityStatus = 'Fatal' ) and ( StrToDateTime( edDate_Pd_To_Cheq.Text ) > deceasedDate ) )then
    begin
      globalEditError := displayError( '*Fatal payment must be before deceased date.', cboPayeeCode );
      exit;
    end;

    // Emerge R4
    if ( ( cboPaymentType.Text <> 'Ongoing' ) and ( StrToInt( edNum_of_Payments.Text ) > 1 ) )then
    begin
      globalEditError := displayError( '*Payment Type must be Ongoing for cyclical payments.', cboPaymentType );
      exit;
    end;

    focusField := edNo_Days_Paid;
    // Emerge R4
    if NC_OVERRIDE then
    begin
      if ( ( cboExpenseCategories.Text = 'Adjustment' ) and
           ( cboExpenseTypes.Text = 'Compensation' ) ) then
      begin
        if ( ( StrToFloat( cleanNumber(edNo_Days_Paid.Text) ) <> 0 ) or
             ( StrToFloat( cleanNumber(edReducedNoDaysToPay.Text) ) <> 0 ) ) then
        begin
          if ( StrToFloat( cleanNumber(edNo_Days_Paid.Text) ) > 0 ) then
          begin
            focusField := edNo_Days_Paid;
          end
          else
          if ( StrToFloat( cleanNumber(edReducedNoDaysToPay.Text) ) > 0 ) then
          begin
            focusField := edReducedNoDaysToPay;
          end;

          globalEditError := displayError( '*Days must be zero when Expense Category = Adjustment and Expense type = Compensation.', focusField );
          exit;
        end;
      end;
    end;

    //in override, then days actual and duration must be zero
    //in regular, then they can't use adjustment
    if not NC_OVERRIDE then
    begin
      if ( cboExpenseCategories.Text = 'Adjustment' ) then
      begin
        globalEditError := displayError( '*All Adjustments must be done in Override.', cboExpenseCategories );
        exit;
      end;
    end;

    // Emerge R4
    //
    // Check to see if we have crossed over January 1 for CPP/QPP
    //
    numberOfPayments := StrToInt( edNum_of_Payments.Text );
    fromDate := StrToDateTime( edDate_Pd_From_Cheq.Text );
    toDate := StrToDateTime( edDate_Pd_To_Cheq.Text );

    if ( dataClaim.TaxCollBen_CPPQPP > 0 ) then
    begin
      if ( numberOfPayments > 1 ) and ( ( cboFrequency.Text = 'Bi-weekly' ) or ( cboFrequency.Text = 'Monthly' ) ) then
      begin
        if ( textAsDate( edDate_Pd_From_Cheq ) > 0) And
           ( textAsDate( edDate_Pd_To_Cheq ) > 0) then
        Begin
          if ( Pay_Frequency = 'Bi-weekly' ) then
          begin
            toDate := toDate + ( 14 * ( Num_of_Payments - 1 ) );
          end
          else
          if ( Pay_Frequency = 'Monthly' ) then
          begin
            decodeDate( toDate, wYear, wMonth, wDay);
            wMonth := wMonth + (Num_of_Payments - 1);

            while ( wMonth > 12 ) do
            begin
              inc( wYear );
              wMonth := wMonth - 12;
            end;

            toDate := encodeDate(wYear, wMonth, MonthDays[IsLeapYear(wYear), wMonth]);
          end;

          DecodeDate( toDate, tYear, tMonth, tDay );

          newYearsDate := EncodeDate( tYear, 1, 1 );

          if ( ( dataClaim.TaxCollBen_CPPQPP > 0 ) and ( ( fromDate < newYearsDate ) and ( toDate >= newYearsDate ) ) ) then
          begin
            globalEditError := displayError( '*Pay From/To dates cross over CPP.', edDate_Pd_From_Cheq );
            Exit;
          end;
        end;
      end;
    end;  //if CalcFullClaim.TaxCollBen_CPPQPP

    if not validateAcceptedCompRehabPayment then exit;

    if not validateDuplicatePayment then exit;

    NCFRMCDE();

    if not validateS7Dates then exit;

    //if not NC_OVERRIDE then if CrossesOverIndexationDate then exit;
    if CrossesOverIndexationDate then exit;

    // Emerge R4
    // Backdating Cyclical payments - Bi-weekly
    if ( ( StrToInt( edNum_of_Payments.Text ) > 1 ) and ( cboFrequency.Text = 'Bi-weekly' ) ) then
    begin
      if ( ( textAsDate( edDate_Pd_From_Cheq ) ) < ( ( utilmod1.getEmergeBusinessDate ) - 22 ) ) then
      begin
        globalEditError := displayError( '*Paid From Date must not be more than 22 days in the past.', edDate_Pd_From_Cheq );
        exit;
      end;
    end;

    // Backdating Cyclical payments - Monthly
    if ( ( StrToInt( edNum_of_Payments.Text ) > 1 ) and ( cboFrequency.Text = 'Monthly' ) ) then
    begin
      //get business date
      decodeDate( utilmod1.getEmergeBusinessDate(), wYear, wMonth, wDay);
      //change business date to the first of the month
      newBusinessDate := encodeDate( wYear, wMonth, 1 );
      //test pd from date to new business date
      if ( ( textAsDate( edDate_Pd_From_Cheq ) ) < ( newBusinessDate ) ) then
      begin
        globalEditError := displayError( '*Paid From Date must not be before the current month.', edDate_Pd_From_Cheq );
        exit;
      end;
    end;
{
    //Check Due Date
    //if frequency = monthly the "Due date"  cannot be greater than 6 weeks
    //into the future from the business date.
    if ( ( StrToInt( edNum_of_Payments.Text ) > 1 ) and ( cboFrequency.Text = 'Monthly' ) ) then
    begin
      //get business date
      newBusinessDate := utilmod1.getEmergeBusinessDate();
      newDueDate := textAsDate( edDueDate );

      //test newDueDate to newBusinessDate
      if ( ( newDueDate - newBusinessDate ) >= 42 ) then //42 = 6 weeks (7 days * 6 weeks)
      begin
        globalEditError := displayError( '*Due date cannot be more than 6 weeks into the future for Monthly payments.', edDueDate );
        exit;
      end;
    end;

    //Check Due Date
    //If frequency = one time or bi-weekly the "Due date"  cannot be greater than 4 weeks
    //into the future from the business date.
    if ( ( cboFrequency.Text = 'Bi-weekly' ) or ( cboFrequency.Text = 'One time' ) ) then
    begin
      //get business date
      newBusinessDate := utilmod1.getEmergeBusinessDate();
      newDueDate := textAsDate( edDueDate );

      //test newDueDate to newBusinessDate
      if ( ( newDueDate - newBusinessDate ) >= 28 ) then //28 = 4 weeks (7 days * 4 weeks)
      begin
        globalEditError := displayError( '*Due date cannot be more than 4 weeks into the future for ' + cboFrequency.Text + ' payments.', edDueDate );
        exit;
      end;
    end;

    //Check To Date
    //if frequency = bi-weekly the "to date"  cannot be greater than 4 weeks
    //into the future from the business date.
    if ( ( StrToInt( edNum_of_Payments.Text ) > 1 ) and ( cboFrequency.Text = 'Bi-weekly' ) ) then
    begin
      //get business date
      newBusinessDate := utilmod1.getEmergeBusinessDate();
      newToDate := textAsDate( edDate_Pd_To_Cheq );

      //test newDueDate to newBusinessDate
      if ( ( newToDate - newBusinessDate ) >= 28 ) then //28 = 4 weeks (7 days * 4 weeks)
      begin
        globalEditError := displayError( '*Pay to date cannot be more than 4 weeks into the future for Bi-weekly payments.', edDate_Pd_From_Cheq );
        exit;
      end;
    end;
}




  //add six weeks to emergeBusinessDate
//  testBusinessDate := IncWeek( emergeBusinessDate, 6 );

//  if ( TextAsDate( edDate_Pd_From_Cheq ) > testBusinessDate ) then
//  begin
//    globalEditError := displayError( '*From Date cannot be more than six weeks into the future', edDate_Pd_From_Cheq );
//    exit;
//  end;

//Confirmation of Emerge Business Rules:
//Frequency = One time and bi-weekly cannot have a "Paid to date" greater than 6 weeks from the business date
//Error message = "To Date cannot be more than 6 weeks into the future for one time and bi-weekly payments"
//Frequency = Monthly cannot have a "Paid to date" greater than 8 weeks from the business date
//Error message = "To date cannot be more than 8 weeks into the future for monthly payments"
//Frequency = One time and bi-weekly cannot have a "Due date" greater than 8 weeks from the business date
//Error message = "Due date cannot be more than 6 weeks into the future for one time and bi-weekly payments"


    emergeBusinessDate := utilmod1.getEmergeBusinessDate();
    //add four weeks to emergeBusinessDate
    testBusinessDate := IncWeek( emergeBusinessDate, 6 );

    if ( ( cboFrequency.Text = 'Bi-weekly' ) or ( cboFrequency.Text = 'One time' ) ) then
    begin
      if ( TextAsDate( edDate_Pd_To_Cheq ) > testBusinessDate ) then
      begin
        globalEditError := displayError( '*To Date cannot be more than 6 weeks into the future for one time and bi-weekly payments', edDate_Pd_To_Cheq );
        exit;
      end;
    end;

    if ( ( cboFrequency.Text = 'Bi-weekly' ) or ( cboFrequency.Text = 'One time' ) ) then
    begin
      if ( TextAsDate( edDueDate ) > testBusinessDate ) then
      begin
        globalEditError := displayError( '*Due date cannot be more than 6 weeks into the future for one time and bi-weekly payments', edDueDate );
        exit;
      end;
    end;

    //add eight weeks to emergeBusinessDate
    testBusinessDate := IncWeek( emergeBusinessDate, 8 );

    if ( ( StrToInt( edNum_of_Payments.Text ) > 1 ) and ( cboFrequency.Text = 'Monthly' ) ) then
    begin
      if ( TextAsDate( edDate_Pd_To_Cheq ) > testBusinessDate ) then
      begin
        globalEditError := displayError( '*To date cannot be more than 8 weeks into the future for monthly payments', edDate_Pd_To_Cheq );
        exit;
      end;

      //if frequency = monthly the "Due date"  cannot be greater than 8 weeks
      //into the future from the business date.
      if ( TextAsDate( edDueDate ) > testBusinessDate ) then
      begin
        globalEditError := displayError( '*Due date cannot be more than 8 weeks into the future for Monthly payments.', edDueDate );
        exit;
      end;
    end;
  end; //with payClaim

  NCCALHAS();

  edLoss_Earn_DateExit( edLoss_Earn_Date );

  if not validateActualDaysToPay then exit;
  if not validateDurationDaysToPay then exit;

  //if not NC_OVERRIDE then
  //begin
    if not validateAmountToPay then exit;
  //end;

  if edOK_to_Process.text <> 'Y' then
  begin
    globalEditError := displayError( '*OK to Process has not been selected.', edOK_to_Process );
    exit;
  end;

  result := true;

  appLog('Leaving validatePayment');
end;

(******************************************************************************)
(*                                                                            *)
(* Validates Payment request to ensure it is not a duplicate.                 *)
(*                                                                            *)
(******************************************************************************)
function TWagelossPaymentForm.validateDuplicatePayment: boolean;
var
  toDate, fromDate, testToDate, testFromDate, endToDate, endFromDate : TDateTime;
  tYear, tMonth, tDay:Word;
  count : Integer;
begin
  appLog('Entering validateDuplicatePayment');
  result := false;
  toDate := 0;
  fromDate := 0;
  testToDate := 0;
  testFromDate := 0;
  endToDate := 0;
  endFromDate := 0;

  try
    with dm1.qryDuplicatePayment do
    begin
      if Active then
        Close;
      SQL.Clear;
      SQL.Add( 'SELECT ' );
      SQL.Add( ' 	paymentRequest.claimNo,' );
      SQL.Add( ' 	paymentItem.fromDate,' );
      SQL.Add( ' 	paymentItem.toDate' );
      SQL.Add( 'FROM ' );
      SQL.Add( '	WageLossPaymentRequest wageLossPaymentRequest' );
      SQL.Add( '	INNER JOIN PaymentRequest paymentRequest' );
      SQL.Add( '		ON wageLossPaymentRequest.paymentRequestId = paymentRequest.paymentRequestId' );
      SQL.Add( '	INNER JOIN PaymentItem paymentItem' );
      SQL.Add( '		ON paymentRequest.paymentRequestId = paymentItem.paymentRequestId' );
      SQL.Add( 'WHERE paymentRequest.claimNo = ' + dataClaim.Claim_No );
      SQL.Add( '  AND paymentRequest.requestedPaymentAmt = ' + stripThousandSeparators( edAmount_Paid.Text ) );
      SQL.Add( '  AND ( paymentItem.statusType = ''Approved'' OR paymentItem.statusType LIKE ''Pending%'' )' );

      if cboFrequency.Text = 'One time' then
      begin
        endFromDate := StrToDateTime( edDate_Pd_From_Cheq.Text );
        endToDate := StrToDateTime( edDate_Pd_To_Cheq.Text );
      end
      else if cboFrequency.Text = 'Bi-weekly' then
      begin
        endFromDate := StrToDateTime( edDate_Pd_From_Cheq.Text ) + ( 14 * StrToInt( edNum_of_Payments.Text ) );
        endToDate := StrToDateTime( edDate_Pd_From_Cheq.Text ) + ( 14 * StrToInt( edNum_of_Payments.Text ) );
      end
      else if cboFrequency.Text = 'Monthly' then
      begin
        endFromDate := IncMonth( StrToDateTime( edDate_Pd_From_Cheq.Text ), ( StrToInt( edNum_of_Payments.Text ) - 1 ) ); //fromDate
        endToDate := IncMonth( StrToDateTime( edDate_Pd_From_Cheq.Text ), ( StrToInt( edNum_of_Payments.Text ) -1 ) );
        DecodeDate( endToDate, tYear, tMonth, tDay );
        endToDate := encodeDate( tYear, tMonth, MonthDays[IsLeapYear(tYear), tMonth] ); //toDate
      end;
      SQL.Add( '	AND ( paymentItem.fromDate BETWEEN ''' +  FormatDateTime( 'mm/dd/yyyy', StrToDateTime( edDate_Pd_From_Cheq.Text ) ) + ''' AND ''' +  FormatDateTime( 'mm/dd/yyyy', endFromDate ) + ''' )' );
      SQL.Add( '	AND ( paymentItem.toDate BETWEEN ''' +  FormatDateTime( 'mm/dd/yyyy', StrToDateTime( edDate_Pd_To_Cheq.Text ) ) + ''' AND ''' +  FormatDateTime( 'mm/dd/yyyy', endToDate ) + ''' )' );

      Open;

      try
        First;
        while not Eof do
        begin
          try
            for count := 0 to StrToInt( edNum_of_Payments.Text ) do
            begin
              if count = 0 then
              begin
                fromDate := FieldByName( 'fromDate' ).asDateTime;
                toDate := FieldByName( 'toDate' ).asDateTime;
                testFromDate := StrToDate( edDate_Pd_From_Cheq.Text ); //fromDate
                testToDate := StrToDate( edDate_Pd_To_Cheq.Text ); //toDate
              end
              else //if there is more than one payment, then calculate
              begin
                if cboFrequency.Text = 'Bi-weekly' then
                begin
                  //for Bi-Weekly payments, fromDate will always be 14 days in the future
                  testFromDate := testFromDate + 14; //fromDate
                  //for Bi-Weekly payments, toDate will always be 14 days in the future
                  testToDate := testToDate + 14; //toDate
                end
                else
                if cboFrequency.Text = 'Monthly' then
                begin
                  //getFromDate
                  testFromDate := IncMonth( testFromDate, 1 ); //fromDate
                  //getToDate
                  testToDate := IncMonth( testToDate, 1 );
                  DecodeDate(testToDate, tYear, tMonth, tDay);
                  testToDate := encodeDate( tYear, tMonth, MonthDays[IsLeapYear(tYear), tMonth] ); //toDate
                end;
              end;

              // if fromdate and toDate = screen values or future cyclical payments, then it's duplicate
              if ( ( fromDate = testFromDate ) and ( toDate = testToDate) ) then
              begin
                globalEditError := displayError( '*Payment Cancelled. Duplicate Payment.', edDate_Pd_From_Cheq );
                exit;
              end; // if
            end; //for
          finally
            Next;
          end;
        end; //while not eof
      finally
        ;
      end; //try

      Close;
    end; //with dm1.qryDuplicatePayment
  finally
    ;
  end;
  result := true;
  appLog('Leaving validateDuplicatePayment');
end;

(******************************************************************************)
(*                                                                            *)
(* Validates Accepted Rehab or Compensation Payment request.                  *)
(*                                                                            *)
(******************************************************************************)
function TWagelossPaymentForm.validateAcceptedCompRehabPayment: boolean;
var
  numberOfClaims : integer;
begin
  appLog('Entering validateAcceptedCompRehabPayment');
  result := false;
  try
    with dm1.qryAcceptedCompRehabPayment do
    begin
      if Active then
        Close;
      SQL.Clear;

      SQL.add( 'SELECT COUNT(*) AS ''numberOfClaims''' );
      SQL.add( 'FROM ClaimDecision claimDecision' );
      SQL.add( 'WHERE' );
      SQL.add( '	claimDecision.claimNo = ' + dataClaim.Claim_No + ' AND ' );
      SQL.add( '	claimDecision.decisionNameType LIKE ''%Accepted%'' AND ' );
      SQL.add( '	(' );
      SQL.add( '		claimDecision.decisionType LIKE ''%Rehabilitation%'' OR ' );
      SQL.add( '		claimDecision.decisionType LIKE ''%Compensation%'' ' );
      SQL.add( '	) ' );

      Open;

      try
        First;
          try
            numberOfClaims := FieldByName( 'numberOfClaims').AsInteger;

            if ( numberOfClaims = 0 ) then
            begin
                globalEditError := displayError( '*Cancelled. An Entitlement decision of type Compensation or Rehabilitation is required to complete a Wage Loss payment.', edDate_Pd_From_Cheq );
                exit;
            end; //if
          finally
          end;
      finally
      end; //try

      Close;
    end; //with dm1
  finally
    ;
  end;
  result := true;
  appLog('Leaving validateAcceptedCompRehabPayment');
end;

(******************************************************************************)
(*                                                                            *)
(* ;+ This script performs validates the dates for "S7" formula code payments.*)
(*                                                                            *)
(******************************************************************************)
function TWagelossPaymentForm.validateS7Dates: boolean;
var
  nc_total_weeks: currency;
  iChoice: integer;
begin
  appLog('Entering validateS7Dates');
  result := false;
  //approvedPendingWeeks := 0;
  with payClaim do
  begin
    //nc_total_weeks := ( Num_of_Payments * reducedNoWeeksToPay ) + No_Weeks_of_Comp_Bnfts + uGlobal.getApprovedPendingWeeks(dataClaim.Claim_No);
    nc_total_weeks := ( Num_of_Payments * reducedNoWeeksToPay ) + getAnnuityEntitlementWeeks(accident_date, claim_no, No_Weeks_of_Comp_Bnfts) + uGlobal.getApprovedPendingWeeks(dataClaim.Claim_No);

    //;Check cyclical comp payments for CFIO paying past Dec 13, 1993
    if not nc_is_80 then
    begin
      if ( ( nc_total_weeks > 96 ) and ( nc_total_weeks <= 104 ) )then
      begin
        try
          iChoice := 0;
          GetChoiceForm := TGetChoiceForm.create(application);
          GetChoiceForm.Message := 'Attempt to pay at 90% beyond 96 Weeks.';
          GetChoiceForm.Question := 'Continue with the Weeks Paid Entered ?';
          GetChoiceForm.AddChoice( 'Y - Yes' );
          GetChoiceForm.AddChoice( 'N - No' );
          GetChoiceForm.showmodal;
          iChoice := GetChoiceForm.Selected;
        finally
          GetChoiceForm.free;
        end;
        if iChoice = 1 then
        begin
          WagelossMainForm.ShowInfoLine2( '*Payment process cancelled by user. ' );
          globalEditError := true;
          exit;
        end;
      end;

      if ( nc_total_weeks > 104.10 ) then
      begin
        messagebeep(0);
        WagelossMainForm.ShowInfoLine2( '*Cannot pay at 90% Net/Sheltered/Pre 104 weeks beyond 104.10 weeks' );
        globalEditError := true;
        exit;
      end;
    end;  //if not nc_is_80
  end; // with payClaim do...

  result := true;
  appLog('Leaving validateS7Dates');
end;

(******************************************************************************)
(*                                                                            *)
(*  Cross Edit for payments against indexation.                               *)
(*                                                                            *)
(*  Check if payment spans an indexation date. The indexation date is the 1st *)
(*  of the month following 2 years after the accident date and annually after *)
(*  that.                                                                     *)
(*                                                                            *)
(******************************************************************************)
function TWagelossPaymentForm.CrossesOverIndexationDate: boolean;
var
  iYear, wYear, wMonth, wDay: Word;
  testYear, testMonth, testDay: Word;
  firstIndexDate, testDate: tDateTime;
  fromDate, toDate:tdatetime;
begin
  result := false;

  if payClaim.Accident_Date < 1 then exit;

  with payClaim do
  begin
    if ( Num_of_Payments < 2 ) then
    begin
      fromDate := Date_Pd_From_Cheq;
      toDate := Date_Pd_To_Cheq;
    end
    else
    begin
      fromDate := Date_Pd_From_Cheq;

      if ( Pay_Frequency = 'Bi-weekly' ) then
      begin
        //toDate := fromDate + ( 14 * ( Num_of_Payments - 1 ) );
        toDate := Date_Pd_To_Cheq + ( 14 * ( Num_of_Payments - 1 ) );
      end
      else
      begin
        decodeDate( fromDate, wYear, wMonth, wDay);
        wMonth := wMonth + (Num_of_Payments - 1);

        while ( wMonth > 12 ) do
        begin
          inc( wYear );
          wMonth := wMonth-12;
        end;

        //toDate := encodeDate(wYear, wMonth, wDay);
        toDate := encodeDate(wYear, wMonth, MonthDays[IsLeapYear(wYear), wMonth]);
        decodeDate( toDate, testYear, testMonth, testDay );
      end;
    end;
  end;

  decodeDate( payClaim.Accident_Date, wYear, wMonth, wDay);
  wYear := wYear + 2;
  wDay := 1;
  if wMonth = 12 then
  begin
    inc(wYear);
    wMonth := 1;
  end
  else
  begin
    inc(wMonth);
  end;

  firstIndexDate := encodeDate(wYear, wMonth, wDay);

  if ( toDate < firstIndexDate ) then exit;

  //if a one time payment and you're in override, allow payment to go through nomatter what
  if ( ( uppercase( cboFrequency.Text ) = 'ONE TIME' ) and ( nc_override ) ) then
  begin
    exit;
  end
  else //for all other conditions
  begin
    // check for cross over indexation dates
    for iYear := year( fromDate ) to year( toDate ) do
    begin
      //testDate = fromDate year, firstIndexDate Month, firstIndexDate Day , i.e. the upcoming indexation date
      testDate := encodeDate(iYear, wMonth, wDay);
      if ( testDate > firstIndexDate ) then
      begin
        //if the from date is before the upcoming indexation date, and
        //the to date (which is the last day of the payment) is after or equal to the upcoming indexation date, then
        //display error message and get out.
        if ( ( fromDate < testDate ) and ( toDate >= testDate ) ) then
        begin
           result := true;
           WagelossMainForm.ShowInfoLine2( '*Pay From/To Dates cross over indexation date.' );
           globalEditError := true;
           exit;
        end;
      end;
    end;
  end;
end;

(******************************************************************************)
(*                                                                            *)
(*  Add "Issue Payment" button as alternative to F10                          *)
(*                                                                            *)
(******************************************************************************)
procedure TWagelossPaymentForm.btnPayMeClick(Sender: TObject);
var
  payeeId : Integer;
  payeeType, stringClaim: String;
begin
  appLog('Entering btnPayMeClick');
  payeeType := cboPayeeCode.Text;

  if validatePayment then
  begin
    //See if there has been a payee setup for the payee that was selected
    if payeeType = 'Worker' then
    begin //check PayeeClaimant
      payeeId := checkPayeeClaimant;
    end //if worker
    else if payeeType = 'Employer' then
    begin //check PayeeFirm
      payeeId := checkPayeeFirm;
    end //if employer
    else //check PayeeAlternatePayee
    begin
      payeeId := checkPayeeAlternatePayee;
      payeeType := 'Alternate';
    end; //else alternatePayee

    if payeeId = 0 then
    begin
      displayError( '*Payee has not been created.  Payment Cancelled.', edOK_to_Process );
      exit;
    end;

    //Search OverpaymentAccount to see if there is an outstanding amount for the payee
    if searchOverpaymentAccount( payeeId, payeeType ) then
    begin
      stringClaim := CalcFullClaim.Claim_No;
      if not (uGlobal.logActivity(stringClaim, uGlobal.LOG_TYPE_PAYMENT, 'BenefitPayment')) then
      begin
        WagelossMainForm.ShowInfoLine2( '*Logging Failed.  Payment Creation Not Allowed!*' );
        exit;
      end;
      //Finally, call createPaymentRequest to write payment record
      createPaymentRequest( payeeId );
    end;
  end;
  appLog('Leaving btnPayMeClick');
end;

(******************************************************************************)
(*                                                                            *)
(*  Checks if the payeeClaimant is a current Claimant                         *)
(*                                                                            *)
(******************************************************************************)
function TWagelossPaymentForm.checkPayeeClaimant : Integer;
var
payeeId, id : Integer;
nextPayeeId, claimantId : String;
begin
  appLog('Entering checkPayeeClaimant');
  payeeId := 0;
    try
      with dm1 do
      begin
        if qryGeneralEmerge.Active then
          qryGeneralEmerge.Close;
        //Select PayeeId if payee is Claimant
        qryGeneralEmerge.SQL.Clear;
        qryGeneralEmerge.SQL.Add( 'SELECT payeeId ' );
        qryGeneralEmerge.SQL.Add( 'FROM PayeeClaimant payeeClaimant ' );
        qryGeneralEmerge.SQL.Add( 'INNER JOIN Claimant claimant ON claimant.claimantId = payeeClaimant.claimantId ' );
        qryGeneralEmerge.SQL.Add( 'WHERE claimant.claimantId = ' );
        qryGeneralEmerge.SQL.Add( '   ( SELECT claimantId ' );
        qryGeneralEmerge.SQL.Add( '     FROM Claim claim ' );
        qryGeneralEmerge.SQL.Add( '     WHERE claim.claimNo = ' + dataClaim.Claim_No + ')' );
        qryGeneralEmerge.Open;
        payeeId := qryGeneralEmerge.FieldByName( 'payeeId').AsInteger;
        qryGeneralEmerge.Close;

        result := payeeId;
        //if payeeId = 0 (i.e. there is no payee) create one
        if payeeId = 0 then
        begin
          //first get the next available payeeId
          id := uGlobal.getNextKey('Payee_Sequence', 1, -1 );
          nextPayeeId := IntToStr( id );

          //next insert a record into the PayeeClaimant table
          try
            if qryGeneralEmerge.Active then
              qryGeneralEmerge.Close;
            qryGeneralEmerge.SQL.Clear;
            qryGeneralEmerge.SQL.Add( 'SELECT claimantId ' );
            qryGeneralEmerge.SQL.Add( 'FROM Claim ' );
            qryGeneralEmerge.SQL.Add( 'WHERE claimNo = ' + dataClaim.Claim_No );
            qryGeneralEmerge.Open;

            claimantId := IntToStr( qryGeneralEmerge.FieldByName( 'claimantId').AsInteger );

            qryGeneralEmerge.SQL.Clear;
            qryGeneralEmerge.SQL.Add( 'INSERT INTO PayeeClaimant (payeeId, claimantId) ' );
            qryGeneralEmerge.SQL.Add( 'VALUES ( ' + nextPayeeId + ', ' + claimantId + ') ' );
            qryGeneralEmerge.ExecSQL;
            qryGeneralEmerge.Close;

            result := StrToInt( nextPayeeId );
          except
            on E:Exception do
            Begin
              result := payeeId;
              dm1.qryGeneralEmerge.Close;
              WagelossMainForm.ShowInfoLine2( '*Creation of New Claimant Payee Failed.' );
              exit;
            end;//exception
          end;//try/except
        end; //end else - Create a payee
      end; //with dm1
    except
      result := payeeId;
    end; //try
    appLog('Leaving checkPayeeClaimant');
end;

(******************************************************************************)
(*                                                                            *)
(*  Checks if the payeeClaimant is a current Firm                             *)
(*                                                                            *)
(******************************************************************************)
function TWagelossPaymentForm.checkPayeeFirm : Integer;
var
payeeId, id : Integer;
nextPayeeId, firmNo, firmSuffix : String;
begin
  appLog('Entering checkPayeeFirm');
  payeeId := 0;
    try
      with dm1 do
      begin
        if qryGeneralEmerge.Active then
          qryGeneralEmerge.Close;
        //Select PayeeId if payee is Employer
        qryGeneralEmerge.SQL.Clear;
        qryGeneralEmerge.SQL.Add( 'SELECT DISTINCT payeeFirm.payeeId ' );
        qryGeneralEmerge.SQL.Add( 'FROM PayeeFirm payeeFirm ' );
        qryGeneralEmerge.SQL.Add( 'INNER JOIN Claim claim ON claim.firmNo = payeeFirm.firmNo' );
        qryGeneralEmerge.SQL.Add( '                      AND claim.firmSuffix = payeeFirm.firmSuffix' );
        qryGeneralEmerge.SQL.Add( 'WHERE claim.firmNo =' );
        qryGeneralEmerge.SQL.Add( '	( SELECT firmNo' );
        qryGeneralEmerge.SQL.Add( '	 FROM Claim claim' );
        qryGeneralEmerge.SQL.Add( '	 WHERE claim.claimNo = ' + dataClaim.Claim_No + ')' );
        qryGeneralEmerge.SQL.Add( '	AND' );
        qryGeneralEmerge.SQL.Add( '	claim.firmSuffix = ' );
        qryGeneralEmerge.SQL.Add( '	(SELECT firmSuffix' );
        qryGeneralEmerge.SQL.Add( '	 FROM Claim claim' );
        qryGeneralEmerge.SQL.Add( '	 WHERE claim.claimNo = ' + dataClaim.Claim_No + ')' );
        qryGeneralEmerge.Open;
        payeeId := qryGeneralEmerge.FieldByName( 'payeeId').AsInteger;

        result := payeeId;
        //if payeeId = 0 (i.e. there is no payee) create one
        if payeeId = 0 then
        begin
          //first get the next available payeeId
          id := uGlobal.getNextKey('Payee_Sequence', 1, -1 );
          nextPayeeId := IntToStr( id );

          //next insert a record into the PayeeFirm table
          try
            if qryGeneralEmerge.Active then
              qryGeneralEmerge.Close;
            qryGeneralEmerge.SQL.Clear;
            qryGeneralEmerge.SQL.Add( 'SELECT firmNo, firmSuffix ' );
            qryGeneralEmerge.SQL.Add( 'FROM Claim ' );
            qryGeneralEmerge.SQL.Add( 'WHERE claimNo = ' + dataClaim.Claim_No );
            qryGeneralEmerge.Open;

            firmNo := IntToStr( qryGeneralEmerge.FieldByName( 'firmNo').AsInteger );
            firmSuffix := qryGeneralEmerge.FieldByName( 'firmSuffix').AsString;

            qryGeneralEmerge.SQL.Clear;
            qryGeneralEmerge.SQL.Add( 'INSERT INTO PayeeFirm (payeeId, firmNo, firmSuffix) ' );
            qryGeneralEmerge.SQL.Add( 'VALUES ( ' + nextPayeeId + ', ' + firmNo + ', ''' + firmSuffix + ''') ' );
            qryGeneralEmerge.ExecSQL;
            qryGeneralEmerge.Close;

            result := StrToInt( nextPayeeId );
          except
            on E:Exception do
            Begin
              result := payeeId;
              dm1.qryGeneralEmerge.Close;
              WagelossMainForm.ShowInfoLine2( '*Creation of New Firm Payee Failed.' );
              exit;
            end;//exception
          end;//try/except
        end;//end else - Create a payee
      end; //with dm1
    except
      result := payeeId;
    end; //try
    appLog('Leaving checkPayeeFirm');
end;

(******************************************************************************)
(*                                                                            *)
(*  Checks if the payeeClaimant is a current AlternatePayee                   *)
(*                                                                            *)
(******************************************************************************)
function TWagelossPaymentForm.checkPayeeAlternatePayee : Integer;
var
  payeeId, id : Integer;
  nextPayeeId, alternatePayeeId, alternatePayeeName, alternatePayeeAddress, account : String;
  emergeBusinessDate, effectiveDatetime, expiryDatetime : TDateTime;
begin
  appLog('Entering checkPayeeAlternatePayee');
  payeeId := 0;
  alternatePayeeType := '';
  organizationName := '';
  emergeBusinessDate := utilmod1.getEmergeBusinessDate();

  try
    with dm1.qryGeneralEmerge do
    begin
      if Active then
        Close;
      //Select PayeeId if payee is AlternatePayee
      SQL.Clear;

      SQL.Add( 'SELECT alternatePayeeId, effectiveDatetime, expiryDatetime, alternatePayeeType, organizationName, firstname + '' '' + lastname AS ''alternatePayeeName'', addressLine1, accountNo' );
      SQL.Add( 'FROM AlternatePayee ' );
      SQL.Add( 'WHERE claimNo = ' + dataClaim.Claim_No );
      SQL.Add( ' AND (alternatePayeeType LIKE ''Garnishee%'' OR alternatePayeeType LIKE ''Estate%'' OR alternatePayeeType = ''Other'' OR alternatePayeeType = ''Assignment of Benefits'')' );
      SQL.Add( 'ORDER BY alternatePayeeType' );
      Open;

      //Get alternatePayeeId based on the alternate payee selected on the screen
      try
        First;
        while not Eof do
        begin
          try
            alternatePayeeDisplay := '';
            alternatePayeeId := FieldByName( 'alternatePayeeId').AsString;
            effectiveDatetime := FieldByName( 'effectiveDatetime' ).AsDateTime;
            expiryDatetime := FieldByName( 'expiryDatetime' ).AsDateTime;
            alternatePayeeType := FieldByName( 'alternatePayeeType').AsString;
            organizationName := FieldByName( 'organizationName').AsString;
            alternatePayeeName := FieldByName( 'alternatePayeeName').AsString;
            alternatePayeeAddress := FieldByName( 'addressLine1' ).AsString;
            account := FieldByName( 'accountNo' ).AsString;

            alternatePayeeDisplay := alternatePayeeDisplay + alternatePayeeType;

            if expiryDatetime = 0 then
            begin
              expiryDatetime := 99999999;
            end;

            if ( ( emergeBusinessDate >= effectiveDatetime ) AND
                 ( emergeBusinessDate <= expiryDatetime ) ) then
            begin
              if (
                  ( alternatePayeeType = 'Garnishee - Maintenance Enforcement' ) or
                  ( alternatePayeeType = 'Other' ) or
                  ( alternatePayeeType = 'Estate' ) )  then
              begin
                if ( alternatePayeeName = '' ) then
                begin
                  alternatePayeeDisplay := alternatePayeeDisplay + ' - ' + organizationName;
                end
                else
                begin
                  alternatePayeeDisplay := alternatePayeeDisplay + ' - ' + alternatePayeeName;
                end;
              //end
              //else if (
              //    ( alternatePayeeType = 'Garnishee - Civil - Court of Queens Bench' ) or
              //    ( alternatePayeeType = 'Garnishee - Federal Orders' ) )  then
              //begin
              //  alternatePayeeDisplay := alternatePayeeDisplay + ' - ' + alternatePayeeAddress;
              end;
              if (account <> '') then
                alternatePayeeDisplay := alternatePayeeDisplay + ' - ' + account;
            end;

            //If PayeeAlternatePayee exists, get out...
            if cboPayeeCode.Text = alternatePayeeDisplay then
            begin
              break;
            end;
        finally
          Next;
        end;
      end;

      //We should now have the alternatePayeeId
      alternatePayeeId := alternatePayeeId;

      //Now we need to see if there's a PayeeAlternatePayee where the
      //alternatePayeeId = AlternatePayee.alternatePayeeId selected
      SQL.Clear;
      SQL.Add( 'SELECT PayeeAlternatePayee.payeeId' );
      SQL.Add( 'FROM PayeeAlternatePayee PayeeAlternatePayee' );
      SQL.Add( 'WHERE PayeeAlternatePayee.alternatePayeeId = ' + alternatePayeeId );
      Open;
      
      try
        First;
        //We should only get one or zero results
        payeeId := FieldByName( 'payeeId').AsInteger;

        if payeeId > 0 then //we know that we have a PayeeAlternatePayee
        begin
          //set the payeeId to the result
          result := payeeId;
        end
        else
        begin
          //if payeeId = 0 (i.e. there is no PayeeAlternatePayee) create one
          //first get the next available payeeId
          id := uGlobal.getNextKey('Payee_Sequence', 1, -1 );
          nextPayeeId := IntToStr( id );

          //next insert a record into the PayeeAlternatePayee table
          try
            if Active then
              Close;

            SQL.Clear;
            SQL.Add( 'INSERT INTO PayeeAlternatePayee (payeeId, alternatePayeeId) ' );
            SQL.Add( 'VALUES ( ' + nextPayeeId + ', ' + alternatePayeeId + ') ' );
            ExecSQL;
            Close;

            payeeId := StrToInt( nextPayeeId );
            result := payeeId;
          except
            on E:Exception do
            Begin
              appLog('Error Message:  ' + e.Message);
              result := payeeId;
              dm1.qryGeneralEmerge.Close;
              WagelossMainForm.ShowInfoLine2( '*Creation of New Alternate Payee Failed.' );
              exit;
          end;//exception
        end;
      end;//try/except

    finally
      Close;
    end; //try
    Close;
    except
      on E:Exception do
      Begin
        appLog('Error Message:  ' + e.Message);
        result := payeeId;
        dm1.qryGeneralEmerge.Close;
        WagelossMainForm.ShowInfoLine2( '*Creation of New Alternate Payee Failed.' );
        exit;
      end;//exception
    end;//try/except
  end; //dm1
  except
    ;
  end; //try

  result := payeeId;
  appLog('Leaving checkPayeeAlternatePayee');
end;

(******************************************************************************)
(*                                                                            *)
(*  General routine to recalculate amounts to pay based on days to pay.       *)
(*                                                                            *)
(******************************************************************************)
procedure TWagelossPaymentForm.recalcAmountsToPay;
var
  actualWeeksToPay,
  reducedDaysToPay,
  reducedWeeksToPay,
  reducedDaysToPayDecimal: double;
begin
  with payClaim do
  begin
    if ( NC_OVERRIDE <> TRUE ) then
    begin
      actualWeeksToPay   := PdoxRound( ( textAsCurrency( edNo_Days_Paid ) / payClaim.Days_Worked_per_Week ), 2 );
      //reducedDaysToPay   := PdoxRound( ( ( payClaim.Wkly_Sal_A -
      //                                     payClaim.Post_Injury_Earn ) /
      //                                     payClaim.Wkly_Sal_A *
      //                                     payClaim.Days_Worked_per_Week *
      //                                     actualWeeksToPay ), 2 );

      //Do not validate duration days to pay if there is no partial wage loss
      if payClaim.Post_Injury_Earn > 0 then
      begin
        reducedDaysToPay   := PdoxRound( ( ( payClaim.Days_Worked_per_Week -
                                             payClaim.Post_Injury_Earn /
                                             ( payClaim.Annual_Gross / 52 ) *
                                             payClaim.Days_Worked_per_Week ) ) *
                                             actualWeeksToPay, 2 );

        //round to nearest half day
        if ( ( reducedDaysToPay / 2 ) > 0 ) then  // we know the reducedDaysToPay is not a whole number
        begin
          //next we have to round the decimal part up or down:
          //eg. 0.75 rounds up to 1.0;
          //eg. 0.74 rounds down to 0.5;
          //eg. 0.25 rounds up to 0.5;
          //eg. 0.24 rounds down to 0.0;
          reducedDaysToPayDecimal := Frac( reducedDaysToPay );
          if reducedDaysToPayDecimal >= 0.75 then
            reducedDaysToPayDecimal := 1
          else if ( ( reducedDaysToPayDecimal < 0.75 ) and ( reducedDaysToPayDecimal > 0.5 ) ) then
            reducedDaysToPayDecimal := 0.5
          else if ( ( reducedDaysToPayDecimal >= 0.25 ) and ( reducedDaysToPayDecimal < 0.5 ) ) then
            reducedDaysToPayDecimal := 0.5
          else if ( reducedDaysToPayDecimal < 0.25 ) then
            reducedDaysToPayDecimal := 0;

          reducedDaysToPay := Int( reducedDaysToPay ) + reducedDaysToPayDecimal;

          if reducedDaysToPay > StrToFloat( edNo_Days_Paid.Text ) then
          begin
            reducedDaysToPay := reducedDaysToPay - 0.25;
          end;
        end;

        reducedWeeksToPay  := PDoxRound( ( reducedDaysToPay / payClaim.Days_Worked_per_Week ), 2 );
      end
      else
      begin
        reducedDaysToPay := StrToFloat( edNo_Days_Paid.Text );
        reducedWeeksToPay  := actualWeeksToPay;
      end;

      edReducedNoDaysToPay.Text := format( '%.2n',[ reducedDaysToPay ] );
      edReducedNoWeeksToPay.Text := format( '%.2n',[ reducedWeeksToPay ] );

      //; calculate number of weeks paid
      No_Weeks_Paid := PdoxRound( textAsCurrency(edNo_Days_Paid) / Days_Worked_per_Week ,2);
      edNo_Weeks_Paid.text := format( '%.2n',[ No_Weeks_Paid ] );
      if ( cboFrequency.Text = 'Bi-weekly' ) and ( No_Weeks_Paid > 2) THEN
      begin
        globalEditError := displayError( '*Attempt to pay more than 2 weeks for bi-weekly', edDate_Pd_To_Cheq);
        exit;
      end;
      if nc_is_80 then
      begin
        //;Calculate amount paid 80%
        No_Days_Paid := textAsCurrency( edNo_Days_Paid );
        Payment_Anty_Earn := PdoxRound(
        No_Days_Paid * Weekly_Benefit /Days_Worked_per_Week,2);

        Payment_Clmt_Contrib := PdoxRound(
                                  No_Days_Paid *
                                  ((nc_104_Wk_Clmt_p_Contrib*Weekly_Benefit)/100.00)
                                  /Days_Worked_per_Week
                                  ,2);

        if Year(Accident_Date) >= 2006 then
        begin
          Payment_WCB_Contrib := PdoxRound(
                                  No_Days_Paid *
                                  (((nc_104_Wk_WCB_p_Contrib) * Weekly_Benefit) / 100)
                                  /Days_Worked_per_Week
                                  ,2);
        end
        else
        begin
          Payment_WCB_Contrib := PdoxRound(
                                  No_Days_Paid *
                                  (((5 - nc_104_Wk_WCB_p_Contrib_Red) * Weekly_Benefit) / 100)
                                  /Days_Worked_per_Week
                                  ,2);
        end;

        Amount_Paid := Payment_Anty_Earn - Payment_Clmt_Contrib;
        // update edit text to match calculations
        edPayment_Anty_Earn.text := format( '%.2n', [ Payment_Anty_Earn ] );
        edPayment_Clmt_Contrib.text := format( '%.2n', [ Payment_Clmt_Contrib ] );
        edPayment_WCB_Contrib.text := format( '%.2n', [ Payment_WCB_Contrib ] );
        edAmount_Paid.text := format( '%.2n', [ Amount_Paid ] );
      end
      else
      begin
        //; calculate amount paid  90%
        No_Days_Paid := textAsCurrency( edNo_Days_Paid );
        Amount_Paid := PdoxRound(No_Days_Paid* Weekly_Benefit / Days_Worked_per_Week,2);
        // update edit text to match calculations
        edAmount_Paid.text := format( '%.2n', [ Amount_Paid ] );
      end;
    end;
  end; // IF(NC_OVERRIDE <> TRUE) then...
end;

(******************************************************************************)
(*                                                                            *)
(*  Process to create a New Payment Request Record                            *)
(*                                                                            *)
(******************************************************************************)
function TWagelossPaymentForm.createPaymentRequestRecord( aPayeeId, aNumberOfPayments : Integer; aStatus : string ): Integer;
var
  statictext, paymentsMessage, s : string;
  paymentRequestId, numberOfPayments : Integer;
  testToDate, fromDate, toDate : TDateTime;
  wYear, wMonth, wDay, testYear, testMonth, testDay, tYear, tMonth, tDay : Word;
  testRequestedAmt : double;
  Service : PaymentsWebService;
begin
  appLog('Entering createPaymentRequestRecord(' + format( '%d', [ aPayeeId ] ) + ', ' + format( '%d', [ aNumberOfPayments ] ) + ', ' + aStatus + ')');
  result := 0;
  if ( aNumberOfPayments = 0 ) then
    numberOfPayments := StrToInt( edNum_of_Payments.Text )
  else
    numberOfPayments := aNumberOfPayments;
  fromDate := StrToDateTime( edDate_Pd_From_Cheq.Text );
  toDate := StrToDateTime( edDate_Pd_To_Cheq.Text );
  testToDate := 0;
  paymentRequestId := 0;
  try
    paymentRequestId := uGlobal.getNextKey('PaymentRequest_Sequence', 1, -1 );
    //Try to Insert data to PaymentRequest
    with dm1.qryPaymentRequest do
    begin
      if Active then
        Close;

      SQL.Clear;

      SQL.Add( 'INSERT INTO PaymentRequest( ');
      SQL.Add( '  paymentRequestId, ');
      SQL.Add( '  paymentRequestType, ');
      SQL.Add( '  claimNo, ');
      SQL.Add( '  payeeId, ');
      SQL.Add( '  payeeType, ');
      SQL.Add( '  statusType, ');
      SQL.Add( '  statusReasonDescription, ');
      SQL.Add( '  requestedPaymentAmt, ');
      SQL.Add( '  expenseCategoryName, ');
      SQL.Add( '  expenseTypeName, ');
      SQL.Add( '  frequencyType, ');
      SQL.Add( '  numberOfPaymentsQty, ');
      SQL.Add( '  fromDate, ');
      SQL.Add( '  toDate, ');
      SQL.Add( '  informationOnlyFlag, ');
      SQL.Add( '  approvedByLoginName, ');
      SQL.Add( '  businessDate, ');
      SQL.Add( '  creationLoginName, ');
      SQL.Add( '  creationDatetime ) ');
      SQL.Add('VALUES( ');
      SQL.Add( SQLInteger( paymentRequestId ) ); //paymentRequestId
      SQL.Add( SQLString( 'Wage Loss' ) ); //paymentRequestType
      SQL.Add( SQLInteger( StrToInt( payClaim.Claim_No ) ) ); //claimNo
      SQL.Add( SQLInteger( aPayeeId ) ); //payeeId

      if ( ( LeftStr( cboPayeeCode.Text, 6 ) = 'Garnis' ) Or
        ( LeftStr( cboPayeeCode.Text, 5 ) = 'Other' ) Or
        ( LeftStr( cboPayeeCode.Text, 6 ) = 'Estate' )Or
        ( LeftStr( cboPayeeCode.Text, 10 ) = 'Assignment' ) ) then //payeeType
      begin
        SQL.Add( SQLString( 'Alternate' ) );
      end
      else
      begin
        SQL.Add( SQLString( cboPayeeCode.Text ) );
      end;

      if ( cboFrequency.Text = 'One time' ) then
      begin
        testToDate := StrToDateTime( edDate_Pd_To_Cheq.Text );
      end
      else if ( cboFrequency.Text = 'Bi-weekly' ) then
      begin
        testToDate := StrToDateTime( edDate_Pd_To_Cheq.Text ) + ( 14 * ( StrToInt( edNum_of_Payments.Text ) - 1 ) );
      end
      else if ( cboFrequency.Text = 'Monthly' ) then
      begin
        decodeDate( StrToDateTime( edDate_Pd_From_Cheq.Text ), wYear, wMonth, wDay);
        wMonth := wMonth + ( StrToInt( edNum_of_Payments.Text ) - 1);
        while ( wMonth > 12 ) do
        begin
          inc( wYear );
          wMonth := wMonth - 12;
        end;
        testToDate := encodeDate(wYear, wMonth, MonthDays[IsLeapYear(wYear), wMonth]);
        decodeDate( testToDate, testYear, testMonth, testDay );
      end;

  		try
        testRequestedAmt := StrToFloat( stripThousandSeparators( edAmount_Paid.Text ) ) * numberOfPayments;
        if ( aStatus = '' ) then
        begin
          //total requested payment amount =  Amount to pay * number of payments
          //testRequestedAmt := StrToFloat( stripThousandSeparators( edAmount_Paid.Text ) ) * StrToInt( edNum_of_Payments.Text );
          Service := GetPaymentsWebService(False, PAYMENTS_WEB_SERVICE_LOCATION, nil);
          statictext := Service.checkWageLossAuthorization(StrToInt( payClaim.Claim_No ), //const aClaimNo: Integer;
                                                         stripThousandSeparators( FloatToStr( testRequestedAmt ) ), //const aRequestedAmt: WideString;
                                                         UserProfile.loginName, //const aLoginName: WideString;
                                                         //edDate_Pd_From_Cheq.Text, //const aRequestDate: WideString;
                                                         DateToStr( testToDate ), //const aRequestDate: WideString;
                                                         aPayeeId, //const aOverpaymentAccountId: Integer;
                                                         stripThousandSeparators( plannedRecoveryAmt ) ); //const aTotalOutstandingAmt: WideString
          savedPaymentRequestStatus := statictext;
        end
        else
        begin
          statictext := aStatus;
        end;
        paymentsMessage := Copy( statictext, 1, 1);

        if ( paymentsMessage = '*' ) then
        begin
          messagebeep(0);
          appLog('STOPPING A DELPHI TRANSACTION:  dm1.dbEmerge');
          if  dm1.dbEmerge.InTransaction then
            dm1.dbEmerge.RollbackTrans;
          MessageDlg( 'Emerge Payments Web Service Failed.  Please notify help desk at 4573.'
                      + chr(10) + chr(13) + chr(10) + chr(13) + 'Detailed Message: ' + statictext
                      + chr(10) + chr(13) + chr(10) + chr(13) + 'Payment Cancelled.', mtError, [mbOK], 0 );
          globalEditError := true;
          exit;
        end
        else
          SQL.Add( SQLString( statictext ) ); //statusType
  		  except
        on E:Exception do
        begin
          appLog('Error Message:  ' + e.Message);
          messagebeep(0);
          appLog('STOPPING A DELPHI TRANSACTION:  dm1.dbEmerge');
          if  dm1.dbEmerge.InTransaction then
            dm1.dbEmerge.RollbackTrans;
          MessageDlg( 'Emerge Payments Web Service Failed.  Please notify help desk at 4573.'
                      + chr(10) + chr(13) + chr(10) + chr(13) + 'Detailed Message: ' + E.Message
                      + chr(10) + chr(13) + chr(10) + chr(13) + 'Payment Cancelled.', mtError, [mbOK], 0 );
          globalEditError := true;
          exit;
        end;
      end;

      SQL.Add( SQLString( '' ) ); //statusReasonDescription
      SQL.Add( SQLCurrency( StrToFloat( stripThousandSeparators( edAmount_Paid.Text ) ) ) ); //requestedPaymentAmt
      SQL.Add( SQLString( cboExpenseCategories.Text ) ); //expenseCategoryName
      SQL.Add( SQLString( cboExpenseTypes.Text ) ); //expenseTypeName
      SQL.Add( SQLString( cboFrequency.Text ) ); // frequencyType
      SQL.Add( SQLInteger( numberOfPayments ) ); //numberOfPaymentsQty

      if edNum_of_Payments.Text = '1' then
      begin
        SQL.Add( SQLString( FormatDateTime( 'yyyy/mm/dd', StrToDateTime( edDate_Pd_From_Cheq.Text ) ) ) ); //fromDate
        SQL.Add( SQLString( FormatDateTime( 'yyyy/mm/dd', StrToDateTime( edDate_Pd_To_Cheq.Text ) ) ) ); //toDate
      end
      else //if there is more than one payment, then calculate
      begin
        if cboFrequency.Text = 'Bi-weekly' then
        begin
          //for Bi-Weekly payments, fromDate will always be 14 days in the future
          fromDate := fromDate + 14;
          SQL.Add( SQLString( FormatDateTime( 'yyyy/mm/dd', fromDate ) ) ); //fromDate
          //for Bi-Weekly payments, toDate will always be 14 days in the future
          toDate := toDate + 14;
          SQL.Add( SQLString( FormatDateTime( 'yyyy/mm/dd', toDate ) ) ); //toDate
        end
        else
        if cboFrequency.Text = 'Monthly' then
        begin
          //getFromDate
          fromDate := IncMonth( fromDate, 1 );
          SQL.Add( SQLString( FormatDateTime( 'yyyy/mm/dd', fromDate ) ) ); //fromDate
          //getToDate
          toDate := IncMonth( toDate, 1 );
          DecodeDate(toDate, tYear, tMonth, tDay);
          toDate := encodeDate( tYear, tMonth, MonthDays[IsLeapYear(tYear), tMonth] );
          SQL.Add( SQLString( FormatDateTime( 'yyyy/mm/dd', toDate ) ) ); //toDate
        end;
      end;

      if ( ( payClaim.CFIO = 'Y' ) and ( cboPayeeCode.Text = 'Employer' ) ) then //informationOnlyFlag
      begin
        SQL.Add( SQLString( 'Y' ) );
      end
      else
      begin
        SQL.Add( SQLString( 'N' ) );
      end;

      if ( statictext = 'Approved' ) then
      begin
        SQL.Add( SQLString( UserProfile.loginName ) ); //approvedByLoginName
      end
      else
      begin
        SQL.Add( 'NULL,' ); //approvedByLoginName
      end;

      SQL.Add( SQLString( FormatDateTime( 'yyyy/mm/dd', utilmod1.getEmergeBusinessDate() ) ) ); //businessDate
      SQL.Add( SQLString( UserProfile.loginName ) ); //creationLoginName
      s := SQLString( FormatDateTime( 'yyyy/mm/dd HH:mm:ss', Now() ) ); //creationDatetime
      s := copy( s, 1, length( s ) -1 );   //remove the trailing comma
      SQL.Add( s );
      SQL.Add(')');

      execSQL;   //Execute Insert

      if (statictext = 'Approved') then
        updateClaimPaymentSummary( testRequestedAmt );

      if ( statictext = 'Pending Payment - Threshold Amount' ) then
      begin
        //Trigger the "Wage Loss Pending Payment - Threshold Amount" event in Emerge
        triggerCreateTaskEvent( WAGELOSS_PENDING_PAYMENT_THRESHOLD_AMOUNT_EVENT_NAME, '' );
      end;

      if ( statictext = 'Pending Payment - Threshold Date' ) then
      begin
        //Trigger the "Wage Loss Pending Payment - Threshold Date" event in Emerge
        triggerCreateTaskEvent( WAGELOSS_PENDING_PAYMENT_THRESHOLD_DATE_EVENT_NAME, '' );
      end;
    end
  except
  on E:Exception do
    begin
      appLog('Error Message:  ' + e.Message);
      messagebeep(0);
      appLog('STOPPING A DELPHI TRANSACTION:  dm1.dbEmerge');
      if  dm1.dbEmerge.InTransaction then
        dm1.dbEmerge.RollbackTrans;
      MessageDlg( 'Emerge PaymentRequest Record Creation Failed.  Please notify help desk at 4573.'
                + chr(10) + chr(13) + chr(10) + chr(13) + 'Detailed Message: ' + E.Message
                + chr(10) + chr(13) + chr(10) + chr(13) + 'Payment Cancelled.' , mtError, [mbOK], 0 );
      globalEditError := true;
    end;
  end;
  result := paymentRequestId;
  appLog('Leaving createPaymentRequestRecord');
end;

(******************************************************************************)
(*                                                                            *)
(*  Process to create a New Payment Item Record                               *)
(*                                                                            *)
(******************************************************************************)
function TWagelossPaymentForm.createPaymentItemRecord( fromDate, toDate : TDateTime; aPaymentRequestId : Integer; aPaymentRequestStatus : string; addPlannedRecoveryAmt : boolean ): Integer;
var
  industryCode, firmSuffix, s, t, coverageType : string;
  paymentItemId, firmNo : Integer;
  dueDate : TDateTime;
begin
  appLog('Entering createPaymentItemRecord(fromDate, toDate, ' + format( '%d', [ aPaymentRequestId ] ) + ', ' + aPaymentRequestStatus + ', addPlannedRecoveryAmt)');
  industryCode := getIndustryCode;
  coverageType := getCoverageType;
  firmNo := StrToInt( payClaim.Prime_Firm_No );
  firmSuffix := getFirmSuffix;
  paymentItemId := 0;

  try
  paymentItemId := uGlobal.getNextKey('PaymentItem_Sequence', 1, -1 );
  with dm1.qryPaymentItem do
  begin
    if Active then
      Close;

    SQL.Clear;

	  SQL.Add( 'INSERT INTO PaymentItem ');
		SQL.Add( '( paymentItemId, ');
		SQL.Add( '  paymentRequestId, ');
		SQL.Add( '  claimNo, ');
		SQL.Add( '  plannedRecoveryAmt, ');
		SQL.Add( '  statusType, ');
		SQL.Add( '  paidAmt, ');
		SQL.Add( '  advancesAmt, ');
		SQL.Add( '  recoveryAmt, ');
		SQL.Add( '  fromDate, ');
		SQL.Add( '  toDate, ');
		SQL.Add( '  dueDate, ');
		SQL.Add( '  daysPaidQty, ');
		SQL.Add( '  weeksPaidQty, ');
		SQL.Add( '  wcbAnnuityEarningsAmt, ');
		SQL.Add( '  workerAnnuityEarningsAmt, ');
		SQL.Add( '  wcbAnnuityContributionAmt, ');
		SQL.Add( '  workerAnnuityContributionAmt, ');
		SQL.Add( '  businessDate, ');
		SQL.Add( '  associatedNoteFlag, ');
		SQL.Add( '  industryCode, ');
		SQL.Add( '  firmNo, ');
		SQL.Add( '  firmSuffix, ');
    SQL.Add( '  cancelReasonDescription, ');
		SQL.Add( '  creationLoginName, ');
		SQL.Add( '  creationDatetime, ');
    SQL.Add( '  actualDaysPaidQty, ');
    SQL.Add( '  actualWeeksPaidQty, ');
    SQL.Add( '  coverageType ) ');
		SQL.Add('VALUES( ');
		SQL.Add( SQLInteger( paymentItemId ) ); //paymentItemId
		SQL.Add( SQLInteger( aPaymentRequestId ) ); //paymentRequestId
		SQL.Add( SQLInteger( StrToInt( payClaim.Claim_No ) ) ); //claimNo

    if addPlannedRecoveryAmt then
    begin
		  if plannedRecoveryAmt = '' then
  		  SQL.Add( 'NULL,' ) //plannedRecoveryAmt
  		else
  		  SQL.Add( SQLCurrency( StrToCurr( stripThousandSeparators( plannedRecoveryAmt ) ) ) ); //plannedRecoveryAmt
    end
    else
    begin
 		  SQL.Add( 'NULL,' ) //plannedRecoveryAmt
    end;

		SQL.Add( SQLString( aPaymentRequestStatus ) ); //statusType
		SQL.Add( SQLInteger( 0 ) );; //paidAmt
    SQL.Add( SQLInteger( 0 ) );  //advancesAmt
		SQL.Add( SQLInteger( 0 ) ); //recoveryAmt

		//if it's the first time through set values to screen
		if addPlannedRecoveryAmt then
		begin
		  SQL.Add( SQLString( FormatDateTime( 'yyyy/mm/dd', StrToDateTime( edDate_Pd_From_Cheq.Text ) ) ) ); //fromDate
		  SQL.Add( SQLString( FormatDateTime( 'yyyy/mm/dd', StrToDateTime( edDate_Pd_To_Cheq.Text ) ) ) ); //toDate
      SQL.Add( SQLString( FormatDateTime( 'yyyy/mm/dd', StrToDateTime( edDueDate.Text ) ) ) ); //dueDate
		end
		else //if there is more than one payment, then calculate
		begin
      if cboFrequency.Text = 'Bi-weekly' then
      begin
        SQL.Add( SQLString( FormatDateTime( 'yyyy/mm/dd', fromDate ) ) ); //fromDate
        SQL.Add( SQLString( FormatDateTime( 'yyyy/mm/dd', toDate ) ) ); //toDate
      end
      else if cboFrequency.Text = 'Monthly' then
      begin
        SQL.Add( SQLString( FormatDateTime( 'yyyy/mm/dd', fromDate ) ) ); //fromDate
        SQL.Add( SQLString( FormatDateTime( 'yyyy/mm/dd', toDate ) ) ); //toDate
      end;

		  //dueDate := toDate - 4;
      dueDate := calculateDueDate( toDate );
		  SQL.Add( SQLString( FormatDateTime( 'yyyy/mm/dd', dueDate ) ) );  //dueDate
		end;

    SQL.Add( SQLCurrency( StrToFloat( cleanNumber(edReducedNoDaysToPay.Text) ) ) ); //daysPaidQty
		SQL.Add( SQLCurrency( StrToFloat( edReducedNoWeeksToPay.Text ) ) ); //weeksPaidQty

    //If either (WCB or Worker) contribution is zero, the corresponding earnings is zero
    if ( edPayment_WCB_Contrib.Text = '0.00' )then  //wcbAnnuityContributionAmt
      SQL.Add( SQLCurrency( StrToCurr( '0.00' ) ) ) //wcbAnnuityEarningsAmt
    else
      SQL.Add( SQLCurrency( StrToCurr( stripThousandSeparators( edPayment_Anty_Earn.Text ) ) ) ); //wcbAnnuityEarningsAmt

    if ( edPayment_Clmt_Contrib.Text = '0.00' )then  //workerAnnuityContributionAmt
      SQL.Add( SQLCurrency( StrToCurr( '0.00' ) ) ) //workerAnnuityEarningsAmt
    else
      SQL.Add( SQLCurrency( StrToCurr( stripThousandSeparators( edPayment_Anty_Earn.Text ) ) ) ); //workerAnnuityEarningsAmt

    SQL.Add( SQLCurrency( StrToCurr( stripThousandSeparators( edPayment_WCB_Contrib.Text ) ) ) ); //wcbAnnuityContributionAmt
   	SQL.Add( SQLCurrency( StrToCurr( stripThousandSeparators( edPayment_Clmt_Contrib.Text ) ) ) ); //workerAnnuityContributionAmt

		SQL.Add( SQLString( FormatDateTime( 'yyyy/mm/dd', utilmod1.getEmergeBusinessDate() ) ) );  //businessDate
		SQL.Add( SQLString( 'N' ) ); //???? associatedNoteFlag
		SQL.Add( SQLString( industryCode ) ); //industryCode
		SQL.Add( SQLInteger( firmNo ) ); //firmNo
		SQL.Add( SQLString( firmSuffix ) ); //firmSuffix
    if (aPaymentRequestStatus = 'Cancelled') then //cancelReasonDescription
      SQL.Add(SQLString( 'Auto-approved initial cyclical payment' ))
    else
      SQL.Add( 'NULL,' );

		SQL.Add( SQLString( UserProfile.loginName ) ); //creationLoginName
    SQL.Add( SQLString( FormatDateTime( 'yyyy/mm/dd HH:mm:ss', Now() ) ) ); //creationDatetime
    SQL.Add( SQLCurrency( StrToFloat( cleanNumber(edNo_Days_Paid.Text) ) ) ); //daysPaidQty
    SQL.Add( SQLCurrency( StrToFloat( edNo_Weeks_Paid.Text ) ) ); //daysPaidQty
		s :=  SQLString( coverageType ); //coverageType
		//s := SQLString( FormatDateTime( 'yyyy/mm/dd HH:mm:ss', Now() ) ); //creationDatetime
		s := copy( s, 1, length( s ) -1 );   //remove the trailing comma
		SQL.Add( s );
    SQL.Add(')');
    t := SQL.Text;
    dm1.qryPaymentItem.ExecSQL;   //Execute Insert
  end
  except
  on E:Exception do
    begin
      appLog('Error Message:  ' + e.Message);
      messagebeep(0);
      appLog('STOPPING A DELPHI TRANSACTION:  dm1.dbEmerge');
      if  dm1.dbEmerge.InTransaction then
        dm1.dbEmerge.RollbackTrans;
      MessageDlg( 'Emerge PaymentItem Record Creation Failed.  Please notify help desk at 4573.'
                + chr(10) + chr(13) + chr(10) + chr(13) + 'Detailed Message: ' + E.Message
                + chr(10) + chr(13) + chr(10) + chr(13) + 'Payment Cancelled.', mtError, [mbOK], 0 );
      globalEditError := true;
    end;
  end;
  result := paymentItemId;
  appLog('Leaving createPaymentItemRecord');
end;

(******************************************************************************)
(*                                                                            *)
(*  Create a new WagelossPaymentRequest                                       *)
(*                                                                            *)
(******************************************************************************)
function TWagelossPaymentForm.createWageLossPaymentRequestRecord ( aPaymentRequestId : Integer ): boolean;
begin
  appLog('Entering createWageLossPaymentRequestRecord(' + format( '%d', [ aPaymentRequestId ] ) + ')');
  result := true;
  try
	  with dm1.qryWageLossPaymentRequest do
	     begin
	     if Active then
	        Close;
	     Parameters.ParamByName( 'intPaymentRequestId' ).Value :=  aPaymentRequestId;
	     Open;
	     Insert;
	     dm1.qryWageLossPaymentRequestpaymentRequestId.Value := aPaymentRequestId; //paymentRequestId
	     dm1.qryWageLossPaymentRequestwageLossCalcFactorId.Value := payClaim.Uniqueness; //wageLossCalcFactorId
	     dm1.qryWageLossPaymentRequestpaymentType.Value := cboPaymentType.Text;  //paymentType

       if nc_override then //manualCalculationFlag
	        dm1.qryWageLossPaymentRequestmanualCalculationFlag.Value := 'Y'
	     else
	        dm1.qryWageLossPaymentRequestmanualCalculationFlag.Value := 'N';

       if ( ( cboRsnForPayChng2.Text = 'Employer Top Up' ) and ( cboRsnForPayChng2.Visible = true ) ) then //employerTopUpFlag
          dm1.qryWageLossPaymentRequestemployerTopUpFlag.Value := 'Y'
       else
          dm1.qryWageLossPaymentRequestemployerTopUpFlag.Value := 'N';

       dm1.qryWageLossPaymentRequestlossOfEarningsDate.Value := StrToDate( edLoss_Earn_Date.Text );  //lossOfEarningsDate
       dmGeneric.SaveChanges(dm1.dbEmerge,[ dm1.qryWageLossPaymentRequest ],False);
       end
  except
	   on E:Exception do
	      begin
        appLog('Error Message:  ' + e.Message);
	      messagebeep(0);
        appLog('STOPPING A DELPHI TRANSACTION:  dm1.dbEmerge');
        if  dm1.dbEmerge.InTransaction then
           dm1.dbEmerge.RollbackTrans;
	      MessageDlg( 'Emerge WageLossPaymentRequest Record Creation Failed.  Please notify help desk at 4573.'
	                + chr(10) + chr(13) + chr(10) + chr(13) + 'Detailed Message: ' + E.Message
	                + chr(10) + chr(13) + chr(10) + chr(13) + 'Payment Cancelled.', mtError, [mbOK], 0 );
	      globalEditError := true;
	      result := false;
	      end;
  end;
  appLog('Leaving createWageLossPaymentRequestRecord');
end;

(******************************************************************************)
(*                                                                            *)
(*  Create new payment messages for a payment item.                           *)
(*                                                                            *)
(******************************************************************************)
function TWagelossPaymentForm.createPaymentItemMessages ( aPaymentItemId : Integer ): boolean;
var
  paymentItemMessageId, remittanceMessageId, i : Integer;
  isFound:Boolean;
begin
  appLog('Entering createPaymentItemMessages(' + format( '%d', [ aPaymentItemId ] ) + ')');
  result := true;
  cdsChequeMessages.CreateDataSet;

  cdsChequeMessages.Open;
  cdsChequeMessages.EmptyDataSet;
  if length( edMessage_Code_A.Text ) > 0 then
     begin
     cdsChequeMessages.Insert;
     cdsChequeMessages.FieldByName('legacyCode').Value := edMessage_Code_A.Text;
     cdsChequeMessages.FieldByName('remittanceMessageId').Value := edMessage_ID_A.Text;
     cdsChequeMessages.Post;
     end;
  if length( edMessage_Code_B.Text ) > 0 then
     begin
     cdsChequeMessages.Insert;
     cdsChequeMessages.FieldByName('legacyCode').Value := edMessage_Code_B.Text;
     cdsChequeMessages.FieldByName('remittanceMessageId').Value := edMessage_ID_B.Text;
     cdsChequeMessages.Post;
     end;
  if length( edMessage_Code_C.Text ) > 0 then
     begin
     cdsChequeMessages.Insert;
     cdsChequeMessages.FieldByName('legacyCode').Value := edMessage_Code_C.Text;
     cdsChequeMessages.FieldByName('remittanceMessageId').Value := edMessage_ID_C.Text;
     cdsChequeMessages.Post;
     end;

  //
  //take the message code field(s) and write it to paymentrequestmessage
  //
  try
    cdsChequeMessages.First;
    while not cdsChequeMessages.Eof do
       begin
       try
          with dm1.qryPaymentItemMessage do
             begin
             paymentItemMessageId := uGlobal.getNextKey('PaymentItemMessage_Sequence', 1, -1 );
             remittanceMessageId := cdsChequeMessages.FieldByName( 'remittanceMessageId').AsInteger;
             if Active then
                Close;
             Parameters.ParamByName( 'intPaymentItemMessageId' ).Value :=  paymentItemMessageId;
             Open;
             Insert;
             dm1.qryPaymentItemMessagepaymentItemMessageId.Value := paymentItemMessageId; //paymentItemMessageId
             dm1.qryPaymentItemMessagepaymentItemId.Value := aPaymentItemId; //paymentItemId
             dm1.qryPaymentItemMessageremittanceMessageId.Value := remittanceMessageId; //remittanceMessageId
             dmGeneric.SaveChanges(dm1.dbEmerge,[ dm1.qryPaymentItemMessage ],False);
             end;
       finally
          cdsChequeMessages.Next;
       end;
       end;
    cdsChequeMessages.Close;
  except
  on E:Exception do
    begin
      appLog('Error Message: ' + e.Message);
      messagebeep(0);
      appLog('STOPPING A DELPHI TRANSACTION:  dm1.dbEmerge');
      if  dm1.dbEmerge.InTransaction then
        dm1.dbEmerge.RollbackTrans;
      MessageDlg( 'Emerge PaymentItem Record Creation Failed.  Please notify help desk at 4573.'
                  + chr(10) + chr(13) + chr(10) + chr(13) + 'Detailed Message: ' + E.Message
                  + chr(10) + chr(13) + chr(10) + chr(13) + 'Payment Cancelled.', mtError, [mbOK], 0 );
      globalEditError := true;
      result := false;
    end;
  end;
  appLog('Leaving createPaymentItemMessages');
end;

(******************************************************************************)
(*                                                                            *)
(*  Update the Claim with the new loss of earnings date.                      *)
(*                                                                            *)
(******************************************************************************)
function TWagelossPaymentForm.updateLossOfEarnings (  ): boolean;
begin
  appLog('Entering updateLossOfEarnings');
  result := true;
  try
    with dm1 do
    begin
      if qryGeneralEmerge.Active then
        qryGeneralEmerge.Close;
      //Update loss of earnings date in claim table
      qryGeneralEmerge.SQL.Clear;
      qryGeneralEmerge.SQL.Add( 'UPDATE Claim SET');
  		qryGeneralEmerge.SQL.Add( '		lossOfEarningsDate = ''' +  FormatDateTime( 'mm/dd/yyyy h:nn:ss', StrToDateTime( edLoss_Earn_Date.Text ) ) + ''',' ); //lossOfEarningsDate
      qryGeneralEmerge.SQL.Add( '		modificationDatetime = ''' +  FormatDateTime( 'mm/dd/yyyy h:nn:ss', Now ) + ''',' ); //modificationDatetime
      qryGeneralEmerge.SQL.Add( '		modificationLoginName = ''' +  UserProfile.loginName + '''' ); //modificationLoginName
      qryGeneralEmerge.SQL.Add( ' WHERE claimNo = ' + dataClaim.Claim_No );
      qryGeneralEmerge.ExecSQL;
      qryGeneralEmerge.Close;
    end; //with dm1
  except
  on E:Exception do
    begin
      appLog('Error Message: ' + e.Message);
      messagebeep(0);
      appLog('STOPPING A DELPHI TRANSACTION:  dm1.dbEmerge');
      if  dm1.dbEmerge.InTransaction then
        dm1.dbEmerge.RollbackTrans;
      MessageDlg( 'Loss Of Earnings Date not updated in Claim table.  Please notify help desk at 4573.'
                    + chr(10) + chr(13) + chr(10) + chr(13) + 'Detailed Message: ' + E.Message
                    + chr(10) + chr(13) + chr(10) + chr(13) + 'Payment Cancelled.', mtError, [mbOK], 0 );
      globalEditError := true;
      result := false;
    end;
  end;
  appLog('Leaving updateLossOfEarnings');
end;

(******************************************************************************)
(*                                                                            *)
(*  Update the WagelossCalcFactor with the new loss of earnings date, reduced *)
(*  number of weeks to pay and reduced number of days to pay.                 *)
(*                                                                            *)
(******************************************************************************)
function TWagelossPaymentForm.updateWagelossCalcFactor (  ): boolean;
var
  s : String;
begin
  appLog('Entering updateWagelossCalcFactor');
  result := true;
  try
    with dm1 do
    begin
      if query1.Active then
        query1.Close;
      //Update loss of earnings date, reducedNoDaysToPayQty, and reducedNoWeeksToPayQty in WageLossCalcFactor table
        query1.SQL.Clear;
        query1.SQL.Add( 'UPDATE WageLossCalcFactor SET');
    	  query1.SQL.Add( '		lossOfEarningsDate = ''' +  FormatDateTime( 'mm/dd/yyyy h:nn:ss', StrToDateTime( edLoss_Earn_Date.Text ) ) + ''',' );
        query1.SQL.Add( '		reducedNoDaysToPayQty = ' +  SQLCurrency( StrToFloat( cleanNumber(edReducedNoDaysToPay.Text) ) ) + '' );
				          s := '		reducedNoWeeksToPayQty = ' + SQLCurrency( StrToFloat( edReducedNoWeeksToPay.Text ) );
				          s := copy( s, 1, length( s ) -1 );   //remove the trailing comma
        query1.SQL.Add( s );
        query1.SQL.Add( ' WHERE wageLossCalcFactorId = ' + IntToStr( dataClaim.Uniqueness ) );
        query1.ExecSQL;
        query1.Close;
    end; //with dm1
  except
  on E:Exception do
    begin
      appLog('Error Message: ' + e.Message);
      messagebeep(0);
      appLog('STOPPING A DELPHI TRANSACTION:  dm1.dbEmerge');
      if  dm1.dbEmerge.InTransaction then
        dm1.dbEmerge.RollbackTrans;
      MessageDlg( 'Loss Of Earnings Date not updated in WageLossCalcFactor table.  Please notify help desk at 4573.'
                    + chr(10) + chr(13) + chr(10) + chr(13) + 'Detailed Message: ' + E.Message
                    + chr(10) + chr(13) + chr(10) + chr(13) + 'Payment Cancelled.', mtError, [mbOK], 0 );
      globalEditError := true;
      result := false;
    end; //try
  end;
  appLog('Leaving updateWagelossCalcFactor');
end;

(******************************************************************************)
(*                                                                            *)
(*  Update the claim ClaimPaymentSummary with the payment requested amount.   *)
(*                                                                            *)
(******************************************************************************)
function TWagelossPaymentForm.updateClaimPaymentSummary( aRequestAmount : double ): boolean;
var
  thresholdAmt : currency;
  s : string;
begin
  appLog('Entering updateClaimPaymentSummary(' + format( '%.2n', [ aRequestAmount ] ) + ')');
  result := true;
  try
    with dm1.qryGeneralEmerge do
    begin
      close;
      SQL.Clear;
      SQL.Add( 'SELECT ' );
  	  SQL.Add( 'wagelossThresholdTotalAmt ' );
      SQL.Add( 'FROM ClaimPaymentSummary ' );
      SQL.Add( 'WHERE claimNo = ' +  payClaim.Claim_No );
      Open;
      First;

      thresholdAmt := FieldByName( 'wagelossThresholdTotalAmt' ).AsCurrency;
      thresholdAmt := thresholdAmt + StrToFloat( stripThousandSeparators( FloatToStr( aRequestAmount ) ) );

      SQL.Clear;
      SQL.Add( 'UPDATE ClaimPaymentSummary ' );
  	  SQL.Add( 'SET wagelossThresholdTotalAmt = ' );
      s := SQLCurrency( thresholdAmt ); //wagelossThresholdTotalAmt
      s := copy( s, 1, length( s ) -1 );   //remove the trailing comma
      SQL.Add( s + ' ' );
      SQL.Add( 'WHERE claimNo = ' + payClaim.Claim_No );
      execSQL;   //Execute Insert
    end;
  except
  on E:Exception do
    begin
      appLog('Error Message: ' + e.Message);
      messagebeep(0);
      appLog('STOPPING A DELPHI TRANSACTION:  dm1.dbEmerge');
      if  dm1.dbEmerge.InTransaction then
        dm1.dbEmerge.RollbackTrans;
      MessageDlg( 'ClaimPaymentSummary Update Failed.  Please notify help desk at 4573.'
                   + chr(10) + chr(13) + chr(10) + chr(13) + 'Detailed Message: ' + E.Message, mtError, [mbOK], 0 );
      globalEditError := true;
      result := false;
    end;
  end;
  appLog('Leaving updateClaimPaymentSummary');
end;

procedure TWagelossPaymentForm.savePaymentInfo( aPayeeId : Integer );
var
  paymentItemId, paymentItemId2, i, numberOfPayments, paymentRequestId, paymentRequestId2 : Integer;
  fromDate, toDate : TDateTime;
  tYear, tMonth, tDay : Word;
  bError : boolean;

begin
  appLog('Entering savePaymentInfo(' + format( '%d', [ aPayeeId ] ) + ')');
  numberOfPayments := StrToInt( edNum_of_Payments.Text );
  fromDate := StrToDateTime( edDate_Pd_From_Cheq.Text );
  toDate := StrToDateTime( edDate_Pd_To_Cheq.Text );
  savedPaymentRequestStatus := '';
  bError := false;

  //dm1.dbEmerge.StartTransaction;
  //create payment records for the number of payments requested
  paymentRequestId := createPaymentRequestRecord(aPayeeId, 0, '');
  if ( paymentRequestId > 0 ) then
  begin
    For i := 0 to numberOfPayments - 1 do
    begin
      if i > 0 then
			begin
        if cboFrequency.Text = 'Bi-weekly' then
        begin
          //for Bi-Weekly payments, fromDate will always be 14 days in the future
          fromDate := fromDate + 14;
          //for Bi-Weekly payments, toDate will always be 14 days in the future
          toDate := toDate + 14;
        end
        else
        if cboFrequency.Text = 'Monthly' then
        begin
          //getFromDate
          fromDate := IncMonth( fromDate, 1 );
          //getToDate
          toDate := IncMonth( toDate, 1 );
          DecodeDate(toDate, tYear, tMonth, tDay);
          toDate := encodeDate( tYear, tMonth, MonthDays[IsLeapYear(tYear), tMonth] );
        end;
        paymentItemId := createPaymentItemRecord( fromDate, toDate, paymentRequestId, savedPaymentRequestStatus, False);
      end
      else
        if (copy(savedPaymentRequestStatus, 1, 4) = 'Pend') and (numberOfPayments <> 1) then
        begin
          paymentItemId := createPaymentItemRecord( fromDate, toDate, paymentRequestId, 'Cancelled', True);
          paymentRequestId2 := createPaymentRequestRecord(aPayeeId, 1, 'Approved');
          paymentItemId2 := createPaymentItemRecord( fromDate, toDate, paymentRequestId2, 'Approved', True);
          bError := not createWageLossPaymentRequestRecord(paymentRequestId2);
          if not bError then
            bError := not createPaymentItemMessages( paymentItemId2 );
        end
        else
        begin
        paymentItemId := createPaymentItemRecord( fromDate, toDate, paymentRequestId, savedPaymentRequestStatus, True);
        end;

      if (not bError and (i = 0)) then
        bError := not createWageLossPaymentRequestRecord(paymentRequestId);

      if not bError then
        bError := not createPaymentItemMessages( paymentItemId );

      if not bError then
        bError := not updateLossOfEarnings(  );

      if not bError then
        bError := not updateWagelossCalcFactor( );
    end;//end for
    //if bError then
    //begin
    //  globalEditError = true;
    //end
    //else
    //begin
    //  if  dm1.dbEmerge.InTransaction then
    //    dm1.dbEmerge.rollback;
    //  exit;
    //end;

  end
  else
  begin
    MessageDlg( 'Error saving Payment Information.  Please call Help Desk at 4573.', mtError, [mbOK], 0 );
    globalEditError := true;
  end;

  if bError then
  begin
    //if  dm1.dbEmerge.InTransaction then
    //  dm1.dbEmerge.Rollback;
    //messagebeep(0);
    MessageDlg( 'Emerge Payment Record Creation Failed.  Please notify help desk at 4573.', mtError, [mbOK], 0 );
    globalEditError := true;
  end;
  appLog('Leaving savePaymentInfo');
end;

procedure TWagelossPaymentForm.triggerCreateTaskEvent( const aTaskName, aPropertyExtension: String );
var
	ep:TEventPublisher;
begin
  appLog('Entering triggerCreateTaskEvent(' + aTaskName + ', ' + aPropertyExtension + ')');
  try
    ep := TEventPublisher.create( dm1.dbSharedLookup, dm1.dbEmerge, HTTPHOST, 'WAGELOSS', userProfile.loginName, '');

    ep.publishTaskEvent( MQMANAGERNAME, aTaskName, payClaim.Claim_No, aPropertyExtension );
	except
    on e:Exception do
    begin
      appLog('Error Message: ' + e.Message);
      appLog('STOPPING A DELPHI TRANSACTION:  dm1.dbEmerge');
      if  dm1.dbEmerge.InTransaction then
        dm1.dbEmerge.RollbackTrans;
		  showAppMessage(e.Message, 2);
    end;
	end;
  appLog('Leaving triggerCreateTaskEvent');
end;

function TWagelossPaymentForm.stripThousandSeparators( aString : String ) : String;
var
  i : integer;
// ThousandSeparator is defined in SysUtils. See date/time formatting
//variables in help
begin
  result := aString;
  i := pos (FormatSettings.ThousandSeparator, result);
  while i > 0 do
     begin
     Delete (result, i, 1);
     i := pos (FormatSettings.ThousandSeparator, result);
     end;
end;

function TWagelossPaymentForm.getFirmSuffix : String;
var
  firmSuffix : String;
begin
  try
    with dm1.qryGeneralEmerge do
    begin
      if Active then
        Close;
      SQL.Clear;
      SQL.Add( 'SELECT firmSuffix ' );
      SQL.Add( 'FROM Claim ' );
      SQL.Add( 'WHERE claimNo = ' + dataClaim.Claim_No );
      Open;

      firmSuffix := FieldByName( 'firmSuffix').AsString;
      Close;
    end;
  except
    on E:Exception do
    Begin
      appLog('Error Message: ' + e.Message);
      result := '';
      dm1.qryGeneralEmerge.Close;
      WagelossMainForm.ShowInfoLine2( '*Firm Suffix not found' );
      exit;
    end;//exception
  end;//try/except

  result := firmSuffix;
end;

function TWagelossPaymentForm.getIndustryCode : String;
var
  industryCode : String;
begin
  try
    with dm1.qryGeneralEmerge do
    begin
      if Active then
        Close;
      SQL.Clear;
      SQL.Add( 'SELECT industryCode ' );
      SQL.Add( 'FROM Claim ' );
      SQL.Add( 'WHERE claimNo = ' + dataClaim.Claim_No );
      Open;

      industryCode := FieldByName( 'industryCode').AsString;
      Close;
    end;
  except
    on E:Exception do
    Begin
      appLog('Error Message: ' + e.Message);
      result := '';
      dm1.qryGeneralEmerge.Close;
      WagelossMainForm.ShowInfoLine2( '*Industry Code not found' );
      exit;
    end;//exception
  end;//try/except

  result := industryCode;
end;

function TWagelossPaymentForm.getCoverageType : String;
var
  coverageType : String;
begin
  try
    with dm1.qryGeneralEmerge do
    begin
      if Active then
        Close;
      SQL.Clear;
      SQL.Add( 'SELECT coverageType ' );
      SQL.Add( 'FROM Claim ' );
      SQL.Add( 'WHERE claimNo = ' + dataClaim.Claim_No );
      Open;

      coverageType := FieldByName( 'coverageType').AsString;
      Close;
    end;
  except
    on E:Exception do
    Begin
      appLog('Error Message: ' + e.Message);
      result := '';
      dm1.qryGeneralEmerge.Close;
      WagelossMainForm.ShowInfoLine2( '*Coverage Type not found' );
      exit;
    end;//exception
  end;//try/except

  result := coverageType;
end;

//Search OverpaymentAccount to see if there is an outstanding amount for the payee
function TWagelossPaymentForm.searchOverpaymentAccount( aPayeeId : Integer; aPayeeType : String ): boolean;
var
  WLTop, WLLeft, payeeId : Integer;
  payeeType : String;
  totalOutstandingReceivableAmt : currency;
  outstandingPaymentSQL:String;
begin
  WLTop := 0;
  WLLeft := 0;
  payeeId := aPayeeId;
  payeeType := aPayeeType;
  plannedRecoveryAmt := '';

  try
    with dm1 do
    begin
      if qryGeneralEmerge.Active then
         qryGeneralEmerge.Close;
      //
      //Select PayeeId if payee is Claimant
      //
      qryGeneralEmerge.SQL.Clear;

      outstandingPaymentSQL := 'SELECT overpaymentAccount.totalOutstandingReceivableAmt ' +
                               'FROM OverpaymentAccount overpaymentAccount ' +
                               'WHERE overpaymentAccount.payeeId = :payeeId ' +
                               'AND overpaymentAccount.payeeType = :payeeType';

      //qryGeneralEmerge.SQL.Add( 'SELECT overpaymentAccount.totalOutstandingReceivableAmt ' );
      //qryGeneralEmerge.SQL.Add( 'FROM OverpaymentAccount overpaymentAccount ' );
      //qryGeneralEmerge.SQL.Add( 'WHERE overpaymentAccount.payeeId = ' + IntToStr(payeeId) );
      //qryGeneralEmerge.SQL.Add( ' AND overpaymentAccount.payeeType = ' + QuotedStr(payeeType) );
      qryGeneralEmerge.SQL.Text := outstandingPaymentSQL;
      qryGeneralEmerge.Parameters.ParamByName('payeeId').Value := payeeId;
      qryGeneralEmerge.Parameters.ParamByName('payeeType').Value := payeeType;
      qryGeneralEmerge.Open;
      totalOutstandingReceivableAmt := qryGeneralEmerge.FieldByName( 'totalOutstandingReceivableAmt').AsCurrency;
      qryGeneralEmerge.Close;
      //
      //if there is an outstanding amount, display a screen
      //if there is not an outstanding amount, countinue processing.
      //
      if totalOutstandingReceivableAmt > 0 then
      begin
        try
          WagelossOverpaymentRecoveryForm := TWagelossOverpaymentRecoveryForm.CreateExtended( application, payeeId , payeeType, dataClaim.Claim_No );
          WagelossOverpaymentRecoveryForm.Top := WLTop + 20;
          WagelossOverpaymentRecoveryForm.Left := WLLeft + 20;

          if ( WagelossOverpaymentRecoveryForm.ShowModal = mrOK ) then
          begin
            plannedRecoveryAmt := WagelossOverpaymentRecoveryForm.edPlannedRecoveryAmt.Text;

            if ( WagelossOverpaymentRecoveryForm.cboOverridePlannedRecovery.Text = 'No' ) then
            begin
              plannedRecoveryAmt := '';
            end;
            result := true;
          end
          else
          begin
            messageDlg( 'Overpayment Recovery Options Cancelled', mtInformation, [mbOK], 0 );
            plannedRecoveryAmt := '';
            result := false;
            exit;
          end;
        finally
          WagelossOverpaymentRecoveryForm.Free;
        end;//try
      end; //totalOutstandingReceivableAmt > 0
    end; //with dm1
  except
  end; //try
  result := true;
end;

procedure TWagelossPaymentForm.updateEmergeWagelossType;
begin

  with dm1.qEmergeCaseType do
     begin
     //dm1.dbEmerge.StartTransaction;
     try
        if Active then
           close;
        Parameters.ParamByName( 'intClaimNo').value := StrToInt( payClaim.Claim_No );
        Open;
        if FieldByName( 'wageLossType').asString = 'No Time Loss' then
           begin
           Edit;
           FieldByName( 'wageLossType').Text := 'Time Loss';
           UpdateBatch(arAll);
           //ApplyUpdates;
           //dm1.dbEmerge.Commit; {on success, commit the changes};
           end;
     except
        begin
        //dm1.dbEmerge.Rollback; {on failure, undo the changes};
        MessageDlg( 'Error updating Emerge Wage Loss Type.  Please call Help Desk at 4573.', mtError, [mbOK], 0 );
        globalEditError := true;
        end;

        raise; {raise the exception to prevent a call to CommitUpdates!}
     end;
    //CommitUpdates; {on success, clear the cache}
  end;
end;

procedure TWagelossPaymentForm.updateCISCaseType;
var
  recChanged : boolean;
  tCaseType, tComplexity : String;
begin
  recChanged := false;

  with dm1.qCISCaseType do
     begin
     appLog('STARTING A DELPHI TRANSACTION:  dm1.dbCis');
     dm1.dbCis.BeginTrans;
     try
        If Active then
           Close;
        Parameters.ParamByName( 'strClaimNo').Value := payClaim.Claim_No;
        Open;
        if RecordCount = 0 then
           //MessageDlg( 'CIS Record was not found.  Please notify help desk at 4573', mtError, [mbOK], 0 )
        else
           begin
           tCaseType := FieldByName( 'case_type').asString;
           tComplexity := FieldByName( 'complexity').asString;
           if tCaseType = 'N' then
              begin
              tCaseType := 'T';
              recChanged := True;
              end;
           if tComplexity = 'A' then
              begin
              tComplexity := 'B';
              recChanged := True;
              end;
           if recChanged then
              begin
              Edit;
              FieldByName( 'case_type').Text := tCaseType;
              FieldByName( 'complexity').Text := tComplexity;
              UpdateBatch(arAll);
              //ApplyUpdates;
              end;
           end;
        appLog('COMMITTING A DELPHI TRANSACTION:  dm1.dbCis');
        dm1.dbCis.CommitTrans; {on success, commit the changes};
     except
        MessageDlg( 'Error updating CIS Case Type.  Please call Help Desk at 4573.', mtError, [mbOK], 0 );
        globalEditError := true;
        appLog('STOPPING A DELPHI TRANSACTION:  dm1.dbCis');
        if  dm1.dbCis.InTransaction then
           dm1.dbCis.RollbackTrans; {on failure, undo the changes};
        raise; {raise the exception to prevent a call to CommitUpdates!}
     end;  // end try
     //appLog('COMMITTING A DELPHI TRANSACTION:  dm1.dbCis');
     //dm1.dbCis.CommitTrans; {on success, clear the cache}
     end; // end with
end;

procedure TWagelossPaymentForm.edMessage_Code_BExit(Sender: TObject);
begin
  if Not (Trim(edMessage_Code_B.Text) = '') then
     begin
     if not ValidateMessageCode(edMessage_Code_B, edMessage_ID_B) then
        begin
        globalEditError := displayError( '*Please enter a valid cheque message code', edMessage_Code_B );
        exit;
        end;
     end;

  ResetInfoLine2;
end;

function TWagelossPaymentForm.ValidateMessageCode(LegacyMessageBox, RemittanceMessageID: TEdit):Boolean;
var
  isFound: boolean;
  i: integer;
begin
  isFound := False;
  LegacyMessageBox.text := uppercase(LegacyMessageBox.Text);
  RemittanceMessageID.Text := '';
  if length(LegacyMessageBox.Text) > 0 then
     begin
     if LegacyMessageBox.Text <> ' ' then
        begin
        for i := low(RemittanceChequeMessages) to high(RemittanceChequeMessages) do
           begin
           if (RemittanceChequeMessages[i].legacyMesageCode = LegacyMessageBox.Text) then
              begin
              isFound := true;
              RemittanceMessageID.Text := IntToStr(RemittanceChequeMessages[i].remittenceMessageId);
              break;
              end
           end;
        end;
     end;
  result := isFound;
end;


procedure TWagelossPaymentForm.edMessage_Code_CExit(Sender: TObject);
begin
  if Not (Trim(edMessage_Code_C.Text) = '') then
     begin
     if not ValidateMessageCode(edMessage_Code_C, edMessage_ID_C) then
        begin
        globalEditError := displayError( '*Please enter a valid cheque message code', edMessage_Code_C );
        exit;
        end;
     end;

  ResetInfoLine2;
end;


procedure TWagelossPaymentForm.FormActivate(Sender: TObject);
begin
  dm1.qryPaymentType.Active := true;

  PopulatePayeeCodeDropDown;
  PopulateExpenseCategoriesDropDown;
  PopulateExpenseTypesDropDown;
  GetOverpaymentBalanceValue;
  if ( fPaymentType = iShelterRebate ) then
  begin
    edNo_Days_Paid.text := format( '%.2n', [ 0.00 ] );
    cboPaymentType.ItemIndex := 1;
    cboExpenseCategories.KeyValue := 'Adjustment';
    edNum_of_PaymentsExit(self);
    cboExpenseCategoriesExit(self);
    cboExpenseTypes.KeyValue := 'Shelter Rebate';
    edMessage_Code_A.SetFocus;
  end;

end;

procedure TWagelossPaymentForm.PopulatePayeeCodeDropDown;
begin
  GetFirmValues;
  GetAlternatePayeeValues;
  GetPaymentTypeValues;
end;

procedure TWagelossPaymentForm.PopulateExpenseCategoriesDropDown;
begin
  with dm1.qryExpenseCategories do
  begin
    Parameters.ParamByName( 'incidentYear' ).Value := Year( dataClaim.Accident_Date );
    Parameters.ParamByName( 'businessDate' ).Value := utilmod1.getEmergeBusinessDate();
    Active := true;
  end;
end;

procedure TWagelossPaymentForm.PopulateExpenseTypesDropDown;
begin
  with dm1.qryExpenseTypes do
  begin
    Parameters.ParamByName( 'incidentYear' ).Value := Year( dataClaim.Accident_Date );
    Parameters.ParamByName( 'businessDate' ).Value := utilmod1.getEmergeBusinessDate();
    Active := true;
  end;
end;

procedure TWagelossPaymentForm.GetFirmValues;
var
  firmNo : Integer;
begin
  //Add Employer to PayeeCode drop down
  try
    with dm1.qryGeneralEmerge do
    begin
      if Active then
        Close;
      SQL.Clear;
      SQL.add( 'SELECT firmNo' );
      SQL.add( 'FROM Claim ' );
      SQL.add( 'WHERE claimNo = ' + dataClaim.Claim_No );
      Open;
      firmNo := FieldByName( 'firmNo').AsInteger;
      //only add the firm if it exists
      if firmNo > 0 then
        cboPayeeCode.Items.Add( 'Employer' );
      Close;
      if ( payClaim.CFIO = 'Y' ) then
      begin
        //;Compute for Information only set Payee Code
        cboPayeeCode.ItemIndex := 1;
      end;
    end;
  finally
    ;
  end;
end;

procedure TWagelossPaymentForm.GetAlternatePayeeValues;
var
  alternatePayeeId : Integer;
  alternatePayeeName, alternatePayeeAddress, account: String;
  emergeBusinessDate, effectiveDatetime, expiryDatetime : TDateTime;
begin
  //Add Alternate Payee to PayeeCode drop down
  emergeBusinessDate := utilmod1.getEmergeBusinessDate();

  try
    with dm1.qryGeneralEmerge do
    begin
      if Active then
        Close;
      SQL.Clear;
      SQL.Add( 'SELECT alternatePayeeId, effectiveDatetime, expiryDatetime, alternatePayeeType, organizationName, firstname + '' '' + lastname AS ''alternatePayeeName'', addressLine1, accountNo ' );
      SQL.Add( 'FROM AlternatePayee ' );
      SQL.Add( 'WHERE claimNo = ' + dataClaim.Claim_No );
      SQL.Add( ' AND (alternatePayeeType LIKE ''Garnishee%'' OR alternatePayeeType LIKE ''Estate%'' OR alternatePayeeType = ''Other'' OR alternatePayeeType = ''Assignment of Benefits'')' );
      SQL.Add( 'ORDER BY alternatePayeeType' );
      Open;
      try
        First;
        while not Eof do
        begin
          try
            alternatePayeeDisplay := '';
            alternatePayeeId := FieldByName( 'alternatePayeeId').AsInteger;
            effectiveDatetime := FieldByName( 'effectiveDatetime' ).AsDateTime;
            expiryDatetime := FieldByName( 'expiryDatetime' ).AsDateTime;
            alternatePayeeType := FieldByName( 'alternatePayeeType').AsString;
            organizationName := FieldByName( 'organizationName').AsString;
            alternatePayeeName := FieldByName( 'alternatePayeeName').AsString;
            alternatePayeeAddress := FieldByName( 'addressLine1' ).AsString;
            account := FieldByName( 'accountNo' ).AsString;

            alternatePayeeDisplay := alternatePayeeDisplay + alternatePayeeType;

            if expiryDatetime = 0 then
            begin
              expiryDatetime := 99999999;
            end;

            if (
                ( alternatePayeeType = 'Garnishee - Maintenance Enforcement' ) or
                ( alternatePayeeType = 'Other' ) or
                ( alternatePayeeType = 'Estate' ) )  then
            begin
              if ( alternatePayeeName = '' ) then
              begin
                alternatePayeeDisplay := alternatePayeeDisplay + ' - ' + organizationName;
              end
              else
              begin
                alternatePayeeDisplay := alternatePayeeDisplay + ' - ' + alternatePayeeName;
              end;
            //end
            //else if (
            //    ( alternatePayeeType = 'Garnishee - Civil - Court of Queens Bench' ) or
            //    ( alternatePayeeType = 'Garnishee - Federal Orders' ) )  then
            //begin
            //  alternatePayeeDisplay := alternatePayeeDisplay + ' - ' + alternatePayeeAddress;
            end;

            //only add the payee if it exists
            if ( ( emergeBusinessDate >= effectiveDatetime ) AND
                 ( emergeBusinessDate <= expiryDatetime ) AND
                 ( alternatePayeeId > 0 ) ) then
            begin
              if (account <> '') then
                alternatePayeeDisplay := alternatePayeeDisplay + ' - ' + account;
              cboPayeeCode.Items.Add( alternatePayeeDisplay );
            end;

            //modify length of drop down box to fit values from database
            //note: property Width is in pixels.  The string method length is in chars.
            //That's the reason why we multiply 9 by the length of the display, to get an
            //approximate size for that field.  Doesn't work 100% of the time, but looks ok
            //the majority of the time.
            if ( cboPayeeCode.Width <= ( length( alternatePayeeDisplay ) * 7 ) ) then
            begin
              cboPayeeCode.Width := length( alternatePayeeDisplay ) * 7;
            end;

          finally
            Next;
          end;
        end; //while not eof
      finally
        ;
      end; //try
      Close;
    end;
  finally
    ;
  end;
end;

procedure TWagelossPaymentForm.GetPaymentTypeValues;
var
  paymentTypeValue: String;
begin
  try
    with dm1.qryGeneralEmerge do
    begin
      if Active then
        Close;
      SQL.Clear;
      SQL.add( 'SELECT im.itemDescription' );
      SQL.add( 'FROM TypeMaster tm' );
      SQL.add( '	INNER JOIN ItemMaster im ON im.typeName = tm.typeName' );
      SQL.add( 'WHERE im.typeName LIKE ''wagelossPaymentType''' );
      SQL.add( 'ORDER BY im.itemDescription' );
      Open;
      try
        First;
        while not Eof do
        begin
          try
              paymentTypeValue := FieldByName( 'itemDescription').AsString;
              cboPaymentType.Items.Add( paymentTypeValue );
          finally
            Next;
          end;
        end; //while not eof
      finally
        ;
      end; //try
      Close;
    end;
  finally
    ;
  end;
end;

procedure TWagelossPaymentForm.GetOverpaymentBalanceValue;
var
  totalOutstandingAmt,
  totalOutstandingReceivableAmt,
  totalOutstandingSuspendedAmt,
  wageLossRecoveryRateAmt : currency;
begin
  //get overpayment balance value
  try
    with dm1.qryGeneralEmerge do
    begin
      if Active then
        Close;
      SQL.Clear;
      SQL.add( 'SELECT ' );
      SQL.add( '  overpaymentAccount.wageLossRecoveryRateAmt, ' );
      SQL.add( '  overpaymentAccount.totalOutstandingAmt, ' );
      SQL.add( '  overpaymentAccount.totalOutstandingReceivableAmt, ' );
      SQL.add( '  overpaymentAccount.totalOutstandingSuspendedAmt ' );
      SQL.add( 'FROM Claim claim ' );
      SQL.add( '	INNER JOIN Claimant claimant ON claim.claimantId = claimant.claimantId ' );
      SQL.add( '	INNER JOIN PayeeClaimant payeeClaimant ON claimant.claimantId = payeeClaimant.claimantId ' );
      SQL.add( '	INNER JOIN OverpaymentAccount overpaymentAccount ON payeeClaimant.payeeId = overpaymentAccount.payeeId ' );
      SQL.add( 'WHERE ' );
      SQL.add( '	claim.claimNo = ' + dataClaim.Claim_No );
      Open;
      wageLossRecoveryRateAmt := FieldByName( 'wageLossRecoveryRateAmt').AsCurrency;
      totalOutstandingAmt := FieldByName( 'totalOutstandingAmt').AsCurrency;
      totalOutstandingReceivableAmt := FieldByName( 'totalOutstandingReceivableAmt').AsCurrency;
      totalOutstandingSuspendedAmt := FieldByName( 'totalOutstandingSuspendedAmt').AsCurrency;

      lblCI05_Rate.Caption := format( '%.2n', [ wageLossRecoveryRateAmt ] );
      lblCI05_Balance.Caption := format( '%.2n', [ totalOutstandingAmt ] );
      lblOutstandingReceivableAmtDesc.Caption := format( '%.2n', [ totalOutstandingReceivableAmt ] );
      lblOutstandingSuspendedAmtDesc.Caption := format( '%.2n', [ totalOutstandingSuspendedAmt ] );

      Close;
    end;
  finally
    ;
  end;
end;

procedure TWagelossPaymentForm.cboFrequencyExit(Sender: TObject);
var
  wYear, wMonth, wDay: Word;
  frequency, strFromDate, strToDate, strDueDate : String;
  tDate : tDateTime;
begin
  frequency := uppercase(cboFrequency.text);

  with payClaim do
  begin
    if ( edNum_of_Payments.Text = '1' ) then
    begin
      if ( frequency <> 'ONE TIME' ) then
      begin
        globalEditError := displayError( '*Invalid Number of Payments. Number of payments must be greater than one if frequency is not equal to ''One Time''.', edNum_of_Payments );
        exit;
      end;
    end //if payments = 1
    else
    if ( frequency = 'ONE TIME' ) then
    begin
      if ( edNum_of_Payments.Text <> '1' ) then
      begin
        globalEditError := displayError( '*Invalid Number of Payments. Only 1 Payment allowed.', edNum_of_Payments );
        exit;
      end;
    end //if one time
    else
    if ( frequency = 'BI-WEEKLY' ) then
    begin
      if not NC_OVERRIDE then
        edNo_Days_Paid.text := format( '%.2n',[ 2 * Days_Worked_per_Week ] );
      //edNo_Weeks_Paid.text := format( '%.2n',[ 2.0 ] );
      selectNext(Sender as tWinControl, true, true );
      recalcAmountsToPay;
      exit;
    end //bi-weekly
    else
    if ( frequency = 'MONTHLY' ) then
    begin
      //edNo_Days_Paid.text := '22.00';
      if not NC_OVERRIDE then
        edNo_Days_Paid.text := FloatToStr( PdoxRound( dataClaim.Days_Worked_per_Week * 52 / 12, 2 ) );
      selectNext( Sender as tWinControl, true, true );

      //
      // make sure due date is next 22nd.
      //
      decodeDate( utilmod1.getEmergeBusinessDate(), wYear, wMonth, wDay);

      if day( utilmod1.getEmergeBusinessDate() ) > 22 then
      begin
        if wMonth = 12 then
        begin
          inc( wYear );
          wMonth := 1;
        end
        else
        begin
          inc( wMonth );
        end;
      end;

      tDate := encodeDate( wYear, wMonth, 1 );
      strFromDate := formatDateTime('dd/mm/yyyy', tDate);

      tDate := encodeDate( wYear, wMonth, MonthDays[IsLeapYear(wYear), wMonth] );
      strToDate := formatDateTime('dd/mm/yyyy', tDate);

      tDate := encodeDate( wYear, wMonth, 22 );
      strDueDate := formatDateTime('dd/mm/yyyy', tDate);

      edDate_Pd_From_Cheq.Text := strFromDate;
      edDate_Pd_To_Cheq.Text := strToDate;
      //edDueDate.Text := strDueDate;

      edDueDate.SetFocus;
      //edNo_Days_Paid.SetFocus;
      recalcAmountsToPay;

      // check for maximum number of payment for monthly
      if ( textAsInteger( edNum_of_Payments ) > 12 ) then
      begin
        globalEditError := displayError( '*Number of payments must be 12 or less for frequency of monthly.', edNum_of_Payments );
        exit;
      end;
    end  //if monthly
    else
    begin
      setEditToNormal(edNo_Days_Paid);
      if not NC_OVERRIDE then setEditToRead(edNo_Weeks_Paid);
      selectNext(Sender as tWinControl, true, true );
      recalcAmountsToPay;
    end;
  end; //  with payClaim do...

  ResetInfoLine2;
end;

procedure TWagelossPaymentForm.cboPayeeCodeExit(Sender: TObject);
begin
  cboPayeeCode.text := cboPayeeCode.text;

  if (cboRsnForPayChng2.Visible) then
  begin
    cboRsnForPayChng2.ItemIndex := 0;
    cboRsnForPayChng2.SetFocus;
  end;

  if cboPayeeCode.Text = '' then
  begin
    globalEditError := displayError( '*Please enter a Payee.', cboPayeeCode );
    exit;
  end;

  ResetInfoLine2;
end;

procedure TWagelossPaymentForm.cboPayeeCodeChange(Sender: TObject);
begin
  cboRsnForPayChng2.Visible := (cboPayeeCode.text = 'Employer' );
  if (cboRsnForPayChng2.Visible) then
  begin
    cboRsnForPayChng2.ItemIndex := 0;
  end;
end;

procedure TWagelossPaymentForm.cboFrequencyChange(Sender: TObject);
begin
  with payClaim do
  begin
    if ( uppercase( cboFrequency.Text ) = 'ONE TIME' ) then
    begin
      edDate_Pd_From_Cheq.Text := '';
      edDate_Pd_To_Cheq.Text := '';
    end //if one time
    else
    if ( uppercase( cboFrequency.Text ) = 'BI-WEEKLY' ) then
    begin
      edDate_Pd_From_Cheq.Text := '';
      edDate_Pd_To_Cheq.Text := '';
    end; //bi-weekly
  end; //  with payClaim do...
end;

procedure TWagelossPaymentForm.cboExpenseCategoriesExit(Sender: TObject);
begin
  with dm1.qryExpenseTypes do
  begin
    Parameters.ParamByName( 'expenseCategory' ).Value := dm1.qryExpenseCategories.Fields[0].Value;
    Close;
    Open;
  end;

  //cboExpenseTypes.ListFieldIndex := -1;
  cboExpenseTypes.ListFieldIndex := 1;
end;

function TWagelossPaymentForm.calculateDueDate( aToDate : TDateTime ): TDateTime;
var
  businessDaysBeforeToDate : Integer;
  workingDate, holidayDate : TDateTime;
begin
  businessDaysBeforeToDate := 0;

  // Initialize working date
  workingDate := aToDate;

  while( businessDaysBeforeToDate < DEFAULT_DAYS_DUE_DATE_IN_ADVANCE_OF_TO_DATE ) do // DEFAULT_DAYS... = 3
  begin
    workingDate := workingDate - 1;

    if ( DayOfWeek( workingDate ) <> 1 ) and  //Sunday
       ( DayOfWeek( workingDate ) <> 7 ) then //Saturday
    begin

      try
        with dm1 do
        begin
          if qryGeneralEmerge.Active then
            qryGeneralEmerge.Close;
          qryGeneralEmerge.SQL.Clear;
          qryGeneralEmerge.SQL.Add( 'SELECT holidayDate ' );
          qryGeneralEmerge.SQL.Add( 'FROM holidays ' );
          qryGeneralEmerge.SQL.Add( 'WHERE holidayDate = ''' + FormatDateTime( 'mm/dd/yyyy', workingDate ) + '''' );
          qryGeneralEmerge.Open;
          qryGeneralEmerge.First;

          holidayDate := dm1.qryGeneralEmerge.FieldByName( 'holidayDate').AsDateTime;

          if holidayDate <> workingDate then
          begin
            businessDaysBeforeToDate := businessDaysBeforeToDate + 1;
          end;

          qryGeneralEmerge.close;
        end;
      finally
        ;
      end;
    end;
  end;

  result := workingDate;
end;

procedure TWagelossPaymentForm.edReducedNoDaysToPayExit(Sender: TObject);
begin
  edReducedNoDaysToPay.text := format( '%.2n',[ textAsCurrency(edReducedNoDaysToPay) ] );

  if ( StrToFloat( cleanNumber(edReducedNoDaysToPay.Text) ) < 0  ) then
  begin
    globalEditError := displayError( '*Duration( Days) cannot be negative.', edReducedNoDaysToPay );
    exit;
  end;

  if not validateDurationDaysToPay then exit;

  ResetInfoLine2;
end;

(******************************************************************************)
(*                                                                            *)
(*  Validate Duration Days To Pay                                             *)
(*                                                                            *)
(******************************************************************************)
function TWagelossPaymentForm.validateDurationDaysToPay: boolean;
begin
  result := false;

  if ( textAsCurrency( edReducedNoDaysToPay ) > textAsCurrency( edNo_Days_Paid ) ) then
  begin
    globalEditError := displayError( '*Duration (Days) to pay cannot be greater than ''Actual # of Days to Pay'' entered.', edReducedNoDaysToPay );
    exit;
  end;

  result := true;
end;

function TWagelossPaymentForm.validateAmountToPay: boolean;
begin
  result := false;

  if ( StrToFloat( stripThousandSeparators( edAmount_Paid.Text ) ) <= 0 ) then
  begin
    globalEditError := displayError( '*Amount to Pay cannot be equal to or less than ''0.00''', edOK_to_Process );
    exit;
  end;

  result := true;
end;


procedure TWagelossPaymentForm.edReducedNoWeeksToPayExit(Sender: TObject);
begin
  if ( StrToFloat( edReducedNoWeeksToPay.Text ) < 0 ) then
  begin
    globalEditError := displayError( '*Duration (Weeks) cannot be negative.', edReducedNoWeeksToPay );
    exit;
  end;

  edReducedNoWeeksToPay.text := format( '%.2n',[ textAsCurrency(edReducedNoWeeksToPay) ] );
  ResetInfoLine2;
end;

(******************************************************************************)
(*                                                                            *)
(*  Validate Actual Number of Days To Pay                                     *)
(*                                                                            *)
(******************************************************************************)
function TWagelossPaymentForm.validateActualDaysToPay: boolean;
begin
  result := false;

  if ( abs(textAsCurrency( edNum_of_Payments )) = 1 ) then
  begin
    if ( abs( textAsCurrency( edNo_Days_Paid ) ) >
        ( textAsDate( edDate_Pd_To_Cheq ) - textAsDate( edDate_Pd_From_Cheq ) + 1 ) ) then
    begin
      globalEditError := displayError( '*Actual # of Days to pay cannot be greater than From/To dates.', edDate_Pd_From_Cheq );
      exit;
    end;
  end;

  result := true;
end;

end.
