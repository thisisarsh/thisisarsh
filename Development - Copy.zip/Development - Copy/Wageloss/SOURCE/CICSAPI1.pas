(******************************************************************************)
(*  Wageloss System                                                           *)
(*                                                                            *)
(*  CICS Calls                                                                *)
(*                                                                            *)
(*                                                                            *)
(*  Author: Brad Trupp  / Capella Systems Group, Inc.                         *)
(*  Date:   July 1997                                                         *)
(*                                                                            *)
(*  Nov 98 - BT - year 2000 windowing fixes                                   *)
(*                                                                            *)
(******************************************************************************)

unit CICSAPI1;

interface

uses
  Windows, Messages, SysUtils, Classes, Graphics, Controls, Forms, Dialogs,
  ComObj, WLDebug, NCRecdef;

const
  ERROR_CODE        = 1;
  SECURITY_CODE     = 1;
  SECURITY_MSG_DCI4 = '*Error: Not authorized to issue DCI4';
  SECURITY_MSG_ECMP = '*Error: Not authorized to issue ECMP';
  SECURITY_MSG_FORM = '*Error: Not authorized to issue FORM';
  TIME_OUT_CODE     = 100;
  TIME_OUT_MSG      = '*Error: User has timed out - please logon';
  MISSING_INFO_CODE = 1;
  MISSING_INFO_MSG  = '*Error: Missing information';
  NO_CONNECT_CODE   = 999;
  NO_CONNECT_MSG    = '*Error: Not connected to CICS - please logon';
  NO_RESPONSE_CODE  = 1;
  NO_RESPONSE_MSG   = '*Error: CICS not responding';
  BAD_FORMULA_MSG   = '*Error: Invalid formula code';
  RESTRICTED_USER_MSG = '*Updates are restricted for this userid';
  RESTRICTED_USER_CODE = 666;

  sNegatives: string[11] = '}JKLMNOPQR';
  sPositives: string[11] = '{ABCDEFGHI';
  sNumerals:  string[11]  = '0123456789';


type

  TCICSSession = class(TObject)
  private
    { Private declarations }
  protected
    { Protected declarations }
    { variables to point to E!PC objects }
    ExtraSystem, sessCollection, sess, OIA, OIAValue, OIAXValue : Variant;
    ExtraVersion: string;
    cicsError: string;
    cicsCode: integer;
    function AttachSession: boolean;
    function DetachSession: boolean;
    function myWaitHostQuiet: boolean;
    function CICSGetString( r, c, l: integer ): shortString;
    function CICSGetDate( r, c, l: integer ): tdatetime;
    function CICSGetInteger( r, c, l: integer ): integer;
    function CICSGetMoney( r, c, l: integer ): double;
    function CICSGetNumber( r, c, l, numDec: integer ): double;
    function CICSPutString( s: shortstring; r, c: integer ): boolean;
    function CICSPutStringPadded( s: shortstring; r, c, l: integer ): boolean;
    function CICSPutNumber100( s: double; r, c, l: integer ): boolean;
    function CICSPutInteger( s: integer; r, c, l: integer ): boolean;
    function CICSPutDate( s: tdatetime; r, c: integer ): boolean;
    function Get_Col: Word;
    function Get_Row: Word;
  public
    { Public declarations }
    constructor Create(AOwner: TComponent);
    destructor Destroy; override;
    function callDCI4( var r: recNCCLAIM ):boolean;
    function callECMP( var r: recNCCLAIM ):boolean;
    function callFORM( var r: recNCFORM ):boolean;
    function callUCI4( var r: recNCCLAIM ):boolean;
    function callLOGI( var r: recNCLOGIN ):boolean;
  published
    { Published declarations }
  end;

var
	CICSSession: TCICSSession;

implementation

uses NCmain, CICSGetP, Utilmod1, uSecurity, uGlobal;

(******************************************************************************)
(*                                                                            *)
(*   Create constructor for CICS Session.                                     *)
(*                                                                            *)
(******************************************************************************)
constructor TCICSSession.Create(AOwner: TComponent);
begin
  {$IFDEF DEBUG}
  ShowDebugLine( 'Creating TCICSSession');
  {$ENDIF}
  ;
end;

(******************************************************************************)
(*                                                                            *)
(*  Destructor for CICS Session.                                              *)
(*                                                                            *)
(******************************************************************************)
destructor TCICSSession.Destroy;
begin
  {$IFDEF DEBUG}
  ShowDebugLine( 'Destroying TCICSSession');
  {$ENDIF}
  inherited;
end;

(******************************************************************************)
(*                                                                            *)
(*  Detect the row and column we are on in the CICS screen                    *)
(*                                                                            *)
(******************************************************************************)
function TCICSSession.Get_Col: Word;
begin
   try
      Result := sess.Screen.Col;
   except
      result:=0;
   end;
end;


function TCICSSession.Get_Row: Word;
begin
   try
      Result := sess.Screen.Row;
   except
      result:=0;
   end;
end;

(******************************************************************************)
(*                                                                            *)
(*  Attach via OLE to current 3270 terminal session.                          *)
(*                                                                            *)
(******************************************************************************)
function TCICSSession.AttachSession: boolean;
begin
  result:=false;
  WagelossMainForm.ShowInfoLine1('Attaching to CICS Session.' );

  { Start up EXTRA! Personal Client... }
  try
      ExtraSystem := GetActiveOleObject('Extra.System'); { Extra! 6.3 }
  except
  begin
    try
      ExtraSystem := CreateOleObject('Extra.System'); { Extra! 6.1 }
    except
    begin
      screen.cursor:=crDefault;
      Application.MessageBox(
        'Unable to attach to EXTRA! terminal emulation program. ',
        'Wageloss Error Message [CICS001]',
        MB_OK);
      exit;
    end;
  end;
  end;
  end;

  try
    ExtraVersion := ExtraSystem.Version;
  except
    ExtraVersion := '0.0';
  end;

  { Get the Sessions collection...we'll need this when using it's Open method
     to access specific sessions... }
  sessCollection := ExtraSystem.sessions;
  if ExtraSystem.Sessions.Count = 0 then
  begin
      screen.cursor:=crDefault;
      Application.MessageBox(
        'No active sessions detected for EXTRA! Personal Client on this computer. ',
        'Wageloss Error Message [CICS002]',
        MB_OK);
    exit;
  end;
  try
    sess := ExtraSystem.ActiveSession;
  except
    begin
      screen.cursor:=crDefault;
      Application.MessageBox(
        'Unable to open active session for EXTRA! Personal Client on this computer. ',
        'Wageloss Error Message [CICS003]',
        MB_OK);
      exit;
    end;
  end;
  result:=true;
end;

(******************************************************************************)
(*                                                                            *)
(*  Close OLE connection to 3270 session.                                     *)
(*                                                                            *)
(******************************************************************************)
function TCICSSession.DetachSession: boolean;
begin
  result:=false;
  WagelossMainForm.ShowInfoLine1('');

  try
  { This closes any open sessions and quits E!PC altogether... }
  { ExtraSystem.Quit;}
  //ExtraSystem := UnAssigned;
  except;
    exit;
  end;
  result:=true;
end;

(******************************************************************************)
(*  Function: myWaitHostQuiet                                                 *)
(*                                                                            *)
(*  Based on Ole method WaitHostQuiet so it returns a true if xclock clears   *)
(*  else returns a false.                                                     *)
(*                                                                            *)
(******************************************************************************)
function TCICSSession.myWaitHostQuiet: boolean;
var
  rc, ret: boolean;
  iRet: integer;
begin
  try
    sess.screen.WaitHostQuiet(500); // wait for not busy for 1/2 second
    ExtraSystem.TimeoutValue := 9000; // set session timeout to 9 seconds...
    (**************************************************************************)
    (*  WaitHostQuiet is not detecting the keyboard being locked. This is a   *)
    (*  Extra 6.1 bug. Temporary fix is to issue a keyboard reset in each     *)
    (*  transaction as a part of the "script".                                *)
    (**************************************************************************)
    rc := sess.screen.WaitHostQuiet(0); // wait until xclock clears or system timeout...
    ret := sess.keyboardlocked;

    if ( compareText('6.1', ExtraVersion ) <> 0 ) then
    begin
      try
      iRet:= sess.screen.oia.xstatus;
      except
        iRet:=0;
      end;
    end
    else
      iRet:=0;

    if ( not rc ) or ( ret ) or ( iRet <> 0 ) then
    begin
      WagelossMainForm.ShowInfoLine1('Sending keyboard reset.' );
      sess.Screen.SendKeys('<reset>'); // send keyboard reset
      sess.screen.WaitHostQuiet(1000);
      rc := sess.screen.WaitHostQuiet(0);
    end;
    result := rc;
  except
    result := false;
  end;
end;

(******************************************************************************)
(*                                                                            *)
(*  Get a string off the CICS screen.                                         *)
(*                                                                            *)
(******************************************************************************)
function TCICSSession.CICSGetString( r, c, l: integer ): shortstring;
var
  ws: string;
begin
  try
    ws:=sess.screen.getstring(r, c, l);
    result:=pdoxtrim(ws);
  except
    result:='';
  end;
end;

(******************************************************************************)
(*                                                                            *)
(*  Get a tDateTime off the CICS screen.                                      *)
(*                                                                            *)
(******************************************************************************)
function TCICSSession.CICSGetDate( r,c, l: integer ): tdatetime;
//  Function      : This routine converts a date to WCB display       //
//                  format for the Paradox program (dd/mm/yy).        //
//                  If date is 000000 then field is returned as "/0". //
var
  ws: string;
  dd,mm,yy:word;
begin
  try
    ws:=sess.screen.getstring(r, c, l);
    if ( ws = '000000' ) or ( ws = '      ' ) then
    begin
      result:=0;
    end
    else
    begin
      dd:=strToInt(copy(ws,1,2));
      mm:=strToInt(copy(ws,3,2));
      yy:=strToInt(copy(ws,5,2));
      // Nov 98 - BT - year 2000 windowing fixes
      if yy < 20 then
        result:=EncodeDate(2000 + yy,mm,dd)
      else
        result:=EncodeDate(1900 + yy,mm,dd);
    end;
  except
    result:=0;
  end;
end;

(******************************************************************************)
(*                                                                            *)
(*  Get an integer off the CICS screen.                                       *)
(*                                                                            *)
(******************************************************************************)
function TCICSSession.CICSGetInteger( r,c, l: integer ): integer;
var
  ws: string;
begin
  try
    ws:=sess.screen.getstring(r, c, l);
    result:=trunc(CICSGetNumber( r, c, l, 0 ));
  except
    result:=0;
  end;
end;

(******************************************************************************)
(*                                                                            *)
(*  Get a currency off the CICS screen.                                       *)
(*                                                                            *)
(******************************************************************************)
function TCICSSession.CICSGetMoney( r,c, l: integer ): double;
var
  ws: string;
begin
  try
    ws:=sess.screen.getstring(r, c, l);
    result:=CICSGetNumber( r, c, l, 2 );
  except
    result:=0.00;
  end;
end;

(******************************************************************************)
(*                                                                            *)
(*  Get a number off the CICS screen and scale to correct decimals.           *)
(*                                                                            *)
(******************************************************************************)
function TCICSSession.CICSGetNumber( r, c, l, numDec: integer ): double;
var
  ws, ns: string;
  iii: integer;
  isNegative: boolean;
  num: double;
begin
  isNegative:=false;
  try
    ws:=sess.screen.getstring(r, c, l);
    ns:='0';
    for iii:= 1 to length(ws) do
    begin
      case ws[iii] of
      '0'..'9':  begin ns:=ns+ws[iii]; end;
      '}': begin isNegative:=true; ns:=ns+'0'; end;
      'J'..'R': begin isNegative:=true; ns:=ns+chr( 1 + ord(ws[iii])- ord('J')); end;
      '{': begin ns:=ns+'0'; end;
      'A'..'I':begin ns:=ns+chr( 1 + ord(ws[iii])- ord('A')); end;
      end;
    end;
    num:=( StrtoInt(ns) ) *1.0;
    iii:= numDec;
    while ( iii > 0 ) do
    begin
      num := num / 10.00;
      dec(iii);
    end;
    if ( isNegative ) then num := num * -1.0;
    result:= num;
  except
    result:=0.00;
  end;
end;

(******************************************************************************)
(*                                                                            *)
(*  Write a string to the CICS screen.                                        *)
(*                                                                            *)
(******************************************************************************)
function TCICSSession.CICSPutString( s:shortstring; r, c: integer ): boolean;
var
  ws: shortstring;
  ch: byte;
begin
  try
    sess.screen.putstring(s, r, c);
    { set MDT bit }
    ws := sess.screen.getstring(r, c-1, 1);
    { hllapiString[0] = hllapiString[0] | 0x01; }
    ch:= byte(ws[1]);
    ch := ch or $01;
    ws[1]:=char(ch);
    sess.screen.putstring(ws, r, c-1);
  except
    ;
  end;
  result:=true;
end;

(******************************************************************************)
(*                                                                            *)
(*  Write a padded string to the CICS screen.                                 *)
(*                                                                            *)
(******************************************************************************)
function TCICSSession.CICSPutStringPadded( s: shortstring; r, c, l: integer ): boolean;
var
  ws: shortstring;
begin
  ws:=s;
  while length(ws) < l do ws:=ws+' ';
  CICSPutString( ws, r, c );
  result:=true;
end;

(******************************************************************************)
(*                                                                            *)
(*  Write a number to the CICS screen. Drop decimal and scale up.             *)
(*                                                                            *)
(******************************************************************************)
function TCICSSession.CICSPutNumber100( s: double; r, c, l: integer ): boolean;
var
  ws, fs: shortstring;
  isNegative: boolean;
  ch: char;
  i: integer;
begin
  isNegative := s < 0;
  s := abs( s );
  fs:='%' + intToStr(l) + '.0f';
  ws:=format(fs, [ s * 100.00 ] );
  if isNegative then
  begin
    ch:= ws[ length( ws ) ];
    i := pos( ch, sNumerals );
    if i > 0 then ch := sNegatives[i];
    ws[ length( ws ) ] := ch;
  end;
  CICSPutString( ws, r, c );
  result:=true;
end;

(******************************************************************************)
(*                                                                            *)
(*  Write an integer to the CICS screen.                                      *)
(*                                                                            *)
(******************************************************************************)
function TCICSSession.CICSPutInteger( s: integer; r, c, l: integer ): boolean;
var
  ws, fs: shortstring;
  isNegative: boolean;
  ch: char;
  i: integer;
begin
  isNegative := s < 0;
  s := abs( s );
  fs:='%' + intToStr(l) + 'd';
  ws:=format(fs, [ s ] );
  if isNegative then
  begin
    ch:= ws[ length( ws ) ];
    i := pos( ch, sNumerals );
    if i > 0 then ch := sNegatives[i];
    ws[ length( ws ) ] := ch;
  end;
  CICSPutString( ws, r, c );
  result:=true;
end;

(******************************************************************************)
(*                                                                            *)
(*  Write a date to the CICS screen.                                          *)
(*                                                                            *)
(******************************************************************************)
function TCICSSession.CICSPutDate( s: tdatetime; r, c: integer ): boolean;
var
  ws: shortstring;
begin
  if s > 1 then
    ws:=formatdatetime('ddmmyy', s )
  else
    ws:='000000';
  CICSPutString( ws, r, c );
  result:=true;
end;

(******************************************************************************)
(*                                                                            *)
(*  Perform CICS DCI4 transaction.                                            *)
(*                                                                            *)
(******************************************************************************)
function TCICSSession.callDCI4( var r: recNCCLAIM ):boolean;
var
  ws, ss: string;
begin
  result:=false;
  cicsError:='';
  cicsCode:=999;
  screen.cursor:=crHourglass;

  { initialize r: recNCCLAIM first }
  ws:= r.Claim_No;
  ClearNCCLAIM( r );
  r.Claim_No:=ws;
  r.Mf_Cics_Status:=9999;
  r.Mf_Cics_Msg:='';

  try
    if not AttachSession then abort;

    ss:='Terminal not in use';
    ws:=sess.screen.getstring(13,27, length(ss));
    if ( comparetext(ss, ws ) = 0 ) then
    begin
      cicsError:=TIME_OUT_MSG; cicsCode:=TIME_OUT_CODE; abort;
    end;

    ss:='ISM Network';
    ws:=sess.screen.getstring(15,51, length(ss));
    if ( comparetext(ss, ws ) = 0 ) then
    begin
      cicsError:=NO_CONNECT_MSG; cicsCode:=NO_CONNECT_CODE; abort;
    end;

    if ( not myWaitHostQuiet ) then
    begin
      cicsError:=NO_RESPONSE_MSG; cicsCode:=NO_RESPONSE_CODE; abort;
    end;

    sess.Screen.SendKeys('<reset>'); // bug in Extra 6.1 - ensure keyboard is reset
    sess.Screen.SendKeys('<clear>');
    if ( not myWaitHostQuiet ) then
    begin
      cicsError:=NO_RESPONSE_MSG; cicsCode:=NO_RESPONSE_CODE; abort;
    end;

    WagelossMainForm.ShowInfoLine1('Requesting claim info for '+ r.Claim_No );
    sess.Screen.SendKeys('DCI4 ' + r.Claim_No + ' <enter>');
    if ( not myWaitHostQuiet ) then
    begin
      cicsError:=NO_RESPONSE_MSG; cicsCode:=NO_RESPONSE_CODE; abort;
    end;
    if ( not myWaitHostQuiet ) then
    begin
      cicsError:=NO_RESPONSE_MSG; cicsCode:=NO_RESPONSE_CODE; abort;
    end;

    ss:='USSMSG';
    ws:=sess.screen.getstring(2,1, length(ss));
    if ( comparetext(ss, ws ) = 0 ) then
    begin
      cicsError:=NO_CONNECT_MSG; cicsCode:=NO_CONNECT_CODE; abort;
    end;

    ss:='S E C U R I T Y ';
    ws:=sess.screen.getstring(8,23, length(ss));
    if ( comparetext(ss, ws ) = 0 ) then
    begin
      cicsError:=SECURITY_MSG_DCI4; cicsCode:=SECURITY_CODE; abort;
    end;

    ss:='DCI4';
    ws:=sess.screen.getstring(24,77, length(ss));
    if ( comparetext(ss, ws ) <> 0 ) then
    begin
      cicsError:=NO_RESPONSE_MSG; cicsCode:=NO_RESPONSE_CODE; abort;
    end;

    r.Mf_Cics_Msg:=sess.screen.getstring(2, 2, 79);

    ss:='TRANSACTION CANCELLED - CLAIM NUMBER NOT VALID';
    ws:=sess.screen.getstring(2,2, length(ss));
    if ( comparetext(ss, ws ) = 0 ) then
    begin
      cicsError:=r.Mf_Cics_Msg; cicsCode:=ERROR_CODE; abort;
    end;

    ss:='TRANSACTION CANCELLED - MAP FAIL';
    ws:=sess.screen.getstring(2,2, length(ss));
    if ( comparetext(ss, ws ) = 0 ) then
    begin
      cicsError:=r.Mf_Cics_Msg; cicsCode:=ERROR_CODE; abort;
    end;

    WagelossMainForm.ShowInfoLine1('Retrieving DCI4 data.' );
    r.MF_CICS_STATUS := cicsCode;
    r.MF_CICS_MSG := cicsError;
    r.CLMNTS_SURNAME:= CICSGetString(3,  2, 25);
    //r.CLMNTS_1ST_NAME:= CICSGetString(3, 28, 13);
    r.CLAIM_SUFFIX:= CICSGetString(3, 46,  4);
    r.PRIME_FIRM_NO:= CICSGetString(3, 51,  9);
    r.CURR_CASE_TYPE:= CICSGetString(3, 68,  1);
    r.ALT_MAIL_ADD_CODE:= CICSGetString(3, 71,  1);
    r.MARITAL_STATUS:= CICSGetString(3, 74,  1);
    r.NO_OF_DEPENDNTS:= CICSGetInteger(3, 78,  2);
    r.CLMNTS_ADD_NO_1:= CICSGetString(4,  2, 30);
    r.LOSS_EARN_DATE:= CICSGetDate(4, 36,  6);
    r.ACCIDENT_DATE:= CICSGetDate(4, 46,  6);
    r.NO_DAYS_OF_COMP_BNFTS:= CICSGetNumber(4, 56,  5, 1);
    r.TOT_COMP_PD_TO_DATE:= CICSGetMoney(4, 66,  9);
    r.CLMNTS_ADD_NO_2:= CICSGetString(5,  2, 30);
    r.DATE_PD_FROM_CHEQ:= CICSGetDate(5, 36,  6);
    r.DATE_PD_TO_CHEQ:= CICSGetDate(5, 46,  6);
    r.DAYS_BNFT_PD_ON_LAST_COMP:= CICSGetNumber(5, 56,  5, 1);
    r.AMOUNT_PAID:= CICSGetMoney(5, 66,  9);
    r.CLMNTS_ADD_NO_3:= CICSGetString(6,  2, 30);
    r.BIRTH_DATE:= CICSGetDate(6, 36,  6);
    r.CLMNTS_POST_CODE:= CICSGetString(7,  2,  6);
    r.NO_WEEKS_OF_COMP_BNFTS:= CICSGetMoney(9,  2,  7);
    r.SIN:= CICSGetString(7, 12,  9);
    r.Original_Wkly_Sal:= CICSGetMoney(7, 32,  7);
    r.Wkly_Sal_Index_Flag:= CICSGetString(7, 42,  1);
    r.Pre_1992_Wkly_Sal:= CICSGetMoney(7, 22,  7);
    r.Tot_WCB_Anty_Elig_Earn:= CICSGetMoney(8,  2,  9);
    r.Tot_WCB_Anty_Contib_Amt:= CICSGetMoney(8, 12,  9);
    r.Tot_CLMT_Anty_Elig_Earn:= CICSGetMoney(8, 22,  9);
    r.Tot_CLMT_Anty_Contrib_Amt:= CICSGetMoney(8, 32,  9);
    r.nc_104_Wk_Clmt_Reply_Date:= CICSGetDate(6, 46,  6);
    r.nc_104_Wk_Effective_Date:= CICSGetDate(6, 56,  6);
    r.nc_104_Wk_WCB_p_Contrib:= CICSGetMoney(7, 46,  3);
    r.nc_104_Wk_WCB_p_Contrib_Red:= CICSGetMoney(7, 50,  3);
    r.nc_104_Wk_WCB_p_Eff_Date:= CICSGetDate(6, 66,  6);
    r.nc_104_Wk_Clmt_p_Contrib:= CICSGetMoney(7, 54,  3);
    r.nc_104_Wk_Clmt_p_Eff_Date:= CICSGetDate(6, 75,  6);
    r.Comp_Wks_Pd_to_63_Flag:= CICSGetString(7, 61,  1);
    r.Comp_Wks_Pd_to_63:= CICSGetMoney(7, 66,  7);
    r.Employer_Top_Up_Flag:= CICSGetString(8, 42,  1);
    r.CI05_Balance:= CICSGetMoney(18,  2,  9);
    r.CI05_Rate:= CICSGetMoney(18, 12,  9);
    r.CI05_Status:= CICSGetString(18, 22,  2);
    r.CI05_Trlrcnt:= CICSGetInteger(18, 25,  3);
    r.PHIN:= CICSGetString(18, 32,  9);

    r.Clmnts_Home_Phone:= CICSGetString(19, 12, 10);
    r.Clmnts_Work_Phone:= CICSGetString(19, 32, 10);
    r.Uniqueness := CICSGetInteger(7, 77, 4);

    ss:='TRANSACTION COMPLETE - CI ONLY';
    ws:=sess.screen.getstring(2,2, length(ss));
    if ( comparetext(ss, ws ) <> 0 ) then
    begin
      r.DAYS_WORKED_PER_WEEK:= CICSGetMoney(9, 12,  3);
      r.SPOUSE_WORKING:= CICSGetString(9, 22,  1);
      r.NO_INFIRM:= CICSGetInteger(9, 32,  3);
      r.EI_EXEMPT:= CICSGetString(9, 42,  1);
      r.TAX_CODE:= CICSGetString(9, 52,  2);
      r.TAX_YEAR:= CICSGetInteger(9, 62,  4);
      r.COLLATERAL_BEN_NON_TAX:= CICSGetMoney(10,  2,  9);
      r.DEEMED_EARNINGS:= CICSGetString(10, 12,  1);
      r.CALC_DATE:= CICSGetDate(10, 22,  6);
      r.MARITAL_STATUS:= CICSGetString(10, 32,  1);
      r.NO_OF_DEPENDNTS:= CICSGetInteger(10, 42,  3);
      r.WKLY_SAL_A:= CICSGetMoney(10, 62,  9);
      r.TAX_EXEMPTION:= CICSGetMoney(11,  2,  9);
      r.ANNUAL_GROSS:= CICSGetMoney(11, 12,  9);
      r.ANNUAL_NET:= CICSGetMoney(11, 22,  9);
      r.ANNUAL_90:= CICSGetMoney(11, 32,  9);
      r.ANNUAL_80:= CICSGetMoney(11, 42,  9);
      r.INC_TAX_FED:= CICSGetMoney(11, 52,  9);
      r.INC_TAX_MAN:= CICSGetMoney(11, 62,  9);
      r.CPP_PREM:= CICSGetMoney(11, 72,  9);
      r.EI_PREM:= CICSGetMoney(12,  2,  9);
      r.TOTAL_DEDS:= CICSGetMoney(12, 12,  9);
      r.ANNUAL_90_S:= CICSGetMoney(12, 22,  9);
      r.ANNUAL_80_S:= CICSGetMoney(12, 32,  9);
      r.INC_TAX_FED_S:= CICSGetMoney(12, 42,  9);
      r.INC_TAX_MAN_S:= CICSGetMoney(12, 52,  9);
      r.CPP_PREM_S:= CICSGetMoney(12, 62,  9);
      r.EI_PREM_S:= CICSGetMoney(12, 72,  9);
      r.TOTAL_DEDS_S:= CICSGetMoney(13,  2,  9);
      r.WEEKLY_NET:= CICSGetMoney(13, 12,  9);
      r.WEEKLY_90:= CICSGetMoney(13, 22,  9);
      r.WEEKLY_80:= CICSGetMoney(13, 32,  9);
      r.WEEKLY_90_S:= CICSGetMoney(13, 42,  9);
      r.WEEKLY_80_S:= CICSGetMoney(13, 52,  9);
      r.CALC_USERNAME:= CICSGetString(14, 12,  8);
      r.COLLATERAL_BEN_TAX:= CICSGetMoney(15,  2,  9);
      r.COLL_BEN_TAX_NET:= CICSGetMoney(15, 12,  9);
      r.POST_INJURY_EARN:= CICSGetMoney(16,  2,  9);
      r.POST_INJURY_EARN_NET:= CICSGetMoney(16, 12,  9);
      r.Wkly_WCB_Anty_Con_Amt:= CICSGetMoney(17,  2,  9);
      r.Wkly_WCB_Anty_Con_Amt_S:= CICSGetMoney(17, 12,  9);
      r.Wkly_Clmt_Anty_Con_Amt:= CICSGetMoney(17, 22,  9);
      r.Wkly_Clmt_Anty_Con_Amt_S:= CICSGetMoney(17, 32,  9);
      r.Indexation_Calc_Date:= CICSGetDate(17, 42,  6);
      r.Indexation_Year:= CICSGetInteger(17, 52,  4);
      r.CI_04_Wkly_NET_Sal:= CICSGetMoney(10, 52,  9);
      r.Weekly_Net_A := r.CI_04_Wkly_NET_Sal; // <== from NCgetclm.sc

      r.AverageEarningsBasedOn:= CICSGetString(19, 2, 1);

      r.Self_Employed:=CICSGetString(20, 2,  1);
      r.Recurrence:=CICSGetString(20, 4,  1);
      r.CPP_Exempt:=CICSGetString(20, 6,  1);
      r.Tax_Exempt:=CICSGetString(20, 8,  1);

      r.Child_Care_Exp:=CICSGetMoney(20, 12,  9);
      r.Spousal_Support:=CICSGetMoney(20, 22,  9);
      r.Child_Support:=CICSGetMoney(20, 32,  9);
      r.Max_Adjustment:=CICSGetMoney(20, 42,  9);


    end;
    If r.Self_Employed = '' then
    	r.Self_Employed := 'N';
    If r.Recurrence = '' then
    	r.Recurrence := 'N';
    If r.CPP_Exempt = '' then
    	r.CPP_Exempt := 'N';
    If r.Tax_Exempt = '' then
    	r.Tax_Exempt := 'N';
    If r.MARITAL_STATUS = '' then
      r.MARITAL_STATUS := 'S';
    If r.SPOUSE_WORKING = '' then
      r.SPOUSE_WORKING := 'N';
    If r.EI_EXEMPT = '' then
      r.EI_EXEMPT := 'N';
    SetOldRecurrenceInd(r.Recurrence);
    WagelossMainForm.ShowInfoLine1('Complete' );
    if not DetachSession then exit;
  except
    screen.cursor:=crDefault;
    r.Mf_Cics_Status := cicsCode;
    r.Mf_Cics_Msg:=cicsError;
    WagelossMainForm.ShowInfoLine1('Error '+ cicsError );
    DetachSession;
    exit;
  end;
  screen.cursor:=crDefault;
  r.Mf_Cics_Status := 0;
  result:=true;
end;

(******************************************************************************)
(*                                                                            *)
(*  Perform CICS ECMP transaction.                                            *)
(*                                                                            *)
(******************************************************************************)
function TCICSSession.callECMP( var r: recNCCLAIM ):boolean;
var
  ws, ss: string;
  ExtraWindowHandle: hWnd;
  ExtraWindowTitle : array[0..254] of char;
  s1,s2: string;
begin
  result:=false;
  cicsError:='';
  cicsCode:=999;
  screen.cursor:=crHourglass;

  try
    ;

//    { temporary trap on network userid }
//    if ( comparetext('MARDEV_1', WagelossMainForm.userid ) = 0 ) then
//    begin
//      cicsError:=RESTRICTED_USER_MSG; cicsCode:=RESTRICTED_USER_CODE; abort;
//    end;

    if not ( ( comparetext( 'F3', r.Formula_Code ) = 0 ) or
             ( comparetext( 'F7', r.Formula_Code ) = 0 ) or
             ( comparetext( 'S7', r.Formula_Code ) = 0 ) or
             ( comparetext( 'S3', r.Formula_Code ) = 0 ) ) then
    begin
      cicsError:=BAD_FORMULA_MSG; cicsCode:=ERROR_CODE; abort;
    end;

    if not AttachSession then abort;

    ss:='Terminal not in use';
    ws:=sess.screen.getstring(13,27, length(ss));
    if ( comparetext(ss, ws ) = 0 ) then
    begin
      cicsError:=TIME_OUT_MSG; cicsCode:=TIME_OUT_CODE; abort;
    end;

    ss:='ISM Network';
    ws:=sess.screen.getstring(15,51, length(ss));
    if ( comparetext(ss, ws ) = 0 ) then
    begin
      cicsError:=NO_CONNECT_MSG; cicsCode:=NO_CONNECT_CODE; abort;
    end;

    if ( not myWaitHostQuiet ) then
    begin
      cicsError:=NO_RESPONSE_MSG; cicsCode:=NO_RESPONSE_CODE; abort;
    end;

    sess.Screen.SendKeys('<reset>'); // bug in Extra 6.1 - ensure keyboard is reset
    sess.Screen.SendKeys('<clear>');
    if ( not myWaitHostQuiet ) then
    begin
      cicsError:=NO_RESPONSE_MSG; cicsCode:=NO_RESPONSE_CODE; abort;
    end;

    WagelossMainForm.ShowInfoLine1('Issuing ECMP transaction.' );
    sess.Screen.SendKeys('ECMP ' + r.Claim_No + ' ' + r.Formula_Code + ' ' +
      inttostr(trunc(r.Hash_Total)) + ' <enter>');
    if ( not myWaitHostQuiet ) then
    begin
      cicsError:=NO_RESPONSE_MSG; cicsCode:=NO_RESPONSE_CODE; abort;
    end;
    if ( not myWaitHostQuiet ) then
    begin
      cicsError:=NO_RESPONSE_MSG; cicsCode:=NO_RESPONSE_CODE; abort;
    end;

    cicsError:=sess.screen.getstring(2, 2, 79);

    ss:='USSMSG';
    ws:=sess.screen.getstring(2,1, length(ss));
    if ( comparetext(ss, ws ) = 0 ) then
    begin
      cicsError:=NO_CONNECT_MSG; cicsCode:=NO_CONNECT_CODE; abort;
    end;

    ss:='S E C U R I T Y ';
    ws:=sess.screen.getstring(8,23, length(ss));
    if ( comparetext(ss, ws ) = 0 ) then
    begin
      cicsError:=SECURITY_MSG_ECMP; cicsCode:=SECURITY_CODE; abort;
    end;

    ss:='** PLEASE ENTER';
    ws:=sess.screen.getstring(2,2, length(ss));
    if ( comparetext(ss, ws ) <> 0 ) then
    begin
      cicsError:=sess.screen.getstring(2, 2, 79); cicsCode:=ERROR_CODE; abort;
    end;

    WagelossMainForm.ShowInfoLine1('Entering ECMP Information.' );

    if ( comparetext( 'F3', r.Formula_Code ) = 0 ) then
    begin
        CICSPutString(r.PAYEE_CODE, 11, 9);
        CICSPutString(r.PAYMENT_TYPE_CODE, 11, 16);
        if ( r.DATE_PD_FROM_CHEQ > 0 ) then
        begin
          CICSPutString(formatdatetime('dd', r.DATE_PD_FROM_CHEQ), 11, 25);
          CICSPutString(formatdatetime('mm', r.DATE_PD_FROM_CHEQ), 11, 28);
          CICSPutString(formatdatetime('yy', r.DATE_PD_FROM_CHEQ), 11, 31);
        end;
        if ( r.DATE_PD_TO_CHEQ > 0 ) then
        begin
          CICSPutString(formatdatetime('dd', r.DATE_PD_TO_CHEQ), 11, 41);
          CICSPutString(formatdatetime('mm', r.DATE_PD_TO_CHEQ), 11, 44);
          CICSPutString(formatdatetime('yy', r.DATE_PD_TO_CHEQ), 11, 47);
        end;
        CICSPutString(r.CLAIM_EXP_CODE, 11, 56);
        CICSPutString(format('%f',[r.AMOUNT_PAID]), 11, 64);
        if ( r.LOSS_EARN_DATE > 0 ) then
        begin
          CICSPutString(formatdatetime('dd', r.LOSS_EARN_DATE), 14, 64);
          CICSPutString(formatdatetime('mm', r.LOSS_EARN_DATE), 14, 67);
          CICSPutString(formatdatetime('yy', r.LOSS_EARN_DATE), 14, 70);
        end;
        CICSPutString(format('%f',[r.NO_DAYS_PAID]), 14, 6);
        CICSPutString(format('%f',[r.NO_WEEKS_PAID]), 14, 17);
        CICSPutString(r.ALT_MAIL_ADD_CODE, 14, 31);
        CICSPutString(r.MESSAGE_CODE_A, 14, 37);
        CICSPutString(r.MESSAGE_CODE_B, 14, 40);
        CICSPutString(r.MESSAGE_CODE_C, 14, 43);
        ws:= format('%f',[r.WKLY_SAL_A]); while length(ws) < 12 do ws:=ws+' ';
        CICSPutString(ws, 14, 46);
        CICSPutString(r.BENEFIT_TYPE_CODE, 17, 55);
        CICSPutString(format('%f',[r.Payment_Anty_Earn]), 20 ,19);
        CICSPutString(format('%f',[r.Payment_WCB_Contrib]), 20 ,34);
        CICSPutString(format('%f',[r.Payment_Clmt_Contrib]), 20 ,48);
    end;

    if ( comparetext( 'F7', r.Formula_Code ) = 0 ) or
       ( comparetext( 'S7', r.Formula_Code ) = 0 ) then
    begin
        CICSPutString(r.PAYEE_CODE, 11, 9);
        CICSPutString(r.PAYMENT_TYPE_CODE, 11, 16);
        if ( r.First_Pay_Date > 0 ) then
        begin
          CICSPutString(formatdatetime('dd', r.First_Pay_Date), 11, 25);
          CICSPutString(formatdatetime('mm', r.First_Pay_Date), 11, 28);
          CICSPutString(formatdatetime('yy', r.First_Pay_Date), 11, 31);
        end;
        CICSPutString(format('%d',[r.NUM_OF_PAYMENTS]), 11, 42);
        CICSPutString(r.CLAIM_EXP_CODE, 11, 52);
        CICSPutString(format('%f',[r.AMOUNT_PAID]), 11, 60);
        if ( r.LOSS_EARN_DATE > 0 ) then
        begin
          CICSPutString(formatdatetime('dd', r.LOSS_EARN_DATE), 14, 62);
          CICSPutString(formatdatetime('mm', r.LOSS_EARN_DATE), 14, 65);
          CICSPutString(formatdatetime('yy', r.LOSS_EARN_DATE), 14, 68);
        end;
        CICSPutString(r.PAY_FREQUENCY, 11, 76);
        CICSPutString(format('%f',[r.NO_DAYS_PAID]), 14, 5);
        CICSPutString(format('%f',[r.NO_WEEKS_PAID]), 14, 16);
        CICSPutString(r.ALT_MAIL_ADD_CODE, 14, 30);
        CICSPutString(r.MESSAGE_CODE_A, 14, 35);
        CICSPutString(r.MESSAGE_CODE_B, 14, 38);
        CICSPutString(r.MESSAGE_CODE_C, 14, 41);
        ws:= format('%f',[r.WKLY_SAL_A]); while length(ws) < 12 do ws:=ws+' ';
        CICSPutString(ws, 14, 44);
        CICSPutString(r.BENEFIT_TYPE_CODE, 17, 10);
        CICSPutString(format('%f',[r.Payment_Anty_Earn]), 17 ,17);
        CICSPutString(format('%f',[r.Payment_WCB_Contrib]), 17 ,32);
        CICSPutString(format('%f',[r.Payment_Clmt_Contrib]), 17 ,46);
    end;

    if ( comparetext( 'S3', r.Formula_Code ) = 0 ) then
    begin
        CICSPutString(r.PAYMENT_TYPE_CODE, 11, 16);
        if ( r.DATE_PD_FROM_CHEQ > 0 ) then
        begin
          CICSPutString(formatdatetime('dd', r.DATE_PD_FROM_CHEQ), 11, 25);
          CICSPutString(formatdatetime('mm', r.DATE_PD_FROM_CHEQ), 11, 28);
          CICSPutString(formatdatetime('yy', r.DATE_PD_FROM_CHEQ), 11, 31);
        end;
        if ( r.DATE_PD_TO_CHEQ > 0 ) then
        begin
          CICSPutString(formatdatetime('dd', r.DATE_PD_TO_CHEQ), 11, 41);
          CICSPutString(formatdatetime('mm', r.DATE_PD_TO_CHEQ), 11, 44);
          CICSPutString(formatdatetime('yy', r.DATE_PD_TO_CHEQ), 11, 47);
        end;
        CICSPutString(r.CLAIM_EXP_CODE, 11, 56);
        CICSPutString(format('%f',[r.AMOUNT_PAID]), 11, 64);
        if ( r.LOSS_EARN_DATE > 0 ) then
        begin
          CICSPutString(formatdatetime('dd', r.LOSS_EARN_DATE), 14, 64);
          CICSPutString(formatdatetime('mm', r.LOSS_EARN_DATE), 14, 67);
          CICSPutString(formatdatetime('yy', r.LOSS_EARN_DATE), 14, 70);
        end;
        CICSPutString(format('%f',[r.NO_DAYS_PAID]), 14, 6);
        CICSPutString(format('%f',[r.NO_WEEKS_PAID]), 14, 17);
        CICSPutString(r.ALT_MAIL_ADD_CODE, 14, 31);
        CICSPutString(r.MESSAGE_CODE_A, 14, 37);
        CICSPutString(r.MESSAGE_CODE_B, 14, 40);
        CICSPutString(r.MESSAGE_CODE_C, 14, 43);
        ws:= format('%f',[r.WKLY_SAL_A]); while length(ws) < 12 do ws:=ws+' ';
        CICSPutString(ws, 14, 46);
        CICSPutString(r.BENEFIT_TYPE_CODE, 17, 55);
        CICSPutString(format('%f',[r.Payment_Anty_Earn]), 20 ,19);
        CICSPutString(format('%f',[r.Payment_WCB_Contrib]), 20 ,34);
        CICSPutString(format('%f',[r.Payment_Clmt_Contrib]), 20 ,48);
    end;



    //********************************************************************//
    //  Press the ENTER key.                                              //
    //********************************************************************//
    sess.Screen.SendKeys('<enter>');

    //********************************************************************//
    //  Jump over to the CICS side to allow operator to work over there.  //
    //********************************************************************//
    WagelossMainForm.ShowInfoLine1('Switching to CICS Session.' );

    //********************************************************************//
    //  The sess.activate does not always seem to work so this will try   //
    //  to find the window handle of the current extra session and force  //
    //  it to be foreground using Windows API calls directly.             //
    //********************************************************************//
    try
        {get Extra! session and application name}
        s1 := sess.name;
        s2 := sess.application.name;
        {build the Window Title and store it into a pointer string }
        StrFmt(ExtraWindowTitle,'%s', [ s1 + ' - ' + s2 ]);
        {locate the Extra! Window }
        ExtraWindowHandle :=  FindWindow(nil,ExtraWindowTitle);
        {give focus to Extra! if it was found }
        if ( ExtraWindowHandle <> 0 ) then
          SetForegroundWindow( ExtraWindowHandle );
    finally
    ;
    end;

    sess.activate;

    myWaitHostQuiet;
    r.Mf_Cics_Msg:=sess.screen.getstring(2, 2, 79);
    if not DetachSession then exit;
  except
    screen.cursor:=crDefault;
    r.Mf_Cics_Status := cicsCode;
    r.Mf_Cics_Msg:=cicsError;
    DetachSession;
    exit;
  end;
  screen.cursor:=crDefault;
  r.Mf_Cics_Status := 0;
  result:=true;
end;

(******************************************************************************)
(*                                                                            *)
(*  Perform CICS FORM transaction.                                            *)
(*                                                                            *)
(******************************************************************************)
function TCICSSession.callFORM( var r: recNCFORM ):boolean;
var
  ws, ss: string;
begin
  result:=false;
  cicsError:='';
  cicsCode:=999;
  screen.cursor:=crHourglass;

  try

//    { temporary trap on network userid }
//    if ( comparetext('MARDEV_1', WagelossMainForm.userid ) = 0 ) then
//    begin
//      cicsError:=RESTRICTED_USER_MSG; cicsCode:=RESTRICTED_USER_CODE; abort;
//    end;

    if ( length(r.Claim_No) < 8 ) or ( length(r.Form_Number) < 4 ) then
    begin
      cicsError:=MISSING_INFO_MSG; cicsCode:=MISSING_INFO_CODE; abort;
    end;


    if not AttachSession then abort;

    ss:='Terminal not in use';
    ws:=sess.screen.getstring(13,27, length(ss));
    if ( comparetext(ss, ws ) = 0 ) then
    begin
      cicsError:=TIME_OUT_MSG; cicsCode:=TIME_OUT_CODE; abort;
    end;

    ss:='ISM Network';
    ws:=sess.screen.getstring(15,51, length(ss));
    if ( comparetext(ss, ws ) = 0 ) then
    begin
      cicsError:=NO_CONNECT_MSG; cicsCode:=NO_CONNECT_CODE; abort;
    end;

    if ( not myWaitHostQuiet ) then
    begin
      cicsError:=NO_RESPONSE_MSG; cicsCode:=NO_RESPONSE_CODE; abort;
    end;

    sess.Screen.SendKeys('<reset>'); // bug in Extra 6.1 - ensure keyboard is reset
    sess.Screen.SendKeys('<clear>');
    if ( not myWaitHostQuiet ) then
    begin
      cicsError:=NO_RESPONSE_MSG; cicsCode:=NO_RESPONSE_CODE; abort;
    end;

    WagelossMainForm.ShowInfoLine1('Issuing FORM transaction.' );
    sess.Screen.SendKeys('FORM ' + r.Form_Number + '      <enter>');
    if ( not myWaitHostQuiet ) then
    begin
      cicsError:=NO_RESPONSE_MSG; cicsCode:=NO_RESPONSE_CODE; abort;
    end;
    if ( not myWaitHostQuiet ) then
    begin
      cicsError:=NO_RESPONSE_MSG; cicsCode:=NO_RESPONSE_CODE; abort;
    end;

    ss:='USSMSG';
    ws:=sess.screen.getstring(2,1, length(ss));
    if ( comparetext(ss, ws ) = 0 ) then
    begin
      cicsError:=NO_CONNECT_MSG; cicsCode:=NO_CONNECT_CODE; abort;
    end;

    ss:='S E C U R I T Y ';
    ws:=sess.screen.getstring(8,23, length(ss));
    if ( comparetext(ss, ws ) = 0 ) then
    begin
      cicsError:=SECURITY_MSG_FORM; cicsCode:=SECURITY_CODE; abort;
    end;

    r.Mf_Cics_Msg:=sess.screen.getstring(2, 2, 79);

    ss:='*** ENTER CLAIM';
    ws:=sess.screen.getstring(2,2, length(ss));
    if ( comparetext(ss, ws ) <> 0 ) then
    begin
      cicsError:=r.Mf_Cics_Msg; cicsCode:=ERROR_CODE; abort;
    end;

    WagelossMainForm.ShowInfoLine1('Entering FORM Data.' );
    CICSPutString(r.Claim_No, 5, 18);
    CICSPutString(r.Firm_Number, 5, 46);
    CICSPutString(r.Firm_Suffix, 5, 54);
    CICSPutString(r.Clinic_Number, 5, 62);
    CICSPutString(r.Doctor_Number, 5, 65);

    sess.Screen.SendKeys('<enter>');
    if ( not myWaitHostQuiet ) then
    begin
      cicsError:=NO_RESPONSE_MSG; cicsCode:=NO_RESPONSE_CODE; abort;
    end;

    ss:='USSMSG';
    ws:=sess.screen.getstring(2,1, length(ss));
    if ( comparetext(ss, ws ) = 0 ) then
    begin
      cicsError:=NO_CONNECT_MSG; cicsCode:=NO_CONNECT_CODE; abort;
    end;

    ss:='S E C U R I T Y ';
    ws:=sess.screen.getstring(8,23, length(ss));
    if ( comparetext(ss, ws ) = 0 ) then
    begin
      cicsError:=SECURITY_MSG_FORM; cicsCode:=SECURITY_CODE; abort;
    end;

    r.Mf_Cics_Msg:=sess.screen.getstring(2, 2, 79);

    ss:='*** FORMS REQUESTS RECORDED';
    ws:=sess.screen.getstring(2,2, length(ss));
    if ( comparetext(ss, ws ) = 0 ) then
    begin
      cicsError:=r.Mf_Cics_Msg; cicsCode:=ERROR_CODE; abort;
    end;

    if not DetachSession then exit;
  except
    result:=false;
    screen.cursor:=crDefault;
    r.Mf_Cics_Status := cicsCode;
    r.Mf_Cics_Msg:=cicsError;
    DetachSession;
    exit;
  end;
  screen.cursor:=crDefault;
  r.Mf_Cics_Status := 0;
  result:=true;
end;

(******************************************************************************)
(*                                                                            *)
(*  Perform CICS UCI4 transaction.                                            *)
(*                                                                            *)
(******************************************************************************)
function TCICSSession.callUCI4( var r: recNCCLAIM ):boolean;
var
  ws, ss: string;
begin
  result:=false;
  cicsError:='';
  cicsCode:=999;
  screen.cursor:=crHourglass;


  try

//    { temporary trap on network userid }
//    if ( comparetext('MARDEV_1', WagelossMainForm.userid ) = 0 ) then
//    begin
//      cicsError:=RESTRICTED_USER_MSG; cicsCode:=RESTRICTED_USER_CODE; abort;
//    end;

    //if not AttachSession then abort;

    ss:='Terminal not in use';
    ws:=sess.screen.getstring(13,27, length(ss));
    if ( comparetext(ss, ws ) = 0 ) then
    begin
      cicsError:=TIME_OUT_MSG; cicsCode:=TIME_OUT_CODE; abort;
    end;

    ss:='ISM Network';
    ws:=sess.screen.getstring(15,51, length(ss));
    if ( comparetext(ss, ws ) = 0 ) then
    begin
      cicsError:=NO_CONNECT_MSG; cicsCode:=NO_CONNECT_CODE; abort;
    end;

    if ( not myWaitHostQuiet ) then
    begin
      cicsError:=NO_RESPONSE_MSG; cicsCode:=NO_RESPONSE_CODE; abort;
    end;

    //********************************************************************//
    //  Check to see that DCI4 for this claimno has already been entered  //
    //  If not, then issue it from here                                   //
    //********************************************************************//

    if ( ( comparetext('DCI4', sess.screen.getstring(1,2,4) ) <> 0 ) or
         ( comparetext('DCI4', sess.screen.getstring(24,77,4) ) <> 0 ) or
         ( comparetext(r.Claim_No , sess.screen.getstring(1,7,8) ) <> 0 ) ) then
    begin
      WagelossMainForm.ShowInfoLine1('Refreshing DCI4 transaction.' );

      sess.Screen.SendKeys('<reset>'); // bug in Extra 6.1 - ensure keyboard is reset
      sess.Screen.SendKeys('<clear>');
      if ( not myWaitHostQuiet ) then
      begin
        cicsError:=NO_RESPONSE_MSG; cicsCode:=NO_RESPONSE_CODE; abort;
      end;

      sess.Screen.SendKeys('DCI4 ' + r.Claim_No + ' <enter>');
      if ( not myWaitHostQuiet ) then
      begin
        cicsError:=NO_RESPONSE_MSG; cicsCode:=NO_RESPONSE_CODE; abort;
      end;
      if ( not myWaitHostQuiet ) then
      begin
        cicsError:=NO_RESPONSE_MSG; cicsCode:=NO_RESPONSE_CODE; abort;
      end;

      ss:='USSMSG';
      ws:=sess.screen.getstring(2,1, length(ss));
      if ( comparetext(ss, ws ) = 0 ) then
      begin
        cicsError:=NO_CONNECT_MSG; cicsCode:=NO_CONNECT_CODE; abort;
      end;

      ss:='S E C U R I T Y ';
      ws:=sess.screen.getstring(8,23, length(ss));
      if ( comparetext(ss, ws ) = 0 ) then
      begin
        cicsError:=SECURITY_MSG_DCI4; cicsCode:=SECURITY_CODE; abort;
      end;

      ss:='DCI4';
      ws:=sess.screen.getstring(24,77, length(ss));
      if ( comparetext(ss, ws ) <> 0 ) then
      begin
        cicsError:=NO_RESPONSE_MSG; cicsCode:=NO_RESPONSE_CODE; abort;
      end;

      r.Mf_Cics_Msg:=sess.screen.getstring(2, 2, 79);

      ss:='TRANSACTION CANCELLED - CLAIM NUMBER NOT VALID';
      ws:=sess.screen.getstring(2,2, length(ss));
      if ( comparetext(ss, ws ) = 0 ) then
      begin
        cicsError:=r.Mf_Cics_Msg; cicsCode:=ERROR_CODE; abort;
      end;

      ss:='TRANSACTION CANCELLED - MAP FAIL';
      ws:=sess.screen.getstring(2,2, length(ss));
      if ( comparetext(ss, ws ) = 0 ) then
      begin
        cicsError:=r.Mf_Cics_Msg; cicsCode:=ERROR_CODE; abort;
      end;

    end;

    WagelossMainForm.ShowInfoLine1('Entering UCI4 data.' );
    //********************************************************************//
    //  Lookup all variables passed to the program and move to screen     //
    //********************************************************************//
    CICSPutNumber100(r.DAYS_WORKED_PER_WEEK, 9, 12, 3);
    CICSPutStringPadded(r.SPOUSE_WORKING, 9, 22, 1);
    CICSPutInteger(r.NO_INFIRM, 9, 32, 3);
    CICSPutStringPadded(r.EI_EXEMPT, 9, 42, 1);
    CICSPutStringPadded(r.TAX_CODE, 9, 52, 3);
    CICSPutInteger(r.TAX_YEAR, 9, 62, 4);
    CICSPutNumber100(r.COLLATERAL_BEN_NON_TAX, 10, 2, 9);
    CICSPutStringPadded(r.DEEMED_EARNINGS, 10, 12, 1);
    CICSPutDate(r.CALC_DATE, 10, 22);
    CICSPutStringPadded(r.MARITAL_STATUS, 10, 32, 1);
    CICSPutInteger(r.NO_OF_DEPENDNTS, 10, 42, 3);
    CICSPutNumber100(r.WKLY_SAL_A, 10, 62, 9);
    CICSPutNumber100(r.TAX_EXEMPTION, 11, 2, 9);
    CICSPutNumber100(r.ANNUAL_GROSS, 11, 12, 9);
    CICSPutNumber100(r.ANNUAL_NET, 11, 22, 9);
    CICSPutNumber100(r.ANNUAL_90, 11, 32, 9);
    CICSPutNumber100(r.ANNUAL_80, 11, 42, 9);
    CICSPutNumber100(r.INC_TAX_FED, 11, 52, 9);
    CICSPutNumber100(r.INC_TAX_MAN, 11, 62, 9);
    CICSPutNumber100(r.CPP_PREM, 11, 72, 9);
    CICSPutNumber100(r.EI_PREM, 12, 2, 9);
    CICSPutNumber100(r.TOTAL_DEDS, 12, 12, 9);
    CICSPutNumber100(r.ANNUAL_90_S, 12, 22, 9);
    CICSPutNumber100(r.ANNUAL_80_S, 12, 32, 9);
    CICSPutNumber100(r.INC_TAX_FED_S, 12, 42, 9);
    CICSPutNumber100(r.INC_TAX_MAN_S, 12, 52, 9);
    CICSPutNumber100(r.CPP_PREM_S, 12, 62, 9);
    CICSPutNumber100(r.EI_PREM_S, 12, 72, 9);
    CICSPutNumber100(r.TOTAL_DEDS_S, 13, 2, 9);
    if Year(r.Accident_Date) >= 2006 then
      CICSPutNumber100(r.WEEKLY_NET, 13, 12, 9)
    else
      CICSPutNumber100(r.WEEKLY_NET - r.Post_Injury_Earn_Net, 13, 12, 9);
    CICSPutNumber100(r.WEEKLY_90, 13, 22, 9);
    CICSPutNumber100(r.WEEKLY_80, 13, 32, 9);
    //Modified - Jan 07 - bcooper - NR64337
    //original:
    CICSPutNumber100(r.WEEKLY_90_S, 13, 42, 9);
    //new:
    //if ( ( r.Weekly_90 - r.Weekly_90_S ) < 0 ) then
    //  CICSPutNumber100(r.WEEKLY_90, 13, 42, 9)
    //else
    //  CICSPutNumber100(r.WEEKLY_90_S, 13, 42, 9);

    CICSPutNumber100(r.WEEKLY_80_S, 13, 52, 9);
    //  CICSPutNumber100(r.CI_04_ELIGIBLE_BNFT_DAILY_RAT, 13, 72, 9);
    //  CICSPutNumber100(r.CI_04_GROSS_75, 14, 2, 9);
    CICSPutStringPadded(userProfile.loginName, 14, 12, 8);
    //  CICSPutStringPadded(r.CALC_USERNAME, 14, 12, 8);
    CICSPutNumber100(r.COLLATERAL_BEN_TAX, 15, 2, 9);
    CICSPutNumber100(r.COLL_BEN_TAX_NET, 15, 12, 9);
    CICSPutNumber100(r.POST_INJURY_EARN, 16, 2, 9);
    CICSPutNumber100(r.POST_INJURY_EARN_NET, 16, 12, 9);
    CICSPutStringPadded(r.SIN, 7, 12, 9);
    CICSPutNumber100(r.Original_Wkly_Sal, 7, 32, 7);
    CICSPutStringPadded(r.Wkly_Sal_Index_Flag, 7, 42, 1);
    CICSPutNumber100(r.Pre_1992_Wkly_Sal, 7, 22, 7);
    CICSPutNumber100(r.Tot_WCB_Anty_Elig_Earn, 8, 2, 9);
    CICSPutNumber100(r.Tot_WCB_Anty_Contib_Amt, 8, 12, 9);
    CICSPutNumber100(r.Tot_CLMT_Anty_Elig_Earn, 8, 22, 9);
    CICSPutNumber100(r.Tot_CLMT_Anty_Contrib_Amt, 8, 32, 9);
    CICSPutDate(r.nc_104_Wk_Clmt_Reply_Date, 6, 46);
    CICSPutDate(r.nc_104_Wk_Effective_Date, 6, 56);
    CICSPutNumber100(r.nc_104_Wk_WCB_p_Contrib, 7, 46, 3);
    CICSPutNumber100(r.nc_104_Wk_WCB_p_Contrib_Red, 7, 50, 3);
    CICSPutDate(r.nc_104_Wk_WCB_p_Eff_Date, 6, 66);
    CICSPutNumber100(r.nc_104_Wk_Clmt_p_Contrib, 7, 54, 3);
    CICSPutDate(r.nc_104_Wk_Clmt_p_Eff_Date, 6, 75);
    CICSPutNumber100(r.Wkly_WCB_Anty_Con_Amt, 17, 2, 9);
    CICSPutNumber100(r.Wkly_WCB_Anty_Con_Amt_S, 17, 12, 9);
    CICSPutNumber100(r.Wkly_Clmt_Anty_Con_Amt, 17, 22, 9);
    CICSPutNumber100(r.Wkly_Clmt_Anty_Con_Amt_S, 17, 32, 9);
    CICSPutDate(r.Indexation_Calc_Date, 17, 42);
    CICSPutInteger(r.Indexation_Year, 17, 52, 4);
    CICSPutStringPadded(r.Employer_Top_Up_Flag,8 , 42, 1);
    r.CI_04_Wkly_NET_Sal := r.Weekly_Net_A; // <== from NCUCI4.sc
    CICSPutNumber100(r.CI_04_Wkly_NET_Sal, 10, 52, 9);

    CICSPutStringPadded(r.AverageEarningsBasedOn, 19, 2, 1);

    CICSPutStringPadded(r.Self_Employed, 20, 2,  1);
    CICSPutStringPadded(r.Recurrence, 20, 4,  1);
    CICSPutStringPadded(r.CPP_Exempt, 20, 6,  1);
    CICSPutStringPadded(r.Tax_Exempt, 20, 8,  1);

    CICSPutNumber100(r.Child_Care_Exp, 20, 12,  9);
    CICSPutNumber100(r.Spousal_Support, 20, 22,  9);
    CICSPutNumber100(r.Child_Support, 20, 32,  9);
    CICSPutNumber100(r.Max_Adjustment, 20, 42,  9);


    CICSPutString('$%=&', 24, 2);

    //********************************************************************//
    //  Issue the UCI4 and wait for the response                          //
    //********************************************************************//

    WagelossMainForm.ShowInfoLine1('Issuing UCI4 transaction.' );
    CICSPutString('UCI4', 1, 2);
    sess.Screen.SendKeys('<PF10>');

      if ( not myWaitHostQuiet ) then
      begin
        cicsError:=NO_RESPONSE_MSG; cicsCode:=NO_RESPONSE_CODE; abort;
      end;
      if ( not myWaitHostQuiet ) then
      begin
        cicsError:=NO_RESPONSE_MSG; cicsCode:=NO_RESPONSE_CODE; abort;
      end;

      ss:='USSMSG';
      ws:=sess.screen.getstring(2,1, length(ss));
      if ( comparetext(ss, ws ) = 0 ) then
      begin
        cicsError:=NO_CONNECT_MSG; cicsCode:=NO_CONNECT_CODE; abort;
      end;

      ss:='S E C U R I T Y ';
      ws:=sess.screen.getstring(8,23, length(ss));
      if ( comparetext(ss, ws ) = 0 ) then
      begin
        cicsError:=SECURITY_MSG_DCI4; cicsCode:=SECURITY_CODE; abort;
      end;

      ss:='UCI4';
      ws:=sess.screen.getstring(24,77, length(ss));
      if ( comparetext(ss, ws ) <> 0 ) then
      begin
        cicsError:=NO_RESPONSE_MSG; cicsCode:=NO_RESPONSE_CODE; abort;
      end;

      r.Mf_Cics_Msg:=sess.screen.getstring(2, 2, 79);

      ss:='UPDATE CANCELLED';
      ws:=sess.screen.getstring(2,2, length(ss));
      if ( comparetext(ss, ws ) = 0 ) then
      begin
        cicsError:=r.Mf_Cics_Msg; cicsCode:=ERROR_CODE; abort;
      end;

    ;
    if not DetachSession then exit;
  except
    screen.cursor:=crDefault;
    r.Mf_Cics_Status := cicsCode;
    r.Mf_Cics_Msg:=cicsError;
    DetachSession;
    exit;
  end;
  screen.cursor:=crDefault;
  r.Mf_Cics_Status := 0;
  result:=true;
end;

(******************************************************************************)
(*                                                                            *)
(*  Perform CICS Logon.                                                       *)
(*                                                                            *)
(******************************************************************************)
function TCICSSession.callLOGI( var r: recNCLOGIN ):boolean;
var
  ws, ss, x, y, z: string;
  res: tmodalresult;
begin
  result:=false;
  cicsError:='*Login to CICS Failed';
  cicsCode:=999;
  screen.cursor:=crHourglass;

  try
    if not AttachSession then
       abort;
    //
    // Prompt for password
    //
    WagelossMainForm.ShowInfoLine1('Userid:'+ r.userid + ' Name:'+
                                   r.userName + ' Region:'+ r.region);

    try
       res:=mrCancel;
       PasswordDlg:=TPasswordDlg.create(application);
       res:= PasswordDlg.showmodal;
       r.password:=PasswordDlg.password.text;
    finally
       PasswordDlg.free;
    end;

    if ( res <> mrOK ) then
       begin
       cicsError:='*Login to CICS cancelled by user';
       abort;
       end;

    screen.cursor:=crHourglass;
    WagelossMainForm.ShowInfoLine1('Clearing CICS Screen.' );
    sess.Screen.SendKeys('<reset>'); // bug in Extra 6.1 - ensure keyboard is reset
    sess.Screen.SendKeys('<clear>');

    if ( not myWaitHostQuiet ) then
       begin
       cicsError:=NO_RESPONSE_MSG; cicsCode:=NO_RESPONSE_CODE; abort;
       end;

    //CICSPutString(r.region, 1, 2);
    //
    // Modified to get the position of the cursor after the reset
    // this will be the "Home" position on the screen
    //
    CICSPutString(r.region, Get_Row, Get_Col);
    sess.Screen.SendKeys('<enter>');

    if ( not myWaitHostQuiet ) then
       begin
       cicsError:=NO_RESPONSE_MSG; cicsCode:=NO_RESPONSE_CODE; abort;
       end;

    if ( not myWaitHostQuiet ) then
       begin
       cicsError:=NO_RESPONSE_MSG; cicsCode:=NO_RESPONSE_CODE; abort;
       end;
    //
    // are we already in CICS?
    //
    if ( ( comparetext('DFHAC2001', x ) <> 0 ) or
         ( comparetext('DFHAC2001', y ) <> 0 ) or
         ( comparetext('F3=Exit' , z ) <> 0 ) ) then
       begin
       WagelossMainForm.ShowInfoLine1('Already attached to CICS.' );
       end
    else
       // else make sure we got into the region successfully.
       begin
       ss:='USSMSG';
       ws:=sess.screen.getstring(2,1, length(ss));

       if ( comparetext(ss, ws ) = 0 ) then
          begin
          cicsError:=NO_CONNECT_MSG; cicsCode:=NO_CONNECT_CODE; abort;
          end;

       if ( not myWaitHostQuiet ) then
          begin
          cicsError:=NO_RESPONSE_MSG; cicsCode:=NO_RESPONSE_CODE; abort;
          end;
       //
       // determine region type from CICS greeting
       //
       ss:='CICS/ESA';
       ws:=sess.screen.getstring(1,13, length(ss));

       if ( comparetext(ss, ws ) <> 0 ) then
          begin
          cicsError:=NO_CONNECT_MSG; cicsCode:=NO_CONNECT_CODE; abort;
          end;
       end;

    //                                                                    //
    //  issue the cesn and wait for the response                          //
    //                                                                    //
    sess.Screen.SendKeys('<reset>'); // bug in Extra 6.1 - ensure keyboard is reset
    sess.Screen.SendKeys('<clear>');

    if ( not myWaitHostQuiet ) then
       begin
       cicsError:=NO_RESPONSE_MSG; cicsCode:=NO_RESPONSE_CODE; abort;
       end;

    WagelossMainForm.ShowInfoLine1('Issuing CICS Signon transaction "CESN".' );
    sess.Screen.SendKeys('CESN <enter>');

    if ( not myWaitHostQuiet ) then
       begin
       cicsError:=NO_RESPONSE_MSG; cicsCode:=NO_RESPONSE_CODE; abort;
       end;

    if ( not myWaitHostQuiet ) then
       begin
       cicsError:=NO_RESPONSE_MSG; cicsCode:=NO_RESPONSE_CODE; abort;
       end;

    ss:='Useri';
    ws:=sess.screen.getstring(10,10, length(ss));

    if ( comparetext(ss, ws ) <> 0 ) then
       begin
       cicsError:='CESN failed.'; cicsCode:=ERROR_CODE; abort;
       end;

    ss:='Pass';
    ws:=sess.screen.getstring(11,10, length(ss));

    if ( comparetext(ss, ws ) <> 0 ) then
       begin
       cicsError:='CESN failed.'; cicsCode:=ERROR_CODE; abort;
       end;

    WagelossMainForm.ShowInfoLine1('Entering Userid and Password.' );
  	CICSPutString(r.userid, 10, 25);
  	CICSPutString(r.password, 11, 25);
    sess.Screen.SendKeys('<enter>');
    WagelossMainForm.ShowInfoLine1('Waiting for Login to proceed.' );

    if ( not myWaitHostQuiet ) then
       begin
       cicsError:=NO_RESPONSE_MSG; cicsCode:=NO_RESPONSE_CODE; abort;
       end;

    if ( not myWaitHostQuiet ) then
       begin
       cicsError:=NO_RESPONSE_MSG; cicsCode:=NO_RESPONSE_CODE; abort;
       end;
    //
  	// Is there a message from CESN?
    //
    ss:='DFH';
    ws:=sess.screen.getstring(23,2, length(ss));

    if ( comparetext(ss, ws ) = 0 ) then
       begin
       sess.activate;
       cicsError:='CESN failed.'; cicsCode:=ERROR_CODE; abort;
       end;
    //
    // Are we still on the CESN screen?
    //
    ss:='Useri';
    ws:=sess.screen.getstring(10, 10, length(ss));
    if ( comparetext(ss, ws ) = 0 ) then
    begin
      sess.activate;
      cicsError:='CESN failed.'; cicsCode:=ERROR_CODE; abort;
    end;

    ss:='PRESS CLEAR TO CONTINUE.';
    ws:=sess.screen.getstring(24, 2, length(ss));
    if ( comparetext(ss, ws ) <> 0 ) then
    begin
      sess.activate;
      cicsError:='CESN failed.'; cicsCode:=ERROR_CODE; abort;
    end;

    ss:='W O R K';
    ws:=sess.screen.getstring(15, 20, length(ss));
    if ( comparetext(ss, ws ) <> 0 ) then
    begin
      sess.activate;
      cicsError:='CESN failed.'; cicsCode:=ERROR_CODE; abort;
    end;

    WagelossMainForm.ShowInfoLine1('Login successful.' );
    if not DetachSession then exit;
  except
    result:=false;
    screen.cursor:=crDefault;
    r.Mf_Cics_Status := cicsCode;
    r.Mf_Cics_Msg:=cicsError;
    DetachSession;
    exit;
  end;
  screen.cursor:=crDefault;
  r.Mf_Cics_Status := 0;
  result:=true;
end;

end.

