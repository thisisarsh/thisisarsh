unit NCWrkRptJul17;

interface

uses
  Windows, Messages, SysUtils, Variants, Classes, Graphics, Controls, Forms,
  Dialogs, NCWrkRptJan16, NCIniMod, UtilMod1, NCWrkRptJan17;

type
  TWrkRptJul17 = class(TWrkRptJan17)
  function getDateHeading():String; Override;
  function TaxCalculationBand1P3(Nc_Bc_Ann_Sal_Net: currency; Nc_Bc_Nrtc: currency): currency; Override;
  Function  TaxCalculationBand1P5b( Nc_Bc_Ann_Sal_Net: currency; Nc_Bc_Mb_Nrtc: currency; Nc_Bc_Mbt: currency): currency; Override;
  private
    { Private declarations }
  public
    { Public declarations }
  end;

var
  WrkRptJul17: TWrkRptJul17;

implementation

{$R *.dfm}

{ TWrkRptJul17 }
(******************************************************************************)
(*                                                                            *)
(*  override this function for each class to avoid having to bring in all of  *)
(*    the methods that contain the date in the heading.                       *)
(*   IE:  the jan 09 class should return  2008/2009                           *)
(*        the july 09 class should return 2009                                *)
(*                                                                            *)
(******************************************************************************)

function TWrkRptJul17.getDateHeading: String;
begin
  Result:='2017'
end;

Function TWrkRptJul17.TaxCalculationBand1P3(Nc_Bc_Ann_Sal_Net: currency;
                                             Nc_Bc_Nrtc: currency): currency;
Var
  const1, const2, const3, const4: currency;
  f1i, f2p, work, temp: currency;
  //dispTaxRate, dispTaxAmt, dispFedTaxAmt, dispBasicFedTaxAmt: currency;
Begin
  with arrayNCTAXRAT[indexNCTAXRAT] do
    begin
    sRpt.add('    +'+ dash(76) + '+');
    sRpt.add( format('    | %-28s | %-20s | %-20s |', [
      'Taxable Income Amount',
      'Federal Tax Rate',
      'Constant'
      ]));
    sRpt.add('    +'+ dash(76) + '+');
    sRpt.add( format('    | %-28s | %-20s | %-20s |', [
      format('%.0n',[FED_income_level_i]) + ' or less',
      format('%.2n',[(FED_tax_rate_i*100.00)]) + '%',
      format('%.2n',[0.00])
      ]));
    const1 := FED_income_level_i * (FED_tax_rate_ii - FED_tax_rate_i);
    temp := Round(const1);
    sRpt.add( format('    | %-28s | %-20s | %-20s |', [
      '> ' + format('%.0n',[FED_income_level_i]),
      format('%.1n',[(FED_tax_rate_ii*100.00)]) + '%',
      format('%.2n',[temp])
      ]));
    const2 := FED_income_level_ii * (FED_tax_rate_iii - FED_tax_rate_ii)
              + const1;
    temp := Round(const2);
    sRpt.add( format('    | %-28s | %-20s | %-20s |', [
      '> ' + format('%.0n',[FED_income_level_ii]),
      format('%.1n',[(FED_tax_rate_iii*100.00)]) + '%',
      format('%.2n',[temp])
      ]));
    const3 := FED_income_level_iii * (FED_tax_rate_iiii - FED_tax_rate_iii)
              + const2;
    temp := Round(const3);
    sRpt.add( format('    | %-28s | %-20s | %-20s |', [
      '> ' + format('%.0n',[FED_income_level_iii]),
      format('%.1n',[(FED_tax_rate_iiii*100.00)]) + '%',
      format('%.2n',[temp])
      ]));
    const4 := FED_income_level_iiii * (FED_tax_rate_iiiii - FED_tax_rate_iiii)
              + const3;
    temp := Round(const4);
    sRpt.add( format('    | %-28s | %-20s | %-20s |', [
      '> ' + format('%.0n',[FED_income_level_iiii]),
      format('%.1n',[(FED_tax_rate_iiiii*100.00)]) + '%',
      format('%.2n',[temp])
      ]));
    sRpt.add('    +'+ dash(76) + '+');
    sRpt.add(' ');
    sRpt.add('Federal Tax:');
    sRpt.add(' ');
    sRpt.add('    For ' + formatF(Nc_Bc_Ann_Sal_Net, 11, 2 ) +' (Amount (LK) above):' );
    const1 := Round(const1);
    const2 := Round(const2);
    const3 := Round(const3);
    const4 := Round(const4);

    if ( Nc_Bc_Ann_Sal_Net > FED_income_level_iiii ) then
      begin
      f2p := FED_tax_rate_iiiii;
      f1i := const4;
      end
    else if ( Nc_Bc_Ann_Sal_Net > FED_income_level_iii ) then
      begin
      f2p := FED_tax_rate_iiii;
      f1i := const3;
      end
    else if ( Nc_Bc_Ann_Sal_Net > FED_income_level_ii ) then
      begin
      f2p := FED_tax_rate_iii;
      f1i := const2;
      end
    else if ( Nc_Bc_Ann_Sal_Net > FED_income_level_i ) then
      begin
      f2p := FED_tax_rate_ii;
      f1i := const1;
      end
    else
      begin
      f2p := FED_tax_rate_i;
      f1i := 0.00;
      end;
    end;

    // added tax exempt here  jwd
  if (wrkClaim.Claim_No = '00000000') or ( wrkClaim.Tax_Exempt = 'Y' ) Then
     begin
     f2p := 0; // set the tax rate to be a blank
     end;

  sRpt.add(' ');
  sRpt.add( format('%-56s %-14s %-14s', [
    '    Multiply by tax rate from above table ' + format('%.2n',[f2p * 100]){FormatF((f2p * 100), 5, 1)} + '%',
    formatF((Nc_Bc_Ann_Sal_Net * f2p), 12, 2 ), ' '
    ] ));
  sRpt.add(' ');
  sRpt.add( format('%-56s %-14s %-14s', [
    '    Less:  Constant from above table',
    formatF(f1i, 12, 2 ), ' '
    ] ));
  work := (Nc_Bc_Ann_Sal_Net * f2p) - f1i;
  if work < 0 then work := 0.00;
  sRpt.add( format('%-56s %-14s %-14s', [ ' ',  dash(12), ' '       ]));
  sRpt.add( format('%-56s %-14s %-14s', [
    '    Federal Tax ',
    formatF( work, 12, 2 ),
    ' (N)'
    ] ));
  sRpt.add(' ');

  if (wrkClaim.Claim_No <> '00000000') Then
     sRpt.add( format('%-56s %-14s %-14s', [
         '    Less: Non Refundable Tax Credit (L) above ',
         formatF( Nc_Bc_Nrtc, 12, 2 ),
         ' '
         ] ))
  else
     sRpt.add( format('%-56s %-14s %-14s', [
         '    Less: Non Refundable Tax Credit (L) above ',
         formatF(0.00, 12, 2 ),
         ' '
         ] ));

  result := ((Nc_Bc_Ann_Sal_Net * f2p) - f1i) - Nc_Bc_Nrtc;
  if result < 0 then result := 0;
  sRpt.add( format('%-56s %-14s %-14s', [ ' ',  dash(12), ' '       ]));
  sRpt.add( format('%-56s %-14s %-14s', [
    '    Basic Federal Tax ',
    formatf( result, 12, 2),
    ' (O)'
    ] ));
  sRpt.add( format('%-56s %-14s %-14s', [ ' ', dDash(12), ' '       ]));
  sRpt.add(' ');
End;

Function  TWrkRptJul17.TaxCalculationBand1P5b( Nc_Bc_Ann_Sal_Net: currency;
                                               Nc_Bc_Mb_Nrtc: currency;
                                               Nc_Bc_Mbt: currency): currency;
var
  const1, const2, f2p, f1i, work: currency;
begin
  sRpt.add(' ');
  sRpt.add(getDateHeading() + ' Manitoba Tax Rates and Income Thresholds (WCB):');
  sRpt.add(' ');
  with arrayNCTAXRAT[indexNCTAXRAT] do
    begin
    sRpt.add('    +'+ dash(76) + '+');
    sRpt.add( format('    | %-28s | %-20s | %-20s |', [
      'Taxable Income Amount',
      'Rate',
      'Constant'
      ]));
    sRpt.add('    +'+ dash(76) + '+');
    sRpt.add( format('    | %-28s | %-20s | %-20s |', [
      format('%.0n',[MB_income_level_i]) + ' or less',
      format('%.2n',[(MB_tax_rate_i*100.00)]) + '%',
      format('%.0n',[0.00])
      ]));
    //const1 := Round(MB_income_level_i * (MB_tax_rate_ii - MB_tax_rate_i));
    const1 := PDoxRound(MB_income_level_i * (MB_tax_rate_ii - MB_tax_rate_i), 0);
    sRpt.add( format('    | %-28s | %-20s | %-20s |', [
      '> ' + format('%.0n',[MB_income_level_i]),
      format('%.2n',[(MB_tax_rate_ii*100.00)]) + '%',
      format('%.0n',[const1])
      ]));
    const2 := Round(MB_income_level_ii * (MB_tax_rate_iii - MB_tax_rate_ii)
      + const1);
    sRpt.add( format('    | %-28s | %-20s | %-20s |', [
      '> ' + format('%.0n',[MB_income_level_ii]),
      format('%.2n',[(MB_tax_rate_iii*100.00)]) + '%',
      format('%.0n',[const2])
      ]));
    sRpt.add('    +'+ dash(76) + '+');
    sRpt.add(' ');
    sRpt.add('Manitoba Tax:');
    sRpt.add(' ');
    sRpt.add('    For ' + formatF(Nc_Bc_Ann_Sal_Net, 11, 2 ) +' (Amount (LK) above):' );

    if ( Nc_Bc_Ann_Sal_Net > MB_income_level_ii ) then
      begin
      f2p := MB_tax_rate_iii;
      f1i := const2;
      end
    else if ( Nc_Bc_Ann_Sal_Net > MB_income_level_i ) then
      begin
      f2p := MB_tax_rate_ii;
      f1i := const1;
      end
    else
      begin
      f2p := MB_tax_rate_i;
      f1i := 0.0;
      end;
    end;

  if (wrkClaim.Claim_No = '00000000')  or ( wrkClaim.Tax_Exempt = 'Y' ) Then
     begin
     f2p := 0; // set the tax rate to be a blank
     end;

  sRpt.add(' ');
  sRpt.add( format('%-56s %-14s %-14s', [
    '    Multiply by tax rate from above table ' + format('%.2n',[f2p * 100]) + '%',
    formatF((Nc_Bc_Ann_Sal_Net * f2p), 12, 2 ), ' '
    ] ));
  sRpt.add(' ');
  sRpt.add( format('%-56s %-14s %-14s', [
    '    Less:  Constant from above table',
    formatF(f1i, 12, 2 ), ' '
    ] ));
  work := (Nc_Bc_Ann_Sal_Net * f2p) - f1i;

  if work < 0 then
     work := 0;

  sRpt.add( format('%-56s %-14s %-14s', [ ' ', dash(12), ' ']));
  sRpt.add( format('%-56s %-14s %-14s (Q)', [
    '    Manitoba Tax ',
    formatF( work, 12, 2 ),
    ' '
    ] ));
  sRpt.add(' ');
  if (wrkClaim.Claim_No <> '00000000') Then
     sRpt.add( format('%-56s %-14s %-14s', [
         '    Less: Non Refundable Tax Credit (M) above ',
         formatF( Nc_Bc_Mb_Nrtc, 12, 2 ),
  	 ' '
         ] ))
  else
     sRpt.add( format('%-56s %-14s %-14s', [
         '    Less: Non Refundable Tax Credit (M) above ',
         formatF(0.00, 12, 2 ),
  	 ' '
         ] ));
  result := Nc_Bc_Mbt;
  sRpt.add( format('%-56s %-14s %-14s', [ ' ', dash(12), ' ' ]));
  sRpt.add( format('%-56s %-14s %-14s (U)', [
  	'    Manitoba Provincial Tax ',
    ' ',
    formatF( result, 12, 2 )
    ] ));
  sRpt.add( format('%-56s %-14s %-14s', [ ' ', ' ', dDash(12)]));
end;


end.
