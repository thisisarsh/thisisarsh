unit NCNonExRpt;

interface

uses
  Windows, Messages, SysUtils, Classes, Graphics, Controls, Forms, Dialogs,
  ExtCtrls, QuickRpt, Qrctrls;

type
  TPrintTopUpNonExemptionForm = class(TForm)
    QRNonExempt: TQuickRep;
    QRBand1: TQRBand;
    QRLabel1: TQRLabel;
    QRExpr2: TQRExpr;
    QRLabel9: TQRLabel;
    QRExpr1: TQRExpr;
    QRGroup2: TQRGroup;
    lblGroupCaption: TQRLabel;
    QRLabel7: TQRLabel;
    QRLabel8: TQRLabel;
    QRLabel12: TQRLabel;
    QRShape2: TQRShape;
    QRBand2: TQRBand;
    QRBand3: TQRBand;
    QRDBText1: TQRDBText;
    QRExpr3: TQRExpr;
    QRDBText2: TQRDBText;
    QRDBText3: TQRDBText;
    lblFooterLabel: TQRLabel;
    QRShape1: TQRShape;
    procedure QRGroup1BeforePrint(Sender: TQRCustomBand;
      var PrintBand: Boolean);
    procedure QRBand3BeforePrint(Sender: TQRCustomBand;
      var PrintBand: Boolean);
  private
    { Private declarations }
  public
    { Public declarations }
  end;

var
  PrintTopUpNonExemptionForm: TPrintTopUpNonExemptionForm;

implementation

uses NCDatMod;

{$R *.DFM}



procedure TPrintTopUpNonExemptionForm.QRGroup1BeforePrint(
  Sender: TQRCustomBand; var PrintBand: Boolean);
begin
     with dm1 do
        begin
          if usp_non_exemption_reportInitialPayment.value = 1 then begin
             lblGroupCaption.Caption := 'Initial Payment Claims';
             lblFooterLabel.Caption := 'Count of Initial Claims:';
          end;
          if usp_non_exemption_reportTwelveWeeks.value = 1 then begin
             lblGroupCaption.Caption := '12 Week Claims';
             lblFooterLabel.Caption := 'Count of 12 Week Claims:';
          end;
          if usp_non_exemption_reportSixtyFourWeeks.value = 1 then begin
             lblGroupCaption.Caption := '64 Week Claims';
             lblFooterLabel.Caption := 'Count of 64 Week Claims:';
          end;
          if usp_non_exemption_reportOneHundredFourWeeks.value = 1 then begin
             lblGroupCaption.Caption := '104 Week Claims';
             lblFooterLabel.Caption := 'Count of 104 Week Claims:';
          end;
        end;
end;

procedure TPrintTopUpNonExemptionForm.QRBand3BeforePrint(
  Sender: TQRCustomBand; var PrintBand: Boolean);
var
  i : Integer;
begin
  with QRBand3 do
  begin
    if Color = $00F0F0F0 then
      Color := $00E0E0E0
    else
      Color := $00F0F0F0;
    for i := 0 to ControlCount-1 do
    begin
       TQRLabel(Controls[i]).Color := Color;
    end;
  end;
end;

end.
