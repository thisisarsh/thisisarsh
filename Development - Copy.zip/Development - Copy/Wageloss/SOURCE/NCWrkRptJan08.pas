unit NCWrkRptJan08;

interface

uses
  Windows, Messages, SysUtils, Variants, Classes, Graphics, Controls, Forms,
  Dialogs, quickrpt, NCIniMod, UtilMod1, NCRecDef, NCWrkRptJul07, NCDatMod;

type
  TWrkRptJan08 = class(TWrkRptJul07)
  procedure CollateralBenefitWagelossBand1; Override;
  procedure ExcemptionAndCreditAmountBand1P1; Override;
  procedure ExcemptionAndCreditAmountBand1Man1; Override;
  procedure ExcemptionAndCreditAmountBand1P2; Override;
  procedure n90NetShelteredTaxBenefitBand1; Override;
  procedure NetIncomeBand1; Override;
  procedure GrossIncomeBand1; Override;
  procedure TaxCalculationBand1P1( const income: currency;
                                     	      sIncType: shortstring;
                                              Nc_Bc_Ann_Sal_Net: currency); Override;
  Function  TaxCalculationBand1P5b( Nc_Bc_Ann_Sal_Net: currency;
                                               Nc_Bc_Mb_Nrtc: currency;
                                               Nc_Bc_Mbt: currency): currency; Override;
  //procedure TaxCalculationBand1P2(const income: currency;
  //                                           Nc_Bc_Ann_Sal_Net: currency;
  //                                           Nc_Bc_Uic: currency;
  //                                           Nc_Bc_Cpp: currency;
  //                                           Nc_Bc_Nrtc: currency;
  //                                           Nc_Bc_Mb_Nrtc: currency;
  //                                           federalCanadaEmploymentCredit: currency); Override;
  procedure TaxCalculationBand1P2(const income: currency;
                                             Nc_Bc_Ann_Sal_Net: currency;
                                             Nc_Bc_Uic: currency;
                                             Nc_Bc_Cpp: currency;
                                             Nc_Bc_Nrtc: currency;
                                             Nc_Bc_Mb_Nrtc: currency;
                                             nc_mbFamilyTaxBenefitAmt: currency); Override;
  private
    { Private declarations }
  public
    { Public declarations }
  end;

var
  WrkRptJan08: TWrkRptJan08;

implementation

uses NCWrkRpt;

{$R *.dfm}

(******************************************************************************)
(*                                                                            *)
(*  Create 90 Net Sheltered Band                                              *)
(*                                                                            *)
(******************************************************************************)
procedure TWrkRptJan08.n90NetShelteredTaxBenefitBand1;
var
  strTemp : String;
  shelterAmount : currency;
begin
  with wrkClaim do
  begin
      if Year(Accident_Date) >= 2006 then begin
        sRpt.add('Minimum Full Wage Loss Benefits payable at 100%');
        sRpt.add('    (i) for actual wages (A) if less than minimum annual earnings (AA) or');
        sRpt.add('    (ii) for minimum annual earnings (AA) if actual wages (A) are greater than minimum (AA)');
        sRpt.add(' ');
        if (Wkly_Sal_A) < (Minimum_wage / 52) then
          weeklyWageGross := formatF(Wkly_Sal_A, 12, 2)
        else
          weeklyWageGross := formatF(Minimum_wage / 52, 12, 2);

        if Pay_At_100_Flag then
          strTemp := ' '
        else
          strTemp := formatF(Wkly_Sal_A, 12, 2);
        sRpt.add( format('%-56s %-14s %-14s', [ 'Weekly Wage (gross)',
                                             weeklyWageGross,
                                              strTemp ]));
        sRpt.add(' ');

        if Self_Employed = 'Y' then begin
          sRpt.add( format('%-56s %-14s %-14s', [ 'Max Adjustment Override',
                                            ' ',
                                             formatF(Wkly_Sal, 12, 2) ]));
          sRpt.add(' ');
        end;

        if Pay_At_100_Flag then
          strTemp := ' '
        else
          strTemp := '        @90%';
        sRpt.add(format('%-56s %-14s %-14s', [ 'Net Sheltered Benefit Calculation:',
                                              '       @100%',
                                              strTemp ]));
        sRpt.add( format('%-56s %-14s %-14s', [ dash(34), ' ', ' ' ]));
        sRpt.add(' ');

        if (Annual_Net / 52.0) < (Min_Wage_Annual_Net_A / 52) then
          weeklyNet := Annual_Net
        else
          weeklyNet := Min_Wage_Annual_Net_A;

        sRpt.add( format('%-56s %-14s %-14s', [
          'Weekly Net (lessor of net (A) or (AA)-minimum benefit)',
          formatF( PDoxRound((weeklyNet / 52.0), 2), 12, 2 ),
          ' '
          ] ));

        sRpt.add( format('%-56s %-14s %-14s', [ ' ',  dash(12), ' '       ]));

        if Pay_At_100_Flag then
          shelterAmount := cWeeklyShelterBenefitAmount
        else
          shelterAmount := cWeeklyShelterMinBenAmount;

        sRpt.add( format('%-56s %-14s %-14s', [
          'Less: Weekly Shelter Benefit Amount ( from (W)-min ben )',
          formatF( PDoxRound(shelterAmount, 2), 12, 2 ),
          ' '
          ] ));
        sRpt.add( format('%-56s %-14s %-14s', [ ' ',  dash(12), ' '       ]));

        if not Pay_At_100_Flag then begin
          sRpt.add( format('%-56s %-14s %-14s', [
              'Weekly Net (lessor of net (A) or (B)-regular benefit)',
              ' ',
              formatF( (PDoxRound((Annual_Net / 52.0), 2) * 0.90), 12, 2 )
              ] ));
          sRpt.add( format('%-56s %-14s %-14s', [ ' ',  ' '     , dash(12) ]));

          sRpt.add( format('%-56s %-14s %-14s', [
            'Less: Weekly Shelter Benefit Amount ( from (W)-reg ben )',
            ' ',
            formatF(PDoxRound(cWeeklyShelterBenefitAmount *0.90, 2), 12, 2 )
            ] ));
          sRpt.add( format('%-56s %-14s %-14s', [ ' ',  ' '     , dash(12) ]));
        end;

        sRpt.add(' ');

        if Pay_At_100_Flag then
          strTemp := ' '
        else
          strTemp := formatF(PDoxRound((PDoxRound((Annual_Net / 52.0),2)-PDoxRound(cWeeklyShelterBenefitAmount, 2))*0.90, 2), 12, 2 );

        sRpt.add( format('%-56s %-14s %-14s', [
          'Weekly Net Sheltered Full Loss of Earnings',
          formatF( (PDoxRound((weeklyNet/ 52.0), 2)-PDoxRound(shelterAmount, 2)), 12, 2 ),
          strTemp
          ] ));

        if Pay_At_100_Flag then
          strTemp := ' '
        else
          strTemp :=  dDash(12);

        sRpt.add( format('%-56s %-14s %-14s', [ ' ',  dDash(12) , strTemp ]));
      end else begin
        sRpt.add( '90% Net Sheltered Benefit Calculation:' );

        sRpt.add(' ');

        sRpt.add( format('%-56s %-14s %-14s', [
          'Weekly Net ( lessor of net (A) or (B) )',
          formatF( PDoxRound((Annual_Net / 52.0), 2), 12, 2 ),
          '(i)'
          ] ));
        sRpt.add( format('%-56s %-14s %-14s', [ ' ',  dash(12), ' '       ]));

        sRpt.add( format('%-56s %-14s %-14s', [
          'Weekly Net @ 90%  ( (i) x 90% )',
          ' ',
          formatF( (PDoxRound((Annual_Net / 52.0), 2) * 0.90), 12, 2 )
          ] ));
        sRpt.add( format('%-56s %-14s %-14s', [ ' ',  ' '     , dDash(12) ]));

        sRpt.add( format('%-56s %-14s %-14s', [
          'Weekly Net @ 80%  ( (i) x 80% )',
          ' ',
          formatF( ( PDoxRound((Annual_Net / 52.0), 2) * 0.80 ), 12, 2 )
          ] ));
        sRpt.add( format('%-56s %-14s %-14s', [ ' ',  ' '     , dDash(12) ]));

        sRpt.add( format('%-56s %-14s %-14s', [
          'Less: Weekly Shelter Benefit Amount ( from (W) )',
          formatF( PDoxRound(cWeeklyShelterBenefitAmount, 2), 12, 2 ),
          ' '
          ] ));
        sRpt.add( format('%-56s %-14s %-14s', [ ' ',  dash(12), ' '       ]));

        sRpt.add( format('%-56s %-14s %-14s', [
          'Weekly Net Sheltered Loss of Earnings',
          formatF( (PDoxRound((Annual_Net/ 52.0), 2)-PDoxRound(cWeeklyShelterBenefitAmount, 2)), 12, 2 ),
          ' (ii)'
          ] ));
        sRpt.add( format('%-56s %-14s %-14s', [ ' ', dDash(12), ' '       ]));

        sRpt.add( format('%-56s %-14s %-14s', [
          'Weekly Net Sheltered @ 90% ( (ii) x 90% )',
          ' ',
          formatF(PDoxRound((PDoxRound((Annual_Net / 52.0),2)-PDoxRound(cWeeklyShelterBenefitAmount, 2))*0.90, 2), 12, 2 )
          ] ));
        sRpt.add( format('%-56s %-14s %-14s', [ ' ',  ' '     , dDash(12) ]));
      end;

    sRpt.add(' ');
    sRpt.add(dash(91));
  end;
end;

(******************************************************************************)
(*                                                                            *)
(*  Create Net Income Band                                                    *)
(*                                                                            *)
(******************************************************************************)
procedure TWrkRptJan08.NetIncomeBand1;
var
  strTemp : String;
  netIncome : currency;
begin
  with wrkClaim do
  begin
    sRpt.add(' ');

    if Year(Accident_Date) >= 2006 then begin
      strTemp := 'Net Income Amounts: ( from calculation attached for Gross Incomes A, ';
      if not Pay_At_100_Flag then
        strTemp := strTemp + 'AA, B & E above )'
      else
        strTemp := strTemp + 'B & E above )';
      sRpt.add(strTemp);
      sRpt.add(' ');
      sRpt.add( format('%-14s %-42s %-14s %14s',[ 'Type',' Annual Net ', 'Weekly Net  ', 'Weekly Net  ']));
      sRpt.add( format('%-14s %-42s %-14s %14s',[ '----',' -----------', '------------', '------------']));
      sRpt.add( format('%-14s %-42s %-14s %14s',[ '  ', '  ', '    @100%', '@90%    '] ));
      sRpt.add(' ');

      //i changed this to annual_net....is this right???
      sRpt.add(
        format('%-14s %-42s %-16s %-14s',
          [ ' (A)',
          formatF(Annual_Net_A, 12, 2  ) + ' / 52 =',
          formatF( ( Annual_Net_A / 52.0 ), 11, 2),
          formatF( PDoxRound((Annual_Net_A / 52.0) * 0.90, 2), 11, 2)
          ] ));
      {sRpt.add(
        format('%-14s %-42s %-16s %-14s',
          [ ' (A)',
          formatF(Annual_Net_A, 12, 2  ) + ' / 52 =',
          formatF( ( Annual_Net_A / 52.0 ), 11, 2),
          formatF( PDoxRound((Annual_Net_A / 52.0) * 0.90, 2), 11, 2)
          ] ));}
      sRpt.add( format('%-14s %-42s %-16s %-14s',[ ' ', 'Actual income', dDash(12), dDash(12) ]));
      sRpt.add(' ');

      //suppress next section if wage is less than minimum
      if not Pay_At_100_Flag then
         begin
         sRpt.add(format('%-14s %-42s %-16s %-14s',
                  [ ' (AA)',
                  formatF(fWorking.Work_nc_bc_netinc_m, 12, 2  ) + ' / 52 =',
                  formatF( ( fWorking.Work_nc_bc_netinc_m / 52.0 ), 11, 2),
                  '$     n/a    '
                  ] ));
         sRpt.add( format('%-14s %-42s %-16s %-14s',[ ' ', 'Minimum Income', dDash(12), dDash(12) ]));
         sRpt.add(' ');
         end;

      //only need to display the next part if the worker has something in the max adjustment
      //override field
      if Max_Adjustment > 0 then begin
        sRpt.add(
          format('%-14s %-42s %-16s %-14s',
            [ ' (B)',
            formatF(Annual_Net, 12, 2  ) + ' / 52 =',
            formatF( ( Annual_Net / 52.0 ), 11, 2),
            formatF( PDoxRound((Annual_Net / 52.0) * 0.90, 2), 11, 2)
            ] ));
        //sRpt.add( format('%-14s %-42s %-16s %-14s',[ ' ', 'Limited to Annual Maximum', dDash(12), dDash(12) ]));
        sRpt.add( format('%-14s %-42s %-16s %-14s',[ ' ', 'Limited to Max Adj Override', dDash(12), dDash(12) ]));
        sRpt.add(' ');
      end;

      netIncome := Set_nc_bc_netinc( 'Post-Injury + Collateral Benefits' );

      sRpt.add(
        format('%-14s %-42s %-16s %-14s',
          [ ' (E)',
          formatF(netIncome, 12, 2  ) + ' / 52 x (i) / D =',
          formatF( Coll_Ben_Tax_Net, 11, 2),
          '$     n/a    '
          ] ));
      sRpt.add( format('%-14s %-42s %-16s %-14s',[ ' ', 'Taxable Collateral Benefits', dDash(12), dDash(12) ]));
      sRpt.add(' ');

      //if Pay_At_100_Flag then
        //strTemp := formatF( (Post_Injury_Earn_Net), 11, 2)
      //else
        //strTemp := formatF( ( PDoxRound(Post_Injury_Earn_Net * 1.11111, 2 ) ), 11, 2);

      sRpt.add(
        format('%-14s %-42s %-16s %-14s',
          [ ' (E)',
          formatF(netIncome, 12, 2  ) + ' / 52 x (ii) / D  =',
          formatF( (Post_Injury_Earn_Net), 11, 2),
          formatF(PDoxRound(Post_Injury_Earn_Net * 0.90, 2), 11, 2)
          ] ));
      sRpt.add( format('%-14s %-42s %-16s %-14s',[ ' ', 'Post Injury Earnings', dDash(12), dDash(12) ]));
      sRpt.add(' ');

      sRpt.add(
        format('%-14s %-42s %-16s %-14s',
          [ ' (E)',
          formatF(( Tax_Coll_Ben_Only * 52.0), 12, 2  ) + ' / 52 =',
          formatF( (Tax_Coll_Ben_Only), 11, 2),
          '$     n/a    '
          ] ));
      sRpt.add( format('%-14s %-42s %-16s %-14s',[ ' ', 'Taxable Collateral Benefits - Only', dDash(12), dDash(12) ]));
      sRpt.add(' ');
    end else begin
      sRpt.add(' ');
      sRpt.add('Net Income Amounts: ( from calculation attached for Gross Incomes A,B,E above )');
      sRpt.add(' ');
      sRpt.add( format('%-14s %-56s %-14s',[ 'Type',' Annual Net ', 'Weekly Net  ']));
      sRpt.add( format('%-14s %-56s %-14s',[ '----',' -----------', '------------']));
      sRpt.add(' ');

      sRpt.add(
        format('%-14s %-56s %-14s',
          [ ' (A)',
          formatF(Annual_Net_A, 12, 2  ) + ' / 52 =',
          formatF( ( Annual_Net_A / 52.0 ), 11, 2)
          ] ));
      sRpt.add( format('%-14s %-56s %-14s',[ ' ', 'actual income', dDash(12) ]));
      sRpt.add(' ');

      sRpt.add(
        format('%-14s %-56s %-14s',
          [ ' (B)',
          formatF(Annual_Net, 12, 2  ) + ' / 52 =',
          formatF( ( Annual_Net / 52.0 ), 11, 2)
          ] ));
      sRpt.add( format('%-14s %-56s %-14s',[ ' ', 'limited to annual maximum', dDash(12) ]));
      sRpt.add(' ');

      sRpt.add(
        format('%-14s %-56s %-14s',
          [ ' (E)',
          formatF((Coll_Ben_Tax_Net*52), 12, 2  ) + ' / 52 x (i) / D =',
          formatF( Coll_Ben_Tax_Net, 11, 2)
          ] ));
      sRpt.add( format('%-14s %-56s %-14s',[ ' ', 'taxable collateral benefits', dDash(12) ]));
      sRpt.add(' ');

      sRpt.add(
        format('%-14s %-56s %-14s',
          [ ' (E)',
          formatF((Post_Injury_Earn_Net*52.0), 12, 2  ) + ' / 52 x (ii) / D  =',
          formatF( (Post_Injury_Earn_Net), 11, 2)
          ] ));
      sRpt.add( format('%-14s %-56s %-14s',[ ' ', 'post injury earnings', dDash(12) ]));
      sRpt.add(' ');
    end;

    sRpt.add(' ');
    sRpt.add(dash(91));
  end;
end;

(******************************************************************************)
(*                                                                            *)
(*  Create Collateral Benefits Band                                           *)
(*                                                                            *)
(******************************************************************************)
procedure TWrkRptJan08.CollateralBenefitWagelossBand1;
var
   CollBenClaim:recNCClaim;
   CollBenWorking:recConst;
   weeklyNet: double;
   strTemp: String;
   CurrTemp:Currency;
begin
  with wrkClaim do
     begin
     CopyNCClaim(wrkClaim, CollBenClaim);
     CollBenClaim.Post_Injury_Earn := 0;
     Calc_Ben(CollBenClaim, CollBenWorking);

     sRpt.add(' ');

     if Pay_At_100_Flag then
      strTemp := ' '
     else
      strTemp := 'Regular';

     if Year(Accident_Date) >= 2006 then begin
      sRpt.add('Collateral Benefit Wage Loss Calculation (FULL):             Minimum        ' + strTemp);
      sRpt.add(' ');

      if (Annual_Net) < (Min_Wage_Annual_Net_A) then
          weeklyNet := Annual_Net
      else
          weeklyNet := Min_Wage_Annual_Net_A;

      sRpt.add( format('%-56s %-14s %-14s', [
          'Weekly Net (lessor of net (A) or (AA) - minimum benefit)',
          formatF( PDoxRound((weeklyNet / 52.0), 2), 12, 2 ),
          ' '
          ] ));

      if not Pay_At_100_Flag then begin
        sRpt.add( format('%-56s %-14s %-14s', [
          'Weekly Net ( (A) - regular benefit)',
          ' ',
          formatF( (PDoxRound((Annual_Net_A /52), 2)), 12, 2 )  //this was Annual_Net
          ] ));
      end;

      if Pay_At_100_Flag then
        strTemp := ' '
      else
        strTemp := formatF(CollBenClaim.Coll_Ben_Tax_Net, 12, 2 );

      sRpt.add( format('%-56s %-14s %-14s', [
          'Less: Net Collateral Benefit ( from (E) )',
          formatF(CollBenClaim.Coll_Ben_Tax_Net, 12, 2),
          strTemp
          ] ));

      if Pay_At_100_Flag then
        strTemp := ' '
      else
        strTemp := formatF(CollBenClaim.Collateral_Ben_Non_Tax, 12, 2 );

      sRpt.add( format('%-56s %-14s %-14s', [
         '      Non Taxable Collateral Benefit ',
         formatF(CollBenClaim.Collateral_Ben_Non_Tax, 12, 2),
         strTemp
         ] ));

      if Pay_At_100_Flag then
        strTemp := ' '
      else
        strTemp := dash(12);

      sRpt.add( format('%-56s %-14s %-14s', [ ' ', dash(12), strTemp ]));

      if Pay_At_100_Flag then
        strTemp := ' '
      else
        //changed from Annual_Net
        strTemp := formatF( (PDoxRound((Annual_Net_A /52) - CollBenClaim.Coll_Ben_Tax_Net
                                                        - CollBenClaim.Collateral_Ben_Non_Tax, 2)) , 12, 2 );

      CurrTemp := (weeklyNet /52) - CollBenClaim.Coll_Ben_Tax_Net - CollBenClaim.Collateral_Ben_Non_Tax;
      If CurrTemp < 0 Then
         CurrTemp := 0;
      sRpt.add( format('%-56s %-14s %-14s', [
         'Maximum Weekly Full Benefit',
         formatF( (PDoxRound(CurrTemp, 2)), 12, 2 ),
         strTemp
         ] ));

      if Pay_At_100_Flag then
        strTemp := ' '
      else
        strTemp := dDash(12);

      sRpt.add( format('%-56s %-14s %-14s', [ ' ',  dDash(12) , strTemp ]));

      //next section....PARTIAL
      //only show if there are Post Accident Earnings
      //Modified - Aug 2006 - bcooper
      // OR asking for blank worksheet (Claim_No is '00000000')
      if ( ( wrkClaim.Post_Injury_Earn_Net > 0 ) OR ( wrkClaim.Claim_No = '00000000' ) ) then begin
        sRpt.add(' ');
          if Pay_At_100_Flag then
            strTemp := ' '
          else
            strTemp := 'Regular';

        sRpt.add('Collateral Benefit Wage Loss Calculation (PARTIAL):          Minimum        ' + strTemp);
        sRpt.add(' ');

        if (Annual_Net) < (Min_Wage_Annual_Net_A) then
          weeklyNet := Annual_Net
        else
          weeklyNet := Min_Wage_Annual_Net_A;

        sRpt.add( format('%-56s %-14s %-14s', [
            'Weekly Net (lessor of net (A) or (AA) - minimum benefit)',
            formatF( PDoxRound((weeklyNet / 52.0), 2), 12, 2 ),
            ' '
            ] ));

        if not Pay_At_100_Flag then begin
          sRpt.add( format('%-56s %-14s %-14s', [
            'Weekly Net ( (A) - regular benefit)',
            ' ',
            formatF( (PDoxRound((Annual_Net_A /52), 2)), 12, 2 ) //this was Annual_Net
            ] ));
        end;

        if Pay_At_100_Flag then
          strTemp := ' '
        else
          strTemp := formatF(Coll_Ben_Tax_Net, 12, 2 );

        sRpt.add( format('%-56s %-14s %-14s', [
          'Less: Net Collateral Benefit ( from (E) )',
          formatF(Coll_Ben_Tax_Net, 12, 2),
          strTemp
          ] ));

        if Pay_At_100_Flag then
          strTemp := ' '
        else
          strTemp := formatF(CollBenClaim.Collateral_Ben_Non_Tax, 12, 2 );

        sRpt.add( format('%-56s %-14s %-14s', [
          '      Non Taxable Collateral Benefit ',
          formatF(CollBenClaim.Collateral_Ben_Non_Tax, 12, 2),
          strTemp
          ] ));

        if Pay_At_100_Flag then begin
          //strTemp1 := formatF((wrkClaim.Post_Injury_Earn_Net), 12, 2 );
          strTemp := ' ';
        end else begin
          //strTemp1 := formatF((wrkClaim.Post_Injury_Earn_Net * 1.11111), 12, 2 );
          strTemp := formatF((wrkClaim.Post_Injury_Earn_Net * 0.90), 12, 2 );
        end;

        sRpt.add( format('%-56s %-14s %-14s', [
          '      Net Post Injury Earnings(100% for min/90% for reg)',
          formatF((wrkClaim.Post_Injury_Earn_Net), 12, 2 ),
          strTemp
          ] ));

        if Pay_At_100_Flag then
          strTemp := ' '
        else
          strTemp := dash(12);

        sRpt.add( format('%-56s %-14s %-14s', [ ' ', dash(12), strTemp ]));

        if Pay_At_100_Flag then begin
          //strTemp1 := formatF( (PDoxRound((weeklyNet /52) - Coll_Ben_Tax_Net
                                              //- wrkClaim.Post_Injury_Earn_Net
                                              //- CollBenClaim.Collateral_Ben_Non_Tax, 2)), 12, 2 );
          strTemp := ' ';
        end else begin
          //changed from Annual_Net
          //strTemp1 := formatF( (PDoxRound((weeklyNet /52) - Coll_Ben_Tax_Net
                                              //- PDoxRound(wrkClaim.Post_Injury_Earn_Net * 1.11111, 2)
                                              //- CollBenClaim.Collateral_Ben_Non_Tax, 2)), 12, 2 );
          if (  (PDoxRound((Annual_Net_A /52) - Coll_Ben_Tax_Net - PDoxRound(wrkClaim.Post_Injury_Earn_Net * 0.90, 2) - CollBenClaim.Collateral_Ben_Non_Tax, 2)) < 0 )  then
            strTemp := formatF( 0, 12, 2 )
          else
            strTemp := formatF( (PDoxRound((Annual_Net_A /52) - Coll_Ben_Tax_Net - PDoxRound(wrkClaim.Post_Injury_Earn_Net * 0.90, 2) - CollBenClaim.Collateral_Ben_Non_Tax, 2)) , 12, 2);
        end;

        CurrTemp := (weeklyNet /52) - Coll_Ben_Tax_Net
                                              - wrkClaim.Post_Injury_Earn_Net
                                              - CollBenClaim.Collateral_Ben_Non_Tax;


        If CurrTemp < 0 Then
           CurrTemp := 0;
        sRpt.add( format('%-56s %-14s %-14s', [
          'Maximum Weekly Partial Benefit',
          formatF( (PDoxRound(CurrTemp, 2)), 12, 2 ),
          strTemp
          ] ));

        if Pay_At_100_Flag then
          strTemp := ' '
        else
          strTemp := dDash(12);

        sRpt.add( format('%-56s %-14s %-14s', [ ' ',  dDash(12) , strTemp ]));
      end;
     end else begin
      sRpt.add(' ');
      sRpt.add('Collateral Benefit Wage Loss Calculation:                     Full           Partial');
      sRpt.add(' ');

      sRpt.add( format('%-56s %-14s %-14s', [
         'Weekly Net ( from (A) )',
         formatF( ( Annual_Net_A / 52.0 ), 12, 2 ),
         formatF( ( Annual_Net_A / 52.0 ), 12, 2 )
         ] ));
      sRpt.add( format('%-56s %-14s %-14s', [ ' ',  dash(12), dash(12)]));

      sRpt.add( format('%-56s %-14s %-14s', [
         'Weekly Net @ 90%  ( (i) x 90% )',
         formatF( ( ( Annual_Net_A / 52.0 ) *0.90 ), 12, 2 ),
         formatF( ( ( Annual_Net_A / 52.0 ) *0.90 ), 12, 2 )
         ] ));
      sRpt.add( format('%-56s %-14s %-14s', [ ' ',  dash(12) ,  dash(12) ]));

      sRpt.add( format('%-56s %-14s %-14s', [
         'Less: Net Collateral Benefit ( from (E) )',
         formatF(CollBenClaim.Coll_Ben_Tax_Net, 12, 2),
         formatF( Coll_Ben_Tax_Net, 12, 2 )
         ] ));
      sRpt.add( format('%-56s %-14s %-14s', [
         '      Non Taxable Collateral Benefit ',
         formatF(CollBenClaim.Collateral_Ben_Non_Tax, 12, 2),
         formatF(CollBenClaim.Collateral_Ben_Non_Tax, 12, 2 )
         ] ));
      sRpt.add( format('%-56s %-14s %-14s', [
         '      Net Post Injury Earnings @ 90% ',
         ' ',
         formatF((wrkClaim.Post_Injury_Earn_Net * 0.90), 12, 2 )
         ] ));
      sRpt.add( format('%-56s %-14s %-14s', [ ' ', dash(12), dash(12) ]));

      sRpt.add( format('%-56s %-14s %-14s', [
         'Maximum Weekly Benefit',
         formatF( (( ( Annual_Net_A / 52.0 ) * 0.90 ) - CollBenClaim.Coll_Ben_Tax_Net
                                                      - CollBenClaim.Collateral_Ben_Non_Tax), 12, 2 ),
         formatF( (( ( Annual_Net_A / 52.0 ) * 0.90 ) - Coll_Ben_Tax_Net
                                                      - Collateral_Ben_Non_Tax
                                                      - (wrkClaim.Post_Injury_Earn_Net * 0.90)), 12, 2 )
         ] ));
      sRpt.add( format('%-56s %-14s %-14s', [ ' ',  dDash(12) , dDash(12) ]));
     end;

     sRpt.add(' ');
     sRpt.add(dash(91));
     end;
end;

(******************************************************************************)
(*                                                                            *)
(*  Create Gross Income Band                                                  *)
(*                                                                            *)
(******************************************************************************)
procedure TWrkRptJan08.GrossIncomeBand1;
begin
  with wrkClaim do
  begin
    if Year(Accident_Date) >= 2006 then begin
      sRpt.add(' ');
      sRpt.add('Gross Income Amounts:');
      sRpt.add(' ');

      sRpt.add(
        format('%-14s %-42s %-14s (A) %-14s',
          [ formatF(Wkly_Sal_A, 11, 2  ),
          ' x 52 = ( actual annual income )',
          formatF( Annual_Gross_A, 12, 2),
          ' '
          ] ));
      sRpt.add( format('%-14s %-42s %-14s %-14s', [ dash(12), ' ', dDash(12), ' ' ] ));
      sRpt.add( format('%-14s %-56s %-14s', [ '  Weekly Wage', ' ', ' ' ] ));
      sRpt.add(' ');
      sRpt.add( format('%-57s %-14s (AA) %-14s', [ 'WCB Minimum Gross Annual Earnings',
                                                    formatF(Minimum_wage, 12, 2),
                                                    ' '] ));
      sRpt.add( format('%-57s %-14s %-14s', [ ' ', dDash(12), ' ' ] ));
      sRpt.add(' ');

      sRpt.add('See Minimum Wage Report for indexed values.');
      sRpt.add(' ');
      sRpt.add(' ');

      if Max_Adjustment <> 0 then
        sRpt.add(
          format('%-56s %-14s (B) %-14s',
            [ 'Max Adjustment Override',
               formatF( Max_Adjustment, 12, 2),
               ' '] ))
      else
        sRpt.add(
          format('%-56s %-14s (B) %-14s',
            [ 'Max Adjustment Override', ' ', ' '
            ] ));

      sRpt.add( format('%-56s %-14s %-14s', [ ' ', dDash(12), ' ' ] ));
      //sRpt.add( format('%-56s %-14s %-14s', [ ' ', '     or', ' ' ] ));

      sRpt.add(' ');

      sRpt.add('PRORATING FACTOR FOR TAX DEDUCTIONS (ONLY IF ACTUAL > MAX ADJ OVERRIDE):');
      sRpt.add(' ');

      //dont know if i have to change anything to the following if statement....
      if Annual_Gross_A > Annual_Gross then
      begin
        sRpt.add(
          format('%-76s %-.4n%% (FT)',
            [
            ' (Max (B)  ' + formatF(Annual_Gross, 12, 2) +
            ' / Actual (A)  ' + formatF(Annual_Gross_A, 12, 2) + ' =',
            (fWorking.Work_nc_prorate*100.00)
            ] ));
        sRpt.add( format('%-56s %-14s %-14s', [ ' ',  ' ', dDash(12) ] ));
      end
      else
      begin
        sRpt.add(
          format('%-84s (FT)',
            [
            ' (Max (B)             /Actual (A)             ='
            ] ));
        sRpt.add(
          format('%-71s %-14s',
            [
            '         ' + dash(12) + '             ' + dash(12),
            dDash(12)
            ] ));
      end;
      sRpt.add(' ');

      sRpt.add(
        format('%-14s %-56s %-14s (C)',
          [ formatF( Annual_Gross, 12, 2  ),
          ' x 75% = ( annual sheltered income )',
          formatF( ( Annual_Gross * 0.75 ), 12, 2 )
          ] ));
      sRpt.add( format('%-14s %-56s %-14s', [ dash(12), ' ', dDash(12) ] ));
      sRpt.add( format('%-56s %-14s %-14s', [ '  Lessor of (A) or (B) above', ' ', ' ' ] ));
      sRpt.add(' ');

      sRpt.add(
        format('%-14s %-56s %-14s (CC)',
          [ formatF( Minimum_wage, 12, 2  ),
          ' x 75% = ( annual sheltered income )',
          formatF( ( Minimum_wage * 0.75 ), 12, 2 )
          ] ));
      sRpt.add( format('%-14s %-56s %-14s', [ dash(12), ' ', dDash(12) ] ));
      sRpt.add( format('%-56s %-14s %-14s', [ '  Based on minimum (AA)', ' ', ' ' ] ));
      sRpt.add(' ');

      sRpt.add(
        format('%-14s %-56s %-14s',
          [  formatF( Collateral_Ben_Tax, 12, 2 ),
          ' (i)   Weekly Taxable Collateral benefits',
          ' '
          ] ));
      sRpt.add(
        format('%-14s %-56s %-14s',
          [ formatF( Post_Injury_Earn, 12, 2  ),
          ' (ii) + Weekly Post Injury Earnings ',
          ' '
          ] ));

      sRpt.add(
        format('%-14s %-56s %-14s (E)',
          [ formatF( ( Collateral_Ben_Tax + Post_Injury_Earn ), 12, 2 ),
          ' (D)  x 52 =( annual benefits + earnings )',
          formatF( (( Collateral_Ben_Tax + Post_Injury_Earn )* 52), 12, 2 )
          ] ));
      sRpt.add( format('%-14s %-56s %-14s', [ dash(12), ' ', dDash(12) ] ));
      sRpt.add( format('%-56s %-14s %-14s', [ ' total ( i + ii )', ' ', ' ' ] ));
    end
    else //if Accident_Date < 2006
    begin
        sRpt.add(' ');
        sRpt.add('Gross Income Amounts:');
        sRpt.add(' ');

        sRpt.add(
          format('%-14s %-56s %-14s (A)',
          [ formatF(Wkly_Sal_A, 11, 2  ),
          ' x 52 = ( actual annual income )',
          formatF( Annual_Gross_A, 12, 2)
          ] ));
        sRpt.add( format('%-14s %-56s %-14s', [ dash(12), ' ', dDash(12) ] ));
        sRpt.add( format('%-14s %-56s %-14s', [ '  Weekly Wage', ' ', ' ' ] ));
        sRpt.add(' ');
        //sRpt.add( format('%-71s %-14s (AA)', [ 'WCB Minimum Gross Annual Earnings',
                                            //formatF(Minimum_wage, 12, 2)] ));
        //sRpt.add( format('%-71s %-14s', [ ' ', dDash(12) ] ));
        //sRpt.add(' ');
        sRpt.add(' ');

        if Max_Adjustment <> 0 then
          sRpt.add(
          format('%-71s %-14s (B)',
            [ 'Max Adjustment Override', formatF( Max_Adjustment, 12, 2)
            ] ))
        else
          sRpt.add(
          format('%-71s %-14s (B)',
            [ 'Max Adjustment Override', ' '
            ] ));

        sRpt.add( format('%-71s %-14s', [ ' ', dDash(12) ] ));
        //sRpt.add( format('%-71s %-14s', [ ' ', '     or' ] ));

        sRpt.add(' ');
        sRpt.add(
          format('%-56s %-14s %-14s (B)',
          [ 'WCB Maximum Gross Annual Income',
            ' ',
          formatF(Annual_Gross, 12, 2 )
          ] ));
        sRpt.add( format('%-14s %-56s %-14s', [ ' ', ' ', dDash(12) ] ));

        sRpt.add(' ');
        sRpt.add('See Annual Maximum Report for indexed values.');
        sRpt.add(' ');
        sRpt.add(' ');

        sRpt.add('PRORATING FACTOR FOR TAX DEDUCTIONS (ONLY IF ACTUAL > MAX):');
        sRpt.add(' ');
        if Annual_Gross_A > Annual_Gross then
        begin
          sRpt.add(
            format('%-76s %-.4n%% (FT)',
            [
            ' (Max (B)  ' + formatF(Annual_Gross, 12, 2) +
            ' / Actual (A)  ' + formatF(Annual_Gross_A, 12, 2) + ' =',
            (fWorking.Work_nc_prorate*100.00)
            ] ));
          sRpt.add( format('%-56s %-14s %-14s', [ ' ',  ' ', dDash(12) ] ));
        end
        else
        begin
          sRpt.add(
            format('%-84s (FT)',
              [
              ' (Max (B)             /Actual (A)             ='
              ] ));
          sRpt.add(
            format('%-71s %-14s',
              [
              '         ' + dash(12) + '             ' + dash(12),
              dDash(12)
              ] ));
        end;
        sRpt.add(' ');

        sRpt.add(
          format('%-14s %-56s %-14s (C)',
            [ formatF( Annual_Gross, 12, 2  ),
            ' x 75% = ( annual sheltered income )',
            formatF( ( Annual_Gross * 0.75 ), 12, 2 )
            ] ));
        sRpt.add( format('%-14s %-56s %-14s', [ dash(12), ' ', dDash(12) ] ));
        sRpt.add( format('%-56s %-14s %-14s', [ '  lessor of (A) or (B) above', ' ', ' ' ] ));
        sRpt.add(' ');

        sRpt.add(
          format('%-14s %-56s %-14s',
          [  formatF( Collateral_Ben_Tax, 12, 2 ),
          ' (i)   Weekly Taxable Collateral benefits',
          ' '
          ] ));
        sRpt.add(
          format('%-14s %-56s %-14s',
          [ formatF( Post_Injury_Earn, 12, 2  ),
          ' (ii) + Weekly Post Injury Earnings ',
          ' '
          ] ));

        sRpt.add(
          format('%-14s %-56s %-14s (E)',
          [ formatF( ( Collateral_Ben_Tax + Post_Injury_Earn ), 12, 2 ),
          ' (D)  x 52 =( annual benefits + earnings )',
          formatF( (( Collateral_Ben_Tax + Post_Injury_Earn )* 52), 12, 2 )
          ] ));
        sRpt.add( format('%-14s %-56s %-14s', [ dash(12), ' ', dDash(12) ] ));
        sRpt.add( format('%-56s %-14s %-14s', [ ' total ( i + ii )', ' ', ' ' ] ));
    end;

    sRpt.add(' ');

    sRpt.add(dash(91));
  end;
end;

procedure TWrkRptJan08.ExcemptionAndCreditAmountBand1P1;
begin
  sRpt.add(' ');
  sRpt.add('Tax Credit and Reduction Amounts:');
  sRpt.add(' ');
  sRpt.add('2007/2008 Federal Non-Refundable Personal Tax Amounts:');
  sRpt.add(' ');
  sRpt.add( format('%-56s %-14s %-14s', [
    '    Worker''s basic personal amount ',
    ' ',
    formatF( fWorking.Work_personal, 12, 2 )
    ] ));
  sRpt.add( format('%-56s %-11s %-14s', [
    '    Dependent Spouse or common law partner claim ' +
      formatf(arrayNCEXMAMT[indexNCEXMAMT].Spouse, 10, 2),
    ' ',
    formatF( fWorking.Work_NC_SPOUSE, 12, 2 )
    ] ));
  sRpt.add('    ie: Married (spouse claimed as a dependent) ');
  sRpt.add( format('%-71s %-14s', [
    '    Single ( claim 1 child as eligible dependent ) ' +
      formatF(arrayNCEXMAMT[indexNCEXMAMT].ChildSpouse, 10, 2),
    formatF( fWorking.Work_NC_CHILDSPOUSE, 12, 2 )
    ] ));

  sRpt.add( format('%-56s %-10s %-14s', [
    //'    Child tax credit (# of children < 18 yrs) ' + intToStr( fWorking.Work_actualNoOfDependants )
    '    Child tax credit (# of children < 18 yrs) ' + intToStr( wrkClaim.No_Of_Dependnts )
      + ' x ' + formatF(arrayNCEXMAMT[indexNCEXMAMT].federalChildTaxCredit, 10, 2),
    ' ',
    formatF( fWorking.Work_federalChildTaxCredit, 12, 2 )
    ] ));

  sRpt.add( format('%-56s %-14s %-14s', [
    '    Infirm dependents ( age 18+ ) ' + intToStr( fWorking.Work_nc_no_infirm )
      + ' x ' + formatF(arrayNCEXMAMT[indexNCEXMAMT].Infirm_Dep, 10, 2),
    ' ',
    formatF( fWorking.Work_infirm, 12, 2 )
    ] ));
  sRpt.add( format('%-56s %-14s %-14s', [ ' ',  ' '     ,  dash(12) ]));
  if (wrkClaim.Claim_No <> '00000000') Then
     sRpt.add( format('%-56s %-14s %-14s (F)', [
         '    Total Federal Personal Amount ',
         ' ',
         formatF( fWorking.Work_NC_EXEMPT_AMOUNT, 12, 2 )
         ] ))
  else
     sRpt.add( format('%-56s %-14s %-14s (F)', [
         '    Total Federal Personal Amount ',
         ' ',
         formatF(0.00, 12, 2 )
         ] ));

  sRpt.add( format('%-56s %-14s %-14s', [ ' ',  ' '     ,  dDash(12) ]));
  sRpt.add(' ');
end;

procedure TWrkRptJan08.ExcemptionAndCreditAmountBand1Man1;
begin
  sRpt.add(' ');
  sRpt.add('2007/2008 Provincial Non-Refundable Personal Tax Amounts:');
  sRpt.add(' ');
  sRpt.add( format('%-56s %-14s %-14s', [
    '    Worker''s basic personal amount ',
    ' ',
    formatF( fWorking.Work_Prov_personal, 12, 2 )
    ] ));
  sRpt.add( format('%-56s %-11s %-14s', [
    '    Dependent Spouse or common law partner claim ' +
      formatf(arrayNCEXMAMT[indexNCEXMAMT].Prov_Spouse, 10, 2),
    ' ',
    formatF( fWorking.Work_NC_Prov_Spouse, 12, 2 )
    ] ));
  sRpt.add('    ie: Married (spouse claimed as a dependent) ');
  sRpt.add( format('%-71s %-14s', [
    '    Single ( claim 1 child as eligible dependent ) ' +
      formatF(arrayNCEXMAMT[indexNCEXMAMT].Prov_ChildSpouse, 10, 2),
    formatF( fWorking.Work_NC_Prov_ChildSpouse, 12, 2 )
    ] ));
  sRpt.add( format('%-56s %-14s %-14s', [
    '    Infirm dependents ( age 18+ ) ' + intToStr( fWorking.Work_nc_no_infirm )
      + ' x ' + formatF(arrayNCEXMAMT[indexNCEXMAMT].Prov_Infirm_Dep, 10, 2),
    ' ',
    formatF( fWorking.Work_Prov_Infirm, 12, 2 )
    ] ));
  sRpt.add( format('%-56s %-14s %-14s', [ ' ',  ' '     ,  dash(12) ]));

  if (wrkClaim.Claim_No <> '00000000') Then
     sRpt.add( format('%-56s %-14s %-14s (G)', [
         '    Total Provincial Personal Amount ',
         ' ',
         formatF( fWorking.Work_NC_MB_Exempt_Amount, 12, 2 )
         ] ))
  else
     sRpt.add( format('%-56s %-14s %-14s (G)', [
         '    Total Provincial Personal Amount ',
         ' ',
         formatF(0.00, 12, 2 )
         ] ));
  sRpt.add( format('%-56s %-14s %-14s', [ ' ',  ' '     ,  dDash(12) ]));
  sRpt.add(' ');
end;

procedure TWrkRptJan08.ExcemptionAndCreditAmountBand1P2;
begin
  sRpt.add('2007/2008 Manitoba Family Tax Reduction Amounts:');
  sRpt.add(' ');
  sRpt.add( format('%-56s %-14s %-14s', [
    '    Worker''s basic reduction ',
    ' ',
    formatF( fWorking.Work_III_Personal, 12, 2 )
    ] ));
  sRpt.add( format('%-56s %-11s %-14s', [
    '    Dependent Spouse or common law partner claim ' +
      formatF(arrayNCEXMAMT[indexNCEXMAMT].III_Spouse, 10, 2),
    ' ',
    formatF( fWorking.Work_NC_III_SPOUSE, 12, 2 )
    ] ));
  sRpt.add('    ie: Married (spouse claimed as a dependent) ');
  sRpt.add( format('%-56s %-9s %-14s', [
    '    Single ( claim 1 child as eligible dependent ) ' +
      formatF(arrayNCEXMAMT[indexNCEXMAMT]. III_ChildSpouse, 10, 2),
    ' ',
    formatF( fworking.Work_NC_III_CHILDSPOUSE, 12, 2 )
    ] ));
  sRpt.add( format('%-56s %-14s %-14s', [
    '    Each additional child  ' + intToStr( fworking.Work_nc_no_of_dep ) + ' x '
      + formatF(arrayNCEXMAMT[indexNCEXMAMT].III_Dep, 10, 2),
    ' ',
    formatF( fworking.Work_NC_III_DEP, 12, 2 )
    ] ));
  sRpt.add( format('%-56s %-14s %-14s', [
    '    Infirm dependents ( age 18+ ) ' + intToStr( fworking.Work_nc_no_infirm ) + ' x '
      + formatF(arrayNCEXMAMT[indexNCEXMAMT].III_Infirm_Dep, 10, 2),
    ' ',
    formatF( fworking.Work_NC_III_INFIRM, 12, 2 )
    ] ));
  sRpt.add( format('%-56s %-14s %-14s', [ ' ',  ' '     ,  dash(12) ]));

  if (wrkClaim.Claim_No <> '00000000') Then
     sRpt.add( format('%-56s %-14s %-14s (H)', [
         '    Manitoba Family Tax Reduction Amount ',
         ' ',
         formatF( fworking.Work_nc_iii_credit, 12, 2 )
         ] ))
  else
     sRpt.add( format('%-56s %-14s %-14s (H)', [
         '    Manitoba Family Tax Reduction Amount ',
         ' ',
         formatF(0.00, 12, 2 )
         ] ));
  sRpt.add( format('%-56s %-14s %-14s', [ ' ',  ' '     , dDash(12) ]));

  sRpt.add(' ');
  sRpt.add(dash(91));
end;

procedure TWrkRptJan08.TaxCalculationBand1P1( const income: currency;
                                     	      sIncType: shortstring;
                                              Nc_Bc_Ann_Sal_Net: currency);
Begin
  sRpt.add(' ');
  sRpt.add('2007/2008 Income Tax, CPP and EI Calculation');
  sRpt.add(' ');
  sRpt.add( format('%-56s %-14s %-14s (I)', [
    'Gross Income ( "' + sIncType + '" ) ',
    ' ',
    formatF( income, 12, 2 )
    ]));
  sRpt.add( format('%-56s %-14s %-14s', [ ' ',  ' ', dDash(12)  ]));
  sRpt.add(' ');
  sRpt.add('Net Income: ');
  sRpt.add( format('%-14s %8.4n%% %-40s %-14s (LK)', [
    formatF(income, 11, 2) + '      - (',
    (fWorking.Work_nc_prorate*100.00),
    ' X ' + formatF(fWorking.Work_nc_bc_deductions, 11, 2) + ')=',
    formatF(Nc_Bc_Ann_Sal_Net, 12, 2 )
    ]));
  sRpt.add( format('%-56s %-14s %-14s', [
     'Amount (I) above - (    FT      X       DED    )',
     ' ',
     dash(12)
     ]));
  sRpt.add('   * FT applies only if type of income not ''Actual'' ');
  sRpt.add(' ');
  sRpt.add('CPP Contribution & EI premiums Calculation:');
  sRpt.add(' ');
End;

Function  TWrkRptJan08.TaxCalculationBand1P5b( Nc_Bc_Ann_Sal_Net: currency;
                                               Nc_Bc_Mb_Nrtc: currency;
                                               Nc_Bc_Mbt: currency): currency;
var
  const1, const2, f2p, f1i, work: currency;
begin
  sRpt.add(' ');
  sRpt.add('2007/2008 Manitoba Tax Rates and Income Thresholds (WCB):');
  sRpt.add(' ');
  with arrayNCTAXRAT[indexNCTAXRAT] do
    begin
    sRpt.add('    +'+ dash(76) + '+');
    sRpt.add( format('    | %-28s | %-20s | %-20s |', [
      'Taxable Income Amount',
      'Rate',
      'Constant'
      ]));
    sRpt.add('    +'+ dash(76) + '+');
    sRpt.add( format('    | %-28s | %-20s | %-20s |', [
      format('%.0n',[MB_income_level_i]) + ' or less',
      format('%.1n',[(MB_tax_rate_i*100.00)]) + '%',
      format('%.0n',[0.00])
      ]));
    const1 := Round(MB_income_level_i * (MB_tax_rate_ii - MB_tax_rate_i));
    sRpt.add( format('    | %-28s | %-20s | %-20s |', [
      '> ' + format('%.0n',[MB_income_level_i]),
      format('%.1n',[(MB_tax_rate_ii*100.00)]) + '%',
      format('%.0n',[const1])
      ]));
    const2 := Round(MB_income_level_ii * (MB_tax_rate_iii - MB_tax_rate_ii)
      + const1);
    sRpt.add( format('    | %-28s | %-20s | %-20s |', [
      '> ' + format('%.0n',[MB_income_level_ii]),
      format('%.1n',[(MB_tax_rate_iii*100.00)]) + '%',
      format('%.0n',[const2])
      ]));
    sRpt.add('    +'+ dash(76) + '+');
    sRpt.add(' ');
    sRpt.add('Manitoba Tax:');
    sRpt.add(' ');
    sRpt.add('    For ' + formatF(Nc_Bc_Ann_Sal_Net, 11, 2 ) +' (Amount (LK) above):' );

    if ( Nc_Bc_Ann_Sal_Net > MB_income_level_ii ) then
      begin
      f2p := MB_tax_rate_iii;
      f1i := const2;
      end
    else if ( Nc_Bc_Ann_Sal_Net > MB_income_level_i ) then
      begin
      f2p := MB_tax_rate_ii;
      f1i := const1;
      end
    else
      begin
      f2p := MB_tax_rate_i;
      f1i := 0.0;
      end;
    end;

  if (wrkClaim.Claim_No = '00000000') Then
     begin
     f2p := 0; // set the tax rate to be a blank
     end;

  sRpt.add(' ');
  sRpt.add( format('%-56s %-14s %-14s', [
    '    Multiply by tax rate from above table ' + format('%.2n',[f2p * 100]){FormatF((f2p * 100), 5, 1)} + '%',
    formatF((Nc_Bc_Ann_Sal_Net * f2p), 12, 2 ), ' '
    ] ));
  sRpt.add(' ');
  sRpt.add( format('%-56s %-14s %-14s', [
    '    Less:  Constant from above table',
    formatF(f1i, 12, 2 ), ' '
    ] ));
  work := (Nc_Bc_Ann_Sal_Net * f2p) - f1i;

  if work < 0 then
     work := 0;

  sRpt.add( format('%-56s %-14s %-14s', [ ' ', dash(12), ' ']));
  sRpt.add( format('%-56s %-14s %-14s (Q)', [
    '    Manitoba Tax ',
    formatF( work, 12, 2 ),
    ' '
    ] ));
  sRpt.add(' ');
  if (wrkClaim.Claim_No <> '00000000') Then
     sRpt.add( format('%-56s %-14s %-14s', [
         '    Less: Non Refundable Tax Credit (M) above ',
         formatF( Nc_Bc_Mb_Nrtc, 12, 2 ),
  	 ' '
         ] ))
  else
     sRpt.add( format('%-56s %-14s %-14s', [
         '    Less: Non Refundable Tax Credit (M) above ',
         formatF(0.00, 12, 2 ),
  	 ' '
         ] ));
  result := Nc_Bc_Mbt;
  sRpt.add( format('%-56s %-14s %-14s', [ ' ', dash(12), ' ' ]));
  sRpt.add( format('%-56s %-14s %-14s (R)', [
  	'    Manitoba Provincial Tax ',
    ' ',
    formatF( result, 12, 2 )
    ] ));
  sRpt.add( format('%-56s %-14s %-14s', [ ' ', ' ', dDash(12)]));
end;

//procedure TWrkRptJan08.TaxCalculationBand1P2(const income: currency;
//                                             Nc_Bc_Ann_Sal_Net: currency;
//                                             Nc_Bc_Uic: currency;
//                                             Nc_Bc_Cpp: currency;
//                                             Nc_Bc_Nrtc: currency;
//                                             Nc_Bc_Mb_Nrtc: currency;
//                                             federalCanadaEmploymentCredit: currency);
procedure TWrkRptJan08.TaxCalculationBand1P2(const income: currency;
                                             Nc_Bc_Ann_Sal_Net: currency;
                                             Nc_Bc_Uic: currency;
                                             Nc_Bc_Cpp: currency;
                                             Nc_Bc_Nrtc: currency;
                                             Nc_Bc_Mb_Nrtc: currency;
                                             nc_mbFamilyTaxBenefitAmt: currency);
Var
  t: currency;
  ws: string;
Begin
  sRpt.add('    CPP: ');
  ws:=format('    ( $%.2n - $%.2n ) x %.4n%% = ( Maximum $%.2n )',
    [
    income,
    arrayNCTAXRAT[indexNCTAXRAT].CPP_basic_exemption,
    ( arrayNCTAXRAT[indexNCTAXRAT].CPP_contrib_rate *100.00 ),
    arrayNCTAXRAT[indexNCTAXRAT].CPP_max_annual_contrib
    ]
    );
  sRpt.add( format('%-70s  %-14s (J)', [ ws, formatF( Nc_Bc_Cpp, 12, 2 ) ] ));
  sRpt.add( format('%-56s %-14s %-14s', [ '     Amount (I) above',  ' ', dash(12)  ]));
  sRpt.add(' ');
  sRpt.add('    EI: ');
  ws:=format('    $%.2n  x %.2n%% = ( Maximum $%.2n )',
    [
    income,
    (arrayNCTAXRAT[indexNCTAXRAT].UIC_premium_rate * 100.00),
    arrayNCTAXRAT[indexNCTAXRAT].UIC_max_annual_premium
    ] );
  sRpt.add( format('%-70s  %-14s (K)', [ ws, formatF( Nc_Bc_Uic, 12, 2 ) ] ));
  sRpt.add( format('%-56s %-14s %-14s', [ '     Amount (I) above',  ' ', dash(12) ]));
  sRpt.add(' ');
  sRpt.add('Non Refundable Tax Credit:');
  sRpt.add(' ');
  //
  sRpt.add('(i) Federal');
  sRpt.add( format('%-56s %-14s %-14s', [
    '    CPP amount (J) above',
  formatF( Nc_Bc_Cpp, 12, 2 ),
    ' '
    ] ));
  sRpt.add(' ');
  sRpt.add( format('%-56s %-14s %-14s', [
    '    EI amount (K) above',
    formatF( Nc_Bc_Uic, 12, 2 ),
    ' '
    ] ));
  sRpt.add(' ');

  if (wrkClaim.Claim_No <> '00000000') Then
     Begin
     sRpt.add( format('%-56s %-14s %-14s', [
         '    Total Federal Personal Amounts (F) from pg. 4',
         formatF( fworking.Work_nc_tax_exmp, 12, 2 ),
         ' '
         ] ));
     sRpt.add( format('%-56s %-14s %-14s', [ ' ',  dash(12),  ' '      ]));
     t := Nc_Bc_Cpp+Nc_Bc_Uic+fworking.Work_nc_tax_exmp;
     sRpt.add( format('%-56s %-14s %-14s (L)', [
         '    Total x '+
         format( '%.2n', [(arrayNCTAXRAT[indexNCTAXRAT].FED_tax_rate_i*100.00) ] ) +
         '%' + ' (lowest Federal tax rate)',
         formatF( t, 12, 2 ),
         formatF( Nc_Bc_Nrtc, 12, 2 )
         ] ));
     end
  else
     Begin
     sRpt.add( format('%-56s %-14s %-14s', [
         '    Total Federal Personal Amounts (F) from pg. 4',
         formatF(0.00, 12, 2 ),
         ' '
         ] ));
     sRpt.add( format('%-56s %-14s %-14s', [ ' ',  dash(12),  ' '      ]));
     sRpt.add( format('%-56s %-14s %-14s (L)', [
         '    Total x '+
         format( '%.2n', [(arrayNCTAXRAT[indexNCTAXRAT].FED_tax_rate_i*100.00) ] ) +
         '%' + ' (lowest Federal tax rate)',
         formatF( 0.00, 12, 2 ),
         formatF( 0.00, 12, 2 )
         ] ));
     end;
  sRpt.add( format('%-56s %-14s %-14s', [ ' ', dDash(12), dDash(12) ]));

  //
  sRpt.add(' ');
  sRpt.add('(ii) Provincial');
  sRpt.add( format('%-56s %-14s %-14s', [
    '    CPP amount (J) above',
  formatF( Nc_Bc_Cpp, 12, 2 ),
    ' '
    ] ));
  sRpt.add(' ');
  sRpt.add( format('%-56s %-14s %-14s', [
    '    EI amount (K) above',
    formatF( Nc_Bc_Uic, 12, 2 ),
    ' '
    ] ));
  sRpt.add(' ');
  if (wrkClaim.Claim_No <> '00000000') Then
     begin
     sRpt.add( format('%-56s %-14s %-14s', [
         '    Total Provincial Personal Amounts (G) from pg. 4',
         formatF( fworking.Work_nc_mb_tax_exmp, 12, 2 ),
         ' '
         ] ));
     sRpt.add( format('%-56s %-14s %-14s', [ ' ',  dash(12),  ' '      ]));
     t:=Nc_Bc_Cpp+Nc_Bc_Uic+fworking.Work_nc_mb_tax_exmp;
     sRpt.add( format('%-56s %-14s %-14s (M)', [
         '    Total x '+
         format( '%.1n', [(arrayNCTAXRAT[indexNCTAXRAT].MB_tax_rate_i*100.00) ] ) +
         '%' + ' (lowest Manitoba Tax Rate)',
         formatF( t, 12, 2 ),
         formatF( Nc_Bc_Mb_Nrtc, 12, 2 )
         ] ));
     end
  else
     begin
     sRpt.add( format('%-56s %-14s %-14s', [
         '    Total Provincial Personal Amounts (G) from pg. 4',
         formatF(0.00, 12, 2 ),
         ' '
         ] ));
     sRpt.add( format('%-56s %-14s %-14s', [ ' ',  dash(12),  ' '      ]));
     sRpt.add( format('%-56s %-14s %-14s (M)', [
         '    Total x '+
         format( '%.1n', [(arrayNCTAXRAT[indexNCTAXRAT].MB_tax_rate_i*100.00) ] ) +
         '%' + ' (lowest Manitoba Tax Rate)',
         formatF( 0.00, 12, 2 ),
         formatF( 0.00, 12, 2 )
         ] ));
     end;


  //
  sRpt.add( format('%-56s %-14s %-14s', [ ' ', dDash(12), dDash(12) ]));
  //sRpt.add( format('%-56s %-14s %-14s (M)', [
  //  '    Total x '+
  //  format( '%.1n', [(arrayNCTAXRAT[indexNCTAXRAT].MB_tax_rate_i*100.00) ] ) +
  //  '%' + ' (Manitoba Tax Rate)',
  //  formatF( t, 12, 2 ),
  //  formatF( Nc_Bc_Mb_Nrtc, 12, 2 )
  //  ] ));
  //sRpt.add( format('%-56s %-14s %-14s', [ ' ', dDash(12), dDash(12) ]));
  sRpt.add(' ');
  sRpt.add('2007/2008 Federal Tax Rates and Income Thresholds (WCB):');
  sRpt.add(' ');
End;

end.
