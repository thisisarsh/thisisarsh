unit NCWrkRptJan00;

interface

uses
  NCWrkRpt, quickrpt, SysUtils;

type
  TWrkRptJan00 = class(TWagelossCalculationWorksheetForm)
  procedure TaxCalculationBand1P4( Nc_Bc_Bft: Currency;
    															 Nc_Bc_Fst: Currency); Override;
  private
    { Private declarations }
  public
    { Public declarations }
  end;

var
  WrkRptJan00: TWrkRptJan00;

implementation

uses NCIniMod, UtilMod1, NCBencal;

{$R *.DFM}

procedure TWrkRptJan00.TaxCalculationBand1P4(Nc_Bc_Bft: Currency;
                                             Nc_Bc_Fst: Currency);
var
  t, tr1, tr2: currency;
begin
  sRpt.add('Federal Surtax:');
  sRpt.add(' ');

  with arrayNCTAXRAT[indexNCTAXRAT] do
    begin
    //
    // calculate the surtax amounts to be used
    //
    t := PDoxRound((Nc_Bc_Bft * FED_surtax_rate_i), 2); // calculate the basic Federal Surtax
    if Nc_Bc_Bft > FED_surtax_limit_ii then
       begin
       tr2 := 0;
       end
    else if Nc_Bc_Bft > 8333.00 then
       begin
       tr2 := 250.00 - ((Nc_Bc_Bft - 8333.00) * 0.06);
       end
    else
       begin
       t := 0.00;
       tr2 := 0;
       end;

    //
    // force the surtax amounts to be rounded to the nearest penny
    //
    tr1 := PDoxRound((((t - tr2) * 0.5 * 100) / 100), 2);

    sRpt.add( format('%-56s %-14s %-14s', [
        'Basic Federal Tax: (O) ' +
        formatF( Nc_Bc_Bft, 12, 2 ) + ' x ' +
        format( '%.2n', [ ( FED_surtax_rate_i * 100.00 ) ] ) + '%',
        formatF( t, 12, 2 ),
        ' '
        ]));
    sRpt.add( format('%-56s %-14s %-14s', [
        '        Apply only if greater than $8,333.00 ',
        ' ',
        ' '
        ]));
    sRpt.add( format('%-56s %-14s %-14s', [
                'Less: $250.00 - ((' +
                formatF( Nc_Bc_Bft, 12, 2 ) + ' - $8,333.00) x 6.00%)',
                formatF( tr2, 12, 2 ),
                ' '
                ]));
    sRpt.add( format('%-56s %-14s %-14s', [
        '        Apply only if greater than $8,333.00 and',
        ' ',
        ' '
        ]));
    sRpt.add( format('%-56s %-14s %-14s', [
        '        less than $12,500, otherwise $0.00',
        ' ',
        ' '
        ]));
    sRpt.add( format('%-56s %-14s %-14s', [ ' ',  dash(12), ' '       ]));
    sRpt.add( format('%-56s %-14s %-14s', [
        '    Basic Federal Surtax: ',
        formatF( Round((t - tr2) * 100) / 100, 12, 2 ),
        ' '
        ]));
    sRpt.add( ' ' );
    sRpt.add( format('%-56s %-14s %-14s', [
        'Less: 50% Basic Federal Surtax: ',
         formatF( Round(tr1 * 100) / 100, 12, 2 ),
         ' '
         ]));
    sRpt.add( format('%-56s %-14s %-14s', [ ' ',  dash(12), ' '       ]));
    sRpt.add( format('%-56s %-14s %-14s', [
        '    Basic Federal Surtax: ',
        formatF( Round ((t - tr1 - tr2) * 100) /100, 12, 2 ),
        ' '
        ]));
    sRpt.add( ' ' );
    
    t := ( Nc_Bc_Bft - FED_surtax_limit_ii ) * FED_surtax_rate_ii;

    if t < 0 then
       t := 0;

    sRpt.add( format('%-56s %-14s %-14s', [
        'add: Amount(O) (' +
        formatF( Nc_Bc_Bft, 12, 2 ) + ' - ' +
        formatF( FED_surtax_limit_ii, 12, 2 ) + ') x ' +
        format( '%.2n', [ ( FED_surtax_rate_Ii * 100.00 ) ] ) + '%',
        formatF( t, 12, 2 ),
        ' '
        ]));
    end;

  sRpt.add( format('%-56s %-14s %-14s', [ ' ',  dash(12), ' '       ]));
  sRpt.add( format('%-56s %-14s %-14s', [
      '    Federal Surtax ',
      formatF( Nc_Bc_Fst, 12, 2 ),
      ' (P1)'
      ] ));
  sRpt.add( format('%-56s %-14s %-14s', [ ' ', dDash(12), ' '       ]));
  sRpt.add(' ');
End;

end.
