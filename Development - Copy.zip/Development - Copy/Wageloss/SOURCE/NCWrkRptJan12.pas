unit NCWrkRptJan12;

interface

uses
  Windows, Messages, SysUtils, Variants, Classes, Graphics, Controls, Forms,
  Dialogs, NCWrkRptJul11;

type
  TWrkRptJan12 = class(TWrkRptJul11)
  function getDateHeading():String; Override;
  private
    { Private declarations }
  public
    { Public declarations }
  end;

var
  WrkRptJan12: TWrkRptJan12;

implementation

{$R *.dfm}
(******************************************************************************)
(*                                                                            *)
(*  override this function for each class to avoid having to bring in all of  *)
(*    the methods that contain the date in the heading.                       *)
(*   IE:  the jan 09 class should return  2008/2009                           *)
(*        the july 09 class should return 2009                                *)
(*                                                                            *)
(******************************************************************************)

function TWrkRptJan12.getDateHeading():String;
begin
  result:='2011/2012'
end;

end.
