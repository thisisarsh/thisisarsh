(*****************************************************************)
(*  Wageloss System                                              *)
(*                                                               *)
(*  Benefit Calculation Report                                   *)
(*                                                               *)
(*                                                               *)
(*  Author: Ron Warkentin / WCB                                  *)
(*  Date:   August 1997                                          *)
(*****************************************************************)

unit NCBenRpt;

interface

uses
  Windows, Messages, SysUtils, Classes, Graphics, Controls, Forms, Dialogs,
  Qrctrls, quickrpt, ExtCtrls, NCRecDef, Math;

type
  TPrintBenCalForm = class(TForm)
    QRBenCal: TQuickRep;
    QRBand1: TQRBand;
    QRLabel1: TQRLabel;
    QRLabel2: TQRLabel;
    QRSysData4: TQRSysData;
    QRSysData2: TQRSysData;
    QRSysData1: TQRSysData;
    QRLabel3: TQRLabel;
    QRLabel4: TQRLabel;
    QRLabel5: TQRLabel;
    QRClaimNumber: TQRLabel;
    QRName: TQRLabel;
    QRAddr1: TQRLabel;
    QRAddr2: TQRLabel;
    QRAddr3: TQRLabel;
    QRUserID: TQRLabel;
    QRSysData3: TQRSysData;
    QRlblSIN: TQRLabel;
    QRlblDOB: TQRLabel;
    QrlblHomePhone: TQRLabel;
    QRlblWorkPhone: TQRLabel;
    QRSIN: TQRLabel;
    QRBirthDate: TQRLabel;
    QRHomePhone: TQRLabel;
    QRWorkPhone: TQRLabel;
    QRlblAccidentDate: TQRLabel;
    QRAccidentDate: TQRLabel;
    QRLabel14: TQRLabel;
    QRWeeklyWage: TQRLabel;
    QRLabel16: TQRLabel;
    QRTaxYear: TQRLabel;
    QRLabel15: TQRLabel;
    QRDaysWorked: TQRLabel;
    QRLabel22: TQRLabel;
    QRMaritalStatus: TQRLabel;
    QRLabel18: TQRLabel;
    QRWorking: TQRLabel;
    QRLabel26: TQRLabel;
    QREIExempt: TQRLabel;
    QRLabel28: TQRLabel;
    QRNumDeps: TQRLabel;
    QRLabel24: TQRLabel;
    QRNumInfirmDeps: TQRLabel;
    QRLabel20: TQRLabel;
    QRLabel21: TQRLabel;
    QRLabel23: TQRLabel;
    QRNonTaxCollBen: TQRLabel;
    QRTaxableCollBenefits: TQRLabel;
    QRlblLossEarnDate: TQRLabel;
    QRLossEarnDate: TQRLabel;
    QRLabel13: TQRLabel;
    QRLabel17: TQRLabel;
    QRLabel19: TQRLabel;
    QRLabel25: TQRLabel;
    QRLabel27: TQRLabel;
    QRTaxFed: TQRLabel;
    QRTaxMan: TQRLabel;
    QRCPP: TQRLabel;
    QREI: TQRLabel;
    QRLabel29: TQRLabel;
    QRlblWeekDed: TQRLabel;
    QRTotDed: TQRLabel;
    QRTotWeekDed: TQRLabel;
    QRLabel31: TQRLabel;
    QRLabel32: TQRLabel;
    QRLabel33: TQRLabel;
    QRPostInjWeekGross: TQRLabel;
    QRPostInjWeekNet: TQRLabel;
    QRShape1: TQRShape;
    QRlblYearIndexed: TQRLabel;
    QRYearIndexed: TQRLabel;
    QRLabel36: TQRLabel;
    QRTaxCollNet: TQRLabel;
    QRlblFull: TQRLabel;
    QRlblPartialHeading: TQRLabel;
    QRLabel39: TQRLabel;
    QRLabel40: TQRLabel;
    QRLabel41: TQRLabel;
    QRLabel42: TQRLabel;
    QRLabel43: TQRLabel;
    QRLabel44: TQRLabel;
    QRLabel45: TQRLabel;
    QRlblWeeklyTaxSheltering: TQRLabel;
    QRLabel47: TQRLabel;
    QRlblEffDate80Net: TQRLabel;
    QRLabel49: TQRLabel;
    QRLabel50: TQRLabel;
    QRlblPctClmtContrib: TQRLabel;
    QRlbl80NetClmtContrib: TQRLabel;
    QRlblPctWCBContrib: TQRLabel;
    QRWeeklyGross: TQRLabel;
    QRWeeklyNetLossEarn: TQRLabel;
    QRWeekly90NetActual: TQRLabel;
    QRWeekly90NetLoss: TQRLabel;
    QRWeeklyTaxSheltering: TQRLabel;
    QRWeekly90NetSheltered: TQRLabel;
    QRlblIncome: TQRLabel;
    QRlblWeekly: TQRLabel;
    QRlblPreInj: TQRLabel;
    QRPartialNetPreInj: TQRLabel;
    QRlblPostInj: TQRLabel;
    QRPartialNetPostInj: TQRLabel;
    QRlblLossEarn: TQRLabel;
    QRPartialNetLossEarn: TQRLabel;
    QRlbl90NetLoss: TQRLabel;
    QRPartial90NetLoss: TQRLabel;
    QRlblTaxSheltering: TQRLabel;
    QRPartialTaxSheltering: TQRLabel;
    QRlbl90NetSheltered: TQRLabel;
    QRPartial90NetSheltered: TQRLabel;
    QRlblEffDateClmtContrib: TQRLabel;
    QRlblClmtContrib: TQRLabel;
    QRlblNetClmtContrib: TQRLabel;
    QRlblWCBContrib: TQRLabel;
    QREffDate80Net: TQRLabel;
    QRPctClmtContrib: TQRLabel;
    QRFull80NetLoss: TQRLabel;
    QRFull80NetSheltered: TQRLabel;
    QRFullClmtContrib: TQRLabel;
    QRFull80NetContrib: TQRLabel;
    QRFullWCBContrib: TQRLabel;
    QRFullPctWCBContrib: TQRLabel;
    QRAnnualGross: TQRLabel;
    QRAnnualNetLossEarn: TQRLabel;
    QRAnnual90NetLoss: TQRLabel;
    QRAnnual90NetSheltered: TQRLabel;
    QRAnnual80NetLoss: TQRLabel;
    QRAnnual80NetSheltered: TQRLabel;
    QRAnnual80NetContrib: TQRLabel;
    QRPartialPctClmtContrib: TQRLabel;
    QRPartialPctWCBContrib: TQRLabel;
    QRPartial80NetLoss: TQRLabel;
    QRPartial80NetSheltered: TQRLabel;
    QRPartialClmtContrib: TQRLabel;
    QRPartial80NetContrib: TQRLabel;
    QRPartialWCBContrib: TQRLabel;
    QREffDateClmtContrib: TQRLabel;
    QRlbl80NetLoss: TQRLabel;
    QRlbl80NetSheltered: TQRLabel;
    QRPartialDailyCompRate: TQRLabel;
    QRlblPartialDailyCompRate: TQRLabel;
    QRLabel6: TQRLabel;
    QRWeeklyDailyCompRate: TQRLabel;
    DetailBand1: TQRBand;
    QRLabel7: TQRLabel;
    QRLabel8: TQRLabel;
    QRCPPExempt: TQRLabel;
    QRTaxExempt: TQRLabel;
    QRLabel11: TQRLabel;
    QRLabel12: TQRLabel;
    QRRecurrence: TQRLabel;
    QRSelfEmp: TQRLabel;
    QRLabel9: TQRLabel;
    QRLabel30: TQRLabel;
    QRLabel10: TQRLabel;
    QRChildCareExp: TQRLabel;
    QRSpousalSupport: TQRLabel;
    QRChildSupport: TQRLabel;
    QRLabel34: TQRLabel;
    QR80WeeklyDailyCompRate: TQRLabel;
    QRlblPartial80DailyCompRate: TQRLabel;
    QRPartial80DailyCompRate: TQRLabel;
    QRRecurrenceDate: TQRLabel;
    lblRecurrenceDateLabel: TQRLabel;
    QRIndexDateLabel: TQRLabel;
    QRIndexationDate: TQRLabel;
    QRLabel35: TQRLabel;
    QRYouthfulWorker: TQRLabel;
    QRFormCode: TQRLabel;
    QRLabel37: TQRLabel;
    QRApprentice: TQRLabel;
    QRLabel38: TQRLabel;
    QRDeemed_Earnings: TQRLabel;
    procedure QRBenCalBeforePrint(Sender: TCustomQuickRep;
      var PrintReport: Boolean);
    procedure QRBenCalNeedData(Sender: TObject; var MoreData: Boolean);
    procedure QRHomePhonePrint(sender: TObject; var Value: String);
    procedure QRWorkPhonePrint(sender: TObject; var Value: String);
    procedure QRSINPrint(sender: TObject; var Value: String);
    procedure FormClose(Sender: TObject; var Action: TCloseAction);
  private
    { Private declarations }
    cntr: integer;
    procedure FullClaim;
    procedure CheckForPartial;
    procedure BlankForCI;
    procedure fillInForm;
  public
    { Public declarations }
    ReportType : integer;
    CalcFullClaim, CalcPartClaim: RecNCClaim;
  end;

var
  PrintBenCalForm: TPrintBenCalForm;

implementation

{$R *.DFM}

uses NCMain, NCIniMod, UtilMod1, uADOSecurity, NCBencal, uGlobal;

procedure TPrintBenCalForm.QRBenCalBeforePrint(Sender: TCustomQuickRep;
  var PrintReport: Boolean);
var
   Acc_Year, Acc_Month, Acc_Day, Idx_Month:Word;
   WorkDate:TDateTime;
begin
  Cntr:=0;

  {  This report can be generated from more than one form.
     Determine the parent and fill in fields accordingly  }
  case ReportType of
  0:
  begin
      QRBenCal.ReportTitle := 'Benefit Calculation Report';
  end;
  1:
  begin
      QRBenCal.ReportTitle := 'Benefit Calculator';
      BlankForCI;
  end;
  end;

  DecodeDate(CalcFullClaim.Accident_Date, Acc_Year, Acc_Month, Acc_Day);
  if ((CalcFullClaim.Indexation_Year > 0) AND (CalcFullClaim.Tax_Year <> Acc_Year)) Then
     Idx_Month := Max(((Acc_Month+1) Mod 13),1)
  else
     Idx_Month := Acc_Month;
  WorkDate := EncodeDate(Min(Max(CalcFullClaim.Indexation_Year,Acc_Year), CalcFullClaim.Tax_Year), Idx_Month, 1);
  QRIndexationDate.Caption := FormatDateTime('d-mmm-yyyy', WorkDate);
  //
  // If the calim has been indexed we need to show the indexed date
  // otherwise hide the field and the label
  //
  If ((CalcFullClaim.Indexation_Year = 0) OR (CalcFullClaim.Tax_Year = Acc_Year)) Then
     Begin
     QRIndexationDate.Enabled := False;
     QRIndexDateLabel.Enabled := False;
     End
  else
     Begin
     QRIndexationDate.Enabled := True;
     QRIndexDateLabel.Enabled := True;
     End;
end;

procedure TPrintBenCalForm.CheckForPartial;
begin
  if ( CalcFullClaim.Post_Injury_Earn = 0.0 ) then
  begin
    QRPartialNetPreInj.enabled := False;
    QRPartialNetPostInj.enabled := False;
    QRPartialNetLossEarn.enabled := False;
    QRPartial90NetLoss.enabled := False;
    QRPartialTaxSheltering.enabled := False;
    QRPartial90NetSheltered.enabled := False;
    QRPartialDailyCompRate.enabled := False;
    QRPartial80NetLoss.enabled := False;
    QRPartial80NetSheltered.enabled := False;
    QRPartial80DailyCompRate.Enabled := False;
    QRPartialPctClmtContrib.enabled := False;
    QRPartialClmtContrib.enabled := False;
    QRPartialPctWCBContrib.enabled := False;
    QRPartial80NetContrib.enabled := False;
    QRPartialWCBContrib.enabled := False;
    QRlblPartialHeading.enabled := False;
    QRlblIncome.enabled := False;
    QRlblWeekly.enabled := False;
    QRlblPreInj.enabled := False;
    QRlblPostInj.enabled := False;
    QRlblLossEarn.enabled := False;
    QRlbl90NetLoss.enabled := False;
    QRlblTaxSheltering.enabled := False;
    QRlbl90NetSheltered.enabled := False;
    QRlblPartialDailyCompRate.enabled := False;
    QRlblPartial80DailyCompRate.Enabled := False;
    QRlblClmtContrib.enabled := False;
    QRlblNetClmtContrib.enabled := False;
    QRlblWCBContrib.enabled := False;
    QRlbl80NetLoss.enabled := False;
    QRlbl80NetSheltered.enabled := False;
  end
  else
  begin
    with CalcPartClaim do
    begin
    QRPostInjWeekNet.caption := Format('%n', [Post_Injury_Earn_Net]);
    QRPartialNetPreInj.caption := Format('%n',  [ CalcFullClaim.Weekly_Net ] );
    QRPartialNetPostInj.caption := Format('%n', [Post_Injury_Earn_Net]);
    QRPartialNetLossEarn.caption := Format('%n', [Weekly_Net]);
    QRPartial90NetLoss.caption := Format('%n', [Weekly_90]);

    //showmessage('Weekly_90 = ' + format('%.2n', [ Weekly_90 ] ) + '  Weekly_90_S = ' + format('%.2n', [ Weekly_90_S ] ));

    if ( Weekly_90_S <= 0 ) then
    begin
    if ( ( pdoxround( ( Weekly_90 + Weekly_90_S ) , 2) <= 0 ) or ( Weekly_90 <= 0 ) ) then
            //lblPartCalcTaxSheltering.caption := '0.00'
      QRPartialTaxSheltering.caption := QRWeeklyTaxSheltering.caption
    else
      if Collateral_Ben_Tax > 0.00 then
        QRPartialTaxSheltering.caption := format('%.2n', [ pdoxround( ( Weekly_90 + Weekly_90_S ) , 2) ] )
        else
          QRPartialTaxSheltering.caption := QRWeeklyTaxSheltering.caption
      end
      else
      begin
        if ( ( pdoxround( ( Weekly_90 - Weekly_90_S ) , 2) <= 0 ) or ( Weekly_90 <= 0 ) ) then
          QRPartialTaxSheltering.caption := '0.00'
        else
          if Collateral_Ben_Tax > 0.00 then
            QRPartialTaxSheltering.caption := format('%.2n', [ pdoxround( ( Weekly_90 - Weekly_90_S ) , 2) ] )
          else
            QRPartialTaxSheltering.caption := QRWeeklyTaxSheltering.caption
        end;

    QRPartialTaxSheltering.caption := Format('%n', [ pdoxround( ( Weekly_90 - Weekly_90_S ) , 2) ] );
    QRPartial90NetSheltered.caption := Format('%n', [Weekly_90_S]);
    QRPartialDailyCompRate.caption := Format('%n', [Weekly_90_S / Days_Worked_per_Week]);
    QRPartial80DailyCompRate.caption := Format('%n', [pdoxround( ( Weekly_80  - Wkly_Clmt_Anty_Con_Amt), 2) / Days_Worked_per_Week]);
    QRPartial80NetLoss.caption := Format('%n', [Weekly_80]);
    QRPartial80NetSheltered.caption := Format('%n', [Weekly_80_S]);
    QRPartialPctClmtContrib.caption := Format('%n', [NC_104_Wk_Clmt_P_Contrib]);
    QRPartialClmtContrib.caption := Format('%n', [Wkly_Clmt_Anty_Con_Amt]);
    QRPartialPctWCBContrib.caption := Format('%n', [ ( 5.00 - nc_104_Wk_WCB_p_Contrib_Red ) ]);
    QRPartial80NetContrib.caption := Format('%n', [ pdoxround( ( Weekly_80  - Wkly_Clmt_Anty_Con_Amt), 2) ] );
    QRPartialWCBContrib.caption := Format('%n', [ pdoxround( ( (((5 - nc_104_Wk_WCB_p_Contrib_Red)*Weekly_80)/100.00) ), 2) ] );
    end;
  end;
end;

procedure TPrintBenCalForm.FullClaim;
begin
  with CalcFullClaim do
  begin
  QRUserID.caption := UserProfile.givenName + ' ' + userProfile.familyName;
  QRClaimNumber.caption :=
       pdoxTrim(Claim_No) + ' / ' + pdoxTrim(Claim_Suffix);
  QRName.caption :=
       pdoxTrim(Clmnts_1st_Name) + ' ' + pdoxTrim(Clmnts_Surname);
  QRSIN.caption  := SIN;
  QRAddr1.caption := Clmnts_Add_No_1;
  QRAddr2.caption := Clmnts_Add_No_2;
  QRAddr3.caption :=
       pdoxTrim(Clmnts_Add_No_3) + ' ' + pdoxTrim(Clmnts_Post_Code);
  if Birth_Date > 0 then
     QRBirthDate.caption := FormatDateTime('d-mmm-yyyy', Birth_Date)
  else
     QRBirthDate.caption := '';
  QRHomePhone.caption  := Clmnts_Home_Phone;
  QRWorkPhone.caption  := Clmnts_Work_Phone;

  if Accident_Date > 0 then
     QRAccidentDate.caption := FormatDateTime('d-mmm-yyyy', Accident_Date)
  else
     QRAccidentDate.caption := '';

  if Loss_Earn_Date > 0 then
     QRLossEarnDate.caption := FormatDateTime('d-mmm-yyyy', Loss_Earn_Date)
  else
     QRLossEarnDate.caption := '';

  if RecurrenceDate > 0 then
     Begin
     QRRecurrenceDate.Caption := FormatDateTime('d-mmm-yyyy', RecurrenceDate);
     lblRecurrenceDateLabel.Enabled := True;
     End
  else
     Begin
     QRRecurrenceDate.caption := '';
     lblRecurrenceDateLabel.Enabled := False;
     End;

  //QRAvgEarnBase.caption := AverageEarningsBasedOn;
  QRMaritalStatus.caption := Marital_Status;
  QRYouthfulWorker.Caption := Youthful_Worker;
  QRApprentice.Caption := Apprentice;
  QRWorking.caption := Spouse_Working;
  QRDaysWorked.caption := Format('%n', [Days_Worked_per_Week]);
  QRWeeklyWage.caption := Format('%n', [Wkly_Sal_A]);
  QRTaxYear.caption := IntToStr(Tax_Year);
  QRYearIndexed.caption := IntToStr(Indexation_Year);
  QRRecurrence.caption := copy(Recurrence,1,1);
  QRSelfEmp.caption := copy(Self_Employed,1,1);
  QRTaxableCollBenefits.caption := Format('%n', [Collateral_Ben_Tax]);
  QRNonTaxCollBen.caption := Format('%n', [Collateral_Ben_Non_Tax]);
  QRTaxCollNet.caption := Format('%n', [CalcPartClaim.Coll_Ben_Tax_Net]);
  QRNumDeps.caption := IntToStr(No_Of_Dependnts);
  QRNumInfirmDeps.caption := IntToStr(No_Infirm);
  QREIExempt.caption := copy(EI_Exempt,1,1);
  QRCPPExempt.caption := copy(CPP_Exempt,1,1);
  QRTaxExempt.caption := copy(Tax_Exempt,1,1);
  QRChildCareExp.caption := Format('%n', [Child_Care_Exp]);
  QRSpousalSupport.caption := Format('%n', [Spousal_Support]);
  QRChildSupport.caption := Format('%n', [Child_Support]);
  QRTaxFed.caption := Format('%n', [Inc_Tax_Fed]);
  QRTaxMan.caption := Format('%n', [Inc_Tax_Man]);
  QRCPP.caption    := Format('%n', [CPP_Prem]);
  QREI.caption     := Format('%n', [EI_Prem]);
  QRTotDed.caption := Format('%n', [ Total_Deds ] );
  QRTotWeekDed.caption := Format('%n', [PdoxRound(Total_Deds / 52.0, 2 ) ]);
  QRPostInjWeekGross.caption := Format('%n', [Post_Injury_Earn]);
  QRDeemed_Earnings.Caption := Copy(Deemed_Earnings, 1, 1);
  QRPostInjWeekNet.caption := Format('%n', [Post_Injury_Earn_Net]);
  QRWeeklyGross.caption := Format('%n', [Wkly_Sal_A]);
  QRAnnualGross.caption := Format('%n', [ Annual_Gross ] );
  QRWeeklyNetLossEarn.caption := Format('%n', [Weekly_Net]);
  QRAnnualNetLossEarn.caption := Format('%n', [ Annual_Net ] );
  QRWeekly90NetActual.caption := Format('%n', [PdoxRound( ( Weekly_Net_A * 0.90 ) , 2)] );
  QRWeekly90NetLoss.caption := Format('%n', [Weekly_90]);
  QRAnnual90NetLoss.caption := Format('%n', [ Annual_90 ] );
  QRWeeklyTaxSheltering.caption := Format('%n', [ pdoxround( ( Weekly_90 - Weekly_90_S ) , 2) ] );
  QRWeekly90NetSheltered.caption := Format('%n', [Weekly_90_S]);
  QRAnnual90NetSheltered.caption := Format('%n', [ Annual_90_S ] );
  QRWeeklyDailyCompRate.caption := Format('%n', [Weekly_90_S / Days_Worked_per_Week]);
  QR80WeeklyDailyCompRate.Caption := Format('%n', [pdoxround( ( Weekly_80  - Wkly_Clmt_Anty_Con_Amt), 2) / Days_Worked_per_Week]);
  QRFull80NetLoss.caption := Format('%n', [Weekly_80]);
  QRAnnual80NetLoss.caption := Format('%n', [ Annual_80 ] );
  QRFull80NetSheltered.caption := Format('%n', [Weekly_80_S]);
  QRAnnual80NetSheltered.caption := Format('%n', [ Annual_80_S ] );
  QRPctClmtContrib.caption := Format('%n', [NC_104_Wk_Clmt_P_Contrib]);
  QRFullClmtContrib.caption := Format('%n', [Wkly_Clmt_Anty_Con_Amt]);
  QRFullPctWCBContrib.caption := Format('%n',[ ( 5.00 - nc_104_Wk_WCB_p_Contrib_Red ) ] );
  QRFull80NetContrib.caption := Format('%n', [ pdoxround( ( Weekly_80  - Wkly_Clmt_Anty_Con_Amt), 2) ] );
  QRAnnual80NetContrib.caption := Format('%n', [ pdoxround( ( Annual_80 - ( 52* Wkly_Clmt_Anty_Con_Amt ) ), 2) ] );
  QRFullWCBContrib.caption := Format('%n', [ pdoxround( ( (((5 - nc_104_Wk_WCB_p_Contrib_Red)*Weekly_80)/100.00) ), 2) ] );
  if nc_104_Wk_Effective_Date > 0 then
     QREffDate80Net.caption := FormatDateTime('d-mmm-yyyy', nc_104_Wk_Effective_Date)
  else
     QREffDate80Net.caption := '';
  if nc_104_Wk_Clmt_P_Eff_Date > 0 then
     QREffDateClmtContrib.caption := FormatDateTime('d-mmm-yyyy', nc_104_Wk_Clmt_P_Eff_Date)
  else
     QREffDateClmtContrib.caption := '';
  end;
end;

procedure TPrintBenCalForm.BlankForCI;
begin
  QRlblSIN.enabled := False;
  QRSIN.enabled := False;
  QRlblDOB.enabled := False;
  QRBirthDate.enabled := False;
  QrlblHomePhone.enabled := False;
  QRHomePhone.enabled := False;
  QRlblWorkPhone.enabled := False;
  QRWorkPhone.enabled := False;
  QRlblLossEarnDate.enabled := False;
  QRLossEarnDate.enabled := False;
  QRlblYearIndexed.enabled := False;
  QRYearIndexed.enabled := False;
  QRlblEffDate80Net.enabled := False;
  QREffDate80Net.enabled := False;
  QRlblEffDateClmtContrib.enabled := False;
  QREffDateClmtContrib.enabled := False;
end;

procedure TPrintBenCalForm.QRBenCalNeedData(Sender: TObject;
  var MoreData: Boolean);
begin
    MoreData := Cntr < 1;
    inc(Cntr);

    if not MoreData then
       exit;

    fillInForm;
end;

procedure TPrintBenCalForm.fillInForm;
begin
  case ReportType of
  0:
      begin
      FullClaim;
      CheckForPartial;
      end;
  1:
      begin
      FullClaim;
      CheckForPartial;
      end;
  end; // end case

end;

procedure TPrintBenCalForm.QRHomePhonePrint(sender: TObject;
  var Value: String);
var
   s:String;
begin
   if length(Value) = 10 Then
      s := '(' + Copy(Value, 1, 3) + ') ' + Copy(Value, 4, 3) + '-' + Copy(Value,7,4)
   else if Length(Value) = 7 Then
      s := Copy(Value, 4, 3) + '-' + Copy(Value,7,4)
   else
      s := Value;

   Value := s;
end;

procedure TPrintBenCalForm.QRWorkPhonePrint(sender: TObject;
  var Value: String);
var
   s:String;
begin
   if length(Value) = 10 Then
      s := '(' + Copy(Value, 1, 3) + ') ' + Copy(Value, 4, 3) + '-' + Copy(Value,7,4)
   else if Length(Value) = 7 Then
      s := Copy(Value, 1, 3) + '-' + Copy(Value,4,4)
   else
      s := Value;

   Value := s;
end;

procedure TPrintBenCalForm.QRSINPrint(sender: TObject; var Value: String);
var
   s:String;
begin
if Length(Value) = 9 then
   s := Copy(Value, 1, 3) + ' ' + Copy(Value, 4, 3) + ' ' + Copy (Value, 7, 3)
else
   s := Value;

Value := s;
end;

procedure TPrintBenCalForm.FormClose(Sender: TObject;
  var Action: TCloseAction);
begin
Action := caFree;
end;

end.

