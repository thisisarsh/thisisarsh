(*****************************************************************)
(*  Wageloss System                                              *)
(*                                                               *)
(*  Benefits Calculator                                          *)
(*                                                               *)
(*                                                               *)
(*  Author: Brad Trupp  / Capella Systems Group, Inc.            *)
(*  Date:   July 1997                                            *)
(*                                                               *)
(*  Oct 2000 - Add fields to accomodate policy changes           *)
(*                                                               *)
(*  Mar 2001 - allow calcs when tax year is accident year + 1 and*)
(*                    a recurrence                               *)
(*****************************************************************)

unit NCCALCI0;

interface

uses
  Windows, Messages, SysUtils, Classes, Graphics, Controls, Forms, Dialogs,
  StdCtrls, ComCtrls, WLDEBUG, NCRecdef, NCIniMod, ExtCtrls;

type
  TBenefitsCalculatorForm = class(TForm)
    ScrollBox1: TScrollBox;
    Label2: TLabel;
    edClaim_No: TEdit;
    edClmnts_1st_Name: TEdit;
    edClmnts_Surname: TEdit;
    edClmnts_Add_No_1: TEdit;
    edClmnts_Add_No_2: TEdit;
    edClmnts_Post_Code: TEdit;
    edWkly_Sal_A: TEdit;
    Label1: TLabel;
    Label3: TLabel;
    edDays_Worked_per_Week: TEdit;
    Label4: TLabel;
    Label5: TLabel;
    Label6: TLabel;
    Label7: TLabel;
    Label8: TLabel;
    Label9: TLabel;
    edTax_Year: TEdit;
    edMarital_Status: TEdit;
    edEI_Exempt: TEdit;
    edNo_Of_Dependnts: TEdit;
    edNo_Infirm: TEdit;
    lblTaxCode: TLabel;
    Label10: TLabel;
    Label11: TLabel;
    Label12: TLabel;
    Label13: TLabel;
    Label14: TLabel;
    edCollateral_Ben_Tax: TEdit;
    edCollateral_Ben_Non_Tax: TEdit;
    edPost_Injury_Earn: TEdit;
    Label16: TLabel;
    edSpouse_Working: TEdit;
    Bevel1: TBevel;
    Label17: TLabel;
    lblTaxCodeAmt: TLabel;
    Label30: TLabel;
    Label31: TLabel;
    Label40: TLabel;
    Label41: TLabel;
    Label42: TLabel;
    Label43: TLabel;
    Label44: TLabel;
    Label45: TLabel;
    lblWkly_Sal_A: TLabel;
    lblWeekly_Net: TLabel;
    lbCalc90p_Wkly_Net_A: TLabel;
    lblAnnual_Gross: TLabel;
    lblAnnual_Net: TLabel;
    Label52: TLabel;
    Label53: TLabel;
    Label54: TLabel;
    lblWeekly_90: TLabel;
    lblCalcTaxSheltering: TLabel;
    lblWeekly_90_S: TLabel;
    lblAnnual_90: TLabel;
    lblAnnual_90_S: TLabel;
    Label61: TLabel;
    Label62: TLabel;
    Label63: TLabel;
    lblWeekly_80: TLabel;
    lblWeekly_80_S: TLabel;
    lblWkly_Clmt_Anty_Con_Amt: TLabel;
    lblAnnual_80: TLabel;
    lblAnnual_80_S: TLabel;
    Label70: TLabel;
    Label71: TLabel;
    lblCalcWkly80p_Net_Clmt_Contr: TLabel;
    lblCalcWkly_p_WCB_Contr: TLabel;
    lblCalcAnnual80p_Net_Clmt_Contr: TLabel;
    Label39: TLabel;
    Label77: TLabel;
    Label78: TLabel;
    Label79: TLabel;
    Label80: TLabel;
    lblPartPre_Weekly_Net: TLabel;
    lblPartPost_Injury_Earn_Net: TLabel;
    lblPartCalcNetLossEarnings: TLabel;
    Label88: TLabel;
    Label89: TLabel;
    Label90: TLabel;
    lblPartWeekly_90: TLabel;
    lblPartCalcTaxSheltering: TLabel;
    lblPartWeekly_90_S: TLabel;
    Label97: TLabel;
    Label98: TLabel;
    Label99: TLabel;
    lblPartWeekly_80: TLabel;
    lblPartWeekly_80_S: TLabel;
    lblPartWkly_Clmt_Anty_Con_Amt: TLabel;
    Label106: TLabel;
    Label107: TLabel;
    lblPartCalcWkly80p_Net_Clmt_Contr: TLabel;
    lblPartCalcWkly_p_WCB_Contr: TLabel;
    lblnc_104_Wk_Clmt_p_Contrib: TLabel;
    lblCalcnc_104_Wk_WCB_p_Contrib_Red: TLabel;
    lblPart_nc_104_Wk_Clmt_p_Contrib: TLabel;
    lblPart_Calcnc_104_Wk_WCB_p_Contrib_Red: TLabel;
    lblDailyCompensationRate: TLabel;
    Label49: TLabel;
    lblPartDailyCompensationRate: TLabel;
    Label56: TLabel;
    Label32: TLabel;
    Label33: TLabel;
    Label34: TLabel;
    Label35: TLabel;
    Label36: TLabel;
    Label37: TLabel;
    Label38: TLabel;
    lblInc_Tax_Fed: TLabel;
    lblInc_Tax_Man: TLabel;
    lblCPP_Prem: TLabel;
    lblEI_Prem: TLabel;
    lblTotal_Deds: TLabel;
    lblWkly_Total_Deds: TLabel;
    Label48: TLabel;
    ednc_104_Wk_WCB_p_Contrib_Red: TEdit;
    Label28: TLabel;
    ednc_104_Wk_Clmt_p_Contrib: TEdit;
    Label47: TLabel;
    Label15: TLabel;
    edCPP_Exempt: TEdit;
    edTax_Exempt: TEdit;
    edChild_Care_Exp: TEdit;
    Label18: TLabel;
    Label19: TLabel;
    Label20: TLabel;
    Label21: TLabel;
    Label22: TLabel;
    edSpousal_Support: TEdit;
    edChild_Support: TEdit;
    Label23: TLabel;
    edMax_Adjustments: TEdit;
    Label64: TLabel;
    edRecurrence: TEdit;
    Label65: TLabel;
    edSelf_Employed: TEdit;
    Label24: TLabel;
    edAccident_Date: TEdit;
    edRecurrenceDate: TEdit;
    procedure FormClose(Sender: TObject; var Action: TCloseAction);
    procedure FormDestroy(Sender: TObject);
    procedure FormKeyDown(Sender: TObject; var Key: Word;
      Shift: TShiftState);
    procedure IntegerKeyPress(Sender: TObject; var Key: Char);
    procedure DoubleKeyPress(Sender: TObject; var Key: Char);
    procedure edWkly_Sal_AExit(Sender: TObject);
    procedure edDays_Worked_per_WeekExit(Sender: TObject);
    procedure edTax_YearExit(Sender: TObject);
    procedure edMarital_StatusExit(Sender: TObject);
    procedure edSpouse_WorkingExit(Sender: TObject);
    procedure edEI_ExemptExit(Sender: TObject);
    procedure edNo_Of_DependntsExit(Sender: TObject);
    procedure edNo_InfirmExit(Sender: TObject);
    procedure edCollateral_Ben_TaxExit(Sender: TObject);
    procedure edCollateral_Ben_Non_TaxExit(Sender: TObject);
    procedure edPost_Injury_EarnExit(Sender: TObject);
//    procedure edDeemed_EarningsExit(Sender: TObject);
    procedure edMarital_StatusKeyPress(Sender: TObject; var Key: Char);
    procedure edEI_ExemptKeyPress(Sender: TObject; var Key: Char);
//    procedure edDeemed_EarningsKeyPress(Sender: TObject; var Key: Char);
    procedure edSpouse_WorkingKeyPress(Sender: TObject; var Key: Char);
    procedure edClmnts_Post_CodeKeyPress(Sender: TObject; var Key: Char);
    procedure edClmnts_Post_CodeExit(Sender: TObject);
    procedure FormCreate(Sender: TObject);
    procedure FormKeyPress(Sender: TObject; var Key: Char);
    procedure ednc_104_Wk_WCB_p_Contrib_RedExit(Sender: TObject);
    procedure ednc_104_Wk_Clmt_p_ContribExit(Sender: TObject);
    procedure FormActivate(Sender: TObject);
    procedure edChild_Care_ExpExit(Sender: TObject);
    procedure edSpousal_SupportExit(Sender: TObject);
    procedure edChild_SupportExit(Sender: TObject);
    procedure edCPP_ExemptKeyPress(Sender: TObject; var Key: Char);
    procedure edCPP_ExemptExit(Sender: TObject);
    procedure edTax_ExemptKeyPress(Sender: TObject; var Key: Char);
    procedure edTax_ExemptExit(Sender: TObject);
    procedure edMax_AdjustmentsExit(Sender: TObject);
    procedure edRecurrenceKeyPress(Sender: TObject; var Key: Char);
    procedure edSelf_EmployedKeyPress(Sender: TObject; var Key: Char);
    procedure edRecurrenceExit(Sender: TObject);
    procedure edSelf_EmployedExit(Sender: TObject);
    procedure edAccident_DateExit(Sender: TObject);
    procedure edAccident_DateKeyPress(Sender: TObject; var Key: Char);
    procedure edRecurrenceDateExit(Sender: TObject);
    procedure ScrollBox1MouseWheelUp(Sender: TObject; Shift: TShiftState;
      MousePos: TPoint; var Handled: Boolean);
    procedure ScrollBox1MouseWheelDown(Sender: TObject; Shift: TShiftState;
      MousePos: TPoint; var Handled: Boolean);
  private
    { Private declarations }
    globalEditError: boolean;
    function DoBenCalc: boolean;
    procedure PrintBenCalcReport;
    procedure ClearCalc;
    procedure ResetCalc;
    procedure ResetInfoLine2;
    procedure RecalcBen;
    procedure fillInForm;
  public
    { Public declarations }
    dataBenCalc, CalcFullClaim, CalcPartClaim: recNCCLAIM;
    fWorking : recConst;
  end;

var
  BenefitsCalculatorForm: TBenefitsCalculatorForm;

implementation

{$R *.DFM}

uses utilmod1, NCMain, NCBenRpt, QPreview, uGlobal, Utils, ValidateDate, ConvertDate;

(******************************************************************************)
(*                                                                            *)
(*  Form Close                                                                *)
(*                                                                            *)
(******************************************************************************)
procedure TBenefitsCalculatorForm.FormClose(Sender: TObject; var Action: TCloseAction);
begin
  Action:=caFree;
end;

(******************************************************************************)
(*                                                                            *)
(*  Form Destroy                                                              *)
(*                                                                            *)
(******************************************************************************)
procedure TBenefitsCalculatorForm.FormDestroy(Sender: TObject);
begin
  BenefitsCalculatorForm:=nil;
  WagelossMainForm.ShowInfoLine1('');
  WagelossMainForm.ShowInfoLine2('');
end;

(******************************************************************************)
(*                                                                            *)
(*  Key Down - preview and process keypresses on form.                        *)
(*                                                                            *)
(******************************************************************************)
procedure TBenefitsCalculatorForm.FormKeyDown(Sender: TObject;
  var Key: Word; Shift: TShiftState);
begin
  case Key of
    27: begin
         Key:=0;
         close;
         end;
    VK_F1: begin
           Key:=0;
           Application.HelpCommand(HELP_CONTENTS, 0);
           end;
    VK_F3: begin
           Key:=0;
           resetCalc;
           end;
    VK_F7: begin
           Key:=0;
           close;
           end;
    VK_F8: begin
           Key:=0;
           scrollbox1.VertScrollBar.position:=scrollbox1.VertScrollBar.range;
           if DoBenCalc then PrintBenCalcReport;
           end;
    VK_F9: begin
           Key:=0;
           scrollbox1.VertScrollBar.position:=scrollbox1.VertScrollBar.range;
           DoBenCalc;
           end;
    VK_NEXT: begin
           Key:=0;
           scrollbox1.VertScrollBar.position:=scrollbox1.VertScrollBar.range;
           end;
    VK_PRIOR: begin
           Key:=0;
           scrollbox1.VertScrollBar.position:=0;
           end;
  end;
end;

(******************************************************************************)
(*                                                                            *)
(*  Key Press - preview and process keypresses on form.                       *)
(*                                                                            *)
(******************************************************************************)
procedure TBenefitsCalculatorForm.FormKeyPress(Sender: TObject;
  var Key: Char);
begin
  case Key of
    Chr(VK_RETURN):
      begin
        Key:=#0;
        SelectNext(ActiveControl as tWinControl, true, true );
      end;
  end;
end;

(******************************************************************************)
(*                                                                            *)
(*  Ensure keys presses are valid for integer                                 *)
(*                                                                            *)
(******************************************************************************)
procedure TBenefitsCalculatorForm.IntegerKeyPress(Sender: TObject;
  var Key: Char);
begin
  case Key of
  #0..#31,'0'..'9':
  else
    Key:=#0;
  end;
end;

(******************************************************************************)
(*                                                                            *)
(*  Ensure keys presses are valid for a double or float or currency           *)
(*                                                                            *)
(******************************************************************************)
procedure TBenefitsCalculatorForm.DoubleKeyPress(Sender: TObject;
  var Key: Char);
begin
  case Key of
  #0..#31,'0'..'9','.','+':
  else
    Key:=#0;
  end;
end;

(******************************************************************************)
(*                                                                            *)
(*  Perform Benefit Calculation.                                              *)
(*                                                                            *)
(*    - Validate edit fields, calculate, and display.                         *)
(*                                                                            *)
(******************************************************************************)
function TBenefitsCalculatorForm.DoBenCalc: boolean;
var
  res: boolean;
  ws: shortstring;
begin
  result:=false;
  ResetInfoLine2;
  { validate all fields }

    res := validateAsDate( edAccident_Date );
    if not res then exit;
    res := validateAsCurrency( edWkly_Sal_A );
    if not res then exit;
    res := validateAsCurrency( edMax_Adjustments );
    if not res then exit;
    res := validateAsCurrency( edDays_Worked_per_Week );
    if not res then exit;
    res := validateAsInteger( edTax_Year );
    if not res then exit;
    res := validateAsInteger( edNo_Of_Dependnts );
    if not res then exit;
    res := validateAsInteger( edNo_Infirm );
    if not res then exit;
    res := validateAsCurrency( edCollateral_Ben_Tax );
    if not res then exit;
    res := validateAsCurrency( edCollateral_Ben_Non_Tax );
    if not res then exit;
    res := validateAsCurrency( edPost_Injury_Earn );
    if not res then exit;
    res := validateAsCurrency( edChild_Care_Exp );
    if not res then exit;
    res := validateAsCurrency( edSpousal_Support );
    if not res then exit;
    res := validateAsCurrency( edChild_Support );
    if not res then exit;
    res := validateAsDate( edRecurrenceDate );
    if not res then exit;

    globalEditError:=false;
    edTax_YearExit( edTax_Year );
    if globalEditError then exit;

    // make sure an accident date was entered
    if length( edAccident_Date.text ) < 1 then
    begin
      edAccident_Date.setfocus;
      WagelossMainForm.ShowInfoLine2('*Please enter an Accident Date.');
      exit;
    end;

    // Support payment fields are not valid for pre-2001 claims
    if year(textAsDate(edAccident_Date)) < 2001 then
    begin
      edChild_Care_Exp.text:='0';
      edSpousal_Support.text:='0';
      edChild_Support.text:='0';

      setEditToRead(edChild_Care_Exp);
      setEditToRead(edSpousal_Support);
      setEditToRead(edChild_Support);
    end
    else
    begin
      setEditToNormal(edChild_Care_Exp);
      setEditToNormal(edSpousal_Support);
      setEditToNormal(edChild_Support);
    end;

    // make sure a wage was entered
    if ( textAsCurrency( edWkly_Sal_A ) < 0.01 ) then
    begin
      edWkly_Sal_A.setfocus;
      WagelossMainForm.ShowInfoLine2('*Please enter a weekly wage.');
      exit;
    end;

    edRecurrence.text := uppercase(edRecurrence.text);
    if (edRecurrence.Text <> 'Y') and (edRecurrence.Text <> 'N') then
    begin
      edRecurrence.setfocus;
      WagelossMainForm.ShowInfoLine2('*Valid values for Recurrence are Y N');
      exit;
    end;

    edSelf_Employed.text := uppercase(edSelf_Employed.text);
    if (edSelf_Employed.Text <> 'Y') and (edSelf_Employed.Text <> 'N') then
    begin
    begin
      edSelf_Employed.setfocus;
      WagelossMainForm.ShowInfoLine2('*Valid values for Self Employed are Y N');
      exit;
    end;
    end;
    if (edRecurrence.text='Y') and ((edSelf_employed.text='N') or (edSelf_employed.text=''))
    	and (GetOldRecurrenceInd='N') then
    begin
     	edRecurrenceDate.Visible := True;
      If Length(edRecurrenceDate.text) < 1 then
    	begin
      	edRecurrenceDate.setfocus;
      	WagelossMainForm.ShowInfoLine2('*Please enter a Recurrence Date.');
      	exit;
    	end;
    end
    else
    begin
    	edRecurrenceDate.text := '';
      edRecurrenceDate.Visible := False;
    end;
    if (edRecurrence.Text='N') and (edSelf_Employed.Text='N') then
    begin
      edMax_Adjustments.Text :='0';
      setEditToRead(edMax_Adjustments);
    end
    else
    begin
      if ((edRecurrence.Text='Y') or (edSelf_Employed.Text='Y')) and
      	(edMax_Adjustments.Enabled=False) then
      begin
        if MessageDlg('Do you wish to change the Max Adjustment amount?',
          mtConfirmation, [mbYes, mbNo], 0) = mrYes then
        begin
          setEditToNormal(edMax_Adjustments);
          edMax_Adjustments.SetFocus;
          exit;
        end;
      end;
    end;

    ws:= copy(edMarital_Status.Text,1,1);
    case ws[1] of
     'M','S','X','D', 'C':
    else
    begin
      edMarital_Status.setfocus;
      WagelossMainForm.ShowInfoLine2('*Valid values for Marital Status are M C S X D');
      exit;
    end;
    end;

    ws:= copy(edSpouse_Working.Text,1,1);
    case ws[1] of
    'Y','N':
    else
      edSpouse_Working.setFocus;
      WagelossMainForm.ShowInfoLine2('*Valid values for Spouse Working are Y N');
    end;

    ws:= copy(edEI_Exempt.Text,1,1);
    case ws[1] of
     'Y','N':
    else
    begin
      edEI_Exempt.setfocus;
      WagelossMainForm.ShowInfoLine2('*Valid values for EI Exempt are Y N');
      exit;
    end;
    end;

    ws:= copy(edCPP_Exempt.Text,1,1);
    case ws[1] of
     'Y','N':
    else
    begin
      edCPP_Exempt.setfocus;
      WagelossMainForm.ShowInfoLine2('*Valid values for CPP Exempt are Y N');
      exit;
    end;
    end;

    ws:= copy(edTax_Exempt.Text,1,1);
    case ws[1] of
     'Y','N':
    else
    begin
      edTax_Exempt.setfocus;
      WagelossMainForm.ShowInfoLine2('*Valid values for Income Tax Exempt are Y N');
      exit;
    end;
    end;

    // Summary checking
    if ( textAsCurrency( ednc_104_Wk_Clmt_p_Contrib ) >
         ( 5 - textAsCurrency( ednc_104_Wk_WCB_p_Contrib_Red ))  ) then
    begin
      messagebeep(0);
      WagelossMainForm.ShowInfoLine2('*Client contribution cannot WCB Contribution');
      ednc_104_Wk_WCB_p_Contrib_Red.setfocus;
      exit;
    end;


//    ws:= copy(edDeemed_Earnings.Text,1,1);
//    case ws[1] of
//     'Y','N':
//    else
//    begin
//      edDeemed_Earnings.setfocus;
//      WagelossMainForm.ShowInfoLine2('*Valid values for Deemed Earnings are Y N');
//      exit;
//    end;
//    end;

  { fill in dataBenCalc record }

    ClearNCCLAIM( dataBenCalc );
    dataBenCalc.Claim_No:= edClaim_No.text;
    dataBenCalc.Clmnts_1st_Name:= edClmnts_1st_Name.text;
    dataBenCalc.Clmnts_Surname:= edClmnts_Surname.text;
    dataBenCalc.Clmnts_Add_No_1:= edClmnts_Add_No_1.text;
    dataBenCalc.Clmnts_Add_No_2:= edClmnts_Add_No_2.text;
    dataBenCalc.Clmnts_Post_Code:= edClmnts_Post_Code.text;
    dataBenCalc.Wkly_Sal_A:= textAsCurrency(edWkly_Sal_A);
    dataBenCalc.Days_Worked_per_Week:= textAsCurrency(edDays_Worked_per_Week);
    dataBenCalc.Tax_Year:= textAsInteger(edTax_Year );
    dataBenCalc.Marital_Status:= edMarital_Status.text;
    dataBenCalc.Spouse_Working:= edSpouse_Working.text;
    dataBenCalc.EI_Exempt:= edEI_Exempt.text;
    dataBenCalc.No_Of_Dependnts:= textAsInteger(edNo_Of_Dependnts);
    dataBenCalc.No_Infirm:= textAsInteger(edNo_Infirm);
    dataBenCalc.Collateral_Ben_Tax:= textAsCurrency(edCollateral_Ben_Tax);
    dataBenCalc.Collateral_Ben_Non_Tax:= textAsCurrency(edCollateral_Ben_Non_Tax);
    dataBenCalc.Post_Injury_Earn:= textAsCurrency(edPost_Injury_Earn);
    dataBenCalc.nc_104_Wk_WCB_p_Contrib_Red:= textAsCurrency( ednc_104_Wk_WCB_p_Contrib_Red );
    dataBenCalc.nc_104_Wk_Clmt_p_Contrib:=textAsCurrency( ednc_104_Wk_Clmt_p_Contrib );
// New fields for 2000 policy changes
    dataBenCalc.Self_Employed:=edSelf_Employed.text;
    dataBenCalc.Recurrence:=edRecurrence.text;
    dataBenCalc.CPP_Exempt:=edCPP_Exempt.text;
    dataBenCalc.Tax_Exempt:=edTax_Exempt.text;
    dataBenCalc.Child_Care_Exp:=textAsCurrency(edChild_Care_Exp);
    dataBenCalc.Spousal_Support:=textAsCurrency(edSpousal_Support);
    dataBenCalc.Child_Support:=textAsCurrency(edChild_Support);
    dataBenCalc.Max_Adjustment:=textAsCurrency(edMax_Adjustments);
    dataBenCalc.Accident_Date:=textAsDate(edAccident_Date);
    dataBenCalc.RecurrenceDate:=textAsDate(edRecurrenceDate);
  try
    copyNCCLAIM( dataBenCalc, CalcFullClaim);
    copyNCCLAIM( dataBenCalc, CalcPartClaim);
    RecalcBen;
    if CalcFullClaim.ReturnCode Then
       Begin
       fillInForm;
       lblTaxCode.caption:= CalcFullClaim.Tax_Code;
       lblTaxCodeAmt.caption:= format('%.2n',[ CalcFullClaim.Tax_Exemption ] );
    // fill dataBenCalc so ben calc report works...
       copyNCCLAIM( CalcPartClaim, dataBenCalc );
       end;
  except
     ;
  end;

  result:=true;
  ResetInfoLine2;
end;

(******************************************************************************)
(*                                                                            *)
(*   Validate Wkly_Sal_A                                                      *)
(*                                                                            *)
(******************************************************************************)
procedure TBenefitsCalculatorForm.edWkly_Sal_AExit(Sender: TObject);
begin
  ClearCalc;
  edWkly_Sal_A.text:=format('%.2n',[ textAsCurrency(edWkly_Sal_A) ] );
  ResetInfoLine2;
end;

(******************************************************************************)
(*                                                                            *)
(*  Validate Days_Worked_Per_Week                                             *)
(*                                                                            *)
(******************************************************************************)
procedure TBenefitsCalculatorForm.edDays_Worked_per_WeekExit(
  Sender: TObject);
var
  f:currency;
begin
  ClearCalc;
  if not validateAsCurrency( edDays_Worked_per_Week ) then
  begin
    messagebeep(0);
    WagelossMainForm.ShowInfoLine2('*invalid DAYS WORKED/WEEK');
    edDays_Worked_per_Week.setfocus;
    globalEditError:=true;
    exit;
  end;
  f:=textAsCurrency(edDays_Worked_per_Week);
  if ( f < 0.5 ) or ( f > 7.0 ) then
  begin
    messagebeep(0);
    WagelossMainForm.ShowInfoLine2('*DAYS WORKED/WEEK must be between 0.5 and 7');
    edDays_Worked_per_Week.setfocus;
    globalEditError:=true;
    exit;
  end;
  edDays_Worked_per_Week.text:=format('%.2n',[ textAsCurrency(edDays_Worked_per_Week) ] );
  ResetInfoLine2;
end;

(******************************************************************************)
(*                                                                            *)
(*  Validate Tax_Year                                                         *)
(*                                                                            *)
(******************************************************************************)
//
// Modified by D. Madill
// Date: March 5, 2003
// Purpose: modified to ensure that the field level check is being performed
// on the screen value
//
procedure TBenefitsCalculatorForm.edTax_YearExit(Sender: TObject);
var
  isFound: boolean;
  iii, testTax_Year: integer;
  testMax_Adjustments: currency;
  testAccidentDate: Tdatetime;
  testRecurrenceDate: Tdatetime;
begin
  ClearCalc;
  if Length(TrimRight(TrimLeft(edTax_Year.text))) = 0 then
     edTax_Year.text := FormatDateTime('yyyy',date);

  isFound:=false;

  // Get values from TAX CODE TABLE

  TestTax_Year := TextAsInteger(edTax_Year);
  if Length(TrimRight(TrimLeft(edAccident_Date.text))) > 0 then
     Begin
     TestAccidentDate := StrToDate(edAccident_Date.text);
     End
  else
     Begin
     WagelossMainForm.ShowInfoLine2('*Please enter a valid Accident Date');
     edAccident_Date.SetFocus;
     globalEditError:=true;
     exit;
     End;

  If Length( edRecurrenceDate.text ) > 0 then
     TestRecurrenceDate := StrToDate( edRecurrenceDate.text )
  else
     TestRecurrenceDate := 0;

  SetTaxYear(testAccidentDate, testRecurrenceDate, testTax_Year);

  for iii := low(arrayNCTAXRAT) to high(arrayNCTAXRAT) do
     begin
     //if (arrayNCCODTAX[iii].Tax_Year = GetTaxYear) and
     if (arrayNCTAXRAT[iii].Tax_Year = TestTax_Year) and
        (arrayNCTAXRAT[iii].Tax_Year > 1991)         then
        begin
        isFound:=true;
        break;
        end
     end;


  // check the value of the Internal Taxyear to that contained on the
  // screen. They should match. Otherwise a failure has occured within
  // the SetTaxYear routine

  if TestTax_Year <> GetTaxYear then
     Begin
     isFound := False;
     End;

  if not isFound then
     begin
     messagebeep(0);
     WagelossMainForm.ShowInfoLine2('*Please enter a valid tax year');
     edTax_Year.setfocus;
     globalEditError:=true;
     exit;
     end;

  testMax_Adjustments:=textAsCurrency(edMax_Adjustments);
  if testMax_Adjustments > 0 then
     begin
     // Get values from MAX table
     for iii := low(arrayNCANNMAX) to high(arrayNCANNMAX) do
        begin
        if (arrayNCANNMAX[iii].Accident_Year > 1900) and
           (arrayNCANNMAX[iii].Accident_Year = testTax_Year) and
           (arrayNCANNMAX[iii].Tax_Year = testTax_Year) then
           begin
           break;
           end;
        end;

     if ((testMax_Adjustments - arrayNCANNMAX[iii].Annual_Maximum) > 0.005) then
        begin
        messagebeep(0);
        WagelossMainForm.ShowInfoLine2('*Max Adj amount greater than current yr. Max: $'+
             format('%.2n', [arrayNCANNMAX[iii].Annual_Maximum]) );
        edMax_Adjustments.setfocus;
        globalEditError:=true;
        exit;
        end;

     end;
  //
  //validate Accident Date if entered
  //
  if (UPPERCASE(edRecurrence.text) <> 'Y') then
     iii := testTax_Year - year(textAsDate(edAccident_Date))
  else
     iii := testTax_Year - year(textAsDate(edRecurrenceDate));

  if ( iii  < 0) then
     begin
     messagebeep(0);
     if  (UPPERCASE(edRecurrence.text) <> 'Y') then
        WagelossMainForm.ShowInfoLine2('*Tax year must be on or after year of the accident')
     else
        WagelossMainForm.ShowInfoLine2('*Tax year must be on or after year of the recurrence');

    edTax_Year.setfocus;
    globalEditError:=true;
    exit;
    end;

  //if ( iii = 1) and (UPPERCASE(edRecurrence.text) <> 'Y') then

  if (iii = 1) then
     begin
     messagebeep(0);
     if  (UPPERCASE(edRecurrence.text) <> 'Y') then
        WagelossMainForm.ShowInfoLine2('*Tax year cannot be the year following the accident')
     else
        WagelossMainForm.ShowInfoLine2('*Tax year cannot be the year following the recurrence');
    edTax_Year.setfocus;
    globalEditError:=true;
    exit;
    end;

  ResetInfoLine2;
end;

(******************************************************************************)
(*                                                                            *)
(*  Validate Marital_Status                                                   *)
(*                                                                            *)
(******************************************************************************)
procedure TBenefitsCalculatorForm.edMarital_StatusExit(Sender: TObject);
begin
  ClearCalc;
  edMarital_Status.text:=uppercase(edMarital_Status.text);
  if edMarital_Status.text ='' then
  begin
    edMarital_Status.text:='S';
    edSpouse_Working.text:='N';
  end;

  if ( edMarital_Status.text ='M' ) or ( edMarital_Status.text ='C' )then
  begin
    if edSpouse_Working.text = '' then edSpouse_Working.text:='Y';
  end;

  if ( edMarital_Status.text ='S' ) or
     ( edMarital_Status.text ='D' ) or
     ( edMarital_Status.text ='X' ) then
  begin
    edSpouse_Working.text:='N';
    setEditToRead(edSpouse_Working);
    selectNext(Sender as tWinControl, true, true );
  end
  else
  begin
    setEditToNormal(edSpouse_Working);
    selectNext(Sender as tWinControl, true, true );
  end;
  ResetInfoLine2;
end;

(******************************************************************************)
(*                                                                            *)
(*  Validate Spouse_Working                                                   *)
(*                                                                            *)
(******************************************************************************)
procedure TBenefitsCalculatorForm.edSpouse_WorkingExit(Sender: TObject);
begin
  ClearCalc;
  edSpouse_Working.text := uppercase(edSpouse_Working.text);

  if edSpouse_Working.text ='' then
  begin
    edSpouse_Working.text:='N';
  end;

  if (( edMarital_Status.text ='S' ) or
      ( edMarital_Status.text ='D' ) or
      ( edMarital_Status.text ='X' ) ) and
      ( edSpouse_Working.text <>'N' ) then
  begin
    edSpouse_Working.text:='N';
    messagebeep(0);
    WagelossMainForm.ShowInfoLine2('*Spouse Working changed to "N" for  Marital Status S,D,X');
    edSpouse_Working.setfocus;
    globalEditError:=true;
    exit;
  end;
  ResetInfoLine2;
end;

(******************************************************************************)
(*                                                                            *)
(*  Validate EI_Exempt                                                        *)
(*                                                                            *)
(******************************************************************************)
procedure TBenefitsCalculatorForm.edEI_ExemptExit(Sender: TObject);
begin
  ClearCalc;
  if edEI_Exempt.text='' then
  begin
    if edSelf_Employed.text='Y' then
      edEI_Exempt.text:='Y'
    else
      edEI_Exempt.text:='N';
  end;
  edEI_Exempt.text := uppercase(edEI_Exempt.text);
  ResetInfoLine2;
end;

(******************************************************************************)
(*                                                                            *)
(*  Validate No_Of_Dependents                                                 *)
(*                                                                            *)
(******************************************************************************)
procedure TBenefitsCalculatorForm.edNo_Of_DependntsExit(Sender: TObject);
var
  i: integer;
begin
  ClearCalc;
  if edNo_Of_Dependnts.text='' then edNo_Of_Dependnts.text:='0';
  if not validateAsInteger( edNo_Of_Dependnts ) then
  begin
    messagebeep(0);
    WagelossMainForm.ShowInfoLine2('*Invalid No. Of Dependents');
    edNo_Of_Dependnts.setfocus;
    globalEditError:=true;
    exit;
  end;
  i:=textAsInteger(edNo_Of_Dependnts);
  if ( i < 0 ) or ( i > 99 ) then
  begin
    messagebeep(0);
    WagelossMainForm.ShowInfoLine2('*No Of Dependents must be between 0 and 99');
    edNo_Of_Dependnts.setfocus;
    globalEditError:=true;
    exit;
  end;
  edNo_Of_Dependnts.text:=format('%d',[ textAsInteger(edNo_Of_Dependnts) ] );
  ResetInfoLine2;
end;

(******************************************************************************)
(*                                                                            *)
(*  Validate No_Infirm                                                        *)
(*                                                                            *)
(******************************************************************************)
procedure TBenefitsCalculatorForm.edNo_InfirmExit(Sender: TObject);
var
  i: integer;
begin
  ClearCalc;
  if edNo_Infirm.text='' then edNo_Infirm.text:='0';
  if not validateAsInteger( edNo_Infirm ) then
  begin
    messagebeep(0);
    WagelossMainForm.ShowInfoLine2('*Invalid No. Of Infirm Dependents');
    edNo_Infirm.setfocus;
    globalEditError:=true;
    exit;
  end;
  i:=textAsInteger(edNo_Infirm);
  if ( i < 0 ) or ( i > 99 ) then
  begin
    messagebeep(0);
    WagelossMainForm.ShowInfoLine2('*No Of Infirm Dependents must be between 0 and 99');
    edNo_Infirm.setfocus;
    globalEditError:=true;
    exit;
  end;
  edNo_Infirm.text:=format('%d',[ textAsInteger(edNo_Infirm) ] );
  ResetInfoLine2;
end;

(******************************************************************************)
(*                                                                            *)
(*  Validate Collateral_Ben_Tax                                               *)
(*                                                                            *)
(******************************************************************************)
procedure TBenefitsCalculatorForm.edCollateral_Ben_TaxExit(
  Sender: TObject);
begin
  ClearCalc;
  if edCollateral_Ben_Tax.text='' then edCollateral_Ben_Tax.text:='0';
  edCollateral_Ben_Tax.text:=format('%.2n',[ textAsCurrency(edCollateral_Ben_Tax) ] );
  ResetInfoLine2;
end;

(******************************************************************************)
(*                                                                            *)
(*  Validate Collateral_Ben_Non_Tax                                           *)
(*                                                                            *)
(******************************************************************************)
procedure TBenefitsCalculatorForm.edCollateral_Ben_Non_TaxExit(
  Sender: TObject);
begin
  ClearCalc;
  if edCollateral_Ben_Non_Tax.text='' then edCollateral_Ben_Non_Tax.text:='0';
  edCollateral_Ben_Non_Tax.text:=format('%.2n',[ textAsCurrency(edCollateral_Ben_Non_Tax) ] );
  ResetInfoLine2;
end;

(******************************************************************************)
(*                                                                            *)
(*  Validate Post_Injury_Earn                                                 *)
(*                                                                            *)
(******************************************************************************)
procedure TBenefitsCalculatorForm.edPost_Injury_EarnExit(Sender: TObject);
begin
  ClearCalc;
  if edPost_Injury_Earn.text='' then edPost_Injury_Earn.text:='0';
  edPost_Injury_Earn.text:=format('%.2n',[ textAsCurrency(edPost_Injury_Earn) ] );
  ResetInfoLine2;
end;

//(******************************************************************************)
//(*                                                                            *)
//(*  Validate Deemed_Earnings flag                                             *)
//(*                                                                            *)
//(******************************************************************************)
//procedure TBenefitsCalculatorForm.edDeemed_EarningsExit(Sender: TObject);
//begin
//  ClearCalc;
//  if edDeemed_Earnings.text='' then edDeemed_Earnings.text:='N';
//  edDeemed_Earnings.text := uppercase(edDeemed_Earnings.text);
//  ResetInfoLine2;
//end;

(******************************************************************************)
(*                                                                            *)
(*  Key press edit for Marital_Status                                         *)
(*                                                                            *)
(******************************************************************************)
procedure TBenefitsCalculatorForm.edMarital_StatusKeyPress(Sender: TObject;
  var Key: Char);
begin
  case Key of
  #0..#31,'m','M','s','S','x','X','d','D','c','C':
  else
    Key:=#0;
    WagelossMainForm.ShowInfoLine2('*Valid values for Marital Status are M C S X D');
  end;
end;

(******************************************************************************)
(*                                                                            *)
(*  Ket press edit for EI_Exempt                                              *)
(*                                                                            *)
(******************************************************************************)
procedure TBenefitsCalculatorForm.edEI_ExemptKeyPress(Sender: TObject;
  var Key: Char);
begin
  case Key of
  #0..#31,'y','Y','n','N':
  else
    Key:=#0;
    WagelossMainForm.ShowInfoLine2('*Valid values for EI Exempt are Y N');
  end;
end;

//(******************************************************************************)
//(*                                                                            *)
//(*  Key press edit for Deemed_Earnings                                        *)
//(*                                                                            *)
//(******************************************************************************)
//procedure TBenefitsCalculatorForm.edDeemed_EarningsKeyPress(
//  Sender: TObject; var Key: Char);
//begin
//  case Key of
//  #0..#31,'y','Y','n','N':
//  else
//    Key:=#0;
//    WagelossMainForm.ShowInfoLine2('*Valid values for Deemed are Y N');
//  end;
//end;

(******************************************************************************)
(*                                                                            *)
(*  Key press edit for Spouse_Working                                         *)
(*                                                                            *)
(******************************************************************************)
procedure TBenefitsCalculatorForm.edSpouse_WorkingKeyPress(Sender: TObject;
  var Key: Char);
begin
  case Key of
  #0..#31,'y','Y','n','N':
  else
    Key:=#0;
    WagelossMainForm.ShowInfoLine2('*Valid values for Spouse Working are Y N');
  end;
end;

(******************************************************************************)
(*                                                                            *)
(*  Print Benefit Calculation Report                                          *)
(*                                                                            *)
(******************************************************************************)
procedure TBenefitsCalculatorForm.PrintBenCalcReport;
var
  MyPreview: TQRCustomPreviewForm;
  MyReport: TPrintBenCalForm;
begin
  screen.cursor:=crHourGlass;
  try
    MyPreview := TQRCustomPreviewForm.create(application);

    //MyReport := TPrintBenCalForm.CreateExtended('BenefitsCalculatorForm',MyPreview);
//    MyReport := TPrintBenCalForm.Create(MyPreview);
    MyReport := TPrintBenCalForm.Create(Self);
    //MyReport.fParentForm:='BenefitsCalculatorForm';
    MyReport.ReportType := 1;
    copyNCCLAIM( CalcFullClaim, MyReport.CalcFullClaim);
    copyNCCLAIM( CalcPartClaim, MyReport.CalcPartClaim);

    MyPreview.ParentQuickReportForm:=MyReport;
    MyPreview.ParentQuickReport:=MyReport.QRBenCal;
    MyPreview.caption:='Benefit Calculation Report';
    screen.cursor:=crDefault;
    try
      MyReport.QRBenCal.OnPreview := MyPreview.CustomPreview;
      MyReport.QRBenCal.Preview;
      //MyReport.QRBenCal.OnPreview := nil;
    finally
      screen.cursor:=crDefault;
      //MyReport.release;
    end;
  finally
  screen.cursor:=crDefault;
  end;
end;

(******************************************************************************)
(*                                                                            *)
(*  Clear calculation result window                                           *)
(*                                                                            *)
(******************************************************************************)
procedure TBenefitsCalculatorForm.ClearCalc;
begin
     ;
end;

(******************************************************************************)
(*                                                                            *)
(*  Reset all Edit fields                                                     *)
(*                                                                            *)
(******************************************************************************)
procedure TBenefitsCalculatorForm.resetCalc;
begin
    ResetInfoLine2;
    edClaim_No.clear;
    edClmnts_1st_Name.clear;
    edClmnts_Surname.clear;
    edClmnts_Add_No_1.clear;
    edClmnts_Add_No_2.clear;
    edClmnts_Post_Code.clear;
    edWkly_Sal_A.clear;
    edDays_Worked_per_Week.clear;
    edTax_Year.clear;

// New fields for 2000 policy changes
    edSelf_Employed.clear;
    edRecurrence.clear;
    edCPP_Exempt.clear;
    edTax_Exempt.clear;
    edChild_Care_Exp.clear;
    edSpousal_Support.clear;
    edChild_Support.clear;
    edMax_Adjustments.clear;
    setEditToRead(edMax_Adjustments);
    edAccident_Date.clear;

    edMarital_Status.clear;
    edEI_Exempt.clear;
    edNo_Of_Dependnts.clear;
    edNo_Infirm.clear;
    edCollateral_Ben_Tax.clear;
    edCollateral_Ben_Non_Tax.clear;
    edPost_Injury_Earn.clear;
//    edDeemed_Earnings.clear;
    setEditToNormal(edSpouse_Working);
    edSpouse_Working.clear;
    lblTaxCode.caption:='';
    lblTaxCodeAmt.caption:='';

    ClearNCCLAIM( CalcFullClaim );
    ClearNCCLAIM( CalcPartClaim );
    fillInForm;

end;

(******************************************************************************)
(*                                                                            *)
(*  Key press edit for Postal Code                                            *)
(*                                                                            *)
(******************************************************************************)
procedure TBenefitsCalculatorForm.edClmnts_Post_CodeKeyPress(
  Sender: TObject; var Key: Char);
var
  l: integer;
begin
  l := length(edClmnts_Post_Code.text) mod 2;
  //if length(edClmnts_Post_Code.text) = 0 then l := -1;
  case Key of
  #0..#31: begin
      end;
  'a'..'z','A'..'Z': begin
      if l <> 0 then begin Key:=#0; end;
      end;
  '0'..'9': begin
      if l <> 1 then begin Key:=#0; end;
    end;
  else
    Key:=#0;
    WagelossMainForm.ShowInfoLine2('*Postal Code must be A#A#A#');
  end;
end;

(******************************************************************************)
(*                                                                            *)
(*  Validate Postal Code                                                      *)
(*                                                                            *)
(******************************************************************************)
procedure TBenefitsCalculatorForm.edClmnts_Post_CodeExit(Sender: TObject);
var
  ws: string;
begin
  ws:=edClmnts_Post_Code.text;
  ws:= uppercase(ws);
  edClmnts_Post_Code.text:=ws;
  if ( length(ws) > 0 ) and ( length(ws) <> 6 ) then
  begin
    messagebeep(0);
    WagelossMainForm.ShowInfoLine2('*Invalid Postal Code');
    edClmnts_Post_Code.setfocus;
    globalEditError:=true;
    exit;
  end;
  ResetInfoLine2;
end;

(******************************************************************************)
(*                                                                            *)
(*  Form Create                                                               *)
(*                                                                            *)
(******************************************************************************)
procedure TBenefitsCalculatorForm.FormCreate(Sender: TObject);
begin
  resetCalc;
  ResetInfoLine2;
  setEditToRead(edMax_Adjustments);
  SetOldRecurrenceInd('N');
end;

(******************************************************************************)
(*                                                                            *)
(*  Reset info line to default value                                          *)
(*                                                                            *)
(******************************************************************************)
procedure TBenefitsCalculatorForm.ResetInfoLine2;
begin
  WagelossMainForm.ShowInfoLine2('F3 - Clear  F7 - Exit  F8 - Print Report  F9 - Calculate');
end;

(******************************************************************************)
(*                                                                            *)
(*  Recalculate Benefits                                                      *)
(*                                                                            *)
(******************************************************************************)
procedure TBenefitsCalculatorForm.RecalcBen;
var
  savePost_Injury_Earn: currency;
begin
  { call ben calc }
  copyNCCLAIM( CalcFullClaim, CalcPartClaim);
  savePost_Injury_Earn:=CalcFullClaim.Post_Injury_Earn;
  CalcFullClaim.Post_Injury_Earn := 0.0;
  Calc_Ben( CalcFullClaim, fWorking);
  if CalcFullClaim.ReturnCode Then
     Begin
     Calc_Ben( CalcPartClaim, fWorking);
     if CalcFullClaim.ReturnCode Then
        Begin
        CalcFullClaim.Post_Injury_Earn := savePost_Injury_Earn;
        End;
     End;
  if Not CalcFullClaim.ReturnCode Then
     Begin
     WagelossMainForm.ShowInfoLine2(CalcFullClaim.ReturnMessage);
     End;
end;

(******************************************************************************)
(*                                                                            *)
(*  Fill in form from claim record(s)                                         *)
(*                                                                            *)
(******************************************************************************)
procedure TBenefitsCalculatorForm.fillInForm;
begin
  with CalcFullClaim do
  begin
    lblInc_Tax_Fed.caption:=format('%.2n', [ Inc_Tax_Fed ] );
    lblInc_Tax_Man.caption:=format('%.2n', [ Inc_Tax_Man ] );
    lblCPP_Prem.caption:=format('%.2n', [ CPP_Prem ] );
    lblEI_Prem.caption:=format('%.2n', [ EI_Prem ] );
    lblTotal_Deds.caption:=format('%.2n', [ Total_Deds ] );
    lblWkly_Total_Deds.caption:=format('%.2n', [ PdoxRound(Total_Deds / 52.0, 2 ) ] );
    edCollateral_Ben_Tax.text:=format('%.2n', [ Collateral_Ben_Tax ] );
    edCollateral_Ben_Non_Tax.text:=format('%.2n', [ Collateral_Ben_Non_Tax ] );
    edPost_Injury_Earn.text:=format('%.2n', [ Post_Injury_Earn ] );
    lblWkly_Sal_A.caption:=format('%.2n', [ Wkly_Sal_A ] );
    lblWeekly_Net.caption:=format('%.2n', [ Weekly_Net ] );
    lbCalc90p_Wkly_Net_A.caption:=format('%.2n',
      [ PdoxRound( ( Weekly_Net_A * 0.90 ) , 2)  ] );
    lblAnnual_Gross.caption:=format('%.2n', [ Annual_Gross ] );
    lblAnnual_Net.caption:=format('%.2n', [ Annual_Net ] );
    lblWeekly_90.caption:=format('%.2n', [ Weekly_90 ] );
    lblCalcTaxSheltering.caption:=format('%.2n',
      [ pdoxround( ( Weekly_90 - Weekly_90_S ) , 2) ] );
    lblWeekly_90_S.caption:=format('%.2n', [ Weekly_90_S ] );
    if ( Days_Worked_per_Week <> 0 ) then
      lblDailyCompensationRate.caption:=format('%.2n', [ Weekly_90_S / Days_Worked_per_Week] )
    else
      lblDailyCompensationRate.caption:='';
    lblAnnual_90.caption:=format('%.2n', [ Annual_90 ] );
    lblAnnual_90_S.caption:=format('%.2n', [ Annual_90_S ] );
    lblWeekly_80.caption:=format('%.2n', [ Weekly_80 ] );
    lblWeekly_80_S.caption:=format('%.2n', [ Weekly_80_S ] );
    lblWkly_Clmt_Anty_Con_Amt.caption:=format('%.2n', [ Wkly_Clmt_Anty_Con_Amt ] );
    lblAnnual_80.caption:=format('%.2n', [ Annual_80 ] );
    lblAnnual_80_S.caption:=format('%.2n', [ Annual_80_S ] );
    lblCalcWkly80p_Net_Clmt_Contr.caption:=format('%.2n',
      [ pdoxround( ( Weekly_80  - Wkly_Clmt_Anty_Con_Amt), 2) ] );
    lblCalcAnnual80p_Net_Clmt_Contr.caption:=format('%.2n',
      [ pdoxround( ( Annual_80 - ( 52* Wkly_Clmt_Anty_Con_Amt ) ), 2) ] );
    lblCalcWkly_p_WCB_Contr.caption:=format('%.2n',
      [ pdoxround( ( (((5 - nc_104_Wk_WCB_p_Contrib_Red)*Weekly_80)/100.00) ), 2) ] );
    lblnc_104_Wk_Clmt_p_Contrib.caption:=format('%.2n', [ nc_104_Wk_Clmt_p_Contrib ] );
    lblCalcnc_104_Wk_WCB_p_Contrib_Red.caption:=format('%.2n',
      [ pdoxround( ( 5 - nc_104_Wk_WCB_p_Contrib_Red ), 2) ] );
  if ( CalcFullClaim.Post_Injury_Earn = 0.0 ) then
  begin
      lblPartPre_Weekly_Net.caption:='';
      lblPartPost_Injury_Earn_Net.caption:='';
      lblPartCalcNetLossEarnings.caption:='';
      lblPartWeekly_90.caption:='';
      lblPartCalcTaxSheltering.caption:='';
      lblPartWeekly_90_S.caption:='';
      lblPartDailyCompensationRate.caption:='';
      lblPartWeekly_80.caption:='';
      lblPartWeekly_80_S.caption:='';
      lblPartWkly_Clmt_Anty_Con_Amt.caption:='';
      lblPartCalcWkly80p_Net_Clmt_Contr.caption:='';
      lblPartCalcWkly_p_WCB_Contr.caption:='';
      lblPart_nc_104_Wk_Clmt_p_Contrib.caption:='';
      lblPart_Calcnc_104_Wk_WCB_p_Contrib_Red.caption:='';
  end
  else
  begin
    with CalcPartClaim do
    begin
      lblPartPre_Weekly_Net.caption:=format('%.2n', [ CalcFullClaim.Weekly_Net ] );
      lblPartPost_Injury_Earn_Net.caption:=format('%.2n', [ Post_Injury_Earn_Net ] );
      lblPartCalcNetLossEarnings.caption:=format('%.2n', [ Weekly_Net ] );
      lblPartWeekly_90.caption:=format('%.2n', [ Weekly_90 ] );
      lblPartCalcTaxSheltering.caption:=format('%.2n',
        [ pdoxround( ( Weekly_90 - Weekly_90_S ) , 2) ] );
      lblPartWeekly_90_S.caption:=format('%.2n', [ Weekly_90_S ] );
      if ( Days_Worked_per_Week <> 0 ) then
        lblPartDailyCompensationRate.caption:=format('%.2n', [ Weekly_90_S / Days_Worked_per_Week] )
      else
        lblPartDailyCompensationRate.caption:='';
      lblPartWeekly_80.caption:=format('%.2n', [ Weekly_80 ] );
      lblPartWeekly_80_S.caption:=format('%.2n', [ Weekly_80_S ] );
      lblPartWkly_Clmt_Anty_Con_Amt.caption:=format('%.2n',
        [ pdoxround( ((nc_104_Wk_Clmt_p_Contrib*Weekly_80)/100.00), 2)
       ] );
      lblPartCalcWkly80p_Net_Clmt_Contr.caption:=format('%.2n',
        [ pdoxround( ( Weekly_80  - Wkly_Clmt_Anty_Con_Amt), 2) ] );
      lblPartCalcWkly_p_WCB_Contr.caption:=format('%.2n',
        [ pdoxround( ( (((5 - nc_104_Wk_WCB_p_Contrib_Red)*Weekly_80)/100.00) ), 2) ] );
      lblPart_nc_104_Wk_Clmt_p_Contrib.caption:=lblnc_104_Wk_Clmt_p_Contrib.caption;
      lblPart_Calcnc_104_Wk_WCB_p_Contrib_Red.caption:=lblCalcnc_104_Wk_WCB_p_Contrib_Red.caption;
    end;
  end;

  end;
end;

(******************************************************************************)
(*                                                                            *)
(*   104 Week WCB % Contribution Reduction Exit Processing                    *)
(*                                                                            *)
(******************************************************************************)
procedure TBenefitsCalculatorForm.ednc_104_Wk_WCB_p_Contrib_RedExit(
  Sender: TObject);
var
  f: currency;
begin
  if ednc_104_Wk_WCB_p_Contrib_Red.text='' then ednc_104_Wk_WCB_p_Contrib_Red.text:='0';
  if not validateAsCurrency( ednc_104_Wk_WCB_p_Contrib_Red ) then
  begin
    messagebeep(0);
    WagelossMainForm.ShowInfoLine2('*Invalid WCB % Annuity Reduction');
    ednc_104_Wk_WCB_p_Contrib_Red.setfocus;
    globalEditError:=true;
    exit;
  end;

  // check range 0 to 5%
  f:=textAsCurrency(ednc_104_Wk_WCB_p_Contrib_Red);
  if ( f < 0.0 ) or ( f > 5.0 ) then
  begin
    messagebeep(0);
    WagelossMainForm.ShowInfoLine2('*WCB % Annuity Reduction must be between 0 and 5.0');
    ednc_104_Wk_WCB_p_Contrib_Red.setfocus;
    globalEditError:=true;
    exit;
  end;

    // Check sum of claimant and WCB reduction  can not exceed 5%
  if not validateAsCurrency( ednc_104_Wk_Clmt_p_Contrib ) then
  begin
    messagebeep(0);
    WagelossMainForm.ShowInfoLine2('*Invalid Clmt % Annuity Contribution');
    ednc_104_Wk_Clmt_p_Contrib.setfocus;
    globalEditError:=true;
    exit;
  end;
  if not validateAsCurrency( ednc_104_Wk_WCB_p_Contrib_Red ) then
  begin
    messagebeep(0);
    WagelossMainForm.ShowInfoLine2('*Invalid WCB % Annuity Reduction');
    ednc_104_Wk_WCB_p_Contrib_Red.setfocus;
    globalEditError:=true;
    exit;
  end;
    if ( textAsCurrency( ednc_104_Wk_Clmt_p_Contrib ) +
       textAsCurrency( ednc_104_Wk_WCB_p_Contrib_Red ) > 5 ) then
  begin
    messagebeep(0);
    WagelossMainForm.ShowInfoLine2('*Total contribution cannot exceed 5 %');
    ednc_104_Wk_Clmt_p_Contrib.setfocus;
    globalEditError:=true;
    exit;
  end;


  ednc_104_Wk_WCB_p_Contrib_Red.text:=format('%.2n',[ textAsCurrency(ednc_104_Wk_WCB_p_Contrib_Red) ] );
  ResetInfoLine2;
end;

(******************************************************************************)
(*                                                                            *)
(*  104 Week Claimant % Contribution Exit Processing                          *)
(*                                                                            *)
(******************************************************************************)
procedure TBenefitsCalculatorForm.ednc_104_Wk_Clmt_p_ContribExit(
  Sender: TObject);
var
  f: currency;
begin
  if ednc_104_Wk_Clmt_p_Contrib.text='' then ednc_104_Wk_Clmt_p_Contrib.text:='0';
  if not validateAsCurrency( ednc_104_Wk_Clmt_p_Contrib ) then
  begin
    messagebeep(0);
    WagelossMainForm.ShowInfoLine2('*Invalid Clmt % Annuity Contribution');
    ednc_104_Wk_Clmt_p_Contrib.setfocus;
    globalEditError:=true;
    exit;
  end;
  // check range 0 to 5%
  f:=textAsCurrency(ednc_104_Wk_Clmt_p_Contrib);
  if ( f < 0.0 ) or ( f > 5.0 ) then
  begin
    messagebeep(0);
    WagelossMainForm.ShowInfoLine2('*Clmt % Annuity Contribution must be between 0 and 5.0');
    ednc_104_Wk_Clmt_p_Contrib.setfocus;
    globalEditError:=true;
    exit;
  end;

    // Check sum of claimant and WCB reduction  can not exceed 5%
  if not validateAsCurrency( ednc_104_Wk_Clmt_p_Contrib ) then
  begin
    messagebeep(0);
    WagelossMainForm.ShowInfoLine2('*Invalid Clmt % Annuity Contribution');
    ednc_104_Wk_Clmt_p_Contrib.setfocus;
    globalEditError:=true;
    exit;
  end;
  if not validateAsCurrency( ednc_104_Wk_WCB_p_Contrib_Red ) then
  begin
    messagebeep(0);
    WagelossMainForm.ShowInfoLine2('*Invalid WCB % Annuity Reduction');
    ednc_104_Wk_WCB_p_Contrib_Red.setfocus;
    globalEditError:=true;
    exit;
  end;
    if ( textAsCurrency( ednc_104_Wk_Clmt_p_Contrib ) +
       textAsCurrency( ednc_104_Wk_WCB_p_Contrib_Red ) > 5 ) then
  begin
    messagebeep(0);
    WagelossMainForm.ShowInfoLine2('*Total contribution cannot exceed 5 %');
    ednc_104_Wk_Clmt_p_Contrib.setfocus;
    globalEditError:=true;
    exit;
  end;


  ednc_104_Wk_Clmt_p_Contrib.text:=format('%.2n',[ textAsCurrency(ednc_104_Wk_Clmt_p_Contrib) ] );
  ResetInfoLine2;
end;

(******************************************************************************)
(*                                                                            *)
(*  Form Activate                                                             *)
(*                                                                            *)
(******************************************************************************)
procedure TBenefitsCalculatorForm.FormActivate(Sender: TObject);
begin
  ResetInfoLine2;
end;

procedure TBenefitsCalculatorForm.edChild_Care_ExpExit(Sender: TObject);
begin
  ClearCalc;
  if edChild_Care_Exp.text='' then edChild_Care_Exp.text:='0';
  edChild_Care_Exp.text:=format('%.2n',[ textAsCurrency(edChild_Care_Exp) ] );
  ResetInfoLine2;
end;

procedure TBenefitsCalculatorForm.edSpousal_SupportExit(Sender: TObject);
begin
  ClearCalc;
  if edSpousal_Support.text='' then edSpousal_Support.text:='0';
  edSpousal_Support.text:=format('%.2n',[ textAsCurrency(edSpousal_Support) ] );
  ResetInfoLine2;
end;

procedure TBenefitsCalculatorForm.edChild_SupportExit(Sender: TObject);
begin
  ClearCalc;
  if edChild_Support.text='' then edChild_Support.text:='0';
  edChild_Support.text:=format('%.2n',[ textAsCurrency(edChild_Support) ] );
  ResetInfoLine2;
end;

procedure TBenefitsCalculatorForm.edCPP_ExemptKeyPress(Sender: TObject;
  var Key: Char);
begin
  case Key of
  #0..#31,'y','Y','n','N':
  else
    Key:=#0;
    WagelossMainForm.ShowInfoLine2('*Valid values for CPP Exempt are Y N');
  end;
end;

procedure TBenefitsCalculatorForm.edCPP_ExemptExit(Sender: TObject);
begin
  ClearCalc;
  if edCPP_Exempt.text='' then edCPP_Exempt.text:='N';
  edCPP_Exempt.text := uppercase(edCPP_Exempt.text);
  ResetInfoLine2;
end;

procedure TBenefitsCalculatorForm.edTax_ExemptKeyPress(Sender: TObject;
  var Key: Char);
begin
  case Key of
  #0..#31,'y','Y','n','N':
  else
    Key:=#0;
    WagelossMainForm.ShowInfoLine2('*Valid values for Income Tax Exempt are Y N');
  end;
end;

procedure TBenefitsCalculatorForm.edTax_ExemptExit(Sender: TObject);
begin
  ClearCalc;
  if edTax_Exempt.text='' then edTax_Exempt.text:='N';
  edTax_Exempt.text := uppercase(edTax_Exempt.text);
  ResetInfoLine2;
end;

procedure TBenefitsCalculatorForm.edMax_AdjustmentsExit(Sender: TObject);
begin
  ClearCalc;
  if edMax_Adjustments.text='' then
     edMax_Adjustments.text:='0';
  edMax_Adjustments.text:=format('%.2n',[ textAsCurrency(edMax_Adjustments) ] );
  ResetInfoLine2;
end;

procedure TBenefitsCalculatorForm.edRecurrenceKeyPress(Sender: TObject;
  var Key: Char);
begin
  case Key of
  #0..#31,'y','Y','n','N':
  else
    Key:=#0;
    WagelossMainForm.ShowInfoLine2('*Valid values for Recurrence are Y N');
  end;
end;

procedure TBenefitsCalculatorForm.edSelf_EmployedKeyPress(Sender: TObject;
  var Key: Char);
begin
  case Key of
  #0..#31,'y','Y','n','N':
  else
    Key:=#0;
    WagelossMainForm.ShowInfoLine2('*Valid values for Self Employed are Y N');
  end;
end;

procedure TBenefitsCalculatorForm.edRecurrenceExit(Sender: TObject);
begin
  ClearCalc;
  edRecurrence.text := uppercase(edRecurrence.text);
  if edRecurrence.text='' then edRecurrence.text:='N';

  if (edRecurrence.text='N') and (edSelf_Employed.text='N') then
  begin
    edMax_Adjustments.text :='0';
    setEditToRead(edMax_Adjustments);
  end;

  if (edRecurrence.text='Y') and (edMax_Adjustments.Enabled=False) then
  begin
    if (edRecurrence.text='Y') and (GetOldRecurrenceInd='N') then
    begin
    	edRecurrenceDate.Visible := True;
    	If Length(edRecurrenceDate.text) < 1 then
    	begin
      	edRecurrenceDate.setfocus;
      	WagelossMainForm.ShowInfoLine2('*Please enter a Recurrence Date.');
      	exit;
    	end;
    end
    else
    begin
    	edRecurrenceDate.text:='';
      edRecurrenceDate.Visible := false;
    end;
    if MessageDlg('Do you wish to change the Max Adjustment amount?',
      mtConfirmation, [mbYes, mbNo], 0) = mrYes then
    begin
      setEditToNormal(edMax_Adjustments);
      edMax_Adjustments.SetFocus;
    end;
  end;

  ResetInfoLine2;
end;

procedure TBenefitsCalculatorForm.edSelf_EmployedExit(Sender: TObject);
begin
  ClearCalc;
  edSelf_Employed.text := uppercase(edSelf_Employed.text);
  if edSelf_Employed.text='' then edSelf_Employed.text:='N';

  if (edRecurrence.text='N') and (edSelf_Employed.text='N') then
  begin
    edMax_Adjustments.text :='0';
    setEditToRead(edMax_Adjustments);
  end;

  if (edSelf_Employed.text='Y') and (edMax_Adjustments.Enabled=False) then
  begin
    if MessageDlg('Do you wish to change the Max Adjustment amount?',
      mtConfirmation, [mbYes, mbNo], 0) = mrYes then
    begin
      setEditToNormal(edMax_Adjustments);
      edMax_Adjustments.SetFocus;
    end;
  end;

  ResetInfoLine2;
end;

procedure TBenefitsCalculatorForm.edAccident_DateExit(Sender: TObject);
begin
  ClearCalc;

  // make sure an accident date was entered
  if Length(edAccident_Date.text ) < 1 then
  begin
    messagebeep(0);
    WagelossMainForm.ShowInfoLine2('*Please enter an Accident Date.');
    edAccident_Date.setfocus;
    globalEditError:=true;
    exit;
  end;

  if not validateAsDate(edAccident_Date) then
  begin
    messagebeep(0);
    WagelossMainForm.ShowInfoLine2('*Invalid Accident Date');
    edAccident_Date.setfocus;
    globalEditError:=true;
    exit;
  end;

  if ( textAsDate( edAccident_Date ) > 0 ) then
    edAccident_Date.text:=formatdatetime('c',textAsDate( edAccident_Date ))
  else
    edAccident_Date.text:='';

  // Support payment fields are not valid for pre-2001 claims
  if year(textAsDate(edAccident_Date)) < 2001 then
  begin
    edChild_Care_Exp.text:='0';
    edSpousal_Support.text:='0';
    edChild_Support.text:='0';

    setEditToRead(edChild_Care_Exp);
    setEditToRead(edSpousal_Support);
    setEditToRead(edChild_Support);
  end
  else
  begin
    setEditToNormal(edChild_Care_Exp);
    setEditToNormal(edSpousal_Support);
    setEditToNormal(edChild_Support);
  end;

  ResetInfoLine2;
end;

procedure TBenefitsCalculatorForm.edAccident_DateKeyPress(Sender: TObject;
  var Key: Char);
begin
  case Key of
  #0..#31,'0'..'9','/','.':
  else
    Key:=#0;
  end;
end;

procedure TBenefitsCalculatorForm.edRecurrenceDateExit(Sender: TObject);
Begin
  // make sure a recurrence date was entered
  if length( edRecurrenceDate.text ) < 1 then
  begin
    messagebeep(0);
    WagelossMainForm.ShowInfoLine2('*Please enter a Recurrence Date.');
    edRecurrenceDate.setfocus;
    globalEditError:=true;
    exit;
  end;

  if not validateAsDate( edRecurrenceDate ) then
  begin
    messagebeep(0);
    WagelossMainForm.ShowInfoLine2('*Invalid Recurrence Date');
    edRecurrenceDate.setfocus;
    globalEditError:=true;
    exit;
  end;

  if ( textAsDate( edRecurrenceDate ) > 0 ) then
    edRecurrenceDate.text:=formatdatetime('c',textAsDate( edRecurrenceDate ))
  else
    edRecurrenceDate.text:='';

  ResetInfoLine2;
end;

procedure TBenefitsCalculatorForm.ScrollBox1MouseWheelUp(Sender: TObject;
  Shift: TShiftState; MousePos: TPoint; var Handled: Boolean);
Const
   iScroll_Increment = 15;
var
   iScroll:Integer;
begin
If scrollbox1.VertScrollBar.position > 0 Then
   Begin
   if  scrollbox1.VertScrollBar.position >  iScroll_Increment Then
       iScroll := scrollbox1.VertScrollBar.position - 15
   else
       iScroll := 0;
   scrollbox1.VertScrollBar.position := iScroll;
   End;
Handled := True;
end;

procedure TBenefitsCalculatorForm.ScrollBox1MouseWheelDown(
  Sender: TObject; Shift: TShiftState; MousePos: TPoint;
  var Handled: Boolean);
Const
   iScroll_Increment = 15;
var
   iScroll:Integer;
begin
if scrollbox1.VertScrollBar.position < scrollbox1.VertScrollBar.range Then
   Begin
   if  scrollbox1.VertScrollBar.position <  (scrollbox1.VertScrollBar.range - iScroll_Increment) Then
       iScroll := scrollbox1.VertScrollBar.position + 15
   else
       iScroll := scrollbox1.VertScrollBar.range;
   scrollbox1.VertScrollBar.position := iScroll;
   End;
Handled := True;
end;


end.

