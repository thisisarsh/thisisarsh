inherited WrkRptJul13: TWrkRptJul13
  Caption = 'WrkRptJul13'
  PixelsPerInch = 96
  TextHeight = 13
end
