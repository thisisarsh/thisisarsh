object WrkRptJan09: TWrkRptJan09
  Left = 247
  Top = 172
  Caption = 'WrkRptJan09'
  ClientHeight = 614
  ClientWidth = 1114
  Color = clBtnFace
  Font.Charset = DEFAULT_CHARSET
  Font.Color = clWindowText
  Font.Height = -11
  Font.Name = 'MS Sans Serif'
  Font.Style = []
  TextHeight = 13
end
