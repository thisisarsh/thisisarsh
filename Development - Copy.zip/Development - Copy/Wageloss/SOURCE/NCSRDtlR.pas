(******************************************************************************)
(*  Wageloss System                                                           *)
(*                                                                            *)
(*  Shelter Rebate Detail Reports                                             *)
(*                                                                            *)
(*                                                                            *)
(*  Author: Brad Trupp  / Capella Systems Group, Inc.                         *)
(*  Date:   October 1998                                                      *)
(*                                                                            *)
(******************************************************************************)

unit NCSRDtlR;

interface

uses
  Windows, Messages, SysUtils, Classes, Graphics, Controls, Forms, Dialogs,
  Qrctrls, QuickRpt, ExtCtrls, Db, StdCtrls, NCRecDef, Data.Win.ADODB; //DBTables,


const
   WLREBDTL_Select_Fields =  'Select Claim_No, ' +
            'Claim_Suffix, ' +
            'Clmt_Name_Initials, ' +
            'Tax_Year, ' +
            'Marital_Status, ' +
            'Spouse_Working, ' +
            'ClaimSpouseForTaxPurposes, ' +
            'Nbr_Of_Dependants, ' +
            'Nbr_Of_Infirm_Deps, ' +
            'Uic_Exempt, ' +
            'Accum_Wks_Yr_PdCst, ' +
            'Accum_Wks_Yr_90Net, ' +
            'Accum_Wks_Yr_90Net, ' +
            'Wkly_Sal, ' +
            'Wkly_Net, ' +
            'Wkly_90, ' +
            'Wkly_90_S, ' +
            'Wkly_80, ' +
            'Annual_Gross, ' +
            'Annual_Net, ' +
            'Annual_90, ' +
            'Annual_90_S, ' +
            'Annual_80, ' +
            'Tax_Exemption, ' +
            'Inc_Tax_Fed, ' +
            'Inc_Tax_Prov, ' +
            'Cpp_Prem, ' +
            'Cpp2_Prem, ' +
            'Uic_Prem, ' +
            'Total_Deds, ' +
            'Wkly_Sal_A, ' +
            'Annual_Gross_A, ' +
            'Annual_Net_A, ' +
            'Tax_Exemption_A, ' +
            'Inc_Tax_Fed_A, ' +
            'Inc_Tax_Prov_A, ' +
            'Cpp_Prem_A, ' +
            'Cpp2_Prem_A, ' +
            'Uic_Prem_A, ' +
            'Tax_Shelter_Bnft, ' +
            'Tax_Shelter_Deduct, ' +
            'Rebate_Amount, ' +
            'Weeks_Worked, ' +
            'Wkly_Tax_S, ' +
            'Total_Deds_A, ' +
            'Total_Tax_S, ' +
            'Total_Deds_P_A, ' +
            'Shelter_Rebate_Year, ' +
            'Prime_Firm_No, ' +
            'Payment_Issued_Flag, ' +
            'Logical_Delete_Flag, ' +
            'accident_date, ' +
    	      'self_employed, ' +
      	    'recurrence, ' +
      	    'cpp_exempt, ' +
      	    'income_tax_exempt, ' +
      	    'child_care_expense, ' +
      	    'spousal_support, ' +
      	    'no_of_actual_shelter_deduc, ' +
            'Recurrence_Date, ' +
            'Youthful_Worker, ' +
            'Accum_Wks_Yr_90Net_Post, ' +
            'workerAnnuityContributionPcnt, ' +
            'wcbAnnuityContributionPercent, ' +
            'workerShetlerAnnuityContribAmt, ' +
            'wcbShelterAnnuityContribAmt, ' +
            'paidFromDate, ' +
            'paidToDate, ' +
            'employerPaidFlag, ' +
            'post_injury_earnings ';


type
  ECalcError = class(Exception);
    
type

  iSRDetailReportType = ( iSingle, iRecord, iBySuffixClaimAllClaims, iBySuffixClaimRebatesOnly, iBySuffixClaimNoRebate );

  TShelterRebateDetailForm = class(TForm)
    QRShelterRebateDetailReport: TQuickRep;
    QRBand1: TQRBand;
    QRLabel1: TQRLabel;
    QRLabel2: TQRLabel;
    QRSysData4: TQRSysData;
    QRBand2: TQRBand;
    QRlblSuffix: TQRLabel;
    QRlblClaim: TQRLabel;
    QRlblName: TQRLabel;
    QRLabel3: TQRLabel;
    Label5: TQRlabel;
    Label15: TQRlabel;
    Label16: TQRlabel;
    Label17: TQRlabel;
    Label18: TQRlabel;
    Label20: TQRlabel;
    Label32: TQRlabel;
    Label33: TQRlabel;
    Label34: TQRlabel;
    Label35: TQRlabel;
    Label36: TQRlabel;
    Label37: TQRlabel;
    lblInc_Tax_Fed: TQRlabel;
    lblInc_Tax_Man: TQRlabel;
    lblCPP_Prem: TQRlabel;
    lblEI_Prem: TQRlabel;
    lblTotal_Deds: TQRlabel;
    Label40: TQRlabel;
    Label41: TQRlabel;
    Label42: TQRlabel;
    Label44: TQRlabel;
    Label45: TQRlabel;
    lblWkly_Sal_A: TQRlabel;
    lblWeekly_Net: TQRlabel;
    lblAnnual_Gross: TQRlabel;
    lblAnnual_Net: TQRlabel;
    Label52: TQRlabel;
    Label53: TQRlabel;
    Label54: TQRlabel;
    lblWeekly_90: TQRlabel;
    lblCalcTaxSheltering: TQRlabel;
    lblWeekly_90_S: TQRlabel;
    edTax_Year: TQRlabel;
    edEI_Exempt: TQRlabel;
    edNo_Of_Dependnts: TQRlabel;
    edNo_Infirm: TQRlabel;
    edSpouse_Working: TQRlabel;
    Label59: TQRlabel;
    Label60: TQRlabel;
    Label64: TQRlabel;
    lblSRWeeks_Worked2: TQRlabel;
    Label66: TQRlabel;
    lblSRTotal_Deds2: TQRlabel;
    Label68: TQRlabel;
    lblSRTotal_Deds_P_A2: TQRlabel;
    lblSRTotal_Deds_A2: TQRlabel;
    lblSRTax_Shelter_Bnft2: TQRlabel;
    Label75: TQRlabel;
    Label76: TQRlabel;
    lblSRShelter_Rebate_Year2: TQRlabel;
    Label82: TQRlabel;
    Label83: TQRlabel;
    lblSRAccum_Wks_Yr_90Net3: TQRlabel;
    Label85: TQRlabel;
    lnlSRWkly_Tax_S3: TQRlabel;
    Label87: TQRlabel;
    lblSRTax_Shelter_Deduct3: TQRlabel;
    lblSRTax_Shelter_Bnft3: TQRlabel;
    lblSRRebate_Amount3: TQRlabel;
    Label94: TQRlabel;
    Label95: TQRlabel;
    lblSRShelter_Rebate_Year3: TQRlabel;
    Label100: TQRlabel;
    Label101: TQRlabel;
    Label3: TQRlabel;
    Label4: TQRlabel;
    Label6: TQRlabel;
    Label7: TQRlabel;
    lblWeeks_Worked: TQRlabel;
    lblAnnual_Gross_A: TQRlabel;
    lblAnnual_Net_A: TQRlabel;
    Label12: TQRlabel;
    Label28: TQRlabel;
    Label29: TQRlabel;
    Label30: TQRlabel;
    Label31: TQRlabel;
    Label38: TQRlabel;
    Label39: TQRlabel;
    lblActualInc_Tax_Fed: TQRlabel;
    lblActualInc_Tax_Man: TQRlabel;
    lblActualCPP_Prem: TQRlabel;
    lblActualEI_Prem: TQRlabel;
    lblActualTotal_Deds: TQRlabel;
    QRShape1: TQRShape;
    QRShape2: TQRShape;
    QRShape3: TQRShape;
    QRShape4: TQRShape;
    QRLabel4: TQRLabel;
    lblAccum_Wks_Yr_PdCst: TQRLabel;
    QRShape5: TQRShape;
    QRShape6: TQRShape;
    QRLabel6: TQRLabel;
    QRLabel8: TQRLabel;
    QRShape7: TQRShape;
    QRLabel9: TQRLabel;
    lblAccum_Wks_Yr_90Net: TQRLabel;
    QRLabel7: TQRLabel;
    QRLabel5: TQRLabel;
    lblAccident_Date: TQRLabel;
    QRLabel10: TQRLabel;
    QRLabel11: TQRLabel;
    lblCPP_Exempt: TQRLabel;
    lblTax_Exempt: TQRLabel;
    QRLabel12: TQRLabel;
    QRLabel13: TQRLabel;
    QRLabel14: TQRLabel;
    QRLabel15: TQRLabel;
    lblSelf_Employed: TQRLabel;
    lblRecurrence: TQRLabel;
    lblChild_Care_Expense: TQRLabel;
    lblTotal_Post_Injury_Earn: TQRLabel;
    QRLabel20: TQRLabel;
    lblSpousal_Support: TQRLabel;
    edMarital_Status: TQRLabel;
    QRLabel16: TQRLabel;
    lblShelter_Deduction: TQRLabel;
    lblRecurrence_Date: TQRLabel;
    QRLabel17: TQRLabel;
    lblYouthful_Worker: TQRLabel;
    QRLabel18: TQRLabel;
    lblAccum_Wks_Yr_90NetPost: TQRLabel;
    QRLabel19: TQRLabel;
    lblRebatePreAnnuity3: TQRLabel;
    lblWorkerAnnuityAmt: TQRLabel;
    QRLabel23: TQRLabel;
    lblRebatePreAnnuity3b: TQRLabel;
    QRLabel25: TQRLabel;
    lblWorkerAnnuityPercent: TQRLabel;
    QRLabel27: TQRLabel;
    QRLabel28: TQRLabel;
    QRShape8: TQRShape;
    lblDisplayAnnuityEarnings: TQRLabel;
    lblWCBAnnuityAmt: TQRLabel;
    QRLabel24: TQRLabel;
    QRLabel26: TQRLabel;
    lblDisplayShelterBeforeAnnuity: TQRLabel;
    lblRebatePreAnnuity3c: TQRLabel;
    QRLabel29: TQRLabel;
    QRLabel30: TQRLabel;
    lblDisplayWeeksCompensation: TQRLabel;
    lblWCBAnnuityPercent: TQRLabel;
    QRLabel31: TQRLabel;
    QRLabel32: TQRLabel;
    lblDisplayWeeks90NetPost: TQRLabel;
    QRLabel33: TQRLabel;
    QRLabel34: TQRLabel;
    QRLabel35: TQRLabel;
    QRLabel22: TQRLabel;
    QRShape9: TQRShape;
    QRLabel36: TQRLabel;
    QRlblClaimhdr: TQRLabel;
    QRShape10: TQRShape;
    QRLabel37: TQRLabel;
    PageFooterBand1: TQRBand;
    QRSysData5: TQRSysData;
    QRSysData1: TQRSysData;
    QRUserID: TQRLabel;
    QRSysData2: TQRSysData;
    QRQuery1: TADOQuery;
    lblClaimSpouseForTaxPurposes: TQRLabel;
    edClaimSpouseForTaxPurposes: TQRLabel;
    QRLabel21: TQRLabel;
    lblActualCPP2_Prem: TQRLabel;
    QRLabel38: TQRLabel;
    lblCPP2_Prem: TQRLabel;
    procedure QRShelterRebateDetailReportBeforePrint(Sender: TCustomQuickRep; var PrintReport: Boolean);
    procedure QRShelterRebateDetailReportNeedData(Sender: TObject; var MoreData: Boolean);
    procedure QRBand2BeforePrint(Sender: TQRCustomBand; var PrintBand: Boolean);
  private
    { Private declarations }
    cntr: integer;
    TempNoShelter: currency;
    TempNet90: currency;
    TempNet90Post: currency;
    procedure SelectClaimsBySingle;
    procedure SelectClaimsBySuffixClaimAllClaims;
    procedure SelectClaimsBySuffixClaimRebatesOnly;
    procedure SelectClaimsBySuffixClaimNoRebates;
    procedure fillInForm;
  public
    { Public declarations }
    fSRClaim : recWLREBDTL;
    fSRDetailReportType: iSRDetailReportType;
  end;

var
  ShelterRebateDetailForm: TShelterRebateDetailForm;

implementation

uses NCDatMod, NCMain, uADOSecurity, Utils;

{$R *.DFM}

(******************************************************************************)
(*                                                                            *)
(*  Before print - query and get data                                         *)
(*                                                                            *)
(******************************************************************************)
procedure TShelterRebateDetailForm.QRBand2BeforePrint(Sender: TQRCustomBand;
  var PrintBand: Boolean);
begin
  if edSpouse_Working.Caption = 'Y' then
     begin
     lblClaimSpouseForTaxPurposes.Visible := false;
     edClaimSpouseForTaxPurposes.Visible := false;
     end
  else
     begin
     lblClaimSpouseForTaxPurposes.Visible := true;
     edClaimSpouseForTaxPurposes.Visible := true;
     end;

end;

procedure TShelterRebateDetailForm.QRShelterRebateDetailReportBeforePrint(
  Sender: TCustomQuickRep; var PrintReport: Boolean);
begin
    Cntr:=0;
    // make additional changes
    QRUserID.caption := userProfile.givenName + ' ' + userProfile.familyName;
    case fSRDetailReportType of
        iSingle:
        begin
            QRShelterRebateDetailReport.reportTitle:='Detail Report - Individual';
            SelectClaimsBySingle;
        end;
        iRecord:
        begin
            QRShelterRebateDetailReport.reportTitle:='Detail Report - Shelter Rebate Calculator';
        end;
        iBySuffixClaimAllClaims:
        begin
            QRShelterRebateDetailReport.reportTitle:='Detail Report - by Suffix and Claim - All Claims';
            SelectClaimsBySuffixClaimAllClaims;
        end;
        iBySuffixClaimRebatesOnly:
        begin
            QRShelterRebateDetailReport.reportTitle:='Detail Report - by Suffix and Claim - Rebates Only';
            SelectClaimsBySuffixClaimRebatesOnly;
        end;
        iBySuffixClaimNoRebate:
        begin
            QRShelterRebateDetailReport.reportTitle:='Detail Report - by Claim - Not Receiving Rebates';
            SelectClaimsBySuffixClaimNoRebates;
        end;
    end;
end;

(******************************************************************************)
(*                                                                            *)
(*  Need Data - process individual records                                    *)
(*                                                                            *)
(******************************************************************************)
procedure TShelterRebateDetailForm.QRShelterRebateDetailReportNeedData(
  Sender: TObject; var MoreData: Boolean);
begin
    if ( fSRDetailReportType = iRecord ) then
    begin
      MoreData := Cntr < 1;
      inc(Cntr);
      fillInForm;
      WagelossMainForm.ShowInfoLine1('Report complete - 1 Record.');
      exit;
    end;

    MoreData := not QRQuery1.eof;
    if not MoreData then
    begin
        WagelossMainForm.ShowInfoLine1('Report complete - ' + intToStr( Cntr ) + ' Records.');
    end
    else
    begin
        inc(Cntr);
        WagelossMainForm.ShowInfoLine1('Records Processed: ' + intToStr( Cntr ) + '.');
        fillInForm;
    end;
    QRQuery1.next;
end;

(******************************************************************************)
(*                                                                            *)
(*  Select Claims in Claim order                                              *)
(*                                                                            *)
(******************************************************************************)
procedure TShelterRebateDetailForm.SelectClaimsBySuffixClaimAllClaims;
begin
  try
    with dm1 do
    begin
      if QRQuery1.active then QRQuery1.close;
      QRQuery1.sql.clear;
      QRQuery1.sql.add(WLREBDTL_Select_Fields);
      //QRQuery1.sql.add('SELECT * ');
      QRQuery1.sql.add('  FROM dbo.WLREBDTL' );
      QRQuery1.sql.add('  WHERE Logical_Delete_Flag <> ''Y'' ');
      QRQuery1.sql.add('  AND reportType <> ''DISQUALIFY'' ');
      QRQuery1.sql.add('  ORDER BY Claim_Suffix, Claim_No');
      QRQuery1.open;
      QRQuery1.first;
    end;
  finally
  ;
  end;
end;

(******************************************************************************)
(*                                                                            *)
(*    Select Claims in Suffix/Claim order                                     *)
(*                                                                            *)
(******************************************************************************)
procedure TShelterRebateDetailForm.SelectClaimsBySuffixClaimRebatesOnly;
begin
  try
    with dm1 do
    begin
      if QRQuery1.active then QRQuery1.close;
      QRQuery1.sql.clear;
      QRQuery1.sql.add(WLREBDTL_Select_Fields);
      //QRQuery1.sql.add('SELECT * ');
      QRQuery1.sql.add('  FROM dbo.WLREBDTL');
      QRQuery1.sql.add('  WHERE Logical_Delete_Flag <> ''Y'' ');
      QRQuery1.sql.add('  AND Rebate_Amount <> 0');
      QRQuery1.sql.add('  AND reportType <> ''DISQUALIFY'' ');
      QRQuery1.sql.add('  ORDER BY Claim_Suffix, Claim_No');
      QRQuery1.open;
      QRQuery1.first;
    end;
  finally
  ;
  end;
end;

(******************************************************************************)
(*                                                                            *)
(*    Select an individual claim                                              *)
(*                                                                            *)
(******************************************************************************)
procedure TShelterRebateDetailForm.SelectClaimsBySingle;
var
   clm: string;
begin
  try
    with dm1 do
    begin
      clm := query2.fieldbyname('Claim_No').asString;
      if QRQuery1.active then QRQuery1.close;
      QRQuery1.sql.clear;
      QRQuery1.sql.add(WLREBDTL_Select_Fields);
      //QRQuery1.sql.add('SELECT * FROM dbo.WLREBDTL where Claim_No = ''' + clm + '''');
      QRQuery1.sql.add('FROM dbo.WLREBDTL where Claim_No = ''' + clm + '''');
      QRQuery1.open;
      QRQuery1.first;
    end;
  finally
  ;
  end;
end;

(******************************************************************************)
(*                                                                            *)
(*    Select Claims in amount order                                          *)
(*                                                                            *)
(******************************************************************************)
procedure TShelterRebateDetailForm.SelectClaimsBySuffixClaimNoRebates;
begin
  try
    with dm1 do
    begin
      if QRQuery1.active then QRQuery1.close;
      QRQuery1.sql.clear;
      QRQuery1.sql.add(WLREBDTL_Select_Fields);
      //QRQuery1.sql.add('SELECT *');
      QRQuery1.sql.add('  FROM dbo.WLREBDTL');
      QRQuery1.sql.add('  WHERE Logical_Delete_Flag <> ''Y'' ');
      QRQuery1.sql.add('  AND reportType <> ''DISQUALIFY'' ');
      QRQuery1.sql.add('  AND Rebate_Amount = 0');
      QRQuery1.sql.add('  ORDER BY Claim_Suffix, Claim_No');
      QRQuery1.open;
      QRQuery1.first;
    end;
  finally
  ;
  end;
end;

(******************************************************************************)
(*                                                                            *)
(*  Fill in report detail from claim record(s)                                *)
(*                                                                            *)
(******************************************************************************)
procedure TShelterRebateDetailForm.fillInForm;
var
    myfSRClaim : recWLREBDTL;
    eligEarn:currency;
begin
  if ( fSRDetailReportType = iRecord ) then
  begin
    myfSRClaim := fSRClaim;
  end
  else
  begin
      try
        with myfSRClaim do
        begin
            Claim_No := QRQuery1.FieldByName('Claim_No').AsString;
            Claim_Suffix := QRQuery1.FieldByName('Claim_Suffix').asString;
            Clmt_Name_Initials := QRQuery1.FieldByName('Clmt_Name_Initials').asString;
            Tax_Year := QRQuery1.FieldByName('Tax_Year').asInteger;
            Marital_Status := QRQuery1.FieldByName('Marital_Status').asString;
            Spouse_Working := QRQuery1.FieldByName('Spouse_Working').asString;
            ClaimSpouseForTaxPurposes := QRQuery1.FieldByName('ClaimSpouseForTaxPurposes').AsString;
            Nbr_Of_Dependants := QRQuery1.FieldByName('Nbr_Of_Dependants').asInteger;
            Nbr_Of_Infirm_Deps := QRQuery1.FieldByName('Nbr_Of_Infirm_Deps').asInteger;
            Uic_Exempt := QRQuery1.FieldByName('Uic_Exempt').asString;
            Accum_Wks_Yr_PdCst := QRQuery1.FieldByName('Accum_Wks_Yr_PdCst').asCurrency;
            Accum_Wks_Yr_90Net := QRQuery1.FieldByName('Accum_Wks_Yr_90Net').asCurrency;
            TempNet90 := QRQuery1.FieldByName('Accum_Wks_Yr_90Net').asCurrency;
            Wkly_Sal := QRQuery1.FieldByName('Wkly_Sal').asCurrency;
            Wkly_Net := QRQuery1.FieldByName('Wkly_Net').asCurrency;
            Wkly_90 := QRQuery1.FieldByName('Wkly_90').asCurrency;
            Wkly_90_S := QRQuery1.FieldByName('Wkly_90_S').asCurrency;
            Wkly_80 := QRQuery1.FieldByName('Wkly_80').asCurrency;
            Annual_Gross := QRQuery1.FieldByName('Annual_Gross').asCurrency;
            Annual_Net := QRQuery1.FieldByName('Annual_Net').asCurrency;
            Annual_90 := QRQuery1.FieldByName('Annual_90').asCurrency;
            Annual_90_S := QRQuery1.FieldByName('Annual_90_S').asCurrency;
            Annual_80 := QRQuery1.FieldByName('Annual_80').asCurrency;
            Tax_Exemption := QRQuery1.FieldByName('Tax_Exemption').asCurrency;
            Inc_Tax_Fed := QRQuery1.FieldByName('Inc_Tax_Fed').asCurrency;
            Inc_Tax_Prov := QRQuery1.FieldByName('Inc_Tax_Prov').asCurrency;
            Cpp_Prem := QRQuery1.FieldByName('Cpp_Prem').asCurrency;
            Cpp2_Prem := QRQuery1.FieldByName('Cpp2_Prem').asCurrency;
            Uic_Prem := QRQuery1.FieldByName('Uic_Prem').asCurrency;
            Total_Deds := QRQuery1.FieldByName('Total_Deds').asCurrency;
            Wkly_Sal_A := QRQuery1.FieldByName('Wkly_Sal_A').asCurrency;
            Annual_Gross_A := QRQuery1.FieldByName('Annual_Gross_A').asCurrency;
            Annual_Net_A := QRQuery1.FieldByName('Annual_Net_A').asCurrency;
            Tax_Exemption_A := QRQuery1.FieldByName('Tax_Exemption_A').asCurrency;
            Inc_Tax_Fed_A := QRQuery1.FieldByName('Inc_Tax_Fed_A').asCurrency;
            Inc_Tax_Prov_A := QRQuery1.FieldByName('Inc_Tax_Prov_A').asCurrency;
            Cpp_Prem_A := QRQuery1.FieldByName('Cpp_Prem_A').asCurrency;
            Cpp2_Prem_A := QRQuery1.FieldByName('Cpp2_Prem_A').asCurrency;
            Uic_Prem_A := QRQuery1.FieldByName('Uic_Prem_A').asCurrency;
            Tax_Shelter_Bnft := QRQuery1.FieldByName('Tax_Shelter_Bnft').asCurrency;
            Tax_Shelter_Deduct := QRQuery1.FieldByName('Tax_Shelter_Deduct').asCurrency;
            Rebate_Amount := QRQuery1.FieldByName('Rebate_Amount').asCurrency;
            Weeks_Worked := QRQuery1.FieldByName('Weeks_Worked').asCurrency;
            Wkly_Tax_S := QRQuery1.FieldByName('Wkly_Tax_S').asCurrency;
            Total_Deds_A := QRQuery1.FieldByName('Total_Deds_A').asCurrency;
            Total_Tax_S := QRQuery1.FieldByName('Total_Tax_S').asCurrency;
            Total_Deds_P_A := QRQuery1.FieldByName('Total_Deds_P_A').asCurrency;
            Shelter_Rebate_Year := QRQuery1.FieldByName('Shelter_Rebate_Year').asInteger;
            Prime_Firm_No := QRQuery1.FieldByName('Prime_Firm_No').asString;
            Payment_Issued_Flag := QRQuery1.FieldByName('Payment_Issued_Flag').asBoolean;
            Logical_Delete_Flag := QRQuery1.FieldByName('Logical_Delete_Flag').asBoolean;
            Accident_Date := QRQuery1.FieldByName('accident_date').asDateTime;
    	      Self_Employed := QRQuery1.FieldByName('self_employed').asString;
      	    Recurrence := QRQuery1.FieldByName('recurrence').asString;
      	    CPP_Exempt := QRQuery1.FieldByName('cpp_exempt').asString;
      	    Tax_Exempt := QRQuery1.FieldByName('income_tax_exempt').asString;
      	    Child_Care_Exp := QRQuery1.FieldByName('child_care_expense').asCurrency;
      	    Spousal_Support := QRQuery1.FieldByName('spousal_support').asCurrency;
      	    //Child_Support := QRQuery1.fields[052].asCurrency;
      	    //Max_Adjustment := QRQuery1.fields[055].asCurrency;
	          Nbr_Act_Shelter_Deduct := QRQuery1.FieldByName('no_of_actual_shelter_deduc').asCurrency;
            TempNoShelter := Nbr_Act_Shelter_Deduct;
            if QRQuery1.FieldByName('Recurrence_Date').IsNull Then
               Recurrence_Date := 0
            else
               Recurrence_Date := QRQuery1.FieldByName('Recurrence_Date').AsDateTime;
            if QRQuery1.FieldByName('Youthful_Worker').IsNull Then
               Youthful_Worker := 'N'
            else
               Youthful_Worker := QRQuery1.FieldByName('Youthful_Worker').AsString;
            Accum_Wks_Yr_90Net_Post := QRQuery1.FieldByName('Accum_Wks_Yr_90Net_Post').asCurrency;
            TempNet90Post := QRQuery1.FieldByName('Accum_Wks_Yr_90Net_Post').asCurrency;
            workerAnnuityContributionPercent := QRQuery1.FieldByName('workerAnnuityContributionPcnt').asCurrency;
            wcbAnnuityContributionPercent := QRQuery1.FieldByName('wcbAnnuityContributionPercent').asCurrency;
            workerShetlerAnnuityContribAmt := QRQuery1.FieldByName('workerShetlerAnnuityContribAmt').asCurrency;
            wcbShelterAnnuityContribAmt := QRQuery1.FieldByName('wcbShelterAnnuityContribAmt').asCurrency;
            paidFromDate := QRQuery1.FieldByName('paidFromDate').AsDateTime;
            paidToDate := QRQuery1.FieldByName('paidToDate').AsDateTime;
            employerPaidFlag := QRQuery1.FieldByName('employerPaidFlag').AsString;
            PostInjuryEarnings := QRQuery1.FieldByName('post_injury_earnings').asCurrency;
        end;
      finally
      ;
      end;
  end;

  with myfSRClaim do
  begin
      QRlblClaimhdr.caption := Claim_No;
      QRlblClaim.caption := Claim_No;
      QRlblSuffix.caption := Claim_Suffix;
      QRlblName.caption := Clmt_Name_Initials;
      lblAccum_Wks_Yr_PdCst.caption := format('%.2n', [ Accum_Wks_Yr_PdCst ] );
      lblAccum_Wks_Yr_90Net.caption := format('%.2n', [ Accum_Wks_Yr_90Net ] );
      lblInc_Tax_Fed.caption := format('%.2n', [ Inc_Tax_Fed ] );
      lblInc_Tax_Man.caption := format('%.2n', [ Inc_Tax_Prov ] );
      lblCPP_Prem.caption := format('%.2n', [ Cpp_Prem ] );
      lblCPP2_Prem.caption := format('%.2n', [ Cpp2_Prem ] );
      lblEI_Prem.caption := format('%.2n', [ Uic_Prem ] );
      lblTotal_Deds.caption := format('%.2n', [ Total_Deds ] );
      edTax_Year.caption := format('%d', [ Tax_Year ] );
      edMarital_Status.caption := Marital_Status;
      edEI_Exempt.caption := Uic_Exempt;
      edNo_Of_Dependnts.caption := format('%d', [ Nbr_Of_Dependants ] );
      edNo_Infirm.caption := format('%d', [ Nbr_Of_Infirm_Deps ] );
      edSpouse_Working.caption := Spouse_Working;
      edClaimSpouseForTaxPurposes.Caption := ClaimSpouseForTaxPurposes;
      lblWkly_Sal_A.caption := format('%.2n', [ Wkly_Sal ] );
      lblWeekly_Net.caption := format('%.2n', [ Wkly_Net ] );
      lblAnnual_Gross.caption := format('%.2n', [ Annual_Gross ] );
      lblAnnual_Net.caption := format('%.2n', [ Annual_Net ] );
      lblWeekly_90.caption := format('%.2n', [ Wkly_90 ] );
      lblCalcTaxSheltering.caption := format('%.2n', [ Wkly_Tax_S ] );
      lblWeekly_90_S.caption := format('%.2n', [ Wkly_90_S ] );
      //lblAnnual_90.caption := format('%.2n', [ Annual_90 ] );
      //lblAnnual_90_S.caption := format('%.2n', [ Annual_90_S ] );
      //lblWeekly_80.caption := format('%.2n', [ Wkly_80 ] );
      //lblAnnual_80.caption := format('%.2n', [ Annual_80 ] );
      lblWeeks_Worked.caption := format('%.2n', [ Weeks_Worked ] );
      //lblTax_Exemption.caption := format('%.2n', [ Tax_Exemption ] );
      lblAnnual_Gross_A.caption := format('%.2n', [ Annual_Gross_A ] );
      lblAnnual_Net_A.caption := format('%.2n', [ Annual_Net_A ] );
      //lblActualTax_Exemption.caption := format('%.2n', [ Tax_Exemption_A ] );
      lblActualInc_Tax_Fed.caption := format('%.2n', [ Inc_Tax_Fed_A ] );
      lblActualInc_Tax_Man.caption := format('%.2n', [ Inc_Tax_Prov_A ] );
      lblActualCPP_Prem.caption := format('%.2n', [ Cpp_Prem_A ] );
      lblActualCPP2_Prem.caption := format('%.2n', [ Cpp2_Prem_A ] );
      lblActualEI_Prem.caption := format('%.2n', [ Uic_Prem_A ] );
      lblActualTotal_Deds.caption := format('%.2n', [ Total_Deds_A ] );
      lblSRWeeks_Worked2.caption :=  format('%n', [ Weeks_Worked ] );
      lblSRTotal_Deds2.caption := format('%.2n', [ Total_Deds  ] );
      lblSRTotal_Deds_P_A2.caption := format('%.2n', [ Total_Deds_P_A ] );
      lblSRTotal_Deds_A2.caption := format('%.2n', [ Total_Deds_A  ] );
      lblSRTax_Shelter_Bnft2.caption := format('%.2n', [ Tax_Shelter_Bnft  ] );
      lblSRShelter_Rebate_Year2.caption := format('%d', [ Shelter_Rebate_Year ] );
      lblAccum_Wks_Yr_90NetPost.caption := format('%.2n', [ Accum_Wks_Yr_90Net_Post ] );
      if (year(Accident_Date) < 2006) then
      begin
        lblSRAccum_Wks_Yr_90Net3.caption := format('%.2n', [ Accum_Wks_Yr_90Net ] );
        if (PostInjuryEarnings > 0) then
          lblSRAccum_Wks_Yr_90Net3.caption := format('%.2n', [ Nbr_Act_Shelter_Deduct ] );
        //Label61.Caption := '80% of Net Loss';
      end
      else
      begin
        lblSRAccum_Wks_Yr_90Net3.caption := format('%.2n', [ Accum_Wks_Yr_90Net + Accum_Wks_Yr_90Net_Post ] );
        if (PostInjuryEarnings > 0) then
          lblSRAccum_Wks_Yr_90Net3.caption := format('%.2n', [ Nbr_Act_Shelter_Deduct ] );
        //Label61.Caption := '90% of Net Loss Post 104';
      end;
      lnlSRWkly_Tax_S3.caption := format('%.2n', [ Wkly_Tax_S  ] );
      lblSRTax_Shelter_Deduct3.caption := format('%.2n', [ Tax_Shelter_Deduct  ] );
      lblSRTax_Shelter_Bnft3.caption := format('%.2n', [ Tax_Shelter_Bnft  ] );
      if Accum_Wks_Yr_PdCst <> 0 then
        eligEarn := Accum_Wks_Yr_90Net_Post / Accum_Wks_Yr_PdCst
      else
        eligEarn := 0;
      lblRebatePreAnnuity3.caption := format('%.2n', [ Rebate_Amount + workerShetlerAnnuityContribAmt  ] );
      lblWorkerAnnuityPercent.caption := format('%.2n', [ workerAnnuityContributionPercent  ] ) + '%';
      if year(Accident_Date) > 2005 then
      begin
        lblRebatePreAnnuity3b.caption := format('%.2n', [ (Rebate_Amount + workerShetlerAnnuityContribAmt) *  eligEarn ] );
        lblRebatePreAnnuity3c.caption := format('%.2n', [ (Rebate_Amount + workerShetlerAnnuityContribAmt) *  eligEarn  ] );
        lblDisplayWeeks90NetPost.caption := format('%.2n', [ Accum_Wks_Yr_90Net_Post  ] );
        lblDisplayWeeksCompensation.caption := format('%.2n', [ Accum_Wks_Yr_PdCst  ] );
        lblDisplayShelterBeforeAnnuity.caption := format('%.2n', [ Rebate_Amount + workerShetlerAnnuityContribAmt  ] );
        lblDisplayAnnuityEarnings.caption := format('%.2n', [ (Rebate_Amount + workerShetlerAnnuityContribAmt) *  eligEarn  ] );
      end
      else
      begin
        lblRebatePreAnnuity3b.caption := '0.00';
        lblRebatePreAnnuity3c.caption := '0.00';
        lblDisplayWeeks90NetPost.caption := '0.00';
        lblDisplayWeeksCompensation.caption := '0.00';
        lblDisplayShelterBeforeAnnuity.caption := '0.00';
        lblDisplayAnnuityEarnings.caption := '0.00';
      end;
      lblWorkerAnnuityAmt.caption := format('%.2n', [ workerShetlerAnnuityContribAmt  ] );
      lblSRRebate_Amount3.caption := format('%.2n', [ Rebate_Amount  ] );
      lblSRShelter_Rebate_Year3.caption := format('%d', [ Shelter_Rebate_Year ] );
      lblWCBAnnuityPercent.caption := format('%.2n', [ wcbAnnuityContributionPercent  ] ) + '%';
      lblWCBAnnuityAmt.caption := format('%.2n', [ wcbShelterAnnuityContribAmt  ] );
      //lblAccident_Date.Caption := formatdatetime('c', accident_date );
      lblAccident_Date.Caption := formatdatetime('ddddd', accident_date );
      lblCPP_Exempt.caption := CPP_Exempt;
      lblTax_Exempt.caption := Tax_Exempt;
      lblSelf_Employed.caption := Self_Employed;
      lblRecurrence.caption := Recurrence;
      lblSpousal_Support.Caption := format('%.2n', [ spousal_support ] );
      lblChild_Care_Expense.caption := format('%.2n', [ child_care_exp ] );
      lblTotal_Post_Injury_Earn.caption := format('%.2n', [ PostInjuryEarnings ] );
      lblShelter_Deduction.caption := format('%.2n', [ Nbr_Act_Shelter_Deduct ] );

      if Recurrence_Date <> 0 Then
         begin
         //lblRecurrence_Date.Caption := FormatDateTime('c', Recurrence_Date);
         lblRecurrence_Date.Caption := FormatDateTime('ddddd', Recurrence_Date);
         end
      else
         lblRecurrence_Date.Caption := '';

      lblYouthful_Worker.Caption := Youthful_Worker;
      //
  end; // with fSRClaim do..

end;


end.
