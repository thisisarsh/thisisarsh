inherited WrkRptJul18: TWrkRptJul18
  Caption = 'WrkRptJul18'
  PixelsPerInch = 96
  TextHeight = 13
end
