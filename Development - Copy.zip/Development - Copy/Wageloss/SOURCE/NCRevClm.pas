(*****************************************************************)
(*  Wageloss System                                              *)
(*                                                                *)
(*  Benefit Review Benefit Levels for 80% net                    *)
(*                                                               *)
(*                                                               *)
(*  Author: Brad Trupp  / Capella Systems Group, Inc.            *)
(*  Date:   August 1997                                          *)
(*****************************************************************)

unit NCRevClm;

interface

uses
  Windows, Messages, SysUtils, Classes, Graphics, Controls, Forms, Dialogs,
  ExtCtrls, StdCtrls;

type
  TReviewBenefitLevelForm = class(TForm)
    Label1: TLabel;
    Label2: TLabel;
    Label3: TLabel;
    lblClaim_No: TLabel;
    lblClmnts_Name: TLabel;
    lblClmnts_Add_No_1: TLabel;
    lblClmnts_Add_No_2: TLabel;
    Label8: TLabel;
    Label9: TLabel;
    Label10: TLabel;
    lblSIN: TLabel;
    lblBirth_Date: TLabel;
    lblClmnts_Home_Phone: TLabel;
    lblClmnts_Post_Code: TLabel;
    lblClaim_Suffix: TLabel;
    lblClmnts_Work_Phone: TLabel;
    Label13: TLabel;
    Label29: TLabel;
    Bevel1: TBevel;
    Label6: TLabel;
    lblAccident_Date: TLabel;
    Label4: TLabel;
    lblBirth_Date2: TLabel;
    Label11: TLabel;
    lblLoss_Earn_Date: TLabel;
    Label14: TLabel;
    Label15: TLabel;
    lblTot_Comp_Pd_To_Date: TLabel;
    lblDate_Pd_To_Cheq: TLabel;
    Label18: TLabel;
    Label19: TLabel;
    lblNo_Days_Of_Comp_Bnfts: TLabel;
    lblNo_Weeks_of_Comp_Bnfts: TLabel;
    ednc_104_Wk_Effective_Date: TEdit;
    Label74: TLabel;
    ednc_104_Wk_Clmt_Reply_Date: TEdit;
    Label22: TLabel;
    procedure FormKeyDown(Sender: TObject; var Key: Word; Shift: TShiftState);
    procedure FormClose(Sender: TObject; var Action: TCloseAction);
    procedure FormCreate(Sender: TObject);
    procedure FormDestroy(Sender: TObject);
    procedure DateKeyPress(Sender: TObject; var Key: Char);
    procedure ednc_104_Wk_Effective_DateExit(Sender: TObject);
    procedure ednc_104_Wk_Clmt_Reply_DateExit(Sender: TObject);
    procedure FormKeyPress(Sender: TObject; var Key: Char);
  private
    { Private declarations }
    globalEditError:boolean;
    saveNc_104_Wk_Effective_Date: tDateTime;
    saveNc_104_Wk_Clmt_Reply_Date: tDateTime;
    procedure ResetInfoLine2;
    procedure fillInForm;
    function validateRevClm: boolean;
    function callRevClm: boolean;
  public
    { Public declarations }
    procedure Loaded; override;
  end;

var
  ReviewBenefitLevelForm: TReviewBenefitLevelForm;

implementation

uses NCMain, NCIniMod, Utilmod1, NCBencal, Utils, uGlobal, ValidateDate, ConvertDate;

{$R *.DFM}

(******************************************************************************)
(*                                                                            *)
(*  Loaded - set active control on form at creation.                          *)
(*                                                                            *)
(******************************************************************************)
procedure TReviewBenefitLevelForm.Loaded;
begin
  inherited;
  ActiveControl:=ednc_104_Wk_Effective_Date;
end;

(******************************************************************************)
(*                                                                            *)
(*  Key Down - preview and process keypresses on form.                        *)
(*                                                                            *)
(******************************************************************************)
procedure TReviewBenefitLevelForm.FormKeyDown(Sender: TObject;
  var Key: Word; Shift: TShiftState);
begin
  case Key of
    VK_F1: begin
           Key:=0;
           Application.HelpCommand(HELP_CONTENTS, 0);
           end;
    VK_F7: begin
           Key:=0;
           close;
           end;
    VK_F10: begin
           Key:=0;
           if validateRevClm then callRevClm;
           end;
  end;
end;

(******************************************************************************)
(*                                                                            *)
(*  Key Press - preview and process keypresses on form.                       *)
(*                                                                            *)
(******************************************************************************)
procedure TReviewBenefitLevelForm.FormKeyPress(Sender: TObject;
  var Key: Char);
begin
  case Key of
    Chr(VK_RETURN):
      begin
        Key:=#0;
        SelectNext(ActiveControl as tWinControl, true, true );
      end;
  end;
end;

(******************************************************************************)
(*                                                                            *)
(*  Form Close                                                                *)
(*                                                                            *)
(******************************************************************************)
procedure TReviewBenefitLevelForm.FormClose(Sender: TObject;
  var Action: TCloseAction);
begin
  action:=caFree;
end;

(******************************************************************************)
(*                                                                            *)
(*  Form Create                                                               *)
(*                                                                            *)
(******************************************************************************)
procedure TReviewBenefitLevelForm.FormCreate(Sender: TObject);
begin
  saveNc_104_Wk_Effective_Date:=dataClaim.nc_104_Wk_Effective_Date;
  saveNc_104_Wk_Clmt_Reply_Date:=dataClaim.nc_104_Wk_Clmt_Reply_Date;
  fillInForm;
  WagelossMainForm.ShowInfoLine2('!Enter the expected 80% Net Effective Date');
  SetFont(Self);
end;

(******************************************************************************)
(*                                                                            *)
(*  Form Destroy                                                              *)
(*                                                                            *)
(******************************************************************************)
procedure TReviewBenefitLevelForm.FormDestroy(Sender: TObject);
begin
  ReviewBenefitLevelForm:=nil;
  WagelossMainForm.ShowInfoLine1('');
  WagelossMainForm.ShowInfoLine2('');
end;

(******************************************************************************)
(*                                                                            *)
(*  Reset Info line for Review Benefit Level Form                             *)
(*                                                                            *)
(******************************************************************************)
procedure TReviewBenefitLevelForm.ResetInfoLine2;
begin
  WagelossMainForm.ShowInfoLine2('F7 - Cancel Benefit Levels  F10 - Update Benefit Levels');
end;

(******************************************************************************)
(*                                                                            *)
(*  Fill in fields for ReviewBenefitLevelForm                                 *)
(*                                                                            *)
(******************************************************************************)
procedure TReviewBenefitLevelForm.fillInForm;
begin
  with dataClaim do
  begin
    lblClaim_No.caption:= Claim_No;
    lblClaim_Suffix.caption:=Claim_Suffix;
    lblClmnts_Name.caption:= pdoxTrim(Clmnts_1st_Name) + ' ' + pdoxTrim(Clmnts_Surname);
    lblClmnts_Add_No_1.caption:= Clmnts_Add_No_1;
    lblClmnts_Add_No_2.caption:= Clmnts_Add_No_2;
    lblSIN.caption:= SIN;
    if Birth_Date > 0 then
       begin
       //lblBirth_Date.caption:= formatdatetime('c',Birth_Date);
       lblBirth_Date.caption:= FormatDateTime('ddddd', Birth_Date);
       end
    else
       lblBirth_Date.caption:= '';
    lblClmnts_Post_Code.caption:=Clmnts_Post_Code;
    lblClmnts_Home_Phone.caption:= Clmnts_Home_Phone;
    lblClmnts_Work_Phone.caption:= Clmnts_Work_Phone;

    if Accident_Date > 0 then
       begin
       //lblAccident_Date.caption:= formatdatetime('c',Accident_Date);
       lblAccident_Date.caption := FormatDateTime('ddddd', Accident_Date);
       end
    else
       lblAccident_Date.caption:= '';

    if Birth_Date > 0 then
       begin
       //lblBirth_Date2.caption:= formatdatetime('c',Birth_Date);
       lblBirth_Date2.caption := FormatDateTime('ddddd', Birth_Date);
       end
    else
       lblBirth_Date2.caption:= '';

    if Loss_Earn_Date > 0 then
       begin
       //lblLoss_Earn_Date.caption:= formatdatetime('c',Loss_Earn_Date);
       lblLoss_Earn_Date.caption := FormatDateTime('ddddd', Loss_Earn_Date);
       end
    else
       lblLoss_Earn_Date.caption:= '';

    lblTot_Comp_Pd_To_Date.caption:= format('%.2n',[Tot_Comp_Pd_To_Date]);

    if Date_Pd_To_Cheq > 0 then
       begin
       //lblDate_Pd_To_Cheq.caption:= formatdatetime('c',Date_Pd_To_Cheq);
       lblDate_Pd_To_Cheq.caption := FormatDateTime('ddddd', Date_Pd_To_Cheq);
       end
    else
       lblDate_Pd_To_Cheq.caption:= '';

    if ( getYearFromAccidentDate(accident_date) >= 2006) then
    begin
      Label18.Caption := '';
      lblNo_Days_Of_Comp_Bnfts.caption := '';
      lblNo_Days_Of_Comp_Bnfts.visible := false;
    end
    else
      lblNo_Days_Of_Comp_Bnfts.caption:= format('%.2n',[No_Days_Of_Comp_Bnfts]);
    lblNo_Weeks_of_Comp_Bnfts.caption:= format('%.2n',[getAnnuityEntitlementWeeks(accident_date, claim_no, No_Weeks_of_Comp_Bnfts)]);

    if nc_104_Wk_Effective_Date > 0 then
       begin
       //ednc_104_Wk_Effective_Date.text := formatdatetime('c',nc_104_Wk_Effective_Date);
       ednc_104_Wk_Effective_Date.text := FormatDateTime('ddddd',nc_104_Wk_Effective_Date);
       end
    else
       ednc_104_Wk_Effective_Date.text := '';

    if nc_104_Wk_Clmt_Reply_Date > 92 then
       begin
       //ednc_104_Wk_Clmt_Reply_Date.text := formatdatetime('c',nc_104_Wk_Clmt_Reply_Date);
       ednc_104_Wk_Clmt_Reply_Date.text := FormatDateTime('ddddd',nc_104_Wk_Clmt_Reply_Date);
       end
    else
       ednc_104_Wk_Clmt_Reply_Date.text:= '';

    //NR81827 - Form displaying wrong label
    if Year(Accident_Date) >= 2006 Then
    begin
      Label74.Caption := 'Effective Date of Annuity Entitlement:';
    end
    else
    begin
      Label74.Caption := 'Effective Date of 80% of Net:';
    end;
  end;
end;

(******************************************************************************)
(*                                                                            *)
(*  Restrict characters for date input.                                       *)
(*                                                                            *)
(******************************************************************************)
procedure TReviewBenefitLevelForm.DateKeyPress(Sender: TObject;
  var Key: Char);
begin
  case Key of
  #0..#31,'0'..'9','/','.':
  else
    Key:=#0;
  end;
end;

(******************************************************************************)
(*                                                                            *)
(*  Validate nc_104_Wk_Effective_Date.                                        *)
(*                                                                            *)
(******************************************************************************)
procedure TReviewBenefitLevelForm.ednc_104_Wk_Effective_DateExit(
  Sender: TObject);
begin
  if not validateAsDate( ednc_104_Wk_Effective_Date ) then
  begin
    globalEditError := displayError( '*Invalid Effective date of 80% of Net', ednc_104_Wk_Effective_Date );
    exit;
  end;

  if ( textAsDate( ednc_104_Wk_Effective_Date ) > 0 ) then
     begin
     //if ( dataclaim.No_Weeks_of_Comp_Bnfts > 95.99 ) then
     if ( getAnnuityEntitlementWeeks(dataClaim.accident_date, dataClaim.claim_no, dataClaim.No_Weeks_of_Comp_Bnfts) > 95.99 ) then
        begin
        if textAsDate( ednc_104_Wk_Clmt_Reply_Date ) < 1 then
           begin
           //ednc_104_Wk_Clmt_Reply_Date.text := formatdatetime('c',textAsDate( ednc_104_Wk_Effective_Date ) + 91);
           ednc_104_Wk_Clmt_Reply_Date.text := formatdatetime('ddddd',textAsDate(ednc_104_Wk_Effective_Date) + 91);
           end;
        end
     else
        begin
        globalEditError:=true;
        WagelossMainForm.ShowInfoLine2('*Cannot update 80% Effective date - weeks paid less than 96.');
        ednc_104_Wk_Effective_Date.setFocus;
        exit;
        end;
     end;

  // ensure Claimant Contrib date is > 2 years after accident date
  if ( textAsDate( ednc_104_Wk_Effective_Date ) > 0 ) then
    if (textAsDate(ednc_104_Wk_Effective_Date) < ( dataclaim.Accident_Date + 727 ) ) then
    begin
      globalEditError := displayError( '*80% Effective Date must be > 2 years past date of incident', ednc_104_Wk_Effective_Date );
      exit;
    end;

  if textAsDate(ednc_104_Wk_Effective_Date) > 0 then
     begin
     //ednc_104_Wk_Effective_Date.text := formatdatetime('c',textAsDate( ednc_104_Wk_Effective_Date ));
     ednc_104_Wk_Effective_Date.text := FormatDateTime('ddddd',textAsDate(ednc_104_Wk_Effective_Date));
     end
  else
     begin
     ednc_104_Wk_Effective_Date.text := '';
     end;

  ResetInfoLine2;
end;

(******************************************************************************)
(*                                                                            *)
(*  Validate ednc_104_Wk_Clmt_Reply_Date.                                     *)
(*                                                                            *)
(******************************************************************************)
procedure TReviewBenefitLevelForm.ednc_104_Wk_Clmt_Reply_DateExit(
  Sender: TObject);
begin
  if not validateAsDate( ednc_104_Wk_Clmt_Reply_Date ) then
  begin
    globalEditError := displayError( '*Invalid Reply By Date', ednc_104_Wk_Clmt_Reply_Date );
    exit;
  end;

  if textAsDate( ednc_104_Wk_Clmt_Reply_Date ) > 0 then
     begin
     if textAsDate( ednc_104_Wk_Effective_Date ) > 0 then
        begin
        if textAsDate( ednc_104_Wk_Clmt_Reply_Date ) < textAsDate( ednc_104_Wk_Effective_Date ) then
           begin
           globalEditError := displayError( '*Reply By Date must be past Effective date.', ednc_104_Wk_Clmt_Reply_Date );
           exit;
           end;
        end;
     end;

  if textAsDate( ednc_104_Wk_Clmt_Reply_Date ) > 0 then
     begin
     //ednc_104_Wk_Clmt_Reply_Date.text:= formatdatetime('c',textAsDate( ednc_104_Wk_Clmt_Reply_Date ));
     ednc_104_Wk_Clmt_Reply_Date.text := FormatDateTime('ddddd', textAsDate(ednc_104_Wk_Clmt_Reply_Date));
     end
  else
     ednc_104_Wk_Clmt_Reply_Date.text:= '';

  ResetInfoLine2;
end;

(******************************************************************************)
(*                                                                            *)
(*  Validate all fields before allowing update.                               *)
(*                                                                            *)
(******************************************************************************)
function TReviewBenefitLevelForm.validateRevClm: boolean;
begin
  globalEditError:=false;

  { make sure system date format hasn't changed }
  result := validateSystemDateFormat;
  if not result then exit;

  // check fields first before forcing exit processing since it sets defaults
  // to blank fields anyway.
  if textAsDate( ednc_104_Wk_Effective_Date ) < 1 then
  begin
    WagelossMainForm.ShowInfoLine2('*Please enter an Effective date of 80% of Net');
    ednc_104_Wk_Effective_Date.setfocus;
    exit;
  end;
  if textAsDate( ednc_104_Wk_Clmt_Reply_Date ) < 1 then
  begin
    WagelossMainForm.ShowInfoLine2('*Please enter a Reply Required by Date');
    ednc_104_Wk_Clmt_Reply_Date.setfocus;
    exit;
  end;
  ednc_104_Wk_Effective_DateExit( ednc_104_Wk_Effective_Date );
  ednc_104_Wk_Clmt_Reply_DateExit( ednc_104_Wk_Clmt_Reply_Date );

  if globalEditError then exit;

  result:=true;
end;

(******************************************************************************)
(*                                                                            *)
(*  Update Claim information                                                  *)
(*                                                                            *)
(******************************************************************************)
function TReviewBenefitLevelForm.callRevClm: boolean;
var
   lngIndex, i:Integer;
   Child:TWagelossBenefitCalcForm;
begin
  result:=false;
  child := nil;
  if ( dataClaim.nc_104_Wk_Effective_Date = textAsDate( ednc_104_Wk_Effective_Date ) ) and
     ( dataClaim. nc_104_Wk_Clmt_Reply_Date = textAsDate( ednc_104_Wk_Clmt_Reply_Date ) ) then
  begin
    WagelossMainForm.ShowInfoLine2('*Update cancelled. No values were changed.');
    exit;
  end;

  if ( ( textAsDate( ednc_104_Wk_Effective_Date ) > 1 ) and
       ( textAsDate( ednc_104_Wk_Clmt_Reply_Date ) < 1 ) ) then
  begin
    ednc_104_Wk_Clmt_Reply_Date.setfocus;
    WagelossMainForm.ShowInfoLine2('*Please enter a Reply Required by Date');
    exit;
  end;

  if ( ( textAsDate( ednc_104_Wk_Effective_Date ) < 1 ) and
       ( textAsDate( ednc_104_Wk_Clmt_Reply_Date ) > 1 ) ) then
  begin
    ednc_104_Wk_Effective_Date.setfocus;
    WagelossMainForm.ShowInfoLine2('*Please enter an Effective date of 80% of Net');
    exit;
  end;


  with dataClaim do
  begin
    nc_104_Wk_Effective_Date:=textAsDate( ednc_104_Wk_Effective_Date );
    nc_104_Wk_Clmt_Reply_Date:=textAsDate( ednc_104_Wk_Clmt_Reply_Date );
  end;

  //
  // See if we can find a Wageloss form already loaded
  //
  lngIndex := WagelossMainForm.MDIChildCount;
  For i := 0 to lngIndex - 1 do
     Begin
     if WagelossMainForm.MDIChildren[i].ClassType = TWagelossBenefitCalcForm Then
        Begin
        Child := WagelossMainForm.MDIChildren[i] as TWagelossBenefitCalcForm;
        If Child.lblAccident_Date.Visible = True then
           Begin
           Break;
           End;
        End;
     End;

  if Child.forceSetClaimInformation( dataClaim ) then
  begin
    result:=true;
      Child.CalcFullClaim.nc_104_Wk_Effective_Date:=dataClaim.nc_104_Wk_Effective_Date;
      Child.CalcFullClaim.nc_104_Wk_Clmt_Reply_Date:=dataClaim.nc_104_Wk_Clmt_Reply_Date;
      Child.CalcPartClaim.nc_104_Wk_Effective_Date:=dataClaim.nc_104_Wk_Effective_Date;
      Child.CalcPartClaim.nc_104_Wk_Clmt_Reply_Date:=dataClaim.nc_104_Wk_Clmt_Reply_Date;
    close;
  end
  else
  begin
    with dataClaim do
    begin
      nc_104_Wk_Effective_Date:=saveNc_104_Wk_Effective_Date;
      nc_104_Wk_Clmt_Reply_Date:=saveNc_104_Wk_Clmt_Reply_Date;
    end;
  end;
end;

end.
