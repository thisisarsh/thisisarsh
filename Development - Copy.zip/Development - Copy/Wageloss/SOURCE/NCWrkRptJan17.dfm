object WrkRptJan17: TWrkRptJan17
  Left = 439
  Top = 119
  Width = 1142
  Height = 656
  Caption = 'WrkRptJan17'
  Color = clBtnFace
  Font.Charset = DEFAULT_CHARSET
  Font.Color = clWindowText
  Font.Height = -11
  Font.Name = 'MS Sans Serif'
  Font.Style = []
  OldCreateOrder = False
  PixelsPerInch = 96
  TextHeight = 13
end
