unit NCSelectYear;

interface

uses
  Windows, Messages, SysUtils, Classes, Graphics, Controls, Forms, Dialogs,
  StdCtrls, Spin;

type
  TSelectYearForm = class(TForm)
    Label1: TLabel;
    edAccidentYear: TSpinEdit;
    OKBtn: TButton;
    CancelBtn: TButton;
    Label2: TLabel;
    edAccidentMonth: TSpinEdit;
    Label3: TLabel;
    edTaxYear: TSpinEdit;
    procedure FormCreate(Sender: TObject);
    procedure OKBtnClick(Sender: TObject);
    procedure CancelBtnClick(Sender: TObject);
    procedure FormClose(Sender: TObject; var Action: TCloseAction);
    procedure edTaxYearChange(Sender: TObject);
    procedure edAccidentYearChange(Sender: TObject);
  private
    { Private declarations }
  public
    { Public declarations }
  end;

var
  SelectYearForm: TSelectYearForm;

implementation

uses Utils, utilmod1;

{$R *.DFM}

procedure TSelectYearForm.FormCreate(Sender: TObject);
var
   iYear, iMonth, iDay:Word;
begin
  DecodeDate( utilmod1.getEmergeBusinessDate(), iYear, iMonth, iDay );
  edAccidentYear.MinValue := 1992;
  edAccidentYear.MaxValue := iYear;
  edAccidentYear.Value := iYear;
  edTaxYear.MinValue := 1992;
  edTaxYear.MaxValue := iYear;
  edTaxYear.Value := iYear;
  edAccidentMonth.MinValue := 1;
  edAccidentMonth.MaxValue := 12;
  edAccidentMonth.Value := iMonth;
  SetFont(Self);
end;

procedure TSelectYearForm.OKBtnClick(Sender: TObject);
begin
  ModalResult := mrOk;
end;

procedure TSelectYearForm.CancelBtnClick(Sender: TObject);
begin
  ModalResult := mrCancel;
end;

procedure TSelectYearForm.FormClose(Sender: TObject; var Action: TCloseAction);
begin
  Action := caFree;
end;

procedure TSelectYearForm.edTaxYearChange(Sender: TObject);
begin
  //
  // Check to see if the tax year is <= to the accident year
  //
  if (edTaxYear.Value < edAccidentYear.Value) Then
    edTaxYear.Value := edAccidentYear.Value;
end;

procedure TSelectYearForm.edAccidentYearChange(Sender: TObject);
begin
  //
  // Check to see if the tax year is <= to the accident year
  //
  if (edTaxYear.Value < edAccidentYear.Value) Then
    edTaxYear.Value := edAccidentYear.Value;
end;

end.
