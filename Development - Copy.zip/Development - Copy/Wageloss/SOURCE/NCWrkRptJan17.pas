unit NCWrkRptJan17;

interface

uses
  Windows, Messages, SysUtils, Variants, Classes, Graphics, Controls, Forms,
  Dialogs, NCWrkRptJul16;

type
  TWrkRptJan17 = class(TWrkRptJul16)
  function getDateHeading():String; Override;
  private
    { Private declarations }
  public
    { Public declarations }
  end;

var
  WrkRptJan17: TWrkRptJan17;

implementation

{$R *.dfm}

function TWrkRptJan17.getDateHeading: String;
begin
  result:='2016/2017'
end;


end.
