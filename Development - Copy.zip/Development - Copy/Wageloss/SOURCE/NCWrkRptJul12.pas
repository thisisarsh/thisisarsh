unit NCWrkRptJul12;

interface

uses
  Windows, Messages, SysUtils, Variants, Classes, Graphics, Controls, Forms,
  Dialogs, NCWrkRptJan12;

type
  TWrkRptJul12 = class(TWrkRptJan12)
  function getDateHeading():String; Override;
  private
    { Private declarations }
  public
    { Public declarations }
  end;

var
  WrkRptJul12: TWrkRptJul12;

implementation

{$R *.dfm}
(******************************************************************************)
(*                                                                            *)
(*  override this function for each class to avoid having to bring in all of  *)
(*    the methods that contain the date in the heading.                       *)
(*   IE:  the jan 09 class should return  2008/2009                           *)
(*        the july 09 class should return 2009                                *)
(*                                                                            *)
(******************************************************************************)

function TWrkRptJul12.getDateHeading():String;
begin
  result:='2012'
end;
end.
