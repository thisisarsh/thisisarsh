object TaxableCollateral: TTaxableCollateral
  Left = 469
  Top = 229
  AutoSize = True
  Caption = 'TaxableCollateral'
  ClientHeight = 268
  ClientWidth = 317
  Color = clBtnFace
  Font.Charset = DEFAULT_CHARSET
  Font.Color = clWindowText
  Font.Height = -14
  Font.Name = 'MS Sans Serif'
  Font.Style = []
  OldCreateOrder = False
  Position = poMainFormCenter
  PixelsPerInch = 120
  TextHeight = 16
  object Label1: TLabel
    Left = 0
    Top = 0
    Width = 216
    Height = 20
    Caption = 'Taxable Collateral Benefits'
    Font.Charset = DEFAULT_CHARSET
    Font.Color = clWindowText
    Font.Height = -16
    Font.Name = 'MS Sans Serif'
    Font.Style = [fsBold]
    ParentFont = False
  end
  object Label2: TLabel
    Left = 0
    Top = 49
    Width = 85
    Height = 20
    Caption = 'CPP/QPP: '
    Font.Charset = DEFAULT_CHARSET
    Font.Color = clWindowText
    Font.Height = -16
    Font.Name = 'MS Sans Serif'
    Font.Style = [fsBold]
    ParentFont = False
  end
  object Label3: TLabel
    Left = 0
    Top = 89
    Width = 29
    Height = 20
    Caption = 'EI: '
    Font.Charset = DEFAULT_CHARSET
    Font.Color = clWindowText
    Font.Height = -16
    Font.Name = 'MS Sans Serif'
    Font.Style = [fsBold]
    ParentFont = False
  end
  object Label4: TLabel
    Left = 0
    Top = 128
    Width = 168
    Height = 20
    Caption = 'Disability Insurance: '
    Font.Charset = DEFAULT_CHARSET
    Font.Color = clWindowText
    Font.Height = -16
    Font.Name = 'MS Sans Serif'
    Font.Style = [fsBold]
    ParentFont = False
  end
  object Label6: TLabel
    Left = 0
    Top = 167
    Width = 56
    Height = 20
    Caption = 'Other: '
    Font.Charset = DEFAULT_CHARSET
    Font.Color = clWindowText
    Font.Height = -16
    Font.Name = 'MS Sans Serif'
    Font.Style = [fsBold]
    ParentFont = False
  end
  object edCPPQPP: TEdit
    Left = 168
    Top = 49
    Width = 149
    Height = 29
    Color = clAqua
    Ctl3D = False
    Font.Charset = ANSI_CHARSET
    Font.Color = clWindowText
    Font.Height = -20
    Font.Name = 'Arial'
    Font.Style = []
    MaxLength = 12
    ParentCtl3D = False
    ParentFont = False
    TabOrder = 0
    OnExit = edCPPQPPExit
  end
  object edEI: TEdit
    Left = 168
    Top = 89
    Width = 149
    Height = 29
    Color = clAqua
    Ctl3D = False
    Font.Charset = ANSI_CHARSET
    Font.Color = clWindowText
    Font.Height = -20
    Font.Name = 'Arial'
    Font.Style = []
    MaxLength = 12
    ParentCtl3D = False
    ParentFont = False
    TabOrder = 1
    OnExit = edEIExit
  end
  object edDisabilityInsurance: TEdit
    Left = 168
    Top = 128
    Width = 149
    Height = 29
    Color = clAqua
    Ctl3D = False
    Font.Charset = ANSI_CHARSET
    Font.Color = clWindowText
    Font.Height = -20
    Font.Name = 'Arial'
    Font.Style = []
    MaxLength = 12
    ParentCtl3D = False
    ParentFont = False
    TabOrder = 2
    OnExit = edDisabilityInsuranceExit
  end
  object btnOK: TButton
    Left = 59
    Top = 238
    Width = 92
    Height = 30
    Caption = 'OK'
    Font.Charset = DEFAULT_CHARSET
    Font.Color = clWindowText
    Font.Height = -15
    Font.Name = 'MS Sans Serif'
    Font.Style = []
    ParentFont = False
    TabOrder = 4
    OnClick = btnOKClick
  end
  object brnCancel: TButton
    Left = 187
    Top = 238
    Width = 92
    Height = 30
    Caption = 'Cancel'
    TabOrder = 5
    OnClick = brnCancelClick
  end
  object edCombination: TEdit
    Left = 168
    Top = 167
    Width = 149
    Height = 29
    Color = clAqua
    Ctl3D = False
    Font.Charset = ANSI_CHARSET
    Font.Color = clWindowText
    Font.Height = -20
    Font.Name = 'Arial'
    Font.Style = []
    MaxLength = 12
    ParentCtl3D = False
    ParentFont = False
    TabOrder = 3
    OnExit = edCombinationExit
  end
end
