unit NCWrkRptJan16;

interface

uses
  Windows, Messages, SysUtils, Variants, Classes, Graphics, Controls, Forms,
  Dialogs, NCWrkRptJul15;

type
  TWrkRptJan16 = class(TWrkRptJul15)
  function getDateHeading():String; Override;
  private
    { Private declarations }
  public
    { Public declarations }
  end;

var
  WrkRptJan16: TWrkRptJan16;

implementation

{$R *.dfm}

{ TWrkRptJan16 }

function TWrkRptJan16.getDateHeading: String;
begin
  result:='2015/2016'
end;

end.
