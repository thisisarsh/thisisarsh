inherited WrkRptJul10: TWrkRptJul10
  Caption = 'WrkRptJul10'
  PixelsPerInch = 96
  TextHeight = 13
end
