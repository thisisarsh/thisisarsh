object frmQATestList: TfrmQATestList
  Left = 335
  Top = 173
  Caption = 'QATestList'
  ClientHeight = 618
  ClientWidth = 1126
  Color = clBtnFace
  Font.Charset = DEFAULT_CHARSET
  Font.Color = clWindowText
  Font.Height = -11
  Font.Name = 'MS Sans Serif'
  Font.Style = []
  FormStyle = fsMDIChild
  OldCreateOrder = False
  Position = poDefault
  Visible = True
  OnClose = FormClose
  OnCreate = FormCreate
  OnShow = FormShow
  PixelsPerInch = 96
  TextHeight = 13
  object Panel1: TPanel
    Left = 0
    Top = 0
    Width = 1126
    Height = 92
    Align = alTop
    BevelInner = bvLowered
    BevelOuter = bvSpace
    Font.Charset = DEFAULT_CHARSET
    Font.Color = clWindowText
    Font.Height = -13
    Font.Name = 'Tahoma'
    Font.Style = []
    ParentFont = False
    TabOrder = 0
    object lblSearchField: TLabel
      Left = 11
      Top = 26
      Width = 81
      Height = 13
      Caption = 'lblSearchField'
      Font.Charset = DEFAULT_CHARSET
      Font.Color = clWindowText
      Font.Height = -11
      Font.Name = 'MS Sans Serif'
      Font.Style = [fsBold]
      ParentFont = False
    end
    object Label1: TLabel
      Left = 912
      Top = 26
      Width = 81
      Height = 13
      Caption = 'Accident Year'
      Font.Charset = DEFAULT_CHARSET
      Font.Color = clWindowText
      Font.Height = -11
      Font.Name = 'MS Sans Serif'
      Font.Style = [fsBold]
      ParentFont = False
    end
    object Label22: TLabel
      Left = 224
      Top = 26
      Width = 92
      Height = 13
      Caption = 'Go to Bookmark'
      Font.Charset = DEFAULT_CHARSET
      Font.Color = clWindowText
      Font.Height = -11
      Font.Name = 'MS Sans Serif'
      Font.Style = [fsBold]
      ParentFont = False
    end
    object Label24: TLabel
      Left = 600
      Top = 23
      Width = 44
      Height = 16
      Caption = 'Label24'
      Visible = False
    end
    object Edit1: TEdit
      Left = 8
      Top = 43
      Width = 209
      Height = 24
      TabOrder = 0
      OnChange = Edit1Change
    end
    object CheckBox1: TCheckBox
      Left = 8
      Top = 69
      Width = 177
      Height = 17
      Caption = 'Search && &Filter Records'
      TabOrder = 1
      OnClick = CheckBox1Click
    end
    object Button3: TButton
      Left = 464
      Top = 42
      Width = 75
      Height = 25
      Caption = 'BookMark'
      Font.Charset = DEFAULT_CHARSET
      Font.Color = clWindowText
      Font.Height = -11
      Font.Name = 'MS Sans Serif'
      Font.Style = [fsBold]
      ParentFont = False
      TabOrder = 2
      OnClick = Button3Click
    end
    object ComboBox2: TComboBox
      Left = 224
      Top = 43
      Width = 233
      Height = 24
      TabOrder = 3
      OnChange = ComboBox2Change
    end
    object ComboBox1: TComboBox
      Left = 600
      Top = 45
      Width = 257
      Height = 22
      Style = csOwnerDrawFixed
      TabOrder = 4
      Visible = False
      OnDrawItem = ComboBox1DrawItem
      OnSelect = ComboBox1Select
      Items.Strings = (
        'Jan'
        'Feb'
        'Mar'
        'Apr'
        'May'
        'Jun'
        'Jul'
        'Aug'
        'Sep'
        'Oct'
        'Nov'
        'Dec')
    end
    object cmbYear: TComboBox
      Left = 912
      Top = 43
      Width = 145
      Height = 24
      TabOrder = 5
      OnChange = cmbYearChange
    end
    object cbxIndexationOnly: TCheckBox
      Left = 913
      Top = 68
      Width = 136
      Height = 17
      Caption = '&Indexation Only'
      TabOrder = 6
      OnClick = cmbYearChange
    end
  end
  object Panel2: TPanel
    Left = 0
    Top = 576
    Width = 1126
    Height = 42
    Align = alBottom
    TabOrder = 1
    object Panel3: TPanel
      Left = 776
      Top = 1
      Width = 349
      Height = 40
      Align = alRight
      BevelOuter = bvNone
      TabOrder = 0
      object DBNavigator1: TDBNavigator
        Left = 28
        Top = 7
        Width = 284
        Height = 28
        DataSource = DataSource1
        VisibleButtons = [nbFirst, nbPrior, nbNext, nbLast]
        TabOrder = 0
      end
    end
    object btnRefreshData: TBitBtn
      Left = 15
      Top = 10
      Width = 113
      Height = 25
      Caption = 'Refresh Data'
      Font.Charset = DEFAULT_CHARSET
      Font.Color = clWindowText
      Font.Height = -11
      Font.Name = 'MS Sans Serif'
      Font.Style = [fsBold]
      ParentFont = False
      TabOrder = 1
      TabStop = False
      OnClick = btnRefreshDataClick
    end
  end
  object dbgridQAData: TDBGrid
    Left = 0
    Top = 92
    Width = 1126
    Height = 484
    Align = alClient
    BorderStyle = bsNone
    DataSource = DataSource1
    Font.Charset = DEFAULT_CHARSET
    Font.Color = clWindowText
    Font.Height = -13
    Font.Name = 'Calibri'
    Font.Style = []
    Options = [dgTitles, dgColumnResize, dgColLines, dgRowLines, dgTabs, dgRowSelect, dgAlwaysShowSelection, dgConfirmDelete, dgCancelOnExit]
    ParentFont = False
    PopupMenu = PopupMenu1
    TabOrder = 2
    TitleFont.Charset = DEFAULT_CHARSET
    TitleFont.Color = clWindowText
    TitleFont.Height = -16
    TitleFont.Name = 'Tahoma'
    TitleFont.Style = []
    OnDrawColumnCell = dbgridQADataDrawColumnCell
    OnDblClick = dbgridQADataDblClick
    OnKeyPress = dbgridQADataKeyPress
    OnKeyUp = dbgridQADataKeyUp
    OnTitleClick = dbgridQADataTitleClick
    Columns = <
      item
        Expanded = False
        FieldName = 'QADataID'
        Visible = True
      end
      item
        Expanded = False
        FieldName = 'QATestID'
        Width = 123
        Visible = True
      end
      item
        Expanded = False
        FieldName = 'Indexed_Year'
        Visible = True
      end
      item
        Expanded = False
        FieldName = 'QADataDescription'
        Width = 150
        Visible = True
      end
      item
        Expanded = False
        FieldName = 'Claim_Year'
        Visible = True
      end
      item
        Expanded = False
        FieldName = 'Claim_No'
        Visible = False
      end
      item
        Expanded = False
        FieldName = 'Claim_Suffix'
        Visible = True
      end
      item
        Expanded = False
        FieldName = 'Clmt_Name'
        Visible = False
      end
      item
        Expanded = False
        FieldName = 'Clmt_Address_1'
        Visible = False
      end
      item
        Expanded = False
        FieldName = 'Clmt_Address_2'
        Visible = False
      end
      item
        Expanded = False
        FieldName = 'Clmt_Address_3'
        Visible = False
      end
      item
        Expanded = False
        FieldName = 'Clmt_Postal_Code'
        Visible = False
      end
      item
        Expanded = False
        FieldName = 'Clmt_SIN'
        Visible = False
      end
      item
        Expanded = False
        FieldName = 'Clmt_DOB'
        Visible = False
      end
      item
        Expanded = False
        FieldName = 'Clmt_Home_Phone'
        Visible = False
      end
      item
        Expanded = False
        FieldName = 'Clmt_Work_Phone'
        Visible = False
      end
      item
        Expanded = False
        FieldName = 'Accident_Date'
        Visible = True
      end
      item
        Expanded = False
        FieldName = 'Weekly_Wage'
        Visible = True
      end
      item
        Expanded = False
        FieldName = 'Tax_Year'
        Visible = True
      end
      item
        Expanded = False
        FieldName = 'Full_Annual_Gross'
        Title.Caption = 'Full_Annual_Gross/Max Adjustment'
        Visible = True
      end
      item
        Expanded = False
        FieldName = 'effectiveDate'
        Visible = True
      end
      item
        Expanded = False
        FieldName = 'Indexed_Date'
        Width = 103
        Visible = True
      end
      item
        Expanded = False
        FieldName = 'Recurence'
        Visible = True
      end
      item
        Expanded = False
        FieldName = 'Recurrence_Date'
        Visible = True
      end
      item
        Expanded = False
        FieldName = 'Days_Week'
        Visible = True
      end
      item
        Expanded = False
        FieldName = 'Loss_Of_Earnings_Date'
        Visible = True
      end
      item
        Expanded = False
        FieldName = 'Youthful_Worker'
        Visible = True
      end
      item
        Expanded = False
        FieldName = 'Self_Employed'
        Visible = True
      end
      item
        Expanded = False
        FieldName = 'Marital_Status'
        Width = 96
        Visible = True
      end
      item
        Expanded = False
        FieldName = 'Spouse_Working'
        Visible = True
      end
      item
        Expanded = False
        FieldName = 'ClaimSpouseForTaxPurposes'
        Visible = True
      end
      item
        Expanded = False
        FieldName = 'Nbr_Of_Dependants'
        Visible = True
      end
      item
        Expanded = False
        FieldName = 'Nbr_Of_Infirm_Deps'
        Visible = True
      end
      item
        Expanded = False
        FieldName = 'Uic_Exempt'
        Visible = True
      end
      item
        Expanded = False
        FieldName = 'CPP_Exempt'
        Visible = True
      end
      item
        Expanded = False
        FieldName = 'Income_Tax_Exempt'
        Visible = True
      end
      item
        Expanded = False
        FieldName = 'Child_Care_Expense'
        Visible = True
      end
      item
        Expanded = False
        FieldName = 'Spousal_Support'
        Visible = True
      end
      item
        Expanded = False
        FieldName = 'Child_Support'
        Visible = True
      end
      item
        Expanded = False
        FieldName = 'Inc_Tax_Fed'
        Visible = False
      end
      item
        Expanded = False
        FieldName = 'Inc_Tax_Prov'
        Visible = False
      end
      item
        Expanded = False
        FieldName = 'Cpp_Prem'
        Visible = False
      end
      item
        Expanded = False
        FieldName = 'Uic_Prem'
        Visible = False
      end
      item
        Expanded = False
        FieldName = 'Total_Deds'
        Visible = False
      end
      item
        Expanded = False
        FieldName = 'Weekly_Deds'
        Visible = False
      end
      item
        Expanded = False
        FieldName = 'Collateral_Taxable'
        Visible = True
      end
      item
        Expanded = False
        FieldName = 'Collateral_Taxable_Net'
        Visible = False
      end
      item
        Expanded = False
        FieldName = 'Collateral_Non_Taxable'
        Visible = True
      end
      item
        Expanded = False
        FieldName = 'Post_Earn_Weekly_Gross'
        Visible = True
      end
      item
        Expanded = False
        FieldName = 'Post_Earn_Weekly_Net'
        Visible = True
      end
      item
        Expanded = False
        FieldName = '80_Effective_Date'
        Visible = False
      end
      item
        Expanded = False
        FieldName = 'Clmnt_Contrib_Effective_Date'
        Visible = False
      end
      item
        Expanded = False
        FieldName = 'Full_Weekly_Gross'
        Visible = False
      end
      item
        Expanded = False
        FieldName = 'Full_Weekly_Net_Loss_Earn'
        Visible = False
      end
      item
        Expanded = False
        FieldName = 'Full_Annual_Net_Loss_Earn'
        Visible = False
      end
      item
        Expanded = False
        FieldName = 'Full_Weekly_90_Net_Actual'
        Visible = False
      end
      item
        Expanded = False
        FieldName = 'Full_Weekly_90_Net_Loss'
        Visible = False
      end
      item
        Expanded = False
        FieldName = 'Full_Annual_90_Net_Loss'
        Visible = False
      end
      item
        Expanded = False
        FieldName = 'Full_Weekly_Tax_Sheltering'
        Visible = False
      end
      item
        Expanded = False
        FieldName = 'Full_Weekly_90_Net_Sheltered'
        Visible = False
      end
      item
        Expanded = False
        FieldName = 'Full_Annual_90_Net_Sheltered'
        Visible = False
      end
      item
        Expanded = False
        FieldName = 'Full_Weekly_Daily_Comp_Rate'
        Visible = False
      end
      item
        Expanded = False
        FieldName = 'Full_Weekly_80_Net_Loss'
        Visible = False
      end
      item
        Expanded = False
        FieldName = 'Full_Annual_80_Net_Loss'
        Visible = False
      end
      item
        Expanded = False
        FieldName = 'Full_Weekly_80_Net_Sheltered'
        Visible = False
      end
      item
        Expanded = False
        FieldName = 'Full_Annual_80_Net_Sheltered'
        Visible = False
      end
      item
        Expanded = False
        FieldName = 'Full_Clmnt_Percent_Contrib'
        Width = 154
        Visible = True
      end
      item
        Expanded = False
        FieldName = 'Full_Clmnt_Contrib'
        Width = 141
        Visible = True
      end
      item
        Expanded = False
        FieldName = 'Full_Weekly_80_Clmnt_Net_Contri'
        Visible = False
      end
      item
        Expanded = False
        FieldName = 'Full_Annual_80_Clmnt_Net_Contri'
        Visible = False
      end
      item
        Expanded = False
        FieldName = 'Full_WCB_Percent_Contrib'
        Visible = True
      end
      item
        Expanded = False
        FieldName = 'Full_WCB_Contrib'
        Visible = True
      end
      item
        Expanded = False
        FieldName = 'Full_Weekly_Adjusted_Daily_Comp'
        Visible = False
      end
      item
        Expanded = False
        FieldName = 'Partial_Net_Pre_Injury'
        Visible = False
      end
      item
        Expanded = False
        FieldName = 'Partial_Net_Post_Injury'
        Visible = False
      end
      item
        Expanded = False
        FieldName = 'Partial_Net_Loss_Earn'
        Visible = False
      end
      item
        Expanded = False
        FieldName = 'Partial_90_Net_Loss_Earn'
        Visible = False
      end
      item
        Expanded = False
        FieldName = 'Partial_Tax_Sheltering'
        Visible = False
      end
      item
        Expanded = False
        FieldName = 'Partial_90_Net_Sheltered'
        Visible = False
      end
      item
        Expanded = False
        FieldName = 'Partial_Daily_Comp_Rate'
        Visible = False
      end
      item
        Expanded = False
        FieldName = 'Partial_80_Net_Loss'
        Visible = False
      end
      item
        Expanded = False
        FieldName = 'Partial_80_Net_Sheltered'
        Visible = False
      end
      item
        Expanded = False
        FieldName = 'Partial_Clmnt_Percent_Contrib'
        Visible = False
      end
      item
        Expanded = False
        FieldName = 'Partial_Clmnt_Contrib'
        Visible = False
      end
      item
        Expanded = False
        FieldName = 'Partial_80_Net_Contrib'
        Visible = False
      end
      item
        Expanded = False
        FieldName = 'Partial_WCB_Percent_Contrib'
        Visible = False
      end
      item
        Expanded = False
        FieldName = 'Partial_WCB_Contrib'
        Visible = False
      end
      item
        Expanded = False
        FieldName = 'Partial_80_Daily_Comp_Rate'
        Visible = False
      end
      item
        Expanded = False
        FieldName = 'Apprentice'
        Visible = True
      end
      item
        Expanded = False
        FieldName = 'Deemed'
        Visible = True
      end
      item
        Expanded = False
        FieldName = 'AvgEarningsBasedOn'
        Width = 156
        Visible = True
      end
      item
        Expanded = False
        FieldName = 'EmergeIndicator'
        Visible = False
      end
      item
        Expanded = False
        FieldName = 'weekly_min_wage'
        Visible = False
      end
      item
        Expanded = False
        FieldName = 'weekly_shelter_benefit'
        Visible = False
      end
      item
        Expanded = False
        FieldName = 'min_wage_indicator'
        Visible = False
      end
      item
        Expanded = False
        FieldName = 'coll_ben_type'
        Visible = False
      end
      item
        Expanded = False
        FieldName = 'weekly_shelter_ben_90'
        Visible = False
      end
      item
        Expanded = False
        FieldName = 'annual_net_a'
        Visible = False
      end
      item
        Expanded = False
        FieldName = 'net_coll_ben'
        Visible = True
      end
      item
        Expanded = False
        FieldName = 'Weekly_Sal'
        Visible = False
      end
      item
        Expanded = False
        FieldName = 'weekly_min_wage_net'
        Visible = True
      end
      item
        Expanded = False
        FieldName = 'min_wage_ind_partial'
        Visible = False
      end
      item
        Expanded = False
        FieldName = 'DeathBenefit'
        Visible = False
      end
      item
        Expanded = False
        FieldName = 'NonTaxable_Coll_Ben_Type'
        Visible = False
      end
      item
        Expanded = False
        FieldName = 'QATestIndexID'
        Visible = True
      end>
  end
  object DataSource1: TDataSource
    DataSet = qryQATestList
    Left = 288
    Top = 176
  end
  object PopupMenu1: TPopupMenu
    Left = 320
    Top = 240
    object Edit2: TMenuItem
      Caption = 'Edit'
      OnClick = Edit2Click
    end
    object Delete1: TMenuItem
      Caption = 'Delete'
      OnClick = Delete1Click
    end
    object NewAttachtoIndex1: TMenuItem
      Caption = 'New Attach to Index'
      OnClick = NewAttachtoIndex1Click
    end
  end
  object qryQATestList: TADOQuery
    Connection = dm1.db1
    CursorType = ctStatic
    OnFilterRecord = qryQATestListFilterRecord
    Parameters = <>
    SQL.Strings = (
      'select * '
      'from QAData '
      'where Tax_Year = -1'
      'order by QATestID, Indexed_Year')
    Left = 192
    Top = 248
  end
  object Q: TADOQuery
    Connection = dm1.db1
    Parameters = <>
    SQL.Strings = (
      'select distinct Year(Accident_Date) '
      'from QAData '
      'order by Year(Accident_Date)')
    Left = 408
    Top = 248
  end
end
