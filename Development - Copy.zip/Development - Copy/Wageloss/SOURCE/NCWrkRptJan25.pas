unit NCWrkRptJan25;

interface

uses
  Winapi.Windows, Winapi.Messages, System.SysUtils, System.Variants, System.Classes, Vcl.Graphics,
  Vcl.Controls, Vcl.Forms, Vcl.Dialogs, NCWrkRptJul24;

type
  TWrkRptJan25 = class(TWrkRptJul24)
  private
    { Private declarations }
  public
    { Public declarations }
  end;

var
  WrkRptJan25: TWrkRptJan25;

implementation

{$R *.dfm}

end.
