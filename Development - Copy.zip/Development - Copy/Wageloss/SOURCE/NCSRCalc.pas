(*****************************************************************)
(*  Wageloss System                                              *)
(*                                                                *)
(*  Shelter Rebate Calculator                                    *)
(*                                                               *)
(*                                                               *)
(*  Author: Brad Trupp  / Capella Systems Group, Inc.            *)
(*  Date:   Nov 1998                                             *)
(*****************************************************************)

unit NCSRCalc;

interface

uses
  Windows, Messages, SysUtils, Classes, Graphics, Controls, Forms, Dialogs,
  StdCtrls, ComCtrls, NCRecdef, NCIniMod, ExtCtrls, DBCtrls,
  System.UITypes, Math;
  //WLDEBUG;

type
  TShelterRebateCalculatorForm = class(TForm)
    ScrollBox1: TScrollBox;
    Label2: TLabel;
    edClaim_No: TEdit;
    edClmnts_1st_Name: TEdit;
    edClmnts_Surname: TEdit;
    edClmnts_Add_No_1: TEdit;
    edClmnts_Add_No_2: TEdit;
    edClmnts_Post_Code: TEdit;
    edWkly_Sal_A: TEdit;
    Label1: TLabel;
    Label5: TLabel;
    Label6: TLabel;
    Label7: TLabel;
    Label8: TLabel;
    Label9: TLabel;
    edTax_Year: TEdit;
    edEI_Exempt: TEdit;
    edNo_Of_Dependnts: TEdit;
    edNo_Infirm: TEdit;
    Label10: TLabel;
    Label11: TLabel;
    Label12: TLabel;
    Label13: TLabel;
    Label14: TLabel;
    edCollateral_Ben_Tax: TEdit;
    edCollateral_Ben_Non_Tax: TEdit;
    edPost_Injury_Earn: TEdit;
    Label16: TLabel;
    edSpouse_Working: TEdit;
    Bevel1: TBevel;
    Label17: TLabel;
    Label51: TLabel;
    Label57: TLabel;
    Label58: TLabel;
    edShelter_Rebate_Year: TEdit;
    edAccum_Wks_Yr_PdCst: TEdit;
    edAccum_Wks_Yr_90Net: TEdit;
    Label32: TLabel;
    Label33: TLabel;
    Label34: TLabel;
    Label35: TLabel;
    Label36: TLabel;
    Label37: TLabel;
    lblInc_Tax_Fed: TLabel;
    lblInc_Tax_Man: TLabel;
    lblCPP_Prem: TLabel;
    lblEI_Prem: TLabel;
    lblTotal_Deds: TLabel;
    Label40: TLabel;
    Label41: TLabel;
    Label42: TLabel;
    Label44: TLabel;
    Label45: TLabel;
    lblWkly_Sal_A: TLabel;
    lblWeekly_Net: TLabel;
    lblAnnual_Gross: TLabel;
    lblAnnual_Net: TLabel;
    Label52: TLabel;
    Label53: TLabel;
    Label54: TLabel;
    lblWeekly_90: TLabel;
    lblCalcTaxSheltering: TLabel;
    lblWeekly_90_S: TLabel;
    Label59: TLabel;
    Label60: TLabel;
    Label64: TLabel;
    lblSRWeeks_Worked2: TLabel;
    Label66: TLabel;
    lblSRTotal_Deds2: TLabel;
    Label68: TLabel;
    lblSRTotal_Deds_P_A2: TLabel;
    lblSRTotal_Deds_A2: TLabel;
    lblSRTax_Shelter_Bnft2: TLabel;
    Label75: TLabel;
    Label76: TLabel;
    lblSRShelter_Rebate_Year2: TLabel;
    Label82: TLabel;
    Label83: TLabel;
    lblSRAccum_Wks_Yr_90Net3: TLabel;
    Label85: TLabel;
    lnlSRWkly_Tax_S3: TLabel;
    Label87: TLabel;
    lblSRTax_Shelter_Deduct3: TLabel;
    lblSRTax_Shelter_Bnft3: TLabel;
    lblSRRebate_Amount3: TLabel;
    Label94: TLabel;
    Label95: TLabel;
    lblSRShelter_Rebate_Year3: TLabel;
    Label100: TLabel;
    Label101: TLabel;
    Label18: TLabel;
    Label19: TLabel;
    Label20: TLabel;
    Label21: TLabel;
    lblWeeks_Worked: TLabel;
    lblAnnual_Gross_A: TLabel;
    lblAnnual_Net_A: TLabel;
    Bevel2: TBevel;
    Label22: TLabel;
    Bevel3: TBevel;
    Bevel4: TBevel;
    Bevel5: TBevel;
    Label24: TLabel;
    Label29: TLabel;
    Label30: TLabel;
    Label31: TLabel;
    Label38: TLabel;
    Label39: TLabel;
    lblActualInc_Tax_Fed: TLabel;
    lblActualInc_Tax_Man: TLabel;
    lblActualCPP_Prem: TLabel;
    lblActualEI_Prem: TLabel;
    lblActualTotal_Deds: TLabel;
    Label3: TLabel;
    edAccident_Date: TEdit;
    edMax_Adjustments: TEdit;
    Label15: TLabel;
    edRecurrence: TEdit;
    Label25: TLabel;
    Label65: TLabel;
    edSelf_Employed: TEdit;
    Label27: TLabel;
    Label28: TLabel;
    edCPP_Exempt: TEdit;
    edTax_Exempt: TEdit;
    Label26: TLabel;
    Label43: TLabel;
    edChild_Care_Exp: TEdit;
    edSpousal_Support: TEdit;
    edNumberShelterDeduct: TEdit;
    Label47: TLabel;
    edRecurrenceDate: TEdit;
    Label4: TLabel;
    edYouthful_Worker: TEdit;
    cboMaritalStatus: TDBLookupComboBox;
    Label48: TLabel;
    edAccum_Wks_Yr_90NetPost: TEdit;
    Label23: TLabel;
    lblRebatePreAnnuity3: TLabel;
    Label49: TLabel;
    Label50: TLabel;
    lblWorkerAnnuityPercent: TLabel;
    Label62: TLabel;
    lblRebatePreAnnuity3b: TLabel;
    Label55: TLabel;
    lblWorkerAnnuityAmt: TLabel;
    Bevel6: TBevel;
    Label56: TLabel;
    Label72: TLabel;
    lblDisplayWeeks90NetPost: TLabel;
    Label81: TLabel;
    lblDisplayWeeksCompensation: TLabel;
    Label74: TLabel;
    lblDisplayShelterBeforeAnnuity: TLabel;
    Label78: TLabel;
    lblDisplayAnnuityEarnings: TLabel;
    lblWCBAnnuityAmt: TLabel;
    Label63: TLabel;
    lblRebatePreAnnuity3c: TLabel;
    Label67: TLabel;
    lblWCBAnnuityPercent: TLabel;
    Label70: TLabel;
    Label71: TLabel;
    edWorkerContribution: TEdit;
    edWCBContribution: TEdit;
    Label61: TLabel;
    Label69: TLabel;
    edIndexYear: TEdit;
    Label73: TLabel;
    lblClaimSpouseForTaxPurposes: TLabel;
    edClaimSpouseForTaxPurposes: TEdit;
    Label46: TLabel;
    lblCPP2_Prem: TLabel;
    Label77: TLabel;
    lblActualCPP2_Prem: TLabel;
    procedure FormClose(Sender: TObject; var Action: TCloseAction);
    procedure FormDestroy(Sender: TObject);
    procedure FormKeyDown(Sender: TObject; var Key: Word; Shift: TShiftState);
    procedure IntegerKeyPress(Sender: TObject; var Key: Char);
    procedure DoubleKeyPress(Sender: TObject; var Key: Char);
    procedure edWkly_Sal_AExit(Sender: TObject);
    procedure edTax_YearExit(Sender: TObject);
    procedure edSpouse_WorkingExit(Sender: TObject);
    procedure edEI_ExemptExit(Sender: TObject);
    procedure edNo_Of_DependntsExit(Sender: TObject);
    procedure edNo_InfirmExit(Sender: TObject);
    procedure edCollateral_Ben_TaxExit(Sender: TObject);
    procedure edCollateral_Ben_Non_TaxExit(Sender: TObject);
    procedure edPost_Injury_EarnExit(Sender: TObject);
    procedure edEI_ExemptKeyPress(Sender: TObject; var Key: Char);
    procedure edSpouse_WorkingKeyPress(Sender: TObject; var Key: Char);
    procedure edClmnts_Post_CodeKeyPress(Sender: TObject; var Key: Char);
    procedure edClmnts_Post_CodeExit(Sender: TObject);
    procedure FormCreate(Sender: TObject);
    procedure FormKeyPress(Sender: TObject; var Key: Char);
    procedure FormActivate(Sender: TObject);
    procedure edShelter_Rebate_YearExit(Sender: TObject);
    procedure edAccum_Wks_Yr_PdCstExit(Sender: TObject);
    procedure edAccum_Wks_Yr_90NetExit(Sender: TObject);
    procedure editWeeks();
    procedure edTax_ExemptExit(Sender: TObject);
    procedure edTax_ExemptKeyPress(Sender: TObject; var Key: Char);
    procedure edCPP_ExemptExit(Sender: TObject);
    procedure edCPP_ExemptKeyPress(Sender: TObject; var Key: Char);
    procedure edSelf_EmployedExit(Sender: TObject);
    procedure edSelf_EmployedKeyPress(Sender: TObject; var Key: Char);
    procedure edRecurrenceExit(Sender: TObject);
    procedure edRecurrenceKeyPress(Sender: TObject; var Key: Char);
    procedure edMax_AdjustmentsExit(Sender: TObject);
    procedure edChild_Care_ExpExit(Sender: TObject);
    procedure edSpousal_SupportExit(Sender: TObject);
    procedure edAccident_DateExit(Sender: TObject);
    procedure edAccident_DateKeyPress(Sender: TObject; var Key: Char);
    procedure edNumberShelterDeductExit(Sender: TObject);
    procedure edRecurrenceDateExit(Sender: TObject);
    procedure edYouthful_WorkerKeyPress(Sender: TObject; var Key: Char);
    procedure edYouthful_WorkerExit(Sender: TObject);
    procedure ScrollBox1MouseWheelDown(Sender: TObject; Shift: TShiftState; MousePos: TPoint; var Handled: Boolean);
    procedure ScrollBox1MouseWheelUp(Sender: TObject; Shift: TShiftState; MousePos: TPoint; var Handled: Boolean);
    procedure cboMaritalStatusExit(Sender: TObject);
    procedure cboMaritalStatusClick(Sender: TObject);
    procedure cboMaritalStatusKeyDown(Sender: TObject; var Key: Word;
      Shift: TShiftState);
    procedure edAccum_Wks_Yr_90NetPostExit(Sender: TObject);
    procedure edWorkerContributionExit(Sender: TObject);
    procedure edWCBContributionExit(Sender: TObject);
    procedure FormResize(Sender: TObject);
    procedure edClaimSpouseForTaxPurposesKeyPress(Sender: TObject;
      var Key: Char);
    procedure edClaimSpouseForTaxPurposesExit(Sender: TObject);
    procedure edIndexYearExit(Sender: TObject);
  private
    { Private declarations }
    globalEditError: boolean;
    fSRClaim : recWLREBDTL;
    function DoBenCalc: boolean;
    procedure PrintShelterRebaterCalcReport;
    procedure ResetCalc;
    procedure ResetInfoLine2;
    //procedure RecalcBen;
    procedure fillInForm;
    procedure RecalcShelterRebate;
  public
    { Public declarations }
    dataBenCalc:recNCCLAIM;
    CalcFullClaim, CalcPartClaim: recNCCLAIM;
    fWorking : recConst;
  end;

var
  ShelterRebateCalculatorForm: TShelterRebateCalculatorForm;
  blnMarital_Status_Change, isIndexation:Boolean;

implementation

{$R *.DFM}

uses utilmod1, NCMain, NCBenRpt, QPreview, NCSRDTLR, uGlobal, Utils, NCDatMod,
     ValidateDate, ConvertDate;

(******************************************************************************)
(*                                                                            *)
(*  Form Close                                                                *)
(*                                                                            *)
(******************************************************************************)
procedure TShelterRebateCalculatorForm.FormClose(Sender: TObject; var Action: TCloseAction);
begin
  Action:=caFree;
end;

(******************************************************************************)
(*                                                                            *)
(*  Form Destroy                                                              *)
(*                                                                            *)
(******************************************************************************)
procedure TShelterRebateCalculatorForm.FormDestroy(Sender: TObject);
begin
  ShelterRebateCalculatorForm:=nil;
  WagelossMainForm.ShowInfoLine1('');
  WagelossMainForm.ShowInfoLine2('');
end;

(******************************************************************************)
(*                                                                            *)
(*  Key Down - preview and process keypresses on form.                        *)
(*                                                                            *)
(******************************************************************************)
procedure TShelterRebateCalculatorForm.FormKeyDown(Sender: TObject;
  var Key: Word; Shift: TShiftState);
begin
  case Key of
    27: begin
         Key:=0;
         close;
         end;
    VK_F1: begin
           Key:=0;
           Application.HelpCommand(HELP_CONTENTS, 0);
           end;
    VK_F3: begin
           Key:=0;
           resetCalc;
           end;
    VK_F7: begin
           Key:=0;
           close;
           end;
    VK_F8: begin
           Key := 0;
           ScrollBox1.VertScrollBar.Position := ScrollBox1.VertScrollBar.Range;
           if DoBenCalc then
              PrintShelterRebaterCalcReport;
           end;
    VK_F9: begin
           Key:=0;
           scrollbox1.VertScrollBar.position := scrollbox1.VertScrollBar.range;
           DoBenCalc;
           end;
    VK_NEXT: begin
           Key:=0;
           scrollbox1.VertScrollBar.position:=scrollbox1.VertScrollBar.range;
           end;
    VK_PRIOR: begin
           Key:=0;
           scrollbox1.VertScrollBar.position:=0;
           end;
  end;
end;

(******************************************************************************)
(*                                                                            *)
(*  Key Press - preview and process keypresses on form.                       *)
(*                                                                            *)
(******************************************************************************)
procedure TShelterRebateCalculatorForm.FormKeyPress(Sender: TObject;
  var Key: Char);
begin
  case Key of
    Chr(VK_RETURN):
      begin
        Key:=#0;
        SelectNext(ActiveControl as tWinControl, true, true );
      end;
  end;
end;

(******************************************************************************)
(*                                                                            *)
(*  Ensure keys presses are valid for integer                                 *)
(*                                                                            *)
(******************************************************************************)
procedure TShelterRebateCalculatorForm.IntegerKeyPress(Sender: TObject;
  var Key: Char);
begin
  case Key of
  #0..#31,'0'..'9':
  else
    Key:=#0;
  end;
end;

(******************************************************************************)
(*                                                                            *)
(*  Ensure keys presses are valid for a double or float or currency           *)
(*                                                                            *)
(******************************************************************************)
procedure TShelterRebateCalculatorForm.DoubleKeyPress(Sender: TObject;
  var Key: Char);
begin
  case Key of
  #0..#31,'0'..'9','.','+':
  else
    Key:=#0;
  end;
end;

(******************************************************************************)
(*                                                                            *)
(*  Perform Benefit Calculation.                                              *)
(*                                                                            *)
(*    - Validate edit fields, calculate, and display.                         *)
(*                                                                            *)
(******************************************************************************)
function TShelterRebateCalculatorForm.DoBenCalc: boolean;
var
  res: boolean;
  ws: shortstring;
  Annual_Max, Annual_Min:Currency;
  strAnnualMax:String;
  iIndexationYear:integer;
begin
  result:=false;
  ResetInfoLine2;

  { make sure system date format hasn't changed }
  res := validateSystemDateFormat;
  if not res then exit;

  { validate all fields }
  res := validateAsDate( edAccident_Date );
  if not res then exit;
  res := validateAsCurrency( edWkly_Sal_A );
  if not res then exit;
  res := validateAsCurrency( edMax_Adjustments );
  if not res then exit;
  res := validateAsInteger( edTax_Year );
  if not res then exit;
  res := validateAsInteger( edIndexYear );
  if not res then exit;
  res := validateAsInteger( edNo_Of_Dependnts );
  if not res then exit;
  res := validateAsInteger( edNo_Infirm );
  if not res then exit;
  res := validateAsCurrency( edCollateral_Ben_Tax );
  if not res then exit;
  res := validateAsCurrency( edCollateral_Ben_Non_Tax );
  if not res then exit;
  res := validateAsCurrency( edPost_Injury_Earn );
  if not res then exit;
  res := validateAsCurrency( edChild_Care_Exp );
  if not res then exit;
  res := validateAsCurrency( edSpousal_Support );
  if not res then exit;
  { validate shelter rebate fields }
  res := validateAsInteger( edShelter_Rebate_Year );
  if not res then exit;
  res := validateAsCurrency( edAccum_Wks_Yr_PdCst );
  if not res then exit;
  res := validateAsCurrency( edAccum_Wks_Yr_90Net );
  if not res then exit;
  res := validateAsCurrency( edAccum_Wks_Yr_90NetPost );
  if not res then exit;
  res := validateAsCurrency( edNumberShelterDeduct );
  if not res then exit;
  res := validateAsDate( edRecurrenceDate );
  if not res then exit;
  globalEditError:=false;
  edTax_YearExit( edTax_Year );
  if globalEditError then exit;
  // make sure an accident date was entered
  if length( edAccident_Date.text ) < 1 then
  begin
    edAccident_Date.setfocus;
    WagelossMainForm.ShowInfoLine2('*Please enter an Incident Date.');
    exit;
  end;
  // Support payment fields are not valid for pre-2001 claims
  if year(textAsDate(edAccident_Date)) < 2001 then
  begin
    edChild_Care_Exp.text:='0';
    edSpousal_Support.text:='0';
    setEditToRead(edChild_Care_Exp);
    setEditToRead(edSpousal_Support);
  end
  else
  begin
    setEditToNormal(edChild_Care_Exp);
    setEditToNormal(edSpousal_Support);
  end;
  // make sure a wage was entered
  if ( textAsCurrency( edWkly_Sal_A ) < 0.01 ) then
  begin
    edWkly_Sal_A.setfocus;
    WagelossMainForm.ShowInfoLine2('*Please enter a weekly wage.');
    exit;
  end;

  edRecurrence.text := uppercase(edRecurrence.text);
  if (edRecurrence.Text <> 'Y') and (edRecurrence.Text <> 'N') then
  begin
    edRecurrence.setfocus;
    WagelossMainForm.ShowInfoLine2('*Valid values for Recurrence are Y N');
    exit;
  end;

  edSelf_Employed.text := uppercase(edSelf_Employed.text);
  if (edSelf_Employed.Text <> 'Y') and (edSelf_Employed.Text <> 'N') then
  begin
    edSelf_Employed.setfocus;
    WagelossMainForm.ShowInfoLine2('*Valid values for Self Employed are Y N');
    exit;
  end;

  if (edRecurrence.text='Y') and ((edSelf_employed.text='N') or (edSelf_employed.text=''))
    and (GetOldRecurrenceInd='N') then
  begin
    edRecurrenceDate.Visible := True;
    If Length(edRecurrenceDate.text) < 1 then
    begin
      edRecurrenceDate.setfocus;
      WagelossMainForm.ShowInfoLine2('*Please enter a Recurrence Date.');
      exit;
    end;
  end
  else
  begin
    edRecurrenceDate.text := '';
    edRecurrenceDate.Visible := False;
  end;

  if (edRecurrence.Text='N') and (edSelf_Employed.Text='N') then
     begin
     edMax_Adjustments.Text :='0';
     setEditToRead(edMax_Adjustments);
     end
  else
     begin
     if ((edSelf_Employed.Text='Y')) and (not edMax_Adjustments.Enabled) then
        begin
        if MessageDlg('Do you wish to change the Max Adjustment amount?',
                      mtConfirmation, [mbYes, mbNo], 0, mbNo) = mrYes then
           begin
           if Length(Trim(edIndexYear.Text)) > 0  then
              iIndexationYear := StrToInt(Trim(edIndexYear.Text))
           else
              iIndexationYear := 0;
           Annual_Max := getMaxAdjustment(CalcFullClaim.Accident_Date, CalcFullClaim.RecurrenceDate, iIndexationYear, Trim(edRecurrence.Text), Trim(edSelf_Employed.Text));
           Annual_Min := getMinAdjustment(CalcFullClaim.Accident_Date, CalcFullClaim.RecurrenceDate, iIndexationYear, Trim(edRecurrence.Text), Trim(edSelf_Employed.Text));

           strAnnualMax := '?Max Adj amount must be >= ' + format('%.2n', [Annual_Min]);
           if (Annual_Max > 0) then
              begin
              strAnnualMax := strAnnualMax + ' and <= ' + format('%.2n', [Annual_Max]);
              end;

           WagelossMainForm.ShowInfoLine2(strAnnualMax);
           setEditToNormal(edMax_Adjustments);
           edMax_Adjustments.SetFocus;
           exit;
           end
        else
           begin
           setEditToRead(edMax_Adjustments);
           end;
        end;
     end;

  ws:= copy(edSpouse_Working.Text,1,1);
  case ws[1] of
  'Y','N':
  else
    edSpouse_Working.setFocus;
    WagelossMainForm.ShowInfoLine2('*Valid values for Spouse Working are Y N');
  end;
  ws:= copy(edEI_Exempt.Text,1,1);
  case ws[1] of
   'Y','N':
  else
  begin
    edEI_Exempt.setfocus;
    WagelossMainForm.ShowInfoLine2('*Valid values for EI Exempt are Y N');
    exit;
  end;
  end;

  ws:= copy(edYouthful_Worker.Text,1,1);
  case ws[1] of
   'Y','N':
  else
     begin
     edYouthful_Worker.setfocus;
     WagelossMainForm.ShowInfoLine2('*Valid values for Youthful Worker are Y N');
     Exit;
     end;
  end;

  ws:= copy(edCPP_Exempt.Text,1,1);
  case ws[1] of
   'Y','N':
  else
  begin
    edCPP_Exempt.setfocus;
    WagelossMainForm.ShowInfoLine2('*Valid values for CPP Exempt are Y N');
    exit;
  end;
  end;

  ws:= copy(edTax_Exempt.Text,1,1);
  case ws[1] of
   'Y','N':
  else
  begin
    edTax_Exempt.setfocus;
    WagelossMainForm.ShowInfoLine2('*Valid values for Income Tax Exempt are Y N');
    exit;
  end;
  end;
    { validate shelter rebate fields fields }
    // do exit processing on all fields to enforce exit edits
  if edShelter_Rebate_Year.enabled then edShelter_Rebate_YearExit(edShelter_Rebate_Year);
  if globalEditError then exit;
  if edAccum_Wks_Yr_PdCst.enabled then edAccum_Wks_Yr_PdCstExit(edAccum_Wks_Yr_PdCst);
  if globalEditError then exit;
  if (edAccum_Wks_Yr_90Net.enabled or edAccum_Wks_Yr_90NetPost.Enabled) then editWeeks();
  if globalEditError then exit;
  if edPost_Injury_Earn.enabled then edPost_Injury_EarnExit(edPost_Injury_Earn);
  if globalEditError then exit;
  if edNumberShelterDeduct.enabled then edNumberShelterDeductExit(edNumberShelterDeduct);
  if globalEditError then exit;
   { fill in dataBenCalc record }
  ClearNCCLAIM( dataBenCalc );

  //workDate := textAsDate(edAccident_Date);
  //if ((year(workDate) <> textAsInteger(edTax_Year )) and ((month(workDate) = 6) or (month(workDate) = 12))) then
  //begin
  //  DecodeDate(workDate, workYear, workMonth, workDay);
  //  workMonth := workMonth - 6;
  //  if (workMonth) = 0 then workMonth := 12;
  //  workDate := EncodeDate(workYear, workMonth, workDay);
  //end;

  dataBenCalc.Claim_No:= edClaim_No.text;
  dataBenCalc.Clmnts_1st_Name:= edClmnts_1st_Name.text;
  dataBenCalc.Clmnts_Surname:= edClmnts_Surname.text;
  dataBenCalc.Clmnts_Add_No_1:= edClmnts_Add_No_1.text;
  dataBenCalc.Clmnts_Add_No_2:= edClmnts_Add_No_2.text;
  dataBenCalc.Clmnts_Post_Code:= edClmnts_Post_Code.text;
  dataBenCalc.Wkly_Sal_A:= textAsCurrency(edWkly_Sal_A);
  dataBenCalc.Days_Worked_per_Week:= 5; // set default since field not entered.
  dataBenCalc.Tax_Year:= textAsInteger(edTax_Year );
  dataBenCalc.Marital_Status := cboMaritalStatus.KeyValue;
  dataBenCalc.Spouse_Working := edSpouse_Working.Text;
  dataBenCalc.ClaimSpouseForTaxPurposes := edClaimSpouseForTaxPurposes.Text;
  dataBenCalc.EI_Exempt:= edEI_Exempt.text;
  dataBenCalc.No_Of_Dependnts:= textAsInteger(edNo_Of_Dependnts);
  dataBenCalc.No_Infirm:= textAsInteger(edNo_Infirm);
  dataBenCalc.Collateral_Ben_Tax:= textAsCurrency(edCollateral_Ben_Tax);
  dataBenCalc.Collateral_Ben_Non_Tax:= textAsCurrency(edCollateral_Ben_Non_Tax);
  dataBenCalc.Post_Injury_Earn:= textAsCurrency(edPost_Injury_Earn);
  dataBenCalc.nc_104_Wk_WCB_p_Contrib_Red:= 0;  // set default since field not entered.
  dataBenCalc.nc_104_Wk_Clmt_p_Contrib:=0;  // set default since field not entered.
  dataBenCalc.Self_Employed:=edSelf_Employed.text;
  dataBenCalc.Recurrence:=edRecurrence.text;
  dataBenCalc.CPP_Exempt:=edCPP_Exempt.text;
  dataBenCalc.Tax_Exempt:=edTax_Exempt.text;
  dataBenCalc.Child_Care_Exp:=textAsCurrency(edChild_Care_Exp);
  dataBenCalc.Spousal_Support:=textAsCurrency(edSpousal_Support);
  dataBenCalc.Max_Adjustment:=textAsCurrency(edMax_Adjustments);
  dataBenCalc.Accident_Date:=textAsDate(edAccident_Date);
  dataBenCalc.RecurrenceDate := textAsDate(edRecurrenceDate);
  dataBenCalc.Youthful_Worker := edYouthful_Worker.Text;
  dataBenCalc.wcbAnnuityContributionPercent :=  textAsCurrency(edWCBContribution);
  dataBenCalc.workerAnnuityContributionPercent := textAsCurrency(edWorkerContribution);

  try
    copyNCCLAIM( dataBenCalc, CalcFullClaim);
    copyNCCLAIM( dataBenCalc, CalcPartClaim);
    //RecalcBen;
    RecalcShelterRebate;
    fillInForm;
    copyNCCLAIM( CalcPartClaim, dataBenCalc );
  except
    ;
  end;
  result:=true;
  ResetInfoLine2;
end;

(******************************************************************************)
(*                                                                            *)
(*  Recalculate Benefits                                                      *)
(*                                                                            *)
(******************************************************************************)
//procedure TShelterRebateCalculatorForm.RecalcBen;
//var
//  savePost_Injury_Earn: currency;
//begin
//  { call ben calc }
//	//copyNCCLAIM( CalcFullClaim, CalcPartClaim);
//  savePost_Injury_Earn:=CalcFullClaim.Post_Injury_Earn;
//  CalcFullClaim.Post_Injury_Earn := 0.0;
//  //uglobal.RecalcBen(CalcFullClaim, fPartialClaim, false);
//  //Calc_Ben(CalcFullClaim, fWorking);
//  //uglobal.RecalcBen(CalcPartClaim, fPartialClaim, false);
//  //Calc_Ben(CalcPartClaim, fWorking);
//  uGlobal.SetUpAndRecalcBen(fSRClaim, edNumberShelterDeduct.enabled, textAsCurrency( edNumberShelterDeduct ));
//  CalcFullClaim.Post_Injury_Earn := savePost_Injury_Earn;
//end;

(******************************************************************************)
(*                                                                            *)
(*  Calculate Shelter Rebate Amounts                                          *)
(*                                                                            *)
(******************************************************************************)
procedure TShelterRebateCalculatorForm.RecalcShelterRebate;
var
    fClaim: recNCCLAIM;
    saveWkly_Sal_A: currency;
begin
  // load fClaim with valid values from claim benefit calc.
  saveWkly_Sal_A := CalcFullClaim.Wkly_Sal_A;
  clearWLREBDTL( fSRClaim );
  fSRClaim.Accident_Date := textAsDate(edAccident_Date);
  fSRClaim.Claim_No := pdoxtrim(edClaim_No.text);
  fSRClaim.Claim_Suffix := '';
  fSRClaim.Clmt_Name_Initials := pdoxtrim(edClmnts_Surname.text) + ', ' + pdoxtrim(edClmnts_Surname.text);
  fSRClaim.Tax_Year := textAsInteger(edTax_Year );
  fSRClaim.Marital_Status := cboMaritalStatus.KeyValue;
  fSRClaim.Spouse_Working := edSpouse_Working.text;
  fSRClaim.ClaimSpouseForTaxPurposes := edClaimSpouseForTaxPurposes.Text;
  fSRClaim.Nbr_Of_Dependants := textAsInteger(edNo_Of_Dependnts);
  fSRClaim.Nbr_Of_Infirm_Deps := textAsInteger(edNo_Infirm);
  fSRClaim.Uic_Exempt := edEI_Exempt.text;
  fSRClaim.Wkly_Sal_A := textAsCurrency(edWkly_Sal_A);
  //fSRClaim.Wkly_Sal := textAsCurrency(edWkly_Sal_A);
  fSRClaim.Prime_Firm_No := '00000';

  // Apply updates from edit fields
  fSRClaim.Accum_Wks_Yr_PdCst:=textAsCurrency( edAccum_Wks_Yr_PdCst );
  fSRClaim.Accum_Wks_Yr_90Net:=textAsCurrency( edAccum_Wks_Yr_90Net );
  fSRClaim.Accum_Wks_Yr_90Net_Post:=textAsCurrency( edAccum_Wks_Yr_90NetPost );

  if edNumberShelterDeduct.enabled then
  	fSRClaim.Accum_Wks_Yr_90Net:=textAsCurrency( edNumberShelterDeduct );

  fSRClaim.Shelter_Rebate_Year:=textAsInteger( edShelter_Rebate_Year );

  // The rest of this routine is same as TShelterRebateEditForm.RecalcBen;
  fSRClaim.Wkly_Sal := saveWkly_Sal_A; // <=== override
  fSRClaim.Annual_Gross := fSRClaim.Wkly_Sal * 52;
  fSRClaim.Weeks_Worked := 52 - fSRClaim.Accum_Wks_Yr_PdCst;

  if fSRClaim.Weeks_Worked < 0 then
     fSRClaim.Weeks_Worked := 0;

  fSRClaim.Annual_Gross_A := fSRClaim.Wkly_Sal * fSRClaim.Weeks_Worked;
  fSRClaim.Wkly_Sal_A := fSRClaim.Annual_Gross_A / 52;
  fSRClaim.Self_Employed:=edSelf_Employed.text;
  fSRClaim.Recurrence:=edRecurrence.text;
  fSRClaim.CPP_Exempt:=edCPP_Exempt.text;
  fSRClaim.Tax_Exempt:=edTax_Exempt.text;
  fSRClaim.Child_Care_Exp:=textAsCurrency(edChild_Care_Exp);
  fSRClaim.Spousal_Support:=fClaim.Spousal_Support;
  fSRClaim.Child_Support:=textAsCurrency(edSpousal_Support);
  fSRClaim.Max_Adjustment:=textAsCurrency(edMax_Adjustments);
  fSRClaim.Nbr_Act_Shelter_Deduct := textAsCurrency(edNumberShelterDeduct);
  fSRClaim.Recurrence_Date := textAsDate(edRecurrenceDate);
  fSRClaim.Youthful_Worker := edYouthful_Worker.Text;
  fSRClaim.wcbAnnuityContributionPercent := textAsCurrency(edWCBContribution);
  fSRClaim.workerAnnuityContributionPercent := textAsCurrency(edWorkerContribution);
  fSRClaim.indexationYear := textAsInteger(edIndexYear );
  fSRClaim.collateralTaxableAmt := textAsCurrency(edCollateral_Ben_Tax);
  fSRClaim.collateralNonTaxableAmt := textAsCurrency(edCollateral_Ben_Non_Tax);
  fSRClaim.Max_Adjustment := textAsCurrency(edMax_Adjustments);
  uGlobal.SetUpAndRecalcBen(fSRClaim, edNumberShelterDeduct.enabled, textAsCurrency( edNumberShelterDeduct ));
end;

(******************************************************************************)
(*                                                                            *)
(*   Validate Wkly_Sal_A                                                      *)
(*                                                                            *)
(******************************************************************************)
procedure TShelterRebateCalculatorForm.edWkly_Sal_AExit(Sender: TObject);
begin
  edWkly_Sal_A.text:=format('%.2n',[ textAsCurrency(edWkly_Sal_A) ] );
  ResetInfoLine2;
end;

(******************************************************************************)
(*                                                                            *)
(*  Validate Tax_Year                                                         *)
(*                                                                            *)
(******************************************************************************)
procedure TShelterRebateCalculatorForm.edTax_YearExit(Sender: TObject);
var
  isFound: boolean;
  iii, TestTax_Year, TestShelter_Rebate_Year, testClaimYear: Integer;
  s: string;
  TestAccidentDate, Work_Date, TestRecurrenceDate: TDateTime;
  Work_Year, Work_Month, Work_Day:Word;
begin
  if edTax_Year.text = '' then
     edTax_Year.Text := FormatDateTime('yyyy', utilmod1.getEmergeBusinessDate() );

  isFound := False;

  // Get values from TAX CODE TABLE
  TestTax_Year := TextAsInteger(edTax_Year);
  TestAccidentDate := StrToDate(edAccident_Date.Text);
  testClaimYear := year(StrToDate(edAccident_Date.Text));

  If length( edRecurrenceDate.text ) > 0 then
     TestRecurrenceDate := StrToDate(edRecurrenceDate.Text)
  else
    TestRecurrenceDate := 0;

  SetTaxYear(TestAccidentDate, TestRecurrenceDate, TestTax_Year);

  for iii := low(arrayNCTAXRAT) to high(arrayNCTAXRAT) do
     begin
     if (arrayNCTAXRAT[iii].Tax_Year = GetTaxYear) and
        (arrayNCTAXRAT[iii].Tax_Year > 1991) then
        begin
        isFound := True;
        break;
        end
     end;

  if not isFound then
  begin
    globalEditError := displayError( '*Please enter a valid tax year', edTax_Year );
    Exit;
  end;


  // Test the on screen tax year contained in the TestTax_Year variable
  //
  // First check to see if we have a future date
  //
  If TestRecurrenceDate <> 0 Then
     Work_Date := TestRecurrenceDate
  else
     Work_Date := TestAccidentDate;

  DecodeDate(Work_Date, Work_Year, Work_Month, Work_Day);

  if ((testTax_Year = NCMain.cnst_Max_Tax_Year) And (Work_Month > NCMain.cnst_Max_Tax_Month)) OR
      (testTax_Year > NCMain.cnst_Max_Tax_Year)                                   Then
     begin
     globalEditError := displayError( '*Please enter a valid tax year', edTax_Year );
     exit;
     end;

  // for claims side only - cross check Tax Year against Accident Year
  // Tax year must be greater than or equal to the year
  // of the accident
  //
  if  (UPPERCASE(edRecurrence.text) <> 'Y') then
     iii := TestTax_Year - year(TestAccidentDate)
  else
     iii := TestTax_Year - year(TestRecurrenceDate);

  if (iii  < 0) then
     begin
     if  (UPPERCASE(edRecurrence.text) <> 'Y') then
        globalEditError := displayError( '*Tax year must be on or after the incident year', edTax_Year )
     else
        globalEditError := displayError( '*Tax year must be on or after year of the recurrence', edTax_Year );
     exit;
     end;

  if (iii = 1) and (UPPERCASE(edRecurrence.text) <> 'Y') then
     begin
     globalEditError := displayError( '*Tax year cannot be the year following the incident', edTax_Year );
     exit;
     end;

  testShelter_Rebate_Year := textAsInteger(edShelter_Rebate_Year);

  if (testShelter_Rebate_Year > 0) then
     begin
     if ( testTax_Year > testShelter_Rebate_Year ) then
        begin
        globalEditError := displayError( '*Tax year can not be greater than Claim Shelter Rebate year', edTax_Year );
        exit;
        end;
     end;

  try
     if (length(edClaim_No.Text) > 2) then
        begin
        //s := copy( edClaim_No.text,1,2);
        //if ( s > '20' ) then
        //   testClaimYear :=  1900 + strToInt( s )
        //else
        //   testClaimYear :=  2000 + strToInt( s );

        if (testTax_Year < testClaimYear) then
           begin
           globalEditError := displayError( '*Tax year can not be prior to Incident year', edTax_Year );
           exit;
           end;
        end;
  except
     ;
  end;

  ResetInfoLine2;
end;

(******************************************************************************)
(*                                                                            *)
(*  Validate Spouse_Working                                                   *)
(*                                                                            *)
(******************************************************************************)
procedure TShelterRebateCalculatorForm.edSpouse_WorkingExit(Sender: TObject);
begin
  edSpouse_Working.text := UpperCase( edSpouse_Working.Text );
  //
  // set the defaults if the field is blank
  //
  if (edSpouse_Working.Text = '') and
      ((UpperCase( cboMaritalStatus.Text) = 'DIVORCED')  or
       (upperCase( cboMaritalStatus.Text) = 'SEPARATED') or
       (UpperCase( cboMaritalStatus.Text) = 'SINGLE')    or
       (UpperCase( cboMaritalStatus.Text) = 'WIDOWED'))  then
     begin
     edSpouse_Working.Text := 'N';
     edClaimSpouseForTaxPurposes.Visible := false;
     lblClaimSpouseForTaxPurposes.Visible := false;
     edClaimSpouseForTaxPurposes.Text := '';
     end
  else
     begin
     if (edSpouse_Working.text = '')                         And
        ((upperCase( cboMaritalStatus.Text) = 'MARRIED')     or
         (upperCase( cboMaritalStatus.Text) = 'COMMON-LAW')) then
        begin
        edSpouse_Working.Text := 'Y';
        edClaimSpouseForTaxPurposes.Visible := false;
        lblClaimSpouseForTaxPurposes.Visible := false;
        edClaimSpouseForTaxPurposes.Text := '';
        end;
     end;

  if ((upperCase(cboMaritalStatus.Text) = 'DIVORCED')  or
      (upperCase(cboMaritalStatus.Text) = 'SEPARATED') or
      (upperCase(cboMaritalStatus.Text) = 'SINGLE')    or
      (upperCase(cboMaritalStatus.Text) = 'WIDOWED'))  and
      (edSpouse_Working.text <>'N' )                   then
     begin
     edSpouse_Working.Text := 'N';
     globalEditError := displayError( '*Spouse Working changed to "N" for Marital Status Single, Divorced, Separated, or Widowed', edSpouse_Working );
     exit;
     end;


  if (edSpouse_Working.Text = 'N') and Not (edClaimSpouseForTaxPurposes.Visible) then
     begin
     edClaimSpouseForTaxPurposes.Visible := true;
     lblClaimSpouseForTaxPurposes.Visible := true;
     if Length(edRecurrenceDate.text) < 1 then
    	  begin
      	edClaimSpouseForTaxPurposes.SetFocus;
      	exit;
    	  end
     else
        begin
    	  edClaimSpouseForTaxPurposes.Text := '';
        edClaimSpouseForTaxPurposes.SetFocus;
        end;
     end
  else
     if (edSpouse_Working.Text = 'Y') And edClaimSpouseForTaxPurposes.Visible Then
        begin
        edClaimSpouseForTaxPurposes.text := '';
        edClaimSpouseForTaxPurposes.Visible := False;
        lblClaimSpouseForTaxPurposes.Visible := true;
        end;



  ResetInfoLine2;
end;

(******************************************************************************)
(*                                                                            *)
(*  Validate EI/UIC_Exempt                                                       *)
(*                                                                            *)
(******************************************************************************)
procedure TShelterRebateCalculatorForm.edEI_ExemptExit(Sender: TObject);
begin
  if edEI_Exempt.text='' then edEI_Exempt.text:='N';
  edEI_Exempt.text := uppercase(edEI_Exempt.text);
  ResetInfoLine2;
end;

(******************************************************************************)
(*                                                                            *)
(*  Validate No_Of_Dependents                                                 *)
(*                                                                            *)
(******************************************************************************)
procedure TShelterRebateCalculatorForm.edNo_Of_DependntsExit(Sender: TObject);
var
  i: integer;
begin
  if edNo_Of_Dependnts.text='' then edNo_Of_Dependnts.text:='0';
  if not validateAsInteger( edNo_Of_Dependnts ) then
  begin
    globalEditError := displayError( '*Invalid No. Of Dependents', edNo_Of_Dependnts );
    exit;
  end;
  i:=textAsInteger(edNo_Of_Dependnts);
  if ( i < 0 ) or ( i > 99 ) then
  begin
    globalEditError := displayError( '*No Of Dependents must be between 0 and 99', edNo_Of_Dependnts );
    exit;
  end;
  edNo_Of_Dependnts.text:=format('%d',[ textAsInteger(edNo_Of_Dependnts) ] );
  ResetInfoLine2;
end;

(******************************************************************************)
(*                                                                            *)
(*  Validate No_Infirm                                                        *)
(*                                                                            *)
(******************************************************************************)
procedure TShelterRebateCalculatorForm.edNo_InfirmExit(Sender: TObject);
var
  i: integer;
begin
  if edNo_Infirm.text='' then edNo_Infirm.text:='0';
  if not validateAsInteger( edNo_Infirm ) then
  begin
    globalEditError := displayError( '*Invalid No. Of Infirm Dependents', edNo_Infirm );
    exit;
  end;
  i:=textAsInteger(edNo_Infirm);
  if ( i < 0 ) or ( i > 99 ) then
  begin
    globalEditError := displayError( '*No Of Infirm Dependents must be between 0 and 99', edNo_Infirm );
    exit;
  end;
  edNo_Infirm.text:=format('%d',[ textAsInteger(edNo_Infirm) ] );
  ResetInfoLine2;
end;

(******************************************************************************)
(*                                                                            *)
(*  Validate Collateral_Ben_Tax                                               *)
(*                                                                            *)
(******************************************************************************)
procedure TShelterRebateCalculatorForm.edCollateral_Ben_TaxExit(
  Sender: TObject);
begin
  if edCollateral_Ben_Tax.text='' then edCollateral_Ben_Tax.text:='0';
  edCollateral_Ben_Tax.text:=format('%.2n',[ textAsCurrency(edCollateral_Ben_Tax) ] );
  ResetInfoLine2;
end;

(******************************************************************************)
(*                                                                            *)
(*  Validate Collateral_Ben_Non_Tax                                           *)
(*                                                                            *)
(******************************************************************************)
procedure TShelterRebateCalculatorForm.edCollateral_Ben_Non_TaxExit(
  Sender: TObject);
begin
  if edCollateral_Ben_Non_Tax.text='' then edCollateral_Ben_Non_Tax.text:='0';
  edCollateral_Ben_Non_Tax.text:=format('%.2n',[ textAsCurrency(edCollateral_Ben_Non_Tax) ] );
  ResetInfoLine2;
end;

(******************************************************************************)
(*                                                                            *)
(*  Validate Post_Injury_Earn                                                 *)
(*                                                                            *)
(******************************************************************************)
procedure TShelterRebateCalculatorForm.edPost_Injury_EarnExit(Sender: TObject);
begin
  if edPost_Injury_Earn.text='' then edPost_Injury_Earn.text:='0';
  edPost_Injury_Earn.text:=format('%.2n',[ textAsCurrency(edPost_Injury_Earn) ] );
  if ( textAsCurrency( edPost_Injury_Earn ) < 0.01 ) then
  begin
    edNumberShelterDeduct.text := '0';
    setEditToRead( edNumberShelterDeduct );
    edShelter_Rebate_Year.SetFocus;
  end
  else
  begin
    setEditToNormal(edNumberShelterDeduct);
    edNumberShelterDeduct.SetFocus;
  end;
  ResetInfoLine2;
end;

(******************************************************************************)
(*                                                                            *)
(*  Ket press edit for EI/UIC_Exempt                                             *)
(*                                                                            *)
(******************************************************************************)
procedure TShelterRebateCalculatorForm.edEI_ExemptKeyPress(Sender: TObject;
  var Key: Char);
begin
  case Key of
  #0..#31,'y','Y','n','N':
  else
    Key:=#0;
    WagelossMainForm.ShowInfoLine2('*Valid values for EI Exempt are Y N');
  end;
end;

procedure TShelterRebateCalculatorForm.edIndexYearExit(Sender: TObject);
begin
  // Force the Default
  if edIndexYear.Text = '' then
     edIndexYear.Text := '0';
end;

(******************************************************************************)
(*                                                                            *)
(*  Key press edit for Spouse_Working                                         *)
(*                                                                            *)
(******************************************************************************)
procedure TShelterRebateCalculatorForm.edSpouse_WorkingKeyPress(Sender: TObject;
  var Key: Char);
begin
  case Key of
  #0..#31,'y','Y','n','N':
  else
    Key:=#0;
    WagelossMainForm.ShowInfoLine2('*Valid values for Spouse Working are Y N');
  end;
end;

(******************************************************************************)
(*                                                                            *)
(*  Print Benefit Calculation Report                                          *)
(*                                                                            *)
(******************************************************************************)
procedure TShelterRebateCalculatorForm.PrintShelterRebaterCalcReport;
var
  MyPreview: TQRCustomPreviewForm;
  MyReport: TShelterRebateDetailForm;
begin
  screen.cursor:=crHourGlass;
  try
    MyPreview := TQRCustomPreviewForm.create(application);

    MyReport := TShelterRebateDetailForm.create(Self);
    // store cycle type
    MyReport.fSRDetailReportType := iRecord;
    fSRClaim.Accum_Wks_Yr_90Net := textascurrency(edAccum_Wks_Yr_90Net);
    fSRClaim.Accum_Wks_Yr_90Net_Post := textascurrency(edAccum_Wks_Yr_90NetPost);
    fSRClaim.Nbr_Act_Shelter_Deduct := textascurrency(edNumberShelterDeduct);
    Myreport.fSRClaim := fSRClaim;

    MyPreview.ParentQuickReportForm:=MyReport;
    MyPreview.ParentQuickReport:=MyReport.QRShelterRebateDetailReport;
    MyPreview.caption:='Shelter Rebate Claim Detail - Shelter Rebate Calculator';
    screen.cursor:=crDefault;
    try
      MyReport.QRShelterRebateDetailReport.OnPreview := MyPreview.CustomPreview;
      MyReport.QRShelterRebateDetailReport.Preview;
    finally
      screen.cursor:=crDefault;
    end;
  finally
  screen.cursor:=crDefault;
  end;
end;

(******************************************************************************)
(*                                                                            *)
(*  Reset all Edit fields                                                     *)
(*                                                                            *)
(******************************************************************************)
procedure TShelterRebateCalculatorForm.resetCalc;
begin
  ResetInfoLine2;
  edClaim_No.clear;
  edClmnts_1st_Name.clear;
  edClmnts_Surname.clear;
  edClmnts_Add_No_1.clear;
  edClmnts_Add_No_2.clear;
  edClmnts_Post_Code.clear;
  edWkly_Sal_A.clear;
  edTax_Year.clear;
  edIndexYear.clear;
  // New fields for 2000 policy changes
  edSelf_Employed.clear;
  edRecurrence.clear;
  edCPP_Exempt.clear;
  edTax_Exempt.clear;
  edChild_Care_Exp.clear;
  edSpousal_Support.clear;
  edMax_Adjustments.clear;
  setEditToRead(edMax_Adjustments);
  edAccident_Date.clear;
  edEI_Exempt.clear;
  edNo_Of_Dependnts.clear;
  edNo_Infirm.clear;
  edCollateral_Ben_Tax.clear;
  edCollateral_Ben_Non_Tax.clear;
  edPost_Injury_Earn.clear;
  setEditToNormal(edSpouse_Working);
  edSpouse_Working.clear;
  edClaimSpouseForTaxPurposes.Clear;
  ClearNCCLAIM( CalcFullClaim );
  ClearNCCLAIM( CalcPartClaim );
  fillInForm;
end;

(******************************************************************************)
(*                                                                            *)
(*  Key press edit for Postal Code                                            *)
(*                                                                            *)
(******************************************************************************)
procedure TShelterRebateCalculatorForm.edClmnts_Post_CodeKeyPress(
  Sender: TObject; var Key: Char);
var
  l: integer;
begin
  l := length(edClmnts_Post_Code.text) mod 2;
  case Key of
  #0..#31: begin
      end;
  'a'..'z','A'..'Z': begin
      if l <> 0 then begin Key:=#0; end;
      end;
  '0'..'9': begin
      if l <> 1 then begin Key:=#0; end;
    end;
  else
    Key:=#0;
    WagelossMainForm.ShowInfoLine2('*Postal Code must be A#A#A#');
  end;
end;

(******************************************************************************)
(*                                                                            *)
(*  Validate Postal Code                                                      *)
(*                                                                            *)
(******************************************************************************)
procedure TShelterRebateCalculatorForm.edClaimSpouseForTaxPurposesExit(
  Sender: TObject);
begin

  edClaimSpouseForTaxPurposes.Text := UpperCase(edClaimSpouseForTaxPurposes.Text);

  if (Trim(edClaimSpouseForTaxPurposes.Text) = '') then
     begin
     edClaimSpouseForTaxPurposes.Setfocus;
     WagelossMainForm.ShowInfoLine2( '*Valid values for Claim Spouse For Tax Purposes are Y N' );
     exit;
     end;

  if (CalcFullClaim.ClaimSpouseForTaxPurposes <> edClaimSpouseForTaxPurposes.Text) then
     begin
     CalcFullClaim.ClaimSpouseForTaxPurposes := edClaimSpouseForTaxPurposes.Text;
     end;

  ResetInfoLine2;
end;

procedure TShelterRebateCalculatorForm.edClaimSpouseForTaxPurposesKeyPress(
  Sender: TObject; var Key: Char);
begin
  case Key of
  #0..#31,'y','Y','n','N':
  else
    Key:=#0;
    WagelossMainForm.ShowInfoLine2('*Valid values for Claim Spouse as Dependent are Y N');
  end;
end;

procedure TShelterRebateCalculatorForm.edClmnts_Post_CodeExit(Sender: TObject);
var
  ws: string;
begin
  ws:=edClmnts_Post_Code.text;
  ws:= uppercase(ws);
  edClmnts_Post_Code.text:=ws;
  if ( length(ws) > 0 ) and ( length(ws) <> 6 ) then
  begin
    globalEditError := displayError( '*Invalid Postal Code', edClmnts_Post_Code );
    exit;
  end;
  ResetInfoLine2;
end;

(******************************************************************************)
(*                                                                            *)
(*  Form Create                                                               *)
(*                                                                            *)
(******************************************************************************)
procedure TShelterRebateCalculatorForm.FormCreate(Sender: TObject);
begin
  resetCalc;
  ResetInfoLine2;
  //setEditToRead( edCollateral_Ben_Tax );
  //setEditToRead( edCollateral_Ben_Non_Tax );
  setEditToRead( edNumberShelterDeduct );
  //setEditToRead( edRecurrence );
  edRecurrence.Text := 'N';
  SetOldRecurrenceInd('N');
  edClaimSpouseForTaxPurposes.Visible := false;
  lblClaimSpouseForTaxPurposes.Visible := false;
  SetFont(Self);
end;

(******************************************************************************)
(*                                                                            *)
(*  Reset info line to default value                                          *)
(*                                                                            *)
(******************************************************************************)
procedure TShelterRebateCalculatorForm.ResetInfoLine2;
begin
  WagelossMainForm.ShowInfoLine2('F3 - Clear  F7 - Exit  F8 - Print Report  F9 - Calculate');
end;

(******************************************************************************)
(*                                                                            *)
(*  Fill in form from claim record(s)                                         *)
(*                                                                            *)
(******************************************************************************)
procedure TShelterRebateCalculatorForm.fillInForm;
var
  eligEarn:currency;
begin
  with CalcFullClaim do
  begin
    edCollateral_Ben_Tax.text:=format('%.2n', [ Collateral_Ben_Tax ] );
    edCollateral_Ben_Non_Tax.text:=format('%.2n', [ Collateral_Ben_Non_Tax ] );
    edPost_Injury_Earn.text:=format('%.2n', [ Post_Injury_Earn ] );
  end;
  with fSRClaim do
  begin
      edShelter_Rebate_Year.text := format('%d', [ Shelter_Rebate_Year ] );
      edAccum_Wks_Yr_PdCst.text := format('%.2n', [ Accum_Wks_Yr_PdCst ] );
      lblInc_Tax_Fed.caption := format('%.2n', [ Inc_Tax_Fed ] );
      lblInc_Tax_Man.caption := format('%.2n', [ Inc_Tax_Prov ] );
      lblCPP_Prem.caption := format('%.2n', [ Cpp_Prem ] );
      lblCPP2_Prem.caption := format('%.2n', [ Cpp2_Prem ] );
      lblEI_Prem.caption := format('%.2n', [ Uic_Prem ] );
      lblTotal_Deds.caption := format('%.2n', [ Total_Deds ] );
      lblWkly_Sal_A.caption := format('%.2n', [ Wkly_Sal ] );
      lblWeekly_Net.caption := format('%.2n', [ Wkly_Net ] );
      lblAnnual_Gross.caption := format('%.2n', [ Annual_Gross ] );
      lblAnnual_Net.caption := format('%.2n', [ Annual_Net ] );
      lblWeekly_90.caption := format('%.2n', [ Wkly_90 ] );
      lblCalcTaxSheltering.caption := format('%.2n', [ Wkly_Tax_S ] );
      lblWeekly_90_S.caption := format('%.2n', [ Wkly_90_S ] );
      lblWeeks_Worked.caption := format('%.2n', [ Weeks_Worked ] );
      lblAnnual_Gross_A.caption := format('%.2n', [ Annual_Gross_A ] );
      lblAnnual_Net_A.caption := format('%.2n', [ Annual_Net_A ] );
      lblActualInc_Tax_Fed.caption := format('%.2n', [ Inc_Tax_Fed_A ] );
      lblActualInc_Tax_Man.caption := format('%.2n', [ Inc_Tax_Prov_A ] );
      lblActualCPP_Prem.caption := format('%.2n', [ Cpp_Prem_A ] );
      lblActualCPP2_Prem.caption := format('%.2n', [ Cpp2_Prem_A ] );
      lblActualEI_Prem.caption := format('%.2n', [ Uic_Prem_A ] );
      lblActualTotal_Deds.caption := format('%.2n', [ Total_Deds_A ] );
      lblSRWeeks_Worked2.caption :=  format('%n', [ Weeks_Worked ] );
      lblSRTotal_Deds2.caption := format('%.2n', [ Total_Deds  ] );
      lblSRTotal_Deds_P_A2.caption := format('%.2n', [ Total_Deds_P_A ] );
      lblSRTotal_Deds_A2.caption := format('%.2n', [ Total_Deds_A  ] );
      lblSRTax_Shelter_Bnft2.caption := format('%.2n', [ Tax_Shelter_Bnft  ] );
      lblSRShelter_Rebate_Year2.caption := format('%d', [ Shelter_Rebate_Year ] );
      if (year(Accident_Date) < 2006) then
      begin
        lblSRAccum_Wks_Yr_90Net3.caption := format('%.2n', [ Accum_Wks_Yr_90Net ] );
        if Nbr_Act_Shelter_Deduct > 0 then
          lblSRAccum_Wks_Yr_90Net3.caption := format('%.2n', [ Nbr_Act_Shelter_Deduct ] );
        setEditToRead(edAccum_Wks_Yr_90NetPost);
      end
      else
      begin
        lblSRAccum_Wks_Yr_90Net3.caption := format('%.2n', [ Accum_Wks_Yr_90Net + Accum_Wks_Yr_90Net_Post ] );
        if Nbr_Act_Shelter_Deduct > 0 then
          lblSRAccum_Wks_Yr_90Net3.caption := format('%.2n', [ Nbr_Act_Shelter_Deduct ] );
        setEditToNormal(edAccum_Wks_Yr_90NetPost);
      end;
      lnlSRWkly_Tax_S3.caption := format('%.2n', [ Wkly_Tax_S  ] );
      lblSRTax_Shelter_Deduct3.caption := format('%.2n', [ Tax_Shelter_Deduct  ] );
      lblSRTax_Shelter_Bnft3.caption := format('%.2n', [ Tax_Shelter_Bnft  ] );
      if Accum_Wks_Yr_PdCst <> 0 then
        eligEarn := Accum_Wks_Yr_90Net_Post / Accum_Wks_Yr_PdCst
      else
        eligEarn := 0;
      lblRebatePreAnnuity3.caption := format('%.2n', [ Rebate_Amount + workerShetlerAnnuityContribAmt  ] );
      lblWorkerAnnuityPercent.caption := format('%.2n', [ workerAnnuityContributionPercent  ] ) + '%';
      if year(Accident_Date) > 2005 then
      begin
        lblRebatePreAnnuity3b.caption := format('%.2n', [ (Rebate_Amount + workerShetlerAnnuityContribAmt) *  eligEarn ] );
        lblRebatePreAnnuity3c.caption := format('%.2n', [ (Rebate_Amount + workerShetlerAnnuityContribAmt) *  eligEarn  ] );
        lblDisplayWeeks90NetPost.caption := format('%.2n', [ Accum_Wks_Yr_90Net_Post  ] );
        lblDisplayWeeksCompensation.caption := format('%.2n', [ Accum_Wks_Yr_PdCst  ] );
        lblDisplayShelterBeforeAnnuity.caption := format('%.2n', [ Rebate_Amount + workerShetlerAnnuityContribAmt  ] );
        lblDisplayAnnuityEarnings.caption := format('%.2n', [ (Rebate_Amount + workerShetlerAnnuityContribAmt) *  eligEarn  ] );
      end
      else
      begin
        lblRebatePreAnnuity3b.caption := '0.00';
        lblRebatePreAnnuity3c.caption := '0.00';
        lblDisplayWeeks90NetPost.caption := '0.00';
        lblDisplayWeeksCompensation.caption := '0.00';
        lblDisplayShelterBeforeAnnuity.caption := '0.00';
        lblDisplayAnnuityEarnings.caption := '0.00';
      end;
      lblWorkerAnnuityAmt.caption := format('%.2n', [ workerShetlerAnnuityContribAmt  ] );
      lblSRRebate_Amount3.caption := format('%.2n', [ Rebate_Amount  ] );
      lblSRShelter_Rebate_Year3.caption := format('%d', [ Shelter_Rebate_Year ] );
      lblWCBAnnuityPercent.caption := format('%.2n', [ wcbAnnuityContributionPercent  ] ) + '%';
      lblWCBAnnuityAmt.caption := format('%.2n', [ wcbShelterAnnuityContribAmt  ] );
  end; // with fSRClaim do..
end;

(******************************************************************************)
(*                                                                            *)
(*  Form Activate                                                             *)
(*                                                                            *)
(******************************************************************************)
procedure TShelterRebateCalculatorForm.FormActivate(Sender: TObject);
begin
  ResetInfoLine2;
  dm1.qryMaritalStatus.Active := True;
end;

(******************************************************************************)
(*                                                                            *)
(*  Exit processing for shelter rebate year                                   *)
(*                                                                            *)
(******************************************************************************)
procedure TShelterRebateCalculatorForm.edShelter_Rebate_YearExit(
  Sender: TObject);
var
  isFound: boolean;
  iii, testTax_Year, TestShelterRebateYear, TestIndexationYear: Integer;
  TestAccidentDate, TestRecurrenceDate:TDateTime;
begin
  isFound := false;
  // Get values from TAX CODE TABLE
  TestTax_Year := TextAsInteger(edTax_Year);

  if (Length(Trim(edAccident_Date.Text)) > 0) AND ValidateAsDate(edAccident_Date) then
     begin
     TestAccidentDate := StrToDate(edAccident_Date.Text);
     end
  else
     begin
     globalEditError := displayError( '*Please enter an Incident Date.', edAccident_Date);
     exit;
     end;

  If length(edRecurrenceDate.text ) > 0 then
     TestRecurrenceDate := StrToDate(edRecurrenceDate.Text)
  else
     TestRecurrenceDate := 0;

  if (Length(Trim(edIndexYear.Text)) > 0) AND (ValidateAsInteger(edIndexYear)) then
     TestIndexationYear := StrToInt(Trim(edIndexYear.Text))
  else
     TestIndexationYear := 0;

  testTax_Year := Max(Max(Year(TestAccidentDate), TestIndexationYear), Year(TestRecurrenceDate));
  SetTaxYear(testAccidentDate, testRecurrenceDate, testTax_Year);


  for iii := low(arrayNCTAXRAT) to high(arrayNCTAXRAT) do
     begin
     if (arrayNCTAXRAT[iii].Tax_Year = GetTaxYear) and
        (arrayNCTAXRAT[iii].Tax_Year > 1991) then
        begin
        isFound := True;
        Break;
        end;
     end;

  if not isFound then
  begin
    globalEditError := displayError( '*Please enter a valid Shelter Rebate year', edShelter_Rebate_Year );
    exit;
  end;

  TestShelterRebateYear := TextAsInteger(edShelter_Rebate_Year);

  if (TestShelterRebateYear > 0) then
     begin
     if (TestTax_Year > TestShelterRebateYear) then
        begin
        globalEditError := displayError( '*Tax year can not be greater than Claim Shelter Rebate year', edTax_Year );
        exit;
        end;
     end
  else
     begin
     globalEditError := displayError( '*Please enter a valid Shelter Rebate year', edShelter_Rebate_Year );
     exit;
     end;
  
  ResetInfoLine2;
end;

(******************************************************************************)
(*                                                                            *)
(*  Exit processing for shelter rebate weeks on paid cost                     *)
(*                                                                            *)
(******************************************************************************)
procedure TShelterRebateCalculatorForm.edAccum_Wks_Yr_PdCstExit(
  Sender: TObject);
var
  f:currency;
begin
  if not validateAsCurrency( edAccum_Wks_Yr_PdCst ) then
  begin
    globalEditError := displayError( '*invalid Accumulated Weeks Paid Cost', edAccum_Wks_Yr_PdCst );
    exit;
  end;

  f:=textAsCurrency(edAccum_Wks_Yr_PdCst);
  if ( f < 40.0 ) or ( f > 52.0 ) then
  begin
    globalEditError := displayError( '*Accumulated Weeks Paid Cost must be between 40 and 52', edAccum_Wks_Yr_PdCst );
    exit;
  end;


  edAccum_Wks_Yr_PdCst.text:=format('%.2n',[ textAsCurrency(edAccum_Wks_Yr_PdCst) ] );
  ResetInfoLine2;
end;

(******************************************************************************)
(*                                                                            *)
(*  Exit processing for shelter rebate weeks paid at 90 net                   *)
(*                                                                            *)
(******************************************************************************)
procedure TShelterRebateCalculatorForm.edAccum_Wks_Yr_90NetExit(
  Sender: TObject);
begin
  edAccum_Wks_Yr_90Net.text:=format('%.2n',[ textAsCurrency(edAccum_Wks_Yr_90Net) ] );
end;

procedure TShelterRebateCalculatorForm.editWeeks();
var
  f, f2 :currency;
begin
  if not validateAsCurrency( edAccum_Wks_Yr_90Net ) then
  begin
    globalEditError := displayError( '*invalid # of wks pre 104', edAccum_Wks_Yr_90Net );
    exit;
  end;
  if not validateAsCurrency( edAccum_Wks_Yr_90NetPost ) then
  begin
    globalEditError := displayError( '*invalid # of wks post 104', edAccum_Wks_Yr_90Net );
    exit;
  end;

  f:=textAsCurrency(edAccum_Wks_Yr_90Net) + textAsCurrency(edAccum_Wks_Yr_90NetPost);
  if ( f <= 0.0 ) or ( f > 52.0 ) then
  begin
    globalEditError := displayError( '*Accumulated Weeks must be greater than 0 and less than or equal to 52', edAccum_Wks_Yr_90Net );
    exit;
  end;

  f2:=textAsCurrency(edAccum_Wks_Yr_PdCst);
  if ( f < 0.0 ) or ( f > f2 ) then
  begin
    globalEditError := displayError( '*Accumulated Weeks 90 Net can not be greater than Paid Cost weeks paid', edAccum_Wks_Yr_90Net );
    exit;
  end;

  ResetInfoLine2;
end;

procedure TShelterRebateCalculatorForm.edTax_ExemptExit(Sender: TObject);
begin
  if edTax_Exempt.text='' then edTax_Exempt.text:='N';
  edTax_Exempt.text := uppercase(edTax_Exempt.text);
  ResetInfoLine2;
end;

procedure TShelterRebateCalculatorForm.edTax_ExemptKeyPress(
  Sender: TObject; var Key: Char);
begin
  case Key of
  #0..#31,'y','Y','n','N':
  else
    Key:=#0;
    WagelossMainForm.ShowInfoLine2('*Valid values for Income Tax Exempt are Y N');
  end;
end;

procedure TShelterRebateCalculatorForm.edCPP_ExemptExit(Sender: TObject);
begin
  if edCPP_Exempt.text='' then edCPP_Exempt.text:='N';
  edCPP_Exempt.text := uppercase(edCPP_Exempt.text);
  ResetInfoLine2;
end;

procedure TShelterRebateCalculatorForm.edCPP_ExemptKeyPress(
  Sender: TObject; var Key: Char);
begin
  case Key of
  #0..#31,'y','Y','n','N':
  else
    Key:=#0;
    WagelossMainForm.ShowInfoLine2('*Valid values for CPP Exempt are Y N');
  end;
end;

procedure TShelterRebateCalculatorForm.edSelf_EmployedExit(Sender: TObject);
var
   iAccident_Year, iAccident_Month, iAccident_Day:Word;
   Accident_Date:TDateTime;
   iTax_Year, iIndexationYear:Integer;
   Annual_Max, Annual_Min:Currency;
   strAnnualMax:String;
begin
  edSelf_Employed.text := UpperCase(edSelf_Employed.text);

  if edSelf_Employed.text = '' then
     edSelf_Employed.text := 'N';

  if (edSelf_Employed.text = 'N') then
     begin
     edMax_Adjustments.text := '0';
     setEditToRead(edMax_Adjustments);
     end;

  if (edSelf_Employed.text = 'Y') and (Not edMax_Adjustments.Enabled) then
     begin
     if MessageDlg('Do you wish to change the Max Adjustment amount?',
        mtConfirmation, [mbYes, mbNo], 0, mbNo) = mrYes then
        begin
        if Length(Trim(edIndexYear.Text)) > 0  then
           iIndexationYear := StrToInt(Trim(edIndexYear.Text))
        else
           iIndexationYear := 0;
        Annual_Max := getMaxAdjustment(CalcFullClaim.Accident_Date, CalcFullClaim.RecurrenceDate, iIndexationYear, Trim(edRecurrence.Text), Trim(edSelf_Employed.Text));
        Annual_Min := getMinAdjustment(CalcFullClaim.Accident_Date, CalcFullClaim.RecurrenceDate, iIndexationYear, Trim(edRecurrence.Text), Trim(edSelf_Employed.Text));

        strAnnualMax := '?Max Adj amount must be >= ' + format('%.2n', [Annual_Min]);
        if (Annual_Max > 0) then
           begin
           strAnnualMax := strAnnualMax + ' and <= ' + format('%.2n', [Annual_Max]);
           end;

        WagelossMainForm.ShowInfoLine2(strAnnualMax);
        setEditToNormal(edMax_Adjustments);
        edMax_Adjustments.SetFocus;
        end
     else
        begin
        setEditToRead(edMax_Adjustments);
        end;
     end;

  //ResetInfoLine2;
end;

procedure TShelterRebateCalculatorForm.edSelf_EmployedKeyPress(
  Sender: TObject; var Key: Char);
begin
  case Key of
  #0..#31,'y','Y','n','N':
  else
    Key:=#0;
    WagelossMainForm.ShowInfoLine2('*Valid values for Self Employed are Y N');
  end;
end;

procedure TShelterRebateCalculatorForm.edRecurrenceExit(Sender: TObject);
begin
  edRecurrence.text := uppercase(edRecurrence.text);
  if edRecurrence.text = '' then
     edRecurrence.text := 'N';

  if (edSelf_Employed.text = 'N') then
     begin
     edMax_Adjustments.text := '0';
     setEditToRead(edMax_Adjustments);
     end;

  if (edRecurrence.Text = 'Y') and Not (edRecurrenceDate.Visible) then
     begin
     edRecurrenceDate.Visible := True;
     if Length(edRecurrenceDate.text) < 1 then
    	  begin
      	edRecurrenceDate.SetFocus;
      	WagelossMainForm.ShowInfoLine2('?Please enter a Recurrence Date.');
      	exit;
    	  end
     else
        begin
    	  edRecurrenceDate.text :='';
        edRecurrenceDate.SetFocus;
        end;
     end
  else
     if (edRecurrence.Text = 'N') And edRecurrenceDate.Visible Then
        begin
        edRecurrenceDate.text := '';
        edRecurrenceDate.Visible := False;
        end;

  ResetInfoLine2;
  //
  // Force an edit of the tax year if we have set the Recurrence to false
  //
  if (edRecurrence.text = 'N') Then
     Begin
     edTax_YearExit(edTax_Year);
     End;
end;

procedure TShelterRebateCalculatorForm.edRecurrenceKeyPress(
  Sender: TObject; var Key: Char);
begin
  case Key of
  #0..#31,'y','Y','n','N':
  else
    Key:=#0;
    WagelossMainForm.ShowInfoLine2('*Valid values for Recurrence are Y N');
  end;
end;

procedure TShelterRebateCalculatorForm.edMax_AdjustmentsExit(
  Sender: TObject);
var
   TestMax_Adjustments, Annual_Max, Annual_Min:Currency;
   Test_Accident_Year, Accident_Month, Accident_Day:Word;
   TestTax_Year, iIndexationYear:Integer;
   strAnnualMax:String;
   iRecurrence_Date:TDateTime;
begin
  if edMax_Adjustments.text='' then
     begin
     edMax_Adjustments.text:='0';
     end;

  isIndexation := StrToInt(edIndexYear.Text) <> 0;
  //
  // Added to test the Max adjustments on exit
  //
  TestMax_Adjustments := TextAsCurrency(edMax_Adjustments);
  //
  // LRC Bill 18
  //
  if (edRecurrence.Text = 'Y') then
     iRecurrence_Date := StrToDate(edRecurrenceDate.Text)
  else
     iRecurrence_Date := 0;

  if Length(Trim(edIndexYear.Text)) > 0  then
     iIndexationYear := StrToInt(Trim(edIndexYear.Text))
  else
     iIndexationYear := 0;

  if (Year(CalcFullClaim.Accident_Date) < 2006)  OR
     (Year(CalcFullClaim.Accident_Date) >= 2022) then
     begin
     Annual_Max := getMaxAdjustment(CalcFullClaim.Accident_Date, CalcFullClaim.RecurrenceDate, iIndexationYear, Trim(edRecurrence.Text), Trim(edSelf_Employed.Text));
     Annual_Min := getMinAdjustment(CalcFullClaim.Accident_Date, CalcFullClaim.RecurrenceDate, iIndexationYear, Trim(edRecurrence.Text), Trim(edSelf_Employed.Text));
     if (TestMax_Adjustments > Annual_Max) then
        begin
        strAnnualMax := '*Max Adj amount must be >= $' + format('%.2n', [Annual_Min]) + ' and <= $' + format('%.2n',[Annual_Max]);
        globalEditError := displayError(strAnnualMax, edMax_Adjustments);
        exit;
        end;
     if (TestMax_Adjustments < Annual_Min) then
        begin
        strAnnualMax := '*Max Adj amount must be >= $' + format('%.2n', [Annual_Min]) + ' and <= $' + format('%.2n',[Annual_Max]);
        globalEditError := displayError(strAnnualMax, edMax_Adjustments);
        exit;
        end;
     end
  else
     begin
     strAnnualMax := isSelfEmployedAdjInRange(TestMax_Adjustments, CalcFullClaim,
                                              isIndexation, edMax_Adjustments,
                                              Trim(edRecurrence.Text), Trim(EdSelf_Employed.Text),
                                              iIndexationYear, iRecurrence_Date);
     if strAnnualMax <> EmptyStr  then
        begin
        globalEditError := displayError(strAnnualMax , edMax_Adjustments );
        globalEditError := True;
        exit;
        end;

     end;
  //
  // End Modification
  //

  edMax_Adjustments.Text := format('%.2n',[ textAsCurrency(edMax_Adjustments) ] );

  ResetInfoLine2;
end;

procedure TShelterRebateCalculatorForm.edChild_Care_ExpExit(
  Sender: TObject);
begin
  if edChild_Care_Exp.text='' then edChild_Care_Exp.text:='0';
  edChild_Care_Exp.text:=format('%.2n',[ textAsCurrency(edChild_Care_Exp) ] );
  ResetInfoLine2;
end;

procedure TShelterRebateCalculatorForm.edSpousal_SupportExit(
  Sender: TObject);
begin
  if edSpousal_Support.text='' then edSpousal_Support.text:='0';
  edSpousal_Support.text:=format('%.2n',[ textAsCurrency(edSpousal_Support) ] );
  ResetInfoLine2;
end;

procedure TShelterRebateCalculatorForm.edAccident_DateExit(Sender: TObject);
begin
  //
  // If we already have a / in the field and the length is 10 then assume we have a date
  //                        +
  if (length(edAccident_Date.text) = 10) AND
     (pos('/',edAccident_Date.text) <> 0) then
     begin
     exit;
     end;
  //
  // make sure an accident date was entered
  //
  if length(edAccident_Date.text) < 1 then
     begin
     globalEditError := displayError( '*Please enter an Incident Date.', edAccident_Date );
     exit;
     end;

  if not validateAsDate(edAccident_Date) then
     begin
     globalEditError := displayError( '*Invalid Incident Date', edAccident_Date );
     exit;
     end;

  if (textAsDate( edAccident_Date) > 0) then
     begin
     //edAccident_Date.text := FormatDateTime('c',TextAsDate( edAccident_Date ));
     edAccident_Date.text := FormatDateTime('ddddd', textAsDate(edAccident_Date));
     end
  else
     edAccident_Date.text := '';

  CalcFullClaim.Accident_Date := StrtoDate(edAccident_Date.Text);

  // Support payment fields are not valid for pre-2001 claims
  if year(StrToDate(edAccident_Date.Text)) < 2001 then
     begin
     edChild_Care_Exp.text:='0';
     edSpousal_Support.text:='0';

     setEditToRead(edChild_Care_Exp);
     setEditToRead(edSpousal_Support);
     end
  else
     begin
     setEditToNormal(edChild_Care_Exp);
     setEditToNormal(edSpousal_Support);
     end;

  if year(StrToDate(edAccident_Date.Text)) < 2006 then
     begin
     edWorkerContribution.text:='0';
     edWCBContribution.text:='0';
     setEditToRead(edAccum_Wks_Yr_90NetPost);
     setEditToRead(edWorkerContribution);
     setEditToRead(edWCBContribution);
     end
  else
     begin
     setEditToNormal(edAccum_Wks_Yr_90NetPost);
     setEditToNormal(edWorkerContribution);
     setEditToNormal(edWCBContribution);
     end;

  ResetInfoLine2;
end;

procedure TShelterRebateCalculatorForm.edAccident_DateKeyPress(
  Sender: TObject; var Key: Char);
begin
  case Key of
  #0..#31,'0'..'9','/','.':
  else
    Key:=#0;
  end;
end;

procedure TShelterRebateCalculatorForm.edNumberShelterDeductExit(
  Sender: TObject);
var
  i: currency;
begin
  if edNumberShelterDeduct.text='' then edNumberShelterDeduct.text:='0';
  if not validateAsCurrency( edNumberShelterDeduct ) then
  begin
    globalEditError := displayError( '*Invalid No. Of Shelter Deductions', edNumberShelterDeduct );
    exit;
  end;
  i:=textAsCurrency(edNumberShelterDeduct);
  if ( (i <= 0) OR (i > 52)) then
  begin
    globalEditError := displayError( '*No Of Shelter Deductions Must Be Greater Than 0.00 And Not Greater Than 52.00', edNumberShelterDeduct );
    exit;
  end;
  edNumberShelterDeduct.text:=format('%.2n',[ textAsCurrency(edNumberShelterDeduct) ] );
  ResetInfoLine2;
end;

procedure TShelterRebateCalculatorForm.edRecurrenceDateExit(Sender: TObject);
Begin
  // make sure a recurrence date was entered
  if length(edRecurrenceDate.text) < 1 then
     begin
     globalEditError := displayError( '*Please enter a Recurrence Date.', edRecurrenceDate );
     exit;
     end;

  if not validateAsDate(edRecurrenceDate) then
     begin
     globalEditError := displayError( '*Invalid Recurrence Date', edRecurrenceDate );
     exit;
     end;

  if (textAsDate(edRecurrenceDate) > 0) then
     begin
     //edRecurrenceDate.Text := Formatdatetime('c',textAsDate( edRecurrenceDate ));
     edRecurrenceDate.Text := Formatdatetime('ddddd', textAsDate(edRecurrenceDate));
     end
  else
     edRecurrenceDate.text := '';

  //
  // Make sure the tax year is on or after the recurrence year
  //

  if Length(edTax_Year.Text) > 0 then
     begin
     if (StrtoInt(edTax_Year.Text) < Year(StrtoDate(edRecurrenceDate.Text))) Then
        begin
        globalEditError := displayError( '*Tax year must be on or after year of the recurrence', edTax_Year );
        exit;
        end;
     end;

  ResetInfoLine2;
end;

procedure TShelterRebateCalculatorForm.edYouthful_WorkerKeyPress(
  Sender: TObject; var Key: Char);
begin
  case Key of
  #0..#31,'y','Y','n','N':
  else
    Key:=#0;
    WagelossMainForm.ShowInfoLine2('*Valid values for Youthful Worker are Y N');
  end;
end;

procedure TShelterRebateCalculatorForm.edYouthful_WorkerExit(
  Sender: TObject);
begin
  edYouthful_Worker.Text := UpperCase(edYouthful_Worker.text);

  // Force the Default
  if edYouthful_Worker.Text='' then
     edYouthful_Worker.Text:='N';
end;

procedure TShelterRebateCalculatorForm.ScrollBox1MouseWheelDown(
  Sender: TObject; Shift: TShiftState; MousePos: TPoint;
  var Handled: Boolean);
Const
   iScroll_Increment = 15;
var
   iScroll:Integer;
begin
if scrollbox1.VertScrollBar.position < scrollbox1.VertScrollBar.range Then
   Begin
   if  scrollbox1.VertScrollBar.position <  (scrollbox1.VertScrollBar.range - iScroll_Increment) Then
       iScroll := scrollbox1.VertScrollBar.position + 15
   else
       iScroll := scrollbox1.VertScrollBar.range;
   scrollbox1.VertScrollBar.position := iScroll;
   End;
Handled := True;
end;

procedure TShelterRebateCalculatorForm.ScrollBox1MouseWheelUp(
  Sender: TObject; Shift: TShiftState; MousePos: TPoint;
  var Handled: Boolean);
Const
   iScroll_Increment = 15;
var
   iScroll:Integer;
begin
If scrollbox1.VertScrollBar.position > 0 Then
   Begin
   if  scrollbox1.VertScrollBar.position >  iScroll_Increment Then
       iScroll := scrollbox1.VertScrollBar.position - 15
   else
       iScroll := 0;
   scrollbox1.VertScrollBar.position := iScroll;
   End;
Handled := True;
end;

procedure TShelterRebateCalculatorForm.cboMaritalStatusExit(
  Sender: TObject);
begin
  //
  // Set to default if blank
  //
  if cboMaritalStatus.Text = '' then
     begin
     cboMaritalStatus.KeyValue := 'SINGLE';
     edSpouse_Working.text := 'N';
     blnMarital_Status_Change := true;
     end;

  //
  // Default the Spouse Working Flag
  //
  if (upperCase(cboMaritalStatus.Text) = 'MARRIED')    OR
     (upperCase(cboMaritalStatus.Text) = 'COMMON-LAW') Then
     begin
     if (cboMaritalStatus.text = '') OR blnMarital_Status_Change then
        edSpouse_Working.text := 'Y';
     end;

  if (upperCase(cboMaritalStatus.Text) = 'DIVORCED')  or
     (upperCase(cboMaritalStatus.Text) = 'SEPARATED') or
     (upperCase(cboMaritalStatus.Text) = 'SINGLE')    or
     (upperCase(cboMaritalStatus.Text) = 'WIDOWED')   then
     begin
     if blnMarital_Status_Change then
        begin
        edSpouse_Working.text := 'N';
        setEditToRead( edSpouse_Working );
        selectNext(Sender as tWinControl, true, true);
        edClaimSpouseForTaxPurposes.Visible := false;
        edClaimSpouseForTaxPurposes.Text := '';
        lblClaimSpouseForTaxPurposes.Visible := false;
        end
     end
  else
     begin
     if blnMarital_Status_Change then
        begin
        setEditToNormal(edSpouse_Working);
        selectNext(Sender as tWinControl, true, true);
        end;
     end;

  blnMarital_Status_Change := false;

  ResetInfoLine2;
end;

procedure TShelterRebateCalculatorForm.cboMaritalStatusKeyDown(Sender: TObject;
  var Key: Word; Shift: TShiftState);
begin
  blnMarital_Status_Change := True;
end;

procedure TShelterRebateCalculatorForm.cboMaritalStatusClick(Sender: TObject);
begin
  blnMarital_Status_Change := True;
end;

procedure TShelterRebateCalculatorForm.edAccum_Wks_Yr_90NetPostExit(
  Sender: TObject);
begin
  edAccum_Wks_Yr_90NetPost.text:=format('%.2n',[ textAsCurrency(edAccum_Wks_Yr_90NetPost) ] );
end;

procedure TShelterRebateCalculatorForm.edWorkerContributionExit(Sender: TObject);
begin
  edWorkerContribution.text:=format('%.2n',[ textAsCurrency(edWorkerContribution) ] );
end;

procedure TShelterRebateCalculatorForm.edWCBContributionExit(Sender: TObject);
begin
  edWCBContribution.text:=format('%.2n',[ textAsCurrency(edWCBContribution) ] );
end;

procedure TShelterRebateCalculatorForm.FormResize(Sender: TObject);
begin
{
  ScrollBox1.left := (Self.width div 2) - ScrollBox1.width div 2 + 5;
  if Self.Height > ScrollBox1.Height then
     ScrollBox1.top := (Self.height div 2) - ScrollBox1.height div 2
  else
     ScrollBox1.top := Self.Top + 50;
}
end;

end.

