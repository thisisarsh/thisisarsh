inherited WrkRptJan13: TWrkRptJan13
  Caption = 'WrkRptJan13'
  PixelsPerInch = 96
  TextHeight = 13
end
