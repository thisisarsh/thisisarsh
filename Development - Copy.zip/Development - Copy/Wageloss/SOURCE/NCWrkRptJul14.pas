unit NCWrkRptJul14;

interface

uses
  Windows, Messages, SysUtils, Variants, Classes, Graphics, Controls, Forms,
  Dialogs, NCWrkRptJan14;

type
  TWrkRptJul14 = class(TWrkRptJan14)
  function getDateHeading():String; Override;
  private
    { Private declarations }
  public
    { Public declarations }
  end;

var
  WrkRptJul14: TWrkRptJul14;

implementation

{$R *.dfm}
(******************************************************************************)
(*                                                                            *)
(*  override this function for each class to avoid having to bring in all of  *)
(*    the methods that contain the date in the heading.                       *)
(*   IE:  the jan 09 class should return  2008/2009                           *)
(*        the july 09 class should return 2009                                *)
(*                                                                            *)
(******************************************************************************)

{ TWrkRptJul14 }

function TWrkRptJul14.getDateHeading: String;
begin
  Result:='2014'
end;

end.
