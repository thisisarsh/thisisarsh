(*****************************************************************)
(*  Wageloss System                                              *)
(*                                                               *)
(*  Wageloss Overpayment Recovery Form                           *)
(*                                                               *)
(*                                                               *)
(*  Author: Bill Cooper                                          *)
(*  Date:   March 2007                                           *)
(*  Emerge Release 4                                             *)
(*****************************************************************)

unit NCWagelossOverpaymentRecoveryForm;

interface

uses
  Windows, Messages, SysUtils, Variants, Classes, Graphics, Controls, Forms,
  Dialogs, StdCtrls, NCRecdef, utilmod1, NCBenPay;

type
  TWagelossOverpaymentRecoveryForm = class(TForm)
    lblPayeeType: TLabel;
    lblPaymentMethod: TLabel;
    lblPayee: TLabel;
    lblTotOutstandingAmt: TLabel;
    lblTotOverpayentAmt: TLabel;
    lblPlannedRecoveryAmt: TLabel;
    lblPayeeTypeDesc: TLabel;
    lblPaymentMethodDesc: TLabel;
    lblTotOverpayentAmtDesc: TLabel;
    lblTotOutstandingAmtDesc: TLabel;
    edPlannedRecoveryAmt: TEdit;
    lblPayeeName: TLabel;
    lblPayeeAddress1: TLabel;
    lblPayeeAddress2: TLabel;
    btnOK: TButton;
    lblTotalOutstandingReceivable: TLabel;
    lblTotalOutstandingReceivableDesc: TLabel;
    lblTotalOutstandingSuspended: TLabel;
    lblTotalOutstandingSuspendedDesc: TLabel;
    lblNumberOfPayments: TLabel;
    lblPaymentAmount: TLabel;
    lblOverridePlannedRecovery: TLabel;
    lblNumberOfPaymentsDesc: TLabel;
    lblPaymentAmountDesc: TLabel;
    cboOverridePlannedRecovery: TComboBox;
    btnCancel: TButton;
    Label1: TLabel;
    lblTotalOutstandingAdvancesDesc: TLabel;
    Label2: TLabel;
    lblPossibleRecoveryAmtDesc: TLabel;
    Label4: TLabel;
    procedure btnCancelClick(Sender: TObject);
    procedure DoubleKeyPress(Sender: TObject; var Key: Char);
    procedure FormCreate(Sender: TObject);
    procedure FormDestroy(Sender: TObject);
    procedure edPlannedRecoveryAmtExit(Sender: TObject);
    procedure btnOKClick(Sender: TObject);
    procedure FormClose(Sender: TObject; var Action: TCloseAction);
    procedure FormActivate(Sender: TObject);
    procedure cboOverridePlannedRecoveryChange(Sender: TObject);
  private
    { Private declarations }
    globalEditError : boolean;
  public
    { Public declarations }
    CalcFullClaim: recNCCLAIM;
    plannedRecoveryRate : currency;
    wageLossRecoveryRateAmt,
    totalOverpaymentAmt,
    totalOutstandingInRecoveryAmt,
    totalOutstandingAmt,
    totalOutstandingSuspendedAmt,
    totalOutstandingAdvancesAmt : currency;
    constructor CreateExtended( AOwner : TComponent ; payeeId : Integer ; payeeType : String ; claimNo : String ); virtual;
  end;

var
  WagelossOverpaymentRecoveryForm: TWagelossOverpaymentRecoveryForm;

implementation

uses NCDatMod, NCMain, Utils;


{$R *.dfm}

(******************************************************************************)
(*                                                                            *)
(*  Form Create                                                               *)
(*                                                                            *)
(******************************************************************************)
procedure TWagelossOverpaymentRecoveryForm.FormCreate(Sender: TObject);
begin
  SetFont(Self);
end;

(******************************************************************************)
(*                                                                            *)
(*  Form CreateExtended                                                       *)
(*                                                                            *)
(******************************************************************************)
constructor TWagelossOverpaymentRecoveryForm.CreateExtended( AOwner : TComponent ; payeeId : Integer ; payeeType : String ; claimNo : String );
var
  overpaymentAccountId : Integer;
  possibleRecoveryAmt : double;
begin
  // call inherited create which calls Form Create
  inherited create(AOwner);

  try
    with dm1.qryOverpaymentAccount do
    begin
      if Active then
        Close;
      SQL.Clear;

      SQL.Add( 'SELECT ' );
      SQL.Add( '  overpaymentAccount.overpaymentAccountId AS overpaymentAccountId, ' );
      SQL.Add( '	overpaymentAccount.payeeType, ' );
      SQL.Add( '  overpaymentAccount.wageLossRecoveryRateAmt, ' );
      SQL.Add( '	overpaymentAccount.totalOverpaymentAmt, ' );
      SQL.Add( '	overpaymentAccount.totalOutstandingAmt, ' );
      SQL.Add( '	overpaymentAccount.totalOutstandingReceivableAmt, ' );
      SQL.Add( '	overpaymentAccount.totalOutstandingSuspendedAmt ' );
      SQL.Add( 'FROM OverpaymentAccount overpaymentAccount ' );
      SQL.Add( 'WHERE ' );
      SQL.Add( '	overpaymentAccount.payeeId = ' + IntToStr( payeeId ) + '' );
      SQL.Add( '  AND overpaymentAccount.payeeType = ''' + payeeType + '''' );

      Open;
      overpaymentAccountId := FieldByName( 'overpaymentAccountId' ).AsInteger;
      wageLossRecoveryRateAmt := FieldByName( 'wageLossRecoveryRateAmt' ).AsCurrency;
      totalOverpaymentAmt := FieldByName( 'totalOverpaymentAmt' ).AsCurrency;
      totalOutstandingAmt := FieldByName( 'totalOutstandingAmt' ).AsCurrency;
      totalOutstandingInRecoveryAmt := FieldByName( 'totalOutstandingReceivableAmt' ).AsCurrency;
      totalOutstandingSuspendedAmt := FieldByName( 'totalOutstandingSuspendedAmt' ).AsCurrency;
      lblPayeeTypeDesc.Caption := FieldByName( 'payeeType' ).AsString;
      lblTotOverpayentAmtDesc.Caption := '$' + format( '%.2n', [ totalOverpaymentAmt ] );
      lblTotOutstandingAmtDesc.Caption := '$' + format( '%.2n', [ totalOutstandingAmt ] );
      lblTotalOutstandingReceivableDesc.Caption := '$' + format( '%.2n', [ totalOutstandingInRecoveryAmt ] );
      lblTotalOutstandingSuspendedDesc.Caption := '$' + format( '%.2n', [ totalOutstandingSuspendedAmt ] );

      Close;
      SQL.Clear;
      SQL.Add( 'SELECT ' );
      SQL.Add( '	outstandingAmt ' );
      SQL.Add( 'FROM Overpayment ' );
      SQL.Add( 'WHERE overpaymentAccountId = ' + IntToStr( overpaymentAccountId ) );
      SQL.Add( 'AND overpaymentClassType = ''Advance''' );
      Open;

      totalOutstandingAdvancesAmt := FieldByName( 'outstandingAmt' ).AsCurrency;
      lblTotalOutstandingAdvancesDesc.Caption := '$' + format( '%.2n', [ totalOutstandingAdvancesAmt ]);
      possibleRecoveryAmt := totalOutstandingInRecoveryAmt - totalOutstandingAdvancesAmt;

      if possibleRecoveryAmt < 0 then
      begin
        lblPossibleRecoveryAmtDesc.Caption := '$0.00';
      end
      else
      begin
        lblPossibleRecoveryAmtDesc.Caption := '$' + format( '%.2n', [ possibleRecoveryAmt ] );
      end;

      Close;
      SQL.Clear;
      SQL.Add( 'SELECT ' );
      SQL.Add( '	overpaymentRecovery.depositMethodType ' );
      SQL.Add( 'FROM OverpaymentAccount overpaymentAccount ' );
      SQL.Add( '	INNER JOIN Overpayment overpayment ' );
      SQL.Add( '		ON overpaymentAccount.overpaymentAccountId = overpayment.overpaymentAccountId ' );
      SQL.Add( '	INNER JOIN OverpaymentRecovery overpaymentRecovery ' );
      SQL.Add( '		ON overpayment.overpaymentId = overpaymentRecovery.overpaymentId ' );
      SQL.Add( 'WHERE overpaymentAccount.overpaymentAccountId = ' + IntToStr( overpaymentAccountId ) );
      Open;

      lblPaymentMethodDesc.Caption := FieldByName( 'depositMethodType' ).AsString;

      Close;
      SQL.Clear;

      //get payee info
      //if payeeType is worker
      if payeeType = 'Worker' then
      begin //Get Claimant Info
        SQL.Add( 'SELECT ' );
        SQL.Add( '	person.lastName + '', '' + person.firstName AS ''Name'', ' );
        SQL.Add( '	address.addressLine1 AS ''Address1'', ' );
        SQL.Add( '	address.municipalityName + '', '' + address.provinceName + '' '' + address.postalCode AS ''Address2'' ' );
        SQL.Add( 'FROM PayeeClaimant payeeClaimant ' );
        SQL.Add( '	INNER JOIN Claimant claimant ON claimant.claimantId = payeeClaimant.claimantId ' );
        SQL.Add( '	INNER JOIN Person person ON person.personId = claimant.personId ' );
        SQL.Add( '	INNER JOIN PersonAddress personAddress ON personAddress.personId = person.personId ' );
        SQL.Add( '	INNER JOIN Address address ON address.addressId = personAddress.addressId ' );
        SQL.Add( 'WHERE payeeClaimant.payeeId = ' + IntToStr( payeeId ) );
        Open;
      end //if worker
      else if payeeType = 'Employer' then
      begin //Get Firm Info
        SQL.Add( 'SELECT TOP 1 ' );
        SQL.Add( '	employerInfo.firmName1 AS ''Name'', ' );
        SQL.Add( '	employerInfo.address1 AS ''Address1'', ' );
        SQL.Add( '	employerInfo.city + '', '' + employerInfo.province + '' '' + employerInfo.postalCode AS ''Address2'' ' );
        SQL.Add( 'FROM PayeeFirm payeeFirm ' );
        SQL.Add( '	INNER JOIN vwEmployerInfo employerInfo ON employerInfo.firmNo = payeeFirm.firmNo ' );
        SQL.Add( '								   AND employerInfo.firmSuffix = payeeFirm.firmSuffix ' );
        SQL.Add( 'WHERE payeeFirm.payeeId = ' + IntToStr( payeeId ) );
        SQL.Add( 'ORDER BY employerInfo.yearAppliesTo DESC ' );
        Open;
      end //if employer
      else //Get AlternatePayee Info
      begin
        SQL.Add( 'SELECT ' );
        SQL.Add( '	alternatePayee.organizationName AS ''Name'', ' );
        SQL.Add( '	alternatePayee.addressLine1 AS ''Address1'', ' );
        SQL.Add( '	alternatePayee.municipalityName + '', '' + alternatePayee.provinceName + '' '' + alternatePayee.postalCode AS ''Address2'' ' );
        SQL.Add( 'FROM PayeeAlternatePayee payeeAlternatePayee ' );
        SQL.Add( '	INNER JOIN AlternatePayee alternatePayee ON alternatePayee.alternatePayeeId = payeeAlternatePayee.alternatePayeeId ' );
        SQL.Add( 'WHERE payeeAlternatePayee.payeeId = ' + IntToStr( payeeId ) );
        Open;
      end; //else alternatePayee

      lblPayeeName.Caption := FieldByName( 'Name' ).AsString;
      lblPayeeAddress1.Caption := FieldByName( 'Address1' ).AsString;
      lblPayeeAddress2.Caption := FieldByName( 'Address2' ).AsString;

      if wageLossRecoveryRateAmt > totalOutstandingInRecoveryAmt then
      begin
        //display the overpaymentaccount outstanding amount
        plannedRecoveryRate := totalOutstandingInRecoveryAmt;
      end
      else
      begin
        //display the wageloss recovery amount
        plannedRecoveryRate := wageLossRecoveryRateAmt;
      end;

      lblNumberOfPaymentsDesc.Caption := WagelossPaymentForm.edNum_of_Payments.Text;
      lblPaymentAmountDesc.Caption := '$' + WagelossPaymentForm.edAmount_Paid.Text;

      if possibleRecoveryAmt > 0 then
      begin
        cboOverridePlannedRecovery.Enabled := true;
      end
      else
      begin
        cboOverridePlannedRecovery.Enabled := false;
      end;

      cboOverridePlannedRecovery.ItemIndex := 1;

      edPlannedRecoveryAmt.Text := format( '%.2n', [ plannedRecoveryRate ] );
      edPlannedRecoveryAmt.Enabled := false;
      edPlannedRecoveryAmt.Color := clBtnFace;
      Close;
    end;
  finally
    ;
  end;
end;

procedure TWagelossOverpaymentRecoveryForm.DoubleKeyPress(Sender: TObject; var Key: Char);
begin
  case Key of #0..#31,'0'..'9','.','+':
  else
    Key:=#0;
  end;
end;

procedure TWagelossOverpaymentRecoveryForm.FormDestroy(Sender: TObject);
begin
  WagelossOverpaymentRecoveryForm := nil;
  WagelossMainForm.ShowInfoLine1('');
  WagelossMainForm.ShowInfoLine2('');
end;

procedure TWagelossOverpaymentRecoveryForm.edPlannedRecoveryAmtExit(Sender: TObject);
begin
  edPlannedRecoveryAmt.Text := Format( '%.2n', [textAsCurrency( edPlannedRecoveryAmt ) ] );

  if not validateAsCurrency( edPlannedRecoveryAmt ) then
  begin
    globalEditError := displayError( '*Invalid planned recovery amount.', edPlannedRecoveryAmt );
    Exit;
  end;

  if ( TextAsCurrency( edPlannedRecoveryAmt ) > totalOutstandingAmt ) then
  begin
    globalEditError := displayError( '*Planned recovery amount cannot be greater than outstanding overpayment amount.', edPlannedRecoveryAmt );
    Exit;
  end;

  if ( TextAsCurrency( edPlannedRecoveryAmt ) > StrToFloat( cleanNumber( lblPaymentAmountDesc.Caption ) ) ) then
  begin
    globalEditError := displayError( '*Planned recovery amount cannot be greater than requested payment amount.', edPlannedRecoveryAmt );
    Exit;
  end;

  //Planned Recovery Amount must be less than or equal to Possible Recovery Amount
  if ( TextAsCurrency( edPlannedRecoveryAmt ) > StrToFloat( cleanNumber( lblPossibleRecoveryAmtDesc.Caption ) ) ) then
  begin
    globalEditError := displayError( '*Planned recovery amount cannot be greater than possible recovery amount.', edPlannedRecoveryAmt );
    Exit;
  end;

  WagelossMainForm.ShowInfoLine2( '' );
end;

procedure TWagelossOverpaymentRecoveryForm.btnOKClick(Sender: TObject);
begin
  ModalResult := mrOK;
end;

procedure TWagelossOverpaymentRecoveryForm.btnCancelClick(Sender: TObject);
begin
  modalresult := mrCancel;
end;

procedure TWagelossOverpaymentRecoveryForm.FormClose(Sender: TObject;
  var Action: TCloseAction);
begin
  Action := caFree;
end;

procedure TWagelossOverpaymentRecoveryForm.FormActivate(Sender: TObject);
begin
  if ( StrToInt( lblNumberOfPaymentsDesc.Caption ) > 1 ) then
  begin
    MessageDlg('Please note that the recovery amount will only be ' +
                'overriden on the first payment of this cyclical payment request',
                mtInformation, [mbOk], 0);
  end;
end;

procedure TWagelossOverpaymentRecoveryForm.cboOverridePlannedRecoveryChange(
  Sender: TObject);
begin
  //if user selects yes
  if cboOverridePlannedRecovery.ItemIndex = 0 then
  begin
    edPlannedRecoveryAmt.Enabled := true;
    edPlannedRecoveryAmt.Color := clAqua;
    edPlannedRecoveryAmt.SetFocus;
  end;
  //if user selects no
  if cboOverridePlannedRecovery.ItemIndex = 1 then
  begin
    edPlannedRecoveryAmt.Enabled := false;
    edPlannedRecoveryAmt.Color := clBtnFace;
    edPlannedRecoveryAmt.Text := format( '%.2n', [ plannedRecoveryRate ] );
  end;
end;



end.
