unit NCWrkRptJan20;

interface

uses
  Winapi.Windows, Winapi.Messages, System.SysUtils, System.Variants, System.Classes, Vcl.Graphics,
  Vcl.Controls, Vcl.Forms, Vcl.Dialogs, NCWrkRptJul19;

type
  TWrkRptJan20 = class(TWrkRptJul19)
    function getDateHeading():String; Override;
  private
    { Private declarations }
  public
    { Public declarations }
  end;

var
  WrkRptJan20: TWrkRptJan20;

implementation

{$R *.dfm}

(******************************************************************************)
(*                                                                            *)
(*  override this function for each class to avoid having to bring in all of  *)
(*    the methods that contain the date in the heading.                       *)
(*   IE:  the jan 09 class should return  2008/2009                           *)
(*        the july 09 class should return 2009                                *)
(*                                                                            *)
(******************************************************************************)

function TWrkRptJan20.getDateHeading: String;
begin
  Result:='2019/2020';
end;

end.
