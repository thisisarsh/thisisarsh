(******************************************************************************)
(*  Wageloss System                                                           *)
(*                                                                            *)
(*  Main module - Tax Tables                                                  *)
(*                                                                            *)
(*                                                                            *)
(*  Author: Brad Trupp  / Capella Systems Group, Inc.                         *)
(*  Date:   July 1997                                                         *)
(******************************************************************************)

unit WLTABL01;

interface

uses SysUtils;

type
(******************************************************************************)
(*                                                                            *)
(*  Include record refinitions                                                *)
(*                                                                            *)
(******************************************************************************)
  {$include NCANNMAX.inc}
  {$include NCANNMAXB18.inc}
  {$include NCCODEXP.inc}
  {$include NCEXMAMT.inc}
  {$include NCINDEXF.inc}
  {$include NCTAXRAT.inc}
  {$include NC_CFIO.inc}
  {$include NCIAWMAX.inc}

const
(******************************************************************************)
(*                                                                            *)
(*  Constants for program use.                                                *)
(*                                                                            *)
(*  Remember to change WLTABL01CurrentTaxYear each year when updating the     *)
(*  tax tables to add a new years information.                                *)
(*                                                                            *)
(******************************************************************************)
  WLTABL01VersionNumber='100.991214.04';
  WLTABL01CurrentTaxYear=2027;

(******************************************************************************)
(*                                                                            *)
(*  Include the data                                                          *)
(*                                                                            *)
(******************************************************************************)
  {$include NCANNMAX.in2}
  {$include NCANNMAXB18.in2}
  {$include NCCODEXP.in2}
  {$include NCEXMAMT.in2}
  {$include NCINDEXF.in2}
  {$include NCTAXRAT.in2}
  {$include NC_CFIO.in2}
  {$include NCIAWMAX.in2}

function  GetCurrentTaxYear: integer; stdcall;
procedure GetNCANNMAX(var tb: array of recNCANNMAX); stdcall;
procedure GetNCANNMAXB18(var tb: array of recNCANNMAXB18); stdcall;
procedure GetNCCODEXP(var tb: array of recNCCODEXP); stdcall;
procedure GetNCEXMAMT(var tb: array of recNCEXMAMT); stdcall;
procedure GetNCINDEXF(var tb: array of recNCINDEXF); stdcall;
procedure GetNCTAXRAT(var tb: array of recNCTAXRAT); stdcall;
procedure GetNC_CFIO(var tb: array of recNC_CFIO); stdcall;
procedure GetNCIAWMAX(var tb: array of recNCIAWMAX); stdcall;

implementation

uses WLTABL00;

(******************************************************************************)
(*                                                                            *)
(*  Return Current Tax Year as Integer                                        *)
(*                                                                            *)
(******************************************************************************)
function  GetCurrentTaxYear: integer;
begin
  result:=WLTABL01CurrentTaxYear;
end;


(******************************************************************************)
(*                                                                            *)
(*   Populate array for NCANNMAX                                              *)
(*                                                                            *)
(******************************************************************************)
procedure GetNCANNMAX(var tb: array of recNCANNMAX); stdcall;
var
   iii,jjj: integer;
begin
  {$IFDEF DEBUG}
  DLLAboutForm.updateStatus('Loading arrayNCANNMAX');
  if ( high(tb)-low(tb) < high(arrayNCANNMAX)-low(arrayNCANNMAX)) then
  begin
    DLLAboutForm.updateStatus('Error in arrayNCANNMAX. Destination too small.');
    exit;
  end;
  {$ENDIF}
  move( arrayNCANNMAX, tb, sizeof(arrayNCANNMAX) ); 
  jjj:= low(tb);
  for iii:=low(arrayNCANNMAX) to high(arrayNCANNMAX) do
  begin
    tb[jjj].Accident_Year  := arrayNCANNMAX[iii].Accident_Year;
    tb[jjj].Tax_Year  := arrayNCANNMAX[iii].Tax_Year;
    tb[jjj].Annual_Maximum  := arrayNCANNMAX[iii].Annual_Maximum;
    tb[jjj].Annual_Maximum_Dec  := arrayNCANNMAX[iii].Annual_Maximum_Dec;
    inc(jjj);
  end;
  for iii:=jjj to high(tb) do
  begin
    tb[iii].Accident_Year  := 0;
    tb[iii].Tax_Year  := 0;
    tb[iii].Annual_Maximum  := 0;
    tb[iii].Annual_Maximum_Dec  := 0;
  end;
  {$IFDEF DEBUG}
  iii:=1 + high(arrayNCANNMAX)- low(arrayNCANNMAX);
  DLLAboutForm.updateStatus('Loaded arrayNCANNMAX ' + inttostr(iii) + ' entrie(s).');
  {$ENDIF}
end;

(******************************************************************************)
(*                                                                            *)
(*   Populate array for NCANNMAXB18                                           *)
(*                                                                            *)
(******************************************************************************)
procedure GetNCANNMAXB18(var tb: array of recNCANNMAXB18); stdcall;
var
   iii,jjj: integer;
begin
  {$IFDEF DEBUG}
  DLLAboutForm.updateStatus('Loading arrayNCANNMAXB18');
  if ( high(tb)-low(tb) < high(arrayNCANNMAXB18)-low(arrayNCANNMAXB18)) then
     begin
     DLLAboutForm.updateStatus('Error in arrayNCANNMAX. Destination too small.');
     exit;
     end;
  {$ENDIF}

  move( arrayNCANNMAXB18, tb, sizeof(arrayNCANNMAXB18) );
  jjj:= low(tb);

  for iii:=low(arrayNCANNMAXB18) to high(arrayNCANNMAXB18) do
     begin
     tb[jjj].Accident_Year  := arrayNCANNMAXB18[iii].Accident_Year;
     tb[jjj].Tax_Year  := arrayNCANNMAXB18[iii].Tax_Year;
     tb[jjj].Annual_Maximum  := arrayNCANNMAXB18[iii].Annual_Maximum;
     tb[jjj].Annual_Maximum_Dec  := arrayNCANNMAXB18[iii].Annual_Maximum_Dec;
     inc(jjj);
     end;

  for iii:=jjj to high(tb) do
     begin
     tb[iii].Accident_Year  := 0;
     tb[iii].Tax_Year  := 0;
     tb[iii].Annual_Maximum  := 0;
     tb[iii].Annual_Maximum_Dec  := 0;
     end;

  {$IFDEF DEBUG}
  iii:=1 + high(arrayNCANNMAXB18)- low(arrayNCANNMAXB18);
  DLLAboutForm.updateStatus('Loaded arrayNCANNMAX ' + inttostr(iii) + ' entrie(s).');
  {$ENDIF}
end;


(******************************************************************************)
(*                                                                            *)
(*   Populate array for NCCODEXP                                              *)
(*                                                                            *)
(******************************************************************************)
procedure GetNCCODEXP(var tb: array of recNCCODEXP); stdcall;
var
   iii,jjj: integer;
begin
  {$IFDEF DEBUG}
  DLLAboutForm.updateStatus('Loading arrayNCCODEXP');
  if ( high(tb)-low(tb) < high(arrayNCCODEXP)-low(arrayNCCODEXP)) then
  begin
    DLLAboutForm.updateStatus('Error in arrayNCCODEXP. Destination too small.');
    exit;
  end;
  {$ENDIF}
  { move( arrayNCCODEXP, tb, sizeof(arrayNCCODEXP) ); }
  jjj:= low(tb);
  for iii:=low(arrayNCCODEXP) to high(arrayNCCODEXP) do
  begin
    tb[jjj].Code := arrayNCCODEXP[iii].Code;
    tb[jjj].Desc1 := arrayNCCODEXP[iii].Desc1;
    tb[jjj].Desc2 := arrayNCCODEXP[iii].Desc2;
    inc(jjj);
  end;
  for iii:=jjj to high(tb) do
  begin
    tb[iii].Code := #0;
    tb[iii].Desc1 := #0;
    tb[iii].Desc2 := #0;
  end;
  {$IFDEF DEBUG}
  iii:=1 + high(arrayNCCODEXP)- low(arrayNCCODEXP);
  DLLAboutForm.updateStatus('Loaded arrayNCCODEXP ' + inttostr(iii) + ' entrie(s).');
  {$ENDIF}
end;


(******************************************************************************)
(*                                                                            *)
(*   Populate array for NCEXMAMT                                              *)
(*                                                                            *)
(******************************************************************************)
procedure GetNCEXMAMT(var tb: array of recNCEXMAMT); stdcall;
var
   iii,jjj: integer;
begin
  {$IFDEF DEBUG}
  DLLAboutForm.updateStatus('Loading arrayNCEXMAMT');
  if ( high(tb)-low(tb) < high(arrayNCEXMAMT)-low(arrayNCEXMAMT)) then
  begin
    DLLAboutForm.updateStatus('Error in arrayNCEXMAMT. Destination too small.');
    exit;
  end;
  {$ENDIF}
  { move( arrayNCEXMAMT, tb, sizeof(arrayNCEXMAMT) ); }
  jjj:= low(tb);
  for iii:=low(arrayNCEXMAMT) to high(arrayNCEXMAMT) do
  begin
    tb[jjj].Tax_Year := arrayNCEXMAMT[iii].Tax_Year;
    tb[jjj].Personal := arrayNCEXMAMT[iii].Personal;
    tb[jjj].Prov_Personal := arrayNCEXMAMT[iii].Prov_Personal; // Midyear 2003
    tb[jjj].Spouse := arrayNCEXMAMT[iii].Spouse;
    tb[jjj].Prov_Spouse := arrayNCEXMAMT[iii].Prov_Spouse; // Midyear 2003
    tb[jjj].ChildSpouse := arrayNCEXMAMT[iii].ChildSpouse;
    tb[jjj].Prov_ChildSpouse := arrayNCEXMAMT[iii].Prov_ChildSpouse; // Midyear 2003
    tb[jjj].Dep_1st := arrayNCEXMAMT[iii].Dep_1st;
    tb[jjj].Dep_3rd := arrayNCEXMAMT[iii].Dep_3rd;
    tb[jjj].Infirm_Dep := arrayNCEXMAMT[iii].Infirm_Dep;
    tb[jjj].Prov_Infirm_Dep := arrayNCEXMAMT[iii].Prov_Infirm_Dep; // Midyear 2003
    tb[jjj].II_Personal := arrayNCEXMAMT[iii].II_Personal;
    tb[jjj].II_Spouse := arrayNCEXMAMT[iii].II_Spouse;
    tb[jjj].II_ChildSpouse := arrayNCEXMAMT[iii].II_ChildSpouse;
    tb[jjj].II_Dep := arrayNCEXMAMT[iii].II_Dep;
    tb[jjj].II_Infirm_Dep := arrayNCEXMAMT[iii].II_Infirm_Dep;
    tb[jjj].III_Personal := arrayNCEXMAMT[iii].III_Personal;
    tb[jjj].III_Spouse := arrayNCEXMAMT[iii].III_Spouse;
    tb[jjj].III_ChildSpouse := arrayNCEXMAMT[iii].III_ChildSpouse;
    tb[jjj].III_Dep := arrayNCEXMAMT[iii].III_Dep;
    tb[jjj].III_Infirm_Dep := arrayNCEXMAMT[iii].III_Infirm_Dep;
    tb[jjj].federalChildTaxCredit := arrayNCEXMAMT[iii].federalChildTaxCredit;  // Midyear 2007
    inc(jjj);
  end;
  for iii:=jjj to high(tb) do
  begin
    tb[iii].Tax_Year := 0;
    tb[iii].Personal := 0;
    tb[iii].Spouse := 0;
    tb[iii].ChildSpouse := 0;
    tb[iii].Dep_1st := 0;
    tb[iii].Dep_3rd := 0;
    tb[iii].Infirm_Dep := 0;
    tb[iii].II_Personal := 0;
    tb[iii].II_Spouse := 0;
    tb[iii].II_ChildSpouse := 0;
    tb[iii].II_Dep := 0;
    tb[iii].II_Infirm_Dep := 0;
    tb[iii].III_Personal := 0;
    tb[iii].III_Spouse := 0;
    tb[iii].III_ChildSpouse := 0;
    tb[iii].III_Dep := 0;
    tb[iii].III_Infirm_Dep := 0;
    tb[iii].federalChildTaxCredit := 0;    // Midyear 2007
  end;
  {$IFDEF DEBUG}
  iii:=1 + high(arrayNCEXMAMT)- low(arrayNCEXMAMT);
  DLLAboutForm.updateStatus('Loaded arrayNCEXMAMT ' + inttostr(iii) + ' entrie(s).');
  {$ENDIF}
end;

(******************************************************************************)
(*                                                                            *)
(*   Populate array for NCINDEXF                                              *)
(*                                                                            *)
(******************************************************************************)
procedure GetNCINDEXF(var tb: array of recNCINDEXF); stdcall;
var
   iii,jjj: integer;
begin
  {$IFDEF DEBUG}
  DLLAboutForm.updateStatus('Loading arrayNCINDEXF');
  if ( high(tb)-low(tb) < high(arrayNCINDEXF)-low(arrayNCINDEXF)) then
  begin
    DLLAboutForm.updateStatus('Error in arrayNCINDEXF. Destination too small.');
    exit;
  end;
  {$ENDIF}
  { move( arrayNCINDEXF, tb, sizeof(arrayNCINDEXF) ); }
  jjj:= low(tb);
  for iii:=low(arrayNCINDEXF) to high(arrayNCINDEXF) do
  begin
    tb[jjj].Indexation_Year := arrayNCINDEXF[iii].Indexation_Year;
    tb[jjj].Indexing_Factor := arrayNCINDEXF[iii].Indexing_Factor;
    inc(jjj);
  end;
  for iii:=jjj to high(tb) do
  begin
    tb[iii].Indexation_Year := 0;
    tb[iii].Indexing_Factor := 0;
  end;
  {$IFDEF DEBUG}
  iii:=1 + high(arrayNCINDEXF)- low(arrayNCINDEXF);
  DLLAboutForm.updateStatus('Loaded arrayNCINDEXF ' + inttostr(iii) + ' entrie(s).');
  {$ENDIF}
end;

(******************************************************************************)
(*                                                                            *)
(*   Populate array for NCTAXRAT                                              *)
(*                                                                            *)
(******************************************************************************)
procedure GetNCTAXRAT(var tb: array of recNCTAXRAT); stdcall;
var
   iii,jjj: integer;
begin
  {$IFDEF DEBUG}
  DLLAboutForm.updateStatus('Loading arrayNCTAXRAT');
  if ( high(tb)-low(tb) < high(arrayNCTAXRAT)-low(arrayNCTAXRAT)) then
  begin
    DLLAboutForm.updateStatus('Error in arrayNCTAXRAT. Destination too small.');
    exit;
  end;
  {$ENDIF}
  { move( arrayNCTAXRAT, tb, sizeof(arrayNCTAXRAT) ); }
  jjj:= low(tb);
  for iii:=low(arrayNCTAXRAT) to high(arrayNCTAXRAT) do
  begin
    tb[jjj].Tax_Year := arrayNCTAXRAT[iii].Tax_Year;
    tb[jjj].UIC_premium_rate := arrayNCTAXRAT[iii].UIC_premium_rate;
    tb[jjj].UIC_max_insured_earnings := arrayNCTAXRAT[iii].UIC_max_insured_earnings;
    tb[jjj].UIC_max_annual_premium := arrayNCTAXRAT[iii].UIC_max_annual_premium;
    tb[jjj].CPP_basic_exemption := arrayNCTAXRAT[iii].CPP_basic_exemption;
    tb[jjj].CPP_contrib_rate := arrayNCTAXRAT[iii].CPP_contrib_rate;
    tb[jjj].CPP_max_annual_contrib := arrayNCTAXRAT[iii].CPP_max_annual_contrib;
    tb[jjj].CPP2_contrib_rate := arrayNCTAXRAT[iii].CPP2_contrib_rate;
    tb[jjj].CPP2_max_annual_contrib := arrayNCTAXRAT[iii].CPP2_max_annual_contrib;
    tb[jjj].FED_income_level_i := arrayNCTAXRAT[iii].FED_income_level_i;
    tb[jjj].FED_income_level_ii := arrayNCTAXRAT[iii].FED_income_level_ii;
    tb[jjj].FED_income_level_iii := arrayNCTAXRAT[iii].FED_income_level_iii;
    tb[jjj].FED_income_level_iiii := arrayNCTAXRAT[iii].FED_income_level_iiii;
    tb[jjj].FED_tax_amt_i := arrayNCTAXRAT[iii].FED_tax_amt_i;
    tb[jjj].FED_tax_amt_ii := arrayNCTAXRAT[iii].FED_tax_amt_ii;
    tb[jjj].FED_tax_amt_iii := arrayNCTAXRAT[iii].FED_tax_amt_iii;
    tb[jjj].FED_tax_amt_iiii := arrayNCTAXRAT[iii].FED_tax_amt_iiii;
    tb[jjj].FED_tax_rate_i := arrayNCTAXRAT[iii].FED_tax_rate_i;
    tb[jjj].FED_tax_rate_ii := arrayNCTAXRAT[iii].FED_tax_rate_ii;
    tb[jjj].FED_tax_rate_iii := arrayNCTAXRAT[iii].FED_tax_rate_iii;
    tb[jjj].FED_tax_rate_iiii := arrayNCTAXRAT[iii].FED_tax_rate_iiii;
    tb[jjj].FED_tax_rate_iiiii := arrayNCTAXRAT[iii].FED_tax_rate_iiiii;
    tb[jjj].FED_surtax_rate_i := arrayNCTAXRAT[iii].FED_surtax_rate_i;
    tb[jjj].FED_surtax_rate_ii := arrayNCTAXRAT[iii].FED_surtax_rate_ii;
    tb[jjj].FED_surtax_limit_ii := arrayNCTAXRAT[iii].FED_surtax_limit_ii;
    tb[jjj].MB_tax_rate := arrayNCTAXRAT[iii].MB_tax_rate;
    tb[jjj].MB_tax_rate_i := arrayNCTAXRAT[iii].MB_tax_rate_i;
    tb[jjj].MB_tax_rate_ii := arrayNCTAXRAT[iii].MB_tax_rate_ii;
    tb[jjj].MB_tax_rate_iii := arrayNCTAXRAT[iii].MB_tax_rate_iii;
    tb[jjj].MB_income_level_i := arrayNCTAXRAT[iii].MB_income_level_i;
    tb[jjj].MB_income_level_ii := arrayNCTAXRAT[iii].MB_income_level_ii;
    tb[jjj].MB_tax_amt_i := arrayNCTAXRAT[iii].MB_tax_amt_i;
    tb[jjj].MB_tax_amt_ii := arrayNCTAXRAT[iii].MB_tax_amt_ii;
    tb[jjj].MB_net_tax_rate := arrayNCTAXRAT[iii].MB_net_tax_rate;
    tb[jjj].mbFamilyTaxBenefitRate := arrayNCTAXRAT[iii].mbFamilyTaxBenefitRate;
    //tb[jjj].federalCanadaEmploymentCredit := arrayNCTAXRAT[iii].federalCanadaEmploymentCredit;
    inc(jjj);
  end;
  for iii:=jjj to high(tb) do
  begin
    tb[iii].Tax_Year := 0;
    tb[iii].UIC_premium_rate := 0;
    tb[iii].UIC_max_insured_earnings := 0;
    tb[iii].UIC_max_annual_premium := 0;
    tb[iii].CPP_basic_exemption := 0;
    tb[iii].CPP_contrib_rate := 0;
    tb[iii].CPP_max_annual_contrib := 0;
    tb[iii].FED_income_level_i := 0;
    tb[iii].FED_income_level_ii := 0;
    tb[iii].FED_income_level_iii := 0;
    tb[iii].FED_tax_amt_i := 0;
    tb[iii].FED_tax_amt_ii := 0;
    tb[iii].FED_tax_amt_iii := 0;
    tb[iii].FED_tax_amt_iiii := 0;
    tb[iii].FED_tax_rate_i := 0;
    tb[iii].FED_tax_rate_ii := 0;
    tb[iii].FED_tax_rate_iii := 0;
    tb[iii].FED_tax_rate_iiii := 0;
    tb[iii].FED_tax_rate_iiiii := 0;
    tb[iii].FED_surtax_rate_i := 0;
    tb[iii].FED_surtax_rate_ii := 0;
    tb[iii].FED_surtax_limit_ii := 0;
    tb[iii].MB_tax_rate := 0;
    tb[iii].MB_tax_rate_i := 0;
    tb[iii].MB_tax_rate_ii := 0;
    tb[iii].MB_tax_rate_iii := 0;
    tb[iii].MB_income_level_i := 0;
    tb[iii].MB_income_level_ii := 0;
    tb[iii].MB_tax_amt_i := 0;
    tb[iii].MB_tax_amt_ii := 0;
    tb[iii].MB_net_tax_rate := 0;
    tb[iii].mbFamilyTaxBenefitRate := 0;
    //tb[iii].federalCanadaEmploymentCredit := 0;
  end;
  {$IFDEF DEBUG}
  iii:=1 + high(arrayNCTAXRAT)- low(arrayNCTAXRAT);
  DLLAboutForm.updateStatus('Loaded arrayNCTAXRAT ' + inttostr(iii) + ' entrie(s).');
  {$ENDIF}
end;

(******************************************************************************)
(*                                                                            *)
(*   Populate array for NC_CFIO                                               *)
(*                                                                            *)
(******************************************************************************)
procedure GetNC_CFIO(var tb: array of recNC_CFIO); stdcall;
var
   iii,jjj: integer;
begin
  {$IFDEF DEBUG}
  DLLAboutForm.updateStatus('Loading arrayNC_CFIO');
  if ( high(tb)-low(tb) < high(arrayNC_CFIO)-low(arrayNC_CFIO)) then
  begin
    DLLAboutForm.updateStatus('Error in arrayNC_CFIO. Destination too small.');
    exit;
  end;
  {$ENDIF}
  { move( arrayNC_CFIO, tb, sizeof(arrayNC_CFIO) ); }
  jjj:= low(tb);
  for iii:=low(arrayNC_CFIO) to high(arrayNC_CFIO) do
  begin
    tb[jjj].PRIME_FIRM_NO := arrayNC_CFIO[iii].PRIME_FIRM_NO;
    tb[jjj].firmClass := arrayNC_CFIO[iii].firmClass;
    tb[jjj].Firm_Name := arrayNC_CFIO[iii].Firm_Name;
    inc(jjj);
  end;
  for iii:=jjj to high(tb) do
  begin
    tb[iii].PRIME_FIRM_NO := #0;
    tb[iii].firmClass := #0;
    tb[iii].Firm_Name := #0;
  end;
  {$IFDEF DEBUG}
  iii:=1 + high(arrayNC_CFIO)- low(arrayNC_CFIO);
  DLLAboutForm.updateStatus('Loaded arrayNC_CFIO ' + inttostr(iii) + ' entrie(s).');
  {$ENDIF}
end;

(******************************************************************************)
(*                                                                            *)
(*   Populate array for NCIAWMAX                                               *)
(*                                                                            *)
(******************************************************************************)
procedure GetNCIAWMAX(var tb: array of recNCIAWMAX); stdcall;
var
   iii,jjj: integer;
begin
  {$IFDEF DEBUG}
  DLLAboutForm.updateStatus('Loading arrayNCIAWMAX');
  if ( high(tb)-low(tb) < high(arrayNCIAWMAX)-low(arrayNCIAWMAX)) then
     begin
     DLLAboutForm.updateStatus('Error in arrayNCIAWMAX. Destination too small.');
     exit;
     end;
  {$ENDIF}
  { move( arrayNCIAWMAX, tb, sizeof(arrayNCIAWMAX) ); }
  jjj:= low(tb);

  for iii:=low(arrayNCIAWMAX) to high(arrayNCIAWMAX) do
     begin
     tb[jjj].Tax_Year := arrayNCIAWMAX[iii].Tax_Year;
     tb[jjj].IAW_Maximum := arrayNCIAWMAX[iii].IAW_Maximum;
     inc(jjj);
     end;

  for iii:=jjj to high(tb) do
     begin
     tb[iii].Tax_Year := 0;
     tb[iii].IAW_Maximum := 0;
     end;
  {$IFDEF DEBUG}
  iii:=1 + high(arrayNCIAWMAX)- low(arrayNCIAWMAX);
  DLLAboutForm.updateStatus('Loaded arrayNCIAWMAX ' + inttostr(iii) + ' entrie(s).');
  {$ENDIF}
end;

end.
