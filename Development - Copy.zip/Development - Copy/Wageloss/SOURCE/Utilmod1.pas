(******************************************************************************)
(*  Wageloss System                                                           *)
(*                                                                            *)
(*  General Utility functions                                                 *)
(*    - to be used in any module.                                             *)
(*                                                                            *)
(*                                                                            *)
(*  Author: Brad Trupp  / Capella Systems Group, Inc.                         *)
(*  Date:   August 1997                                                       *)
(*                                                                            *)
(*  Nov 98 - BT - year 2000 windowing fixes                                   *)
(*                                                                            *)
(******************************************************************************)

unit utilmod1;

interface

uses
  Windows, Messages, SysUtils, Classes, Graphics, Controls, Forms, Dialogs,
  StdCtrls, ComCtrls, Math;

function PdoxRound( n: currency; d: integer ): currency;
function PdoxMax( const n1, n2: currency ): currency;
function cleanNumber( const s: shortstring ): shortstring;
function validateAsInteger( te: TEdit ): boolean;
function validateAsCurrency( te: TEdit ): boolean;
//function validateAsDate( te: TEdit ): boolean;
function validateSystemDateFormat : boolean;
function textAsInteger( te: TEdit ): integer;
function textAsCurrency( te: TEdit ): currency;
//function textAsDate( te: TEdit ): tdatetime;
function year( const d: tdatetime): integer;
function month( const d: tdatetime): integer;
function day( const d: tdatetime): integer;
function pdoxTrim( const s: shortstring ): shortstring;
procedure setEditToRead( te: TEdit );
procedure setEditToNormal( te: TEdit );
procedure hideEdit( te: TEdit );
procedure hideLabel( lb: TLabel );

function SQLString( s:shortstring ): shortstring;
function SQLInteger( i:integer ): shortstring;
function SQLCurrency( c:currency ): shortstring;
function SQLBoolean( b:boolean ): shortstring;
function SQLDateTime( t:tDateTime ): shortstring;

function getTempFolder:String;
function displayError( aErrorMessage : String; aFormField : TWinControl ) : boolean;
function getEmergeBusinessDate : TDateTime;
function AddMonths(aDate: TDateTime; Months: Word): TDateTime;
function DaysInMonth(Year, Month: Word): Word;
function GetDayTable(Year: Word): PDayTable;
function IsLeapYear(Year: Word): Boolean;
implementation

uses NCMain, NCDatMod;

(******************************************************************************)
(*                                                                            *)
(*  Equivalent to Round( n, 2 ) in Paradox                                    *)
(*                                                                            *)
(******************************************************************************)
//function PdoxRound( const n: currency; d: integer ): currency;
//begin
//  result:= round( n * 100.00 ) / 100.00;
//end;

//bcooper - 01/12/2007
//Changed PdoxRound function because of rounding errors in Wage Loss.  The
//delphi function Round( n, 2 ) uses "bankers rounding" which is not the type of
//rounding that we are going to use.  This new function replaces that.
function PdoxRound(n: currency; d: Integer): currency;
// roundDecimal(123.456, 0) = 123.00
// roundDecimal(123.456, 2) = 123.46
// roundDecimal(123456, -3) = 123000
var
  x: Extended;
begin
  x := IntPower(10, d);
  n := n * x;
  Result := (Int(n) + Int(Frac(n) * 2)) / x;
end;


(******************************************************************************)
(*                                                                            *)
(*  Equivalent to Max( n1, n2 ) in Paradox                                   *)
(*                                                                            *)
(******************************************************************************)
function PdoxMax( const n1, n2: currency ): currency;
begin
  if n1 > n2 then result:=n1 else result:=n2;
end;

(******************************************************************************)
(*                                                                            *)
(*  Remove extraneous formatting from a number string.                        *)
(*                                                                            *)
(******************************************************************************)
function cleanNumber( const s: shortstring ): shortstring;
var
  ws: shortstring;
  iii: integer;
begin
  ws := '';
  for iii:=1 to length( s ) do
  begin
    case s[iii] of
    '0'..'9','-','.': ws:= ws + s[iii];
    end;
  end;
  result:=ws;
end;

(******************************************************************************)
(*                                                                            *)
(*  Validates the text in a TEdit to be a valid integer.                      *)
(*                                                                            *)
(******************************************************************************)
function validateAsInteger( te: TEdit ): boolean;
begin
  result:=true;
  if length( te.text ) < 1 then exit;
  try
     strToInt( cleanNumber(te.text) );
  except
     result:=false;
     messagebeep(0);
     WagelossMainForm.ShowInfoLine2('Invalid Integer for '+ copy(te.name,3, length(te.name)));
     if te.Enabled then
      te.setfocus;
  end;
end;

(******************************************************************************)
(*                                                                            *)
(*  Validates the text in a TEdit to be a valid currency.                     *)
(*                                                                            *)
(******************************************************************************)
function validateAsCurrency( te: TEdit ): boolean;
begin
  result:=true;
  if length( te.text ) < 1 then exit;
  try
     strToFloat( cleanNumber(te.text) );
  except
     result:=false;
     messagebeep(0);
     WagelossMainForm.ShowInfoLine2('Invalid Currency for '+ copy(te.name,3, length(te.name)));
     if te.Enabled then
      te.setfocus;
  end;
end;

(******************************************************************************)
(*                                                                            *)
(*  Validates the text in a TEdit to be a valid Date.                         *)
(*                                                                            *)
(******************************************************************************)
//function validateAsDate( te: TEdit ): boolean;
//var
//  ts: shortstring;
//  dd,mm,yy:word;
//begin
//  result:=true;
//  ts:=te.text;
//  if length( ts ) < 1 then exit;
//
//  try
//
//  // try to convert ddmmyy to proper format
//  if ( length ( ts ) = 6 ) and ( pos( '/',ts ) = 0 ) then
//     begin
//     dd:=strToInt(copy(ts,1,2));
//     mm:=strToInt(copy(ts,3,2));
//     yy:=strToInt(copy(ts,5,2));
//     // Nov 98 - BT - year 2000 windowing fixes
//     if yy < 40 then
//        ts := formatdatetime('c',EncodeDate(2000 + yy,mm,dd))
//     else
//        ts := formatdatetime('c',EncodeDate(1900 + yy,mm,dd));
//     end
//  //
//  // Modified to handle an 8 character date in the form ddmmyyyy
//  //
//  else if (Length(ts) = 8) and (pos('/',ts) = 0) then
//     begin
//     dd:=strToInt(copy(ts,1,2));
//     mm:=strToInt(copy(ts,3,2));
//     yy:=strToInt(copy(ts,5,4));
//     // Nov 98 - BT - year 2000 windowing fixes
//     ts := formatdatetime('c',EncodeDate(yy,mm,dd));
//     end;
//
//  strToDate( ts );
//
//  except
//     result:=false;
//     messagebeep(0);
//     WagelossMainForm.ShowInfoLine2('Invalid Date for '+ copy(te.name,3, length(te.name)));
//     if te.Enabled then
//      te.setfocus;
//  end;
//end;

(******************************************************************************)
(*                                                                            *)
(*  Ensure that system date format remains dd/MM/yyyy.                        *)
(*                                                                            *)
(******************************************************************************)
function validateSystemDateFormat : boolean;
var
  testDateStr: string;
  testDate: TDateTime;
  dd,mm,yy:word;
begin
  result := true;
  testDateStr:='01/11/2010';
  testDate:=StrToDate(testDateStr);
  DecodeDate(testDate, yy, mm, dd);
  if not ( ( dd = 1 ) and ( mm = 11 ) ) then
    begin
      messagebeep(0);
      WagelossMainForm.ShowInfoLine2('*Incorrect System Date Format.  Please call Help Desk at 4573.');
      result := false;
    end;
end;

(******************************************************************************)
(*                                                                            *)
(*  Returns the text in a TEdit as an integer.                                *)
(*                                                                            *)
(******************************************************************************)
function textAsInteger( te: TEdit ): integer;
begin
  result:=0;
  if length( te.text ) < 1 then exit;
  try
     result:=strToInt( cleanNumber(te.text) );
  except
     result:=0;
  end;
end;

(******************************************************************************)
(*                                                                            *)
(*  Returns the text in a TEdit as currency.                                  *)
(*                                                                            *)
(******************************************************************************)
function textAsCurrency( te: TEdit ): currency;
begin
  result:=0.0;
  if length( te.text ) < 1 then exit;
  try
     result:=strToFloat( cleanNumber(te.text) );
  except
     result:=0.0;
  end;
end;

(******************************************************************************)
(*                                                                            *)
(*  Returns the text in a TEdit as a tDateTime.                               *)
(*                                                                            *)
(******************************************************************************)
//function textAsDate( te: TEdit ): tdatetime;
//var
//  ts: shortstring;
//  dd,mm,yy:word;
//begin
//  result:=0;
//  ts:=te.text;
//  if length( ts ) < 1 then exit;
//  try
//
//  // try to convert ddmmyy to proper format
//  if ( length ( ts ) = 6 ) and ( pos( '/',ts ) = 0 ) then
//     begin
//     dd:=strToInt(copy(ts,1,2));
//     mm:=strToInt(copy(ts,3,2));
//     yy:=strToInt(copy(ts,5,2));
//     // Nov 98 - BT - year 2000 windowing fixes
//     if yy < 40 then
//        ts := formatdatetime('c',EncodeDate(2000 + yy,mm,dd))
//     else
//        ts := formatdatetime('c',EncodeDate(1900 + yy,mm,dd));
//     end
//  //
//  // Modified to handle an 8 character date in the form ddmmyyyy
//  //
//  else if (Length(ts) = 8) and (pos('/',ts) = 0) then
//     begin
//     dd:=strToInt(copy(ts,1,2));
//     mm:=strToInt(copy(ts,3,2));
//     yy:=strToInt(copy(ts,5,4));
//     // Nov 98 - BT - year 2000 windowing fixes
//     ts := formatdatetime('c',EncodeDate(yy,mm,dd));
//     end;
//
//  result := strToDate( ts );
//
//  except
//     result:=0;
//  end;
//end;

(******************************************************************************)
(*                                                                            *)
(*  Equivalent to year( d ) function in Paradox.                              *)
(*                                                                            *)
(******************************************************************************)
function year( const d: tdatetime): integer;
begin
  try
    result:= strtoint( formatdatetime('yyyy', d ) );
  except
    result:=0;
  end;
end;

(******************************************************************************)
(*                                                                            *)
(*  Equivalent to month( d ) function in Paradox.                             *)
(*                                                                            *)
(******************************************************************************)
function month( const d: tdatetime): integer;
begin
  try
    result:= strtoint( formatdatetime('mm', d ) );
  except
    result:=0;
  end;
end;

(******************************************************************************)
(*                                                                            *)
(*  Equivalent to day( d ) function in Paradox.                               *)
(*                                                                            *)
(******************************************************************************)
function day( const d: tdatetime): integer;
begin
  try
    result:= strtoint( formatdatetime('dd', d ) );
  except
    result:=0;
  end;
end;

(******************************************************************************)
(*                                                                            *)
(*  Trims all leading and trailing spaces. Note: a string of all spaces is    *)
(*  trimmed to a null string.                                                 *)
(*                                                                            *)
(******************************************************************************)
function pdoxTrim( const s: shortstring ): shortstring;
var
  ws: shortstring;
begin
  ws:=s;
  while (length(ws) > 0 ) and ( ws[1] = ' ' ) do delete(ws,1,1);
  while (length(ws) > 0 ) and ( ws[length(ws)] = ' ' ) do delete(ws,length(ws),1);
  result:=ws;
end;

(******************************************************************************)
(*                                                                            *)
(*  Changes a TEdit to a display field.                                       *)
(*                                                                            *)
(******************************************************************************)
procedure setEditToRead( te: TEdit );
begin
  te.readonly:=true;
  te.color:=clBtnFace;
  te.enabled:=false;
end;

(******************************************************************************)
(*                                                                            *)
(*  Resets a TEdit back to being editable.                                    *)
(*                                                                            *)
(******************************************************************************)
procedure setEditToNormal( te: TEdit );
begin
  te.readonly:=false;
  te.color:=clAqua; //clWindow;
  te.enabled:=true;
end;


(******************************************************************************)
(*                                                                            *)
(*  Hides a TEdit object.                                                     *)
(*                                                                            *)
(******************************************************************************)
procedure hideEdit( te: TEdit );
begin
  te.enabled:=false;
  te.visible:=false;
end;

(******************************************************************************)
(*                                                                            *)
(*  Hides a TLabel object.                                                    *)
(*                                                                            *)
(******************************************************************************)
procedure hideLabel( lb: TLabel );
begin
  lb.visible:=false;
end;

(******************************************************************************)
(*                                                                            *)
(*  Convert a string to SQL friendly format                                   *)
(*                                                                            *)
(******************************************************************************)
function SQLString( s:shortstring ):shortstring;
//
// Modified by D. Madill
// May 2004
// Modified to use a character code to delimit SQL string instead of a single quote
//
begin
  //result := chr(39) + s + chr(39) + ',';
  result := QuotedStr(s) + ',';
end;

(******************************************************************************)
(*                                                                            *)
(*  Convert an integer to SQL friendly format                                 *)
(*                                                                            *)
(******************************************************************************)
function SQLInteger( i:integer ): shortstring;
begin
  Result := IntToStr(i) + ',';
end;

(******************************************************************************)
(*                                                                            *)
(*  Convert a currencyto SQL friendly format                                  *)
(*                                                                            *)
(******************************************************************************)
function SQLCurrency( c:currency ): shortstring;
begin
  result := format('%.2f', [ c ] ) + ',';
end;

(******************************************************************************)
(*                                                                            *)
(*  Convert a boolean to SQL friendly format                                  *)
(*                                                                            *)
(******************************************************************************)
function SQLBoolean( b:boolean ): shortstring;
begin
  if b then result := '''Y'',' else result := '''N'',';
end;

(******************************************************************************)
(*                                                                            *)
(*  Convert a tDateTime to SQL friendly format                                *)
(*                                                                            *)
(******************************************************************************)
//
// Modified by D. Madill
// Oct 2004
// Modified to Date Time to an actual Date Time format
//
function SQLDateTime( t:tDateTime ): shortstring;
begin
  if t = 0 then
    result := 'NULL,'
  else
    result := '''' + FormatDateTime('mm/dd/yyyy h:nn:ss',t)+''',';
end;
//
//
//
function getTempFolder:String;
var
  temp_char: pchar;
  sz: DWORD;
  CurrTempPath:String;
begin
  // get system userid from Windows
  getmem(temp_Char,128 * SizeOf(Char));
  sz:=127;

  try
    GetTempPath(sz,temp_Char);
    CurrTempPath := UpperCase(strpas(temp_Char));
  finally
    freemem(temp_Char);
  end;

  result := CurrTempPath;
end;

function displayError( aErrorMessage : String; aFormField : TWinControl ) : boolean;
var
  errorMessage : String;
  formField : TWinControl;
  globalEditError : boolean;
begin
  errorMessage := aErrorMessage;
  formField := aFormField;

  messagebeep(0);
  if formField.Enabled then
    formField.setfocus;
  WagelossMainForm.ShowInfoLine2( errorMessage );
  globalEditError := true;

  result := globalEditError;
end;

function getEmergeBusinessDate : TDateTime;
var
  emergeBusinessDate : TDateTime;
begin
  try
    with dm1.qryGeneralEmerge do
    begin
      if Active then
        Close;
      SQL.Clear;
      SQL.Add( 'SELECT Max(businessDate) businessDate FROM BusinessDate' );
      Open;

      emergeBusinessDate := FieldByName( 'businessDate').AsDateTime;
      Close;
    end;
  except
    on E:Exception do
    Begin
      result := StrToDate('');
      dm1.qryGeneralEmerge.Close;
      WagelossMainForm.ShowInfoLine2( '*Emerge Business Date not found' );
      exit;
    end;//exception
  end;//try/except

  result := PdoxRound( emergeBusinessDate, 0 );
end;

function AddMonths(aDate: TDateTime; Months: Word): TDateTime;
var
  TotalDays, CurrentMonth, CurrentYear: Word;
begin
  TotalDays := 0;
  CurrentMonth := Month( aDate );
  CurrentYear := Year( aDate );

  while Months > 0 do
  begin
    Inc( TotalDays, DaysInMonth( CurrentYear, CurrentMonth ) );
    if CurrentMonth = 12 then
    begin
      CurrentMonth := 1;
      Inc( CurrentYear );
    end
    else
      Inc( CurrentMonth );
    Dec(Months);
  end;

  Result := aDate + TotalDays;
end;

function DaysInMonth(Year, Month: Word): Word;
begin
  Result := GetDayTable( Year )[Month];
end;

function GetDayTable(Year: Word): PDayTable;
const
  DayTable1: TDayTable =
    ( 31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31 );
  DayTable2: TDayTable =
    ( 31, 29, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31 );
  DayTables: array[Boolean] of PDayTable = (@DayTable1, @DayTable2);
begin
  Result := DayTables[IsLeapYear( Year )];
end;

(******************************************************************************)
(*                                                                            *)
(*  Display Indexation Form                                                   *)
(*                                                                            *)
(******************************************************************************)
//
// Modified March 5, 2003
// Modified by D. Madill
// modified to check that the claim is eligible for indexation by checking the
// date to see if we have passed the indexation date. Also if the tax year
// does not exist it will not allow the indexation
//
function IsLeapYear(Year: Word): Boolean;
begin
  Result := ( Year mod 4 = 0 ) and
            ( ( Year mod 100 <> 0 ) or
              ( Year mod 400 = 0 ) );
end;

end.
