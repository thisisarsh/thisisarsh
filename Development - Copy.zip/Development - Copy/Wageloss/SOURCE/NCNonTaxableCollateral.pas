unit NCNonTaxableCollateral;

interface

uses
  Windows, Messages, SysUtils, Variants, Classes, Graphics, Controls, Forms,
  Dialogs, StdCtrls;

type
  TNonTaxableCollateral = class(TForm)
    Label1: TLabel;
    Label2: TLabel;
    Label3: TLabel;
    edEmpTopUp: TEdit;
    edPrivateIns: TEdit;
    btnOK: TButton;
    btnCancel: TButton;
    procedure btnOKClick(Sender: TObject);
    procedure btnCancelClick(Sender: TObject);
    procedure edEmpTopUpExit(Sender: TObject);
    procedure edPrivateInsExit(Sender: TObject);
  private
    { Private declarations }
  public
    { Public declarations }
  end;

var
  NonTaxableCollateral: TNonTaxableCollateral;

implementation

uses Utils, NCMain;

{$R *.dfm}

procedure TNonTaxableCollateral.btnOKClick(Sender: TObject);
begin
  ModalResult := mrOK;
end;

procedure TNonTaxableCollateral.btnCancelClick(Sender: TObject);
begin
  ModalResult := mrCancel;
end;

procedure TNonTaxableCollateral.edEmpTopUpExit(Sender: TObject);
begin
  if not ValidateAsCurrency(edEmpTopUp) then
     begin
     MessageBeep(0);
     WagelossMainForm.ShowInfoLine2('*Invalid Employer Top Up Amount.');
     edEmpTopUp.SetFocus;
     Exit;
     end;

  If Not (TextAsCurrency(edEmpTopUp) >= 0) Then
     Begin
     MessageBeep(0);
     WagelossMainForm.ShowInfoLine2('*Employer Top Up must be greater than or equal to $0.00');
     edEmpTopUp.SetFocus;
     Exit;
     end;

  edEmpTopUp.Text := Format('%.2n',[textAsCurrency(edEmpTopUp)]);
end;

procedure TNonTaxableCollateral.edPrivateInsExit(Sender: TObject);
begin
  if not ValidateAsCurrency(edPrivateIns) then
     begin
     MessageBeep(0);
     WagelossMainForm.ShowInfoLine2('*Invalid Private Insurance Amount.');
     edPrivateIns.SetFocus;
     Exit;
     end;

  If Not (TextAsCurrency(edPrivateIns) >= 0) Then
     Begin
     MessageBeep(0);
     WagelossMainForm.ShowInfoLine2('*Private Insurance must be greater than or equal to $0.00');
     edPrivateIns.SetFocus;
     Exit;
     end;

  edPrivateIns.Text := Format('%.2n',[textAsCurrency(edPrivateIns)]);
end;

end.
