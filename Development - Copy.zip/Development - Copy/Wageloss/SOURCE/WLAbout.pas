(*****************************************************************)
(*  Wageloss System                                              *)
(*                                                               *)
(*  About program dialog                                         *)
(*                                                               *)
(*                                                               *)
(*  Author: Brad Trupp  / Capella Systems Group, Inc.            *)
(*  Date:   June 1997                                            *)
(*****************************************************************)

unit WLAbout;

interface

uses
  Windows, Messages, SysUtils, Classes, Graphics, Controls, Forms, Dialogs,
  StdCtrls, ExtCtrls;

(******************************************************************************)
(*                                                                            *)
(*  Define About Screen Information                                           *)
(*                                                                            *)
(******************************************************************************)
const
    FProduct         = 'Workers Compensation Board of Manitoba';
    FProduct2        = 'Benefits Wageloss System';
    FTitle           = 'Benefits Wageloss System';
    FRegUser         = '';
    FRegCompany      = 'Workers Compensation Board of Manitoba';

type
  TfrmAboutDlg = class(TForm)
    imgPro: TImage;
    cmdOK: TButton;
    lblPro: TLabel;
    lblVer: TLabel;
    lblCop: TLabel;
    lblPhy: TLabel;
    lblRAM: TLabel;
    lblWVe: TLabel;
    Label1: TLabel;
    Label2: TLabel;
    lblCurrentUser: TLabel;
    lblUserGIDName: TLabel;
    Image1: TImage;
    Label4: TLabel;
    lblDLLTaxYear: TLabel;
    Label8: TLabel;
    lblSql: TLabel;
    procedure FormCreate(Sender: TObject);
  private
	public
    procedure Loaded; override;
  end;

var
  frmAboutDlg: TfrmAboutDlg;

implementation

{$R *.DFM}

uses NCMain, NCIniMod, uADOSecurity, uGlobal, rsFileVersion;

var
	fv: TRsFileVersion;

(******************************************************************************)
(*                                                                            *)
(*  Fill in text information once About form is fully created.                *)
(*                                                                            *)
(******************************************************************************)
procedure TfrmAboutDlg.Loaded;
var
  MemoryStruct : TMemoryStatus;
  MemoryString, wlVersion : String;
  OSVersionInfo : TOSVersionInfo;
  Ver : String;
begin
  MemoryStruct.dwLength := SizeOf(MemoryStruct);
  GlobalMemoryStatus(MemoryStruct);
  MemoryStruct.dwTotalPhys := MemoryStruct.dwTotalPhys div 1024;
  MemoryString := IntToStr(MemoryStruct.dwTotalPhys);
  OSVersionInfo.dwOSVersionInfoSize := SizeOf(OSVersionInfo);
  GetVersionEx(OSVersionInfo);
  case OSVersionInfo.dwPlatformID of
    VER_PLATFORM_WIN32s        : Ver := 'Windows (Win32s)';
    VER_PLATFORM_WIN32_WINDOWS : Ver := 'Windows 95';
    VER_PLATFORM_WIN32_NT      : Ver := 'Windows NT';
  end;
  Ver := Ver + ' v' + IntToStr(OSVersionInfo.dwMajorVersion) +
                '.' + IntToStr(OSVersionInfo.dwMinorVersion) +
                ' (Build ' + IntToStr(OSVersionInfo.dwBuildNumber) + ')';
  Caption := FTitle;
  lblWVe.Caption := Ver;
  lblRAM.Caption := Copy(MemoryString,1,length(MemoryString) -3) + ','
                 + Copy(MemoryString,length(MemoryString)-2,10) + ' KB';
  if FProduct = '' then
    lblPro.Caption  := Application.Title
  else
    lblPro.Caption := FProduct;
  lblVer.Caption := FProduct2;

  if fv = nil then
  	fv := TrsFileVersion.Create();
	if fv.GetFileVersion( Application.ExeName ) then
		wlVersion :=  'Version ' + fv.Version;

  lblCop.Caption := wlVersion;
  imgPro.Picture.Icon := Application.Icon;

  with WagelossMainForm do
  begin
    lblCurrentUser.caption:=userProfile.givenName + ' ' + userProfile.familyName;
    lblUserGIDName.caption:=userProfile.capabilities;
    lblSQL.caption := uGlobal.CurrServer1 + ':' + uGlobal.CurrDatabaseName1;
  end;

  lblDLLTaxYear.caption:= intToStr(GetCurrentTaxYear);
end;

(******************************************************************************)
(*                                                                            *)
(*  Form Create - load background bitmap.                                     *)
(*                                                                            *)
(******************************************************************************)
procedure TfrmAboutDlg.FormCreate(Sender: TObject);
begin
  Width:=Image1.Picture.Bitmap.Width;
  Height:=Image1.Picture.Bitmap.Height;
end;

(******************************************************************************)
(*                                                                            *)
(*  Form Destroy - release background bitmap.                                 *)
(*                                                                            *)
(******************************************************************************)
end.
