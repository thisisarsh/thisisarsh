unit NCStartDate;

interface

uses
  Windows, Messages, SysUtils, Classes, Graphics, Controls, Forms, Dialogs,
  StdCtrls, ComCtrls;

type
  TSelectDateForm = class(TForm)
    OKBtn: TButton;
    CancelBtn: TButton;
    dtpStartDate: TDateTimePicker;
    procedure CancelBtnClick(Sender: TObject);
    procedure OKBtnClick(Sender: TObject);
    procedure FormActivate(Sender: TObject);
    procedure FormCreate(Sender: TObject);
  private
    { Private declarations }
  public
    { Public declarations }
  end;

var
  SelectDateForm: TSelectDateForm;

implementation

uses Utils, utilmod1;

{$R *.DFM}

procedure TSelectDateForm.CancelBtnClick(Sender: TObject);
begin
     ModalResult := mrCancel;
end;

procedure TSelectDateForm.OKBtnClick(Sender: TObject);
begin
     ModalResult := mrOK;
end;

procedure TSelectDateForm.FormActivate(Sender: TObject);
var
   Year, Day, Month: Word;
   DateForDtp: TDateTime;
begin
   DecodeDate( utilmod1.getEmergeBusinessDate(), Year, Month, Day );
   DateForDtp := EncodeDate(Year - 2, 1, 1);
   dtpStartDate.Date := DateForDtp;
end;

procedure TSelectDateForm.FormCreate(Sender: TObject);
begin
SetFont(Self);
end;

end.
