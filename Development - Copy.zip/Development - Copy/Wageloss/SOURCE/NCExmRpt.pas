(*****************************************************************)
(*  Wageloss System                                              *)
(*                                                               *)
(*  Exemption Amounts Report                                     *)
(*                                                               *)
(*                                                               *)
(*  Author: Ron Warkentin / WCB                                  *)
(*  Date:   August 1997                                          *)
(*****************************************************************)

unit NCExmRpt;

interface

uses
  Windows, Messages, SysUtils, Classes, Graphics, Controls, Forms, Dialogs,
  ExtCtrls, quickrpt, Qrctrls;

type
  TPrintExemptionAmountsForm = class(TForm)
    QRExemptionAmounts: TQuickRep;
    QRBand1: TQRBand;
    QRBand2: TQRBand;
    QRSysData2: TQRSysData;
    QRSysData3: TQRSysData;
    QRSysData4: TQRSysData;
    QRYear: TQRLabel;
    QRLabel4: TQRLabel;
    QRLabel5: TQRLabel;
    QRLabel6: TQRLabel;
    QRLabel7: TQRLabel;
    QRLabel8: TQRLabel;
    QRLabel9: TQRLabel;
    QRLabel10: TQRLabel;
    QRLabel11: TQRLabel;
    QRLabel3: TQRLabel;
    QRLabel12: TQRLabel;
    QRLabel13: TQRLabel;
    QRPersonal: TQRLabel;
    QRSpouse: TQRLabel;
    QRInfirm: TQRLabel;
    QRDep3rd: TQRLabel;
    QRChildSpouse: TQRLabel;
    QRDep1st: TQRLabel;
    QRIIPersonal: TQRLabel;
    QRIIChildSpouse: TQRLabel;
    QRIISpouse: TQRLabel;
    QRIIDep: TQRLabel;
    QRIIInfirm: TQRLabel;
    QRIIIPersonal: TQRLabel;
    QRIIISpouse: TQRLabel;
    QRIIIChildSpouse: TQRLabel;
    QRIIIDep: TQRLabel;
    QRIIIInfirm: TQRLabel;
    QRUserID: TQRLabel;
    QRLabel2: TQRLabel;
    QRLabel1: TQRLabel;
    QRSysData1: TQRSysData;
    procedure QRExemptionAmountsBeforePrint(Sender: TCustomQuickRep;
      var PrintReport: Boolean);
    procedure QRExemptionAmountsNeedData(Sender: TObject;
      var MoreData: Boolean);
    procedure QRBand2BeforePrint(Sender: TQRCustomBand;
      var PrintBand: Boolean);
  private
    { Private declarations }
    iii: integer;
  public
    { Public declarations }
  end;

var
  PrintExemptionAmountsForm: TPrintExemptionAmountsForm;

implementation

{$R *.DFM}

uses
  NCIniMod, NCMain, uADOSecurity;

procedure TPrintExemptionAmountsForm.QRExemptionAmountsBeforePrint(
  Sender: TCustomQuickRep; var PrintReport: Boolean);
begin
  {Set starting point for array index.}
  iii := low(arrayNCEXMAMT);
  QRUserID.caption := UserProfile.givenName + ' ' + userProfile.familyName;
end;

procedure TPrintExemptionAmountsForm.QRExemptionAmountsNeedData(
  Sender: TObject; var MoreData: Boolean);
begin
  If iii > high(arrayNCEXMAMT) then
     MoreData := False {the end of the array has been reached}
  Else
  If length(IntToStr(arrayNCEXMAMT[iii].Tax_Year)) <= 1 then
     MoreData := False {lengths of 1 indicate blank array values}

  Else
  begin
    // Print values from EXEMPTION AMOUNTS TABLE
    QRYear.caption  := IntToStr(arrayNCEXMAMT[iii].Tax_Year);
    QRPersonal.caption := Format('%n', [arrayNCEXMAMT[iii].Personal]);
    QRSpouse.caption := Format('%n', [arrayNCEXMAMT[iii].Spouse]);
    QRChildSpouse.caption := Format('%n', [arrayNCEXMAMT[iii].ChildSpouse]);
    QRDep1st.caption := Format('%n', [arrayNCEXMAMT[iii].Dep_1st]);
    QRDep3rd.caption := Format('%n', [arrayNCEXMAMT[iii].Dep_3rd]);
    QRInfirm.caption := Format('%n', [arrayNCEXMAMT[iii].Infirm_Dep]);
    QRIIPersonal.caption := Format('%n', [arrayNCEXMAMT[iii].II_Personal]);
    QRIISpouse.caption := Format('%n', [arrayNCEXMAMT[iii].II_Spouse]);
    QRIIChildSpouse.caption := Format('%n', [arrayNCEXMAMT[iii].II_ChildSpouse]);
    QRIIDep.caption := Format('%n', [arrayNCEXMAMT[iii].II_Dep]);
    QRIIInfirm.caption := Format('%n', [arrayNCEXMAMT[iii].II_Infirm_Dep]);
    QRIIIPersonal.caption := Format('%n', [arrayNCEXMAMT[iii].III_Personal]);
    QRIIISpouse.caption := Format('%n', [arrayNCEXMAMT[iii].III_Spouse]);
    QRIIIChildSpouse.caption := Format('%n', [arrayNCEXMAMT[iii].III_ChildSpouse]);
    QRIIIDep.caption := Format('%n', [arrayNCEXMAMT[iii].III_Dep]);
    QRIIIInfirm.caption := Format('%n', [arrayNCEXMAMT[iii].III_Infirm_Dep]);

    Inc(iii);
    MoreData := True; {more data to process}
  end;
end;

procedure TPrintExemptionAmountsForm.QRBand2BeforePrint(
  Sender: TQRCustomBand; var PrintBand: Boolean);
var
 i : Integer;
begin
  with QRBand2 do
  begin
    if Color = $00F0F0F0 then
      Color := $00E0E0E0
    else
      Color := $00F0F0F0;
    for i := 0 to ControlCount-1 do
    begin
       TQRLabel(Controls[i]).Color := Color;
    end;
  end;
end;

end.
