object WagelossOverpaymentRecoveryForm: TWagelossOverpaymentRecoveryForm
  Left = 413
  Top = 133
  ActiveControl = edPlannedRecoveryAmt
  BorderStyle = bsDialog
  Caption = 'Overpayment Recovery Options'
  ClientHeight = 431
  ClientWidth = 827
  Color = clBtnFace
  Font.Charset = DEFAULT_CHARSET
  Font.Color = clWindowText
  Font.Height = -11
  Font.Name = 'MS Sans Serif'
  Font.Style = []
  OldCreateOrder = False
  OnActivate = FormActivate
  OnClose = FormClose
  OnCreate = FormCreate
  OnDestroy = FormDestroy
  PixelsPerInch = 96
  TextHeight = 13
  object lblPayeeType: TLabel
    Left = 11
    Top = 8
    Width = 73
    Height = 16
    Alignment = taRightJustify
    Caption = 'Payee Type:'
    Font.Charset = ANSI_CHARSET
    Font.Color = clWindowText
    Font.Height = -13
    Font.Name = 'Arial'
    Font.Style = []
    ParentFont = False
  end
  object lblPaymentMethod: TLabel
    Left = 11
    Top = 32
    Width = 103
    Height = 16
    Alignment = taRightJustify
    Caption = 'Payment Method:'
    Font.Charset = ANSI_CHARSET
    Font.Color = clWindowText
    Font.Height = -13
    Font.Name = 'Arial'
    Font.Style = []
    ParentFont = False
  end
  object lblPayee: TLabel
    Left = 312
    Top = 8
    Width = 45
    Height = 16
    Alignment = taRightJustify
    Caption = 'Pay To:'
    Font.Charset = ANSI_CHARSET
    Font.Color = clWindowText
    Font.Height = -13
    Font.Name = 'Arial'
    Font.Style = []
    ParentFont = False
  end
  object lblTotOutstandingAmt: TLabel
    Left = 11
    Top = 112
    Width = 155
    Height = 16
    Alignment = taRightJustify
    Caption = 'Total Outstanding Amount:'
    Font.Charset = ANSI_CHARSET
    Font.Color = clWindowText
    Font.Height = -13
    Font.Name = 'Arial'
    Font.Style = []
    ParentFont = False
  end
  object lblTotOverpayentAmt: TLabel
    Left = 11
    Top = 88
    Width = 161
    Height = 16
    Alignment = taRightJustify
    Caption = 'Total Overpayment Amount:'
    Font.Charset = ANSI_CHARSET
    Font.Color = clWindowText
    Font.Height = -13
    Font.Name = 'Arial'
    Font.Style = []
    ParentFont = False
  end
  object lblPlannedRecoveryAmt: TLabel
    Left = 11
    Top = 344
    Width = 157
    Height = 16
    Alignment = taRightJustify
    Caption = 'Planned Recovery Amount:'
    Font.Charset = ANSI_CHARSET
    Font.Color = clWindowText
    Font.Height = -13
    Font.Name = 'Arial'
    Font.Style = []
    ParentFont = False
  end
  object lblPayeeTypeDesc: TLabel
    Left = 186
    Top = 8
    Width = 111
    Height = 18
    AutoSize = False
    Caption = '???'
    Font.Charset = ANSI_CHARSET
    Font.Color = clWindowText
    Font.Height = -13
    Font.Name = 'Arial'
    Font.Style = [fsBold]
    ParentFont = False
  end
  object lblPaymentMethodDesc: TLabel
    Left = 186
    Top = 32
    Width = 111
    Height = 18
    AutoSize = False
    Caption = '???'
    Font.Charset = ANSI_CHARSET
    Font.Color = clWindowText
    Font.Height = -13
    Font.Name = 'Arial'
    Font.Style = [fsBold]
    ParentFont = False
  end
  object lblTotOverpayentAmtDesc: TLabel
    Left = 186
    Top = 88
    Width = 111
    Height = 18
    AutoSize = False
    Caption = '???'
    Font.Charset = ANSI_CHARSET
    Font.Color = clWindowText
    Font.Height = -13
    Font.Name = 'Arial'
    Font.Style = [fsBold]
    ParentFont = False
  end
  object lblTotOutstandingAmtDesc: TLabel
    Left = 186
    Top = 112
    Width = 111
    Height = 18
    AutoSize = False
    Caption = '???'
    Font.Charset = ANSI_CHARSET
    Font.Color = clWindowText
    Font.Height = -13
    Font.Name = 'Arial'
    Font.Style = [fsBold]
    ParentFont = False
  end
  object lblPayeeName: TLabel
    Left = 506
    Top = 8
    Width = 303
    Height = 18
    AutoSize = False
    Caption = '???'
    Font.Charset = ANSI_CHARSET
    Font.Color = clWindowText
    Font.Height = -13
    Font.Name = 'Arial'
    Font.Style = [fsBold]
    ParentFont = False
  end
  object lblPayeeAddress1: TLabel
    Left = 506
    Top = 32
    Width = 303
    Height = 18
    AutoSize = False
    Caption = '???'
    Font.Charset = ANSI_CHARSET
    Font.Color = clWindowText
    Font.Height = -13
    Font.Name = 'Arial'
    Font.Style = [fsBold]
    ParentFont = False
  end
  object lblPayeeAddress2: TLabel
    Left = 506
    Top = 56
    Width = 303
    Height = 18
    AutoSize = False
    Caption = '???'
    Font.Charset = ANSI_CHARSET
    Font.Color = clWindowText
    Font.Height = -13
    Font.Name = 'Arial'
    Font.Style = [fsBold]
    ParentFont = False
  end
  object lblTotalOutstandingReceivable: TLabel
    Left = 312
    Top = 88
    Width = 185
    Height = 16
    Alignment = taRightJustify
    Caption = 'Total Outstanding - In Recovery:'
    Font.Charset = ANSI_CHARSET
    Font.Color = clWindowText
    Font.Height = -13
    Font.Name = 'Arial'
    Font.Style = []
    ParentFont = False
  end
  object lblTotalOutstandingReceivableDesc: TLabel
    Left = 506
    Top = 88
    Width = 111
    Height = 18
    AutoSize = False
    Caption = '???'
    Font.Charset = ANSI_CHARSET
    Font.Color = clWindowText
    Font.Height = -13
    Font.Name = 'Arial'
    Font.Style = [fsBold]
    ParentFont = False
  end
  object lblTotalOutstandingSuspended: TLabel
    Left = 312
    Top = 112
    Width = 175
    Height = 16
    Alignment = taRightJustify
    Caption = 'Total Outstanding Suspended:'
    Font.Charset = ANSI_CHARSET
    Font.Color = clWindowText
    Font.Height = -13
    Font.Name = 'Arial'
    Font.Style = []
    ParentFont = False
  end
  object lblTotalOutstandingSuspendedDesc: TLabel
    Left = 506
    Top = 112
    Width = 111
    Height = 18
    AutoSize = False
    Caption = '???'
    Font.Charset = ANSI_CHARSET
    Font.Color = clWindowText
    Font.Height = -13
    Font.Name = 'Arial'
    Font.Style = [fsBold]
    ParentFont = False
  end
  object lblNumberOfPayments: TLabel
    Left = 11
    Top = 152
    Width = 126
    Height = 16
    Alignment = taRightJustify
    Caption = 'Number of Payments:'
    Font.Charset = ANSI_CHARSET
    Font.Color = clWindowText
    Font.Height = -13
    Font.Name = 'Arial'
    Font.Style = []
    ParentFont = False
  end
  object lblPaymentAmount: TLabel
    Left = 11
    Top = 176
    Width = 105
    Height = 16
    Alignment = taRightJustify
    Caption = 'Payment Amount:'
    Font.Charset = ANSI_CHARSET
    Font.Color = clWindowText
    Font.Height = -13
    Font.Name = 'Arial'
    Font.Style = []
    ParentFont = False
  end
  object lblOverridePlannedRecovery: TLabel
    Left = 11
    Top = 312
    Width = 159
    Height = 16
    Alignment = taRightJustify
    Caption = 'Override Planned Recovery:'
    Font.Charset = ANSI_CHARSET
    Font.Color = clWindowText
    Font.Height = -13
    Font.Name = 'Arial'
    Font.Style = []
    ParentFont = False
  end
  object lblNumberOfPaymentsDesc: TLabel
    Left = 186
    Top = 152
    Width = 111
    Height = 18
    AutoSize = False
    Caption = '???'
    Font.Charset = ANSI_CHARSET
    Font.Color = clWindowText
    Font.Height = -13
    Font.Name = 'Arial'
    Font.Style = [fsBold]
    ParentFont = False
  end
  object lblPaymentAmountDesc: TLabel
    Left = 186
    Top = 176
    Width = 111
    Height = 18
    AutoSize = False
    Caption = '???'
    Font.Charset = ANSI_CHARSET
    Font.Color = clWindowText
    Font.Height = -13
    Font.Name = 'Arial'
    Font.Style = [fsBold]
    ParentFont = False
  end
  object Label1: TLabel
    Left = 11
    Top = 208
    Width = 166
    Height = 16
    Alignment = taRightJustify
    Caption = 'Total Outstanding Advances:'
    Font.Charset = ANSI_CHARSET
    Font.Color = clWindowText
    Font.Height = -13
    Font.Name = 'Arial'
    Font.Style = []
    ParentFont = False
  end
  object lblTotalOutstandingAdvancesDesc: TLabel
    Left = 186
    Top = 208
    Width = 111
    Height = 18
    AutoSize = False
    Caption = '???'
    Font.Charset = ANSI_CHARSET
    Font.Color = clWindowText
    Font.Height = -13
    Font.Name = 'Arial'
    Font.Style = [fsBold]
    ParentFont = False
  end
  object Label2: TLabel
    Left = 11
    Top = 280
    Width = 160
    Height = 16
    Alignment = taRightJustify
    Caption = 'Possible Recovery Amount:'
    Font.Charset = ANSI_CHARSET
    Font.Color = clWindowText
    Font.Height = -13
    Font.Name = 'Arial'
    Font.Style = []
    ParentFont = False
  end
  object lblPossibleRecoveryAmtDesc: TLabel
    Left = 186
    Top = 280
    Width = 111
    Height = 18
    AutoSize = False
    Caption = '???'
    Font.Charset = ANSI_CHARSET
    Font.Color = clWindowText
    Font.Height = -13
    Font.Name = 'Arial'
    Font.Style = [fsBold]
    ParentFont = False
  end
  object Label4: TLabel
    Left = 11
    Top = 256
    Width = 268
    Height = 16
    Alignment = taRightJustify
    Caption = 'Planned Recovery not including Advances'
    Font.Charset = ANSI_CHARSET
    Font.Color = clWindowText
    Font.Height = -13
    Font.Name = 'Arial'
    Font.Style = [fsBold]
    ParentFont = False
  end
  object edPlannedRecoveryAmt: TEdit
    Left = 184
    Top = 344
    Width = 105
    Height = 22
    Color = clAqua
    Ctl3D = False
    Font.Charset = ANSI_CHARSET
    Font.Color = clWindowText
    Font.Height = -13
    Font.Name = 'Arial'
    Font.Style = []
    ParentCtl3D = False
    ParentFont = False
    TabOrder = 1
    Text = '???'
    OnExit = edPlannedRecoveryAmtExit
    OnKeyPress = DoubleKeyPress
  end
  object btnOK: TButton
    Left = 325
    Top = 384
    Width = 81
    Height = 33
    Caption = 'Save'
    Font.Charset = ANSI_CHARSET
    Font.Color = clWindowText
    Font.Height = -13
    Font.Name = 'Arial'
    Font.Style = []
    ParentFont = False
    TabOrder = 2
    OnClick = btnOKClick
  end
  object cboOverridePlannedRecovery: TComboBox
    Left = 184
    Top = 312
    Width = 65
    Height = 21
    Color = clAqua
    ItemHeight = 13
    ItemIndex = 1
    TabOrder = 0
    Text = 'No'
    OnChange = cboOverridePlannedRecoveryChange
    Items.Strings = (
      'Yes'
      'No')
  end
  object btnCancel: TButton
    Left = 421
    Top = 384
    Width = 81
    Height = 33
    Caption = 'Cancel'
    Font.Charset = ANSI_CHARSET
    Font.Color = clWindowText
    Font.Height = -13
    Font.Name = 'Arial'
    Font.Style = []
    ParentFont = False
    TabOrder = 3
    OnClick = btnCancelClick
  end
end
