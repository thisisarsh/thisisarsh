inherited WrkRptJul17: TWrkRptJul17
  Left = 432
  Top = 213
  Caption = 'WrkRptJul17'
  PixelsPerInch = 96
  TextHeight = 13
end
