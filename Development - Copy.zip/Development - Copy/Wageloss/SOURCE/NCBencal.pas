(******************************************************************************)
(*  Wageloss System                                                           *)
(*                                                                            *)
(*  Benefit Calculation Form                                                  *)
(*                                                                            *)
(*                                                                            *)
(*  Author: Brad Trupp  / Capella Systems Group, Inc.                         *)
(*  Date:   August 1997                                                       *)
(*                                                                            *)
(*  Nov 1998 - BT - year 2000 windowing fixes                                 *)
(*  Jan 1999 - BT - Fix call to FORM. Firm Suffix was not being set.          *)
(*  Oct 2000 - Add fields to accomodate policy changes                        *)
(*  Mar 2001 - allow calcs when tax year is accident year + 1 and a recurrence*)
(*                                                                            *)
(*  2007 - Emerge R4                                                          *)
(*                                                                            *)
(******************************************************************************)

unit NCBencal;

interface

uses
  Windows, Messages, SysUtils, Classes, Graphics, Controls, Forms, Dialogs,
  StdCtrls, ExtCtrls, ncrecdef, Menus, Spin, Buttons, NCMain, NCBenPay,
  qrprntr, NCWrkRptBase, Math, DateUtils, MaskUtils, DBCtrls, DB,
  uTriggerEvent, ComCtrls, ToolWin, ADODB, Vcl.Mask; //DBTables,

type
  TDayTable = array [1..12] of Word;
  PDayTable = ^TDayTable;

const
  //Wage Loss Letters
  WL01 = 'Benefit Explanation Pre 2001';
  WL02 = 'Benefit Explanation With Annuity Pre 2001';
  WL03 = 'Benefit Explanation Without Annuity Pre 2001';
  WL04 = 'Benefit Explanation With Allowable Tax Application - 2001 - 2005';
  WL05 = 'Benefit Explanation Without Allowable Tax Application 2001 - 2005';
  WL06 = 'Benefit Explanation With Worker Annuity Contribution 2001 - 2005';
  WL07 = 'Benefit Explanation Without Worker Annuity Contribution 2001 - 2005';
  WL08 = 'Benefit Explanation With Allowable Tax Application 2006 - 2021';
  WL09 = 'Benefit Explanation Without Allowable Tax Application 2006 - 2021';
  WL10 = 'Benefit Explanation With Worker Annuity Contribution 2006 - 2021';
  WL11 = 'Benefit Explanation Without Worker Annuity Contribution 2006 - 2021';
  WL12 = 'Benefit Explanation With Allowable Tax Application 2022 +';
  WL13 = 'Benefit Explanation Without Allowable Tax Application 2022 +';
  WL14 = 'Benefit Explanation With Worker Annuity Contribution 2022 +';
  WL15 = 'Benefit Explanation Without Worker Annuity Contribution 2022 +';

type
  TWagelossBenefitCalcForm = class(TForm)
    ScrollBox1: TScrollBox;
    Label1: TLabel;
    Label2: TLabel;
    Label3: TLabel;
    lblClaim_No: TLabel;
    lblClmnts_Name: TLabel;
    lblClmnts_Add_No_1: TLabel;
    lblClmnts_Add_No_2: TLabel;
    Label8: TLabel;
    Label9: TLabel;
    Label10: TLabel;
    lblSIN: TLabel;
    lblBirth_Date: TLabel;
    lblClmnts_Home_Phone: TLabel;
    lblClmnts_Post_Code: TLabel;
    Label4: TLabel;
    lblAccident_Date: TLabel;
    Label6: TLabel;
    lblLoss_Earn_Date: TLabel;
    Label11: TLabel;
    Label12: TLabel;
    lblAverageEarningsBasedOn: TLabel;
    Label5: TLabel;
    Label7: TLabel;
    Label15: TLabel;
    Label16: TLabel;
    Label17: TLabel;
    Label18: TLabel;
    lblIndexation_Year: TLabel;
    Label20: TLabel;
    Label19: TLabel;
    Label21: TLabel;
    Label22: TLabel;
    Label23: TLabel;
    Label24: TLabel;
    Label25: TLabel;
    Label26: TLabel;
    lblColl_Ben_Tax_Net: TLabel;
    lblPost_Injury_Earn_Net: TLabel;
    lblFullWageLoss: TLabel;
    lblPartialWageLoss: TLabel;
    Label32: TLabel;
    Label33: TLabel;
    Label34: TLabel;
    Label35: TLabel;
    Label36: TLabel;
    Label37: TLabel;
    Label38: TLabel;
    lblInc_Tax_Fed: TLabel;
    lblInc_Tax_Man: TLabel;
    lblCPP_Prem: TLabel;
    lblEI_Prem: TLabel;
    lblTotal_Deds: TLabel;
    lblWkly_Total_Deds: TLabel;
    Label40: TLabel;
    Label41: TLabel;
    Label42: TLabel;
    lblNetActual: TLabel;
    Label44: TLabel;
    Label45: TLabel;
    lblWkly_Sal_A: TLabel;
    lblWeekly_Net: TLabel;
    lbCalc90p_Wkly_Net_A: TLabel;
    lblAnnual_Gross: TLabel;
    lblAnnual_Net: TLabel;
    lblNetLoss: TLabel;
    Label53: TLabel;
    lblNetSheltered: TLabel;
    lblWeekly_90: TLabel;
    lblCalcTaxSheltering: TLabel;
    lblWeekly_90_S: TLabel;
    lblAnnual_90: TLabel;
    lblAnnual_90_S: TLabel;
    lbl80NetLoss: TLabel;
    lbl80NetSheltered: TLabel;
    lbl80PercentClaimantContrib: TLabel;
    lblWeekly_80: TLabel;
    lblWeekly_80_S: TLabel;
    lblWkly_Clmt_Anty_Con_Amt: TLabel;
    lblAnnual_80: TLabel;
    lblAnnual_80_S: TLabel;
    lbl80PercentClaimContribution: TLabel;
    lbl80PercentWCBContribution: TLabel;
    lblCalcWkly80p_Net_Clmt_Contr: TLabel;
    lblCalcWkly_p_WCB_Contr: TLabel;
    lblCalcAnnual80p_Net_Clmt_Contr: TLabel;
    Label74: TLabel;
    Label39: TLabel;
    Label77: TLabel;
    Label78: TLabel;
    Label79: TLabel;
    Label80: TLabel;
    lblPartPre_Weekly_Net: TLabel;
    lblPartPost_Injury_Earn_Net: TLabel;
    lblPartCalcNetLossEarnings: TLabel;
    lblNetLossPartial: TLabel;
    Label89: TLabel;
    lblNetShelteredPartial: TLabel;
    lblPartWeekly_90: TLabel;
    lblPartCalcTaxSheltering: TLabel;
    lblPartWeekly_90_S: TLabel;
    lbl80NetLossPartial: TLabel;
    lbl80NetShelteredPartial: TLabel;
    lbl80PercentClaimantContribPartial: TLabel;
    lblPartWeekly_80: TLabel;
    lblPartWeekly_80_S: TLabel;
    lblPartWkly_Clmt_Anty_Con_Amt: TLabel;
    lbl80PercentClaimContributionPartial: TLabel;
    lbl80PercentWCBContributionPartial: TLabel;
    lblPartCalcWkly80p_Net_Clmt_Contr: TLabel;
    lblPartCalcWkly_p_WCB_Contr: TLabel;
    Label112: TLabel;
    lblClaim_Suffix: TLabel;
    lblnc_104_Wk_Clmt_p_Contrib: TLabel;
    lblCalcnc_104_Wk_WCB_p_Contrib_Red: TLabel;
    lblPart_nc_104_Wk_Clmt_p_Contrib: TLabel;
    lblPart_Calcnc_104_Wk_WCB_p_Contrib_Red: TLabel;
    lblWCBAnnuityContr: TLabel;
    lblClmnts_Work_Phone: TLabel;
    lblOverpayment: TLabel;
    Label46: TLabel;
    Label47: TLabel;                                              
    Label28: TLabel;
    lblDailyCompensationRate: TLabel;
    Label49: TLabel;
    Label50: TLabel;
    lblCalc2nc_104_Wk_WCB_p_Contrib_Red: TLabel;
    lblPartDailyCompensationRate: TLabel;
    Label56: TLabel;
    Label55: TLabel;
    Label51: TLabel;
    Label57: TLabel;
    lblOverrideAdjustment: TLabel;
    Label59: TLabel;
    Label60: TLabel;
    Label64: TLabel;
    Label65: TLabel;
    lbl80DailyCompRate: TLabel;
    lblDaily80FullCompensationRate: TLabel;
    lblPartDaily80CompensationRate: TLabel;
    lbl80DailyCompRatePartial: TLabel;
    Label68: TLabel;
    Label69: TLabel;
    Label14: TLabel;
    Label30: TLabel;
    Label31: TLabel;
    lblEffectiveDate: TLabel;
    edAccident_Date: TEdit;
    edWkly_Sal_A: TEdit;
    edDays_Worked_per_Week: TEdit;
    edTax_Year: TEdit;
    edEI_Exempt: TEdit;
    edNo_Of_Dependnts: TEdit;
    edNo_Infirm: TEdit;
    edSpouse_Working: TEdit;
    edCollateral_Ben_Tax: TEdit;
    edCollateral_Ben_Non_Tax: TEdit;
    edPost_Injury_Earn: TEdit;
    ednc_104_Wk_Effective_Date: TEdit;
    ednc_104_Wk_WCB_p_Contrib_Red: TEdit;
    ednc_104_Wk_Clmt_p_Contrib: TEdit;
    ednc_104_Wk_Clmt_p_Eff_Date: TEdit;
    edPlaceholder1: TEdit;
    edPlaceholder2: TEdit;
    edChild_Care_Exp: TEdit;
    edSpousal_Support: TEdit;
    edMax_Adjustments: TEdit;
    edTax_Exempt: TEdit;
    edCPP_Exempt: TEdit;
    edRecurrence: TEdit;
    edSelf_Employed: TEdit;
    edRecurrenceDate: TEdit;
    edClmnts_Add_No_1: TEdit;
    edClmnts_Add_No_2: TEdit;
    edClmnts_Post_Code: TEdit;
    edSIN: TEdit;
    edBirth_Date: TEdit;
    edClmnts_Home_Phone: TEdit;
    edClmnts_Work_Phone: TEdit;
    edYouthful_Worker: TEdit;
    edApprentice: TEdit;
    edDeemed_Earnings: TEdit;
    btnCollTax: TBitBtn;
    ed_WCB_Annuity_Contr: TEdit;
    btnCollNonTax: TBitBtn;
    edCalculationType: TComboBox;
    edClmnts_Name: TEdit;
    cboAverageEarningsBasedOn: TDBLookupComboBox;
    edEffectiveDate: TEdit;
    cboMaritalStatus: TDBLookupComboBox;
    Bevel3: TBevel;
    Bevel1: TBevel;
    Label13: TLabel;
    pnlTestHeader: TPanel;
    DBNavigator1: TDBNavigator;
    edClaimPrefix: TLabeledEdit;
    edClaimDescription: TLabeledEdit;
    btnIndexation: TButton;
    edQATestID: TEdit;
    btnList: TSpeedButton;
    cmbAccidentYear: TComboBox;
    lblAccidentYear: TLabel;
    cbxIndexationOnly: TCheckBox;
    cbxRecurrance: TCheckBox;
    Label29: TLabel;
    lblClaimSpouseForTaxPurposes: TLabel;
    edClaimSpouseForTaxPurposes: TEdit;
    Label27: TLabel;
    lblCPP2_Prem: TLabel;
    procedure FormClose(Sender: TObject; var Action: TCloseAction);
    procedure FormDestroy(Sender: TObject);
    procedure FormKeyDown(Sender: TObject; var Key: Word;
      Shift: TShiftState);
    procedure FormCreate(Sender: TObject);
    procedure IntegerKeyPress(Sender: TObject; var Key: Char);
    procedure DoubleKeyPress(Sender: TObject; var Key: Char);
    procedure DateKeyPress(Sender: TObject; var Key: Char);
    procedure edEI_ExemptKeyPress(Sender: TObject; var Key: Char);
    procedure edSpouse_WorkingKeyPress(Sender: TObject; var Key: Char);
    procedure edDeemed_EarningsKeyPress(Sender: TObject; var Key: Char);
    procedure edWkly_Sal_AExit(Sender: TObject);
    procedure edDays_Worked_per_WeekExit(Sender: TObject);
    procedure edTax_YearExit(Sender: TObject);
    procedure edSpouse_WorkingExit(Sender: TObject);
    procedure edEI_ExemptExit(Sender: TObject);
    procedure edNo_Of_DependntsExit(Sender: TObject);
    procedure edNo_InfirmExit(Sender: TObject);
    procedure edCollateral_Ben_TaxExit(Sender: TObject);
    procedure edCollateral_Ben_Non_TaxExit(Sender: TObject);
    procedure edPost_Injury_EarnExit(Sender: TObject);
    procedure edDeemed_EarningsExit(Sender: TObject);
    procedure ednc_104_Wk_Effective_DateExit(Sender: TObject);
    procedure ednc_104_Wk_Clmt_p_ContribExit(Sender: TObject);
    procedure ednc_104_Wk_WCB_p_Contrib_RedExit(Sender: TObject);
    procedure FormCloseQuery(Sender: TObject; var CanClose: Boolean);
    procedure ednc_104_Wk_Clmt_p_Eff_DateExit(Sender: TObject);
    procedure FormKeyPress(Sender: TObject; var Key: Char);
    procedure FormActivate(Sender: TObject);
    procedure edChild_Care_ExpExit(Sender: TObject);
    procedure edSpousal_SupportExit(Sender: TObject);
    procedure edCPP_ExemptExit(Sender: TObject);
    procedure edCPP_ExemptKeyPress(Sender: TObject; var Key: Char);
    procedure edTax_ExemptExit(Sender: TObject);
    procedure edTax_ExemptKeyPress(Sender: TObject; var Key: Char);
    procedure edMax_AdjustmentsExit(Sender: TObject);
    procedure edRecurrenceExit(Sender: TObject);
    procedure edSelf_EmployedExit(Sender: TObject);
    procedure edRecurrenceKeyPress(Sender: TObject; var Key: Char);
    procedure edSelf_EmployedKeyPress(Sender: TObject; var Key: Char);
    procedure edRecurrenceDateExit(Sender: TObject);
    procedure ScrollBox1MouseWheelUp(Sender: TObject; Shift: TShiftState;
      MousePos: TPoint; var Handled: Boolean);
    procedure ScrollBox1MouseWheelDown(Sender: TObject; Shift: TShiftState;
      MousePos: TPoint; var Handled: Boolean);
    procedure edAccident_DateKeyPress(Sender: TObject; var Key: Char);
    procedure edAccident_DateExit(Sender: TObject);
    procedure PrintBenCalcReport;
    procedure edClmnts_NameExit(Sender: TObject);
    procedure edClmnts_Add_No_1Exit(Sender: TObject);
    procedure edClmnts_Add_No_2Exit(Sender: TObject);
    procedure edClmnts_Post_CodeExit(Sender: TObject);
    procedure edSINExit(Sender: TObject);
    procedure edBirth_DateExit(Sender: TObject);
    procedure edClmnts_Home_PhoneExit(Sender: TObject);
    procedure edClmnts_Work_PhoneExit(Sender: TObject);
    procedure edYouthful_WorkerExit(Sender: TObject);
    procedure edYouthful_WorkerKeyPress(Sender: TObject; var Key: Char);
    procedure edApprenticeExit(Sender: TObject);
    procedure edApprenticeKeyPress(Sender: TObject; var Key: Char);
    procedure btnUpdateCollateralBenefitsClick(Sender: TObject);
    procedure ed_WCB_Annuity_ContrExit(Sender: TObject);
    procedure btnCollNonTaxClick(Sender: TObject);
    procedure PrintIndexReport;
    procedure cboAverageEarningsBasedOnExit(Sender: TObject);
    function validateAverageEarningsBasedOn:Boolean;
    procedure edEffectiveDateExit(Sender: TObject);
    procedure edEffectiveDateKeyPress(Sender: TObject; var Key: Char);
    procedure SetUpEmergeDisplayFlag( aFlag : String);
    procedure cboMaritalStatusExit(Sender: TObject);
    procedure cboMaritalStatusKeyDown(Sender: TObject; var Key: Word;
      Shift: TShiftState);
    procedure cboMaritalStatusClick(Sender: TObject);
    procedure edCalculationTypeExit(Sender: TObject);
    procedure cboAverageEarningsBasedOnClick(Sender: TObject);
    procedure edCalculationTypeClick(Sender: TObject);
    procedure SelectCalcType(numWeeks: currency);
    procedure FormResize(Sender: TObject);
    procedure btnIndexationClick(Sender: TObject);
    procedure DBNavigator1Click(Sender: TObject; Button: TNavigateBtn);
    procedure FormShow(Sender: TObject);
    procedure btnListClick(Sender: TObject);
    procedure cmbAccidentYearChange(Sender: TObject);
    procedure cbxRecurranceClick(Sender: TObject);
    procedure edQATestIDExit(Sender: TObject);
    procedure edMax_AdjustmentsEnter(Sender: TObject);
    procedure edClaimSpouseForTaxPurposesKeyPress(Sender: TObject;
      var Key: Char);
    procedure edClaimSpouseForTaxPurposesExit(Sender: TObject);
  private
    { Private declarations }
    allowUpdateClaim: boolean;
    globalEditError:boolean;
    NextMaxAdjTab:TWinControl;
    SetInfoLine:Boolean;
    SetValidate:Boolean;
    blnRecurrence_Set:Boolean;
    blnCheck_Year:Boolean;
    RptDestination:String;
    DeathBenefitCalc:Boolean;
    blnSetPre104: Boolean;
    blnSetPost104: Boolean;
    blnSelfEmpTestDone: Boolean;
    //***
    allowQASave  : Boolean;
    FnextQATestID : Integer; // This will be used only when indexation is to be saved.
    isIndexation : Boolean;
    isInTestEditMode : Boolean;
    FInTestIndexationEditMode : Boolean;
    FqryEditTestRecord : TADOQuery;
    wcActive, wcPrevious : TWinControl;
    isYearChange : Boolean;
    //***
    procedure fillInForm;
    procedure fillInFormRecurrence;
    procedure WagelossIndexation;
    procedure WagelossPayment( paymentType: iPaymentType );
    function setClaimInformation( var r: recNCCLAIM ): boolean;
    procedure ResetInfoLine2;
    procedure SetMenuChoices;
    procedure ResetMenuChoices;
    procedure ProcessPAY90SHELTERED(var MSG: Tmessage); message WAGELOSS_START_PAY90SHELTERED;
    procedure ProcessPAY90NET(var MSG: Tmessage); message WAGELOSS_START_PAY90NET;
    procedure ProcessPAY80SHELTERED(var MSG: Tmessage); message WAGELOSS_START_PAY80SHELTERED;
    procedure ProcessPAY80NET(var MSG: Tmessage); message WAGELOSS_START_PAY80NET;
    procedure ProcessPAYOVERRIDE(var MSG: Tmessage); message WAGELOSS_START_PAYOVERRIDE;
    procedure ProcessINDEXATION(var MSG: Tmessage); message WAGELOSS_START_INDEXATION;
    procedure PrintINDEXATION(var MSG: Tmessage); message WAGELOSS_PRINT_INDEXATION;
    procedure PrintCLAIM_INFO(var MSG: Tmessage); message WAGELOSS_PRINT_CLAIM_INFO;
    procedure PrintCALC_WORKSHEET(var MSG: Tmessage); message WAGELOSS_PRINT_CALC_WORKSHEET;
    procedure ProcessREVIEW_BENEFITS_LEVEL(var MSG: Tmessage); message WAGELOSS_REVIEW_BENEFITS_LEVEL;
    procedure ProcessDEATH_BENEFIT_REPORT(var MSG: Tmessage); message WAGELOSS_DEATH_BENEFIT_REPORT;
    procedure DisplayBenefitCalculationInEmerge;
    procedure PrintBenefitCalculationReport;
    procedure PrintWageLossLetter;
    procedure set80pNetFields;
    procedure RecurrenceExitProc;
    procedure ResetCalc;
    procedure SetCalcMenuChoices;
    procedure ReSetCalcMenuChoices;
    procedure SaveRecurrenceDate;

//    function getSelfEmployedMaxAdjustment(iTaxYear, iAccidentYear, iAccidentMonth:Integer; AccidentDate:TDateTime): currency;
//    function getSelfEmployedMinAdjustment(iTaxYear, iAccidentYear, iAccident_Month:integer; iAccident_Date:TDateTime): currency;
//    function isSelfEmployedAdjInRange(adjAmount : Currency): String;


    function Calc_New_Max(Indexation_Year:Integer;
                          Self_Employed:Boolean;
                          Recurrence:Boolean;
                          Recurrence_Date:TDateTime;
                          Accident_Date:TDateTime;
                          NewIndexation_Year:Integer;
                          Max_Adjustment:Currency
                          ):Currency;
    function CheckMaxLoaded:Boolean;
    procedure SaveYouthful_Worker;
    procedure SaveApprentice;
    procedure SaveTaxableCollateral;
    procedure SaveNonTaxableCollateral;
    procedure Save_Weekly_Sal_History(Claim_No:String;
                                  Index_Year:integer;
                                  New_Weekly_Wage, Old_Weekly_Wage:Currency);

    procedure triggerSendDocumentEvent(const aFormName:String);overload;
    procedure triggerSendDocumentEvent(const aFormName, aPropertyExtension: String);overload;
    procedure SetUpdateInd(value:boolean);

    //***
    function SaveQAData(): Boolean;
    procedure resetControlsAfterQASave;
    procedure resetControlsAfterIndexation;
    procedure fillInFormQATestData;
    procedure DoShowHint(var HintStr: string;var CanShow: Boolean;
                                             var HintInfo: THintInfo);
    procedure MarkMisMatchLabels(lArray: array of TLabel);
    procedure SetEditTestRecord(qryTestRecord : TADOQuery);
    procedure QAWagelossIndexation;
    procedure PressFunctionKey(_K : Word);
    procedure ActiveControlChanged(Sender: TObject) ;
    //***
  public
    { Public declarations }
    CalcFullClaim, CalcPartClaim: recNCCLAIM;
    blnMarital_Status_Change:Boolean;
    fWorking, fFullMinWage, fPartMinWage : recConst;
    function forceSetClaimInformation( var r: recNCCLAIM ):boolean;
    procedure Loaded; override;
    function isClaimEmerge(claimNo : String):Boolean;
    //***
    property nextQATestID : Integer read FnextQATestID write FnextQATestID; // This will be used only when indexation is to be saved.
    property qryEditTestRecord : TADOQuery read FqryEditTestRecord write SetEditTestRecord;
    property isInTestIndexationEditMode : Boolean read FInTestIndexationEditMode write FInTestIndexationEditMode;
    function ValidateAndRecalcBen: boolean;
    procedure CheckForMisMatchValues;
    //***

  end;

var
  WagelossBenefitCalcForm: TWagelossBenefitCalcForm;

const
  sqlQA  = 'SELECT *'+#13#10+'FROM QAData'+#13#10+
           'WHERE QATestID IN (SELECT QATestID FROM QAData GROUP BY QATestID HAVING COUNT(*) = 1  )'+#13#10+
           'ORDER BY QADataID, QATestIndexID';

  sqlQAwithWhere  = 'SELECT *'+#13#10+'FROM QAData'+#13#10+
           'WHERE QATestID IN (SELECT QATestID FROM QAData GROUP BY QATestID HAVING COUNT(*) = 1  )'+#13#10+
           'AND Year(Accident_Date) = %S'+#13#10+
           'ORDER BY QADataID, QATestIndexID';

  sqlQAIndex = 'SELECT *'+#13#10+'FROM QAData'+#13#10+
               'WHERE QATestID IN (SELECT QATestID FROM QAData GROUP BY QATestID HAVING COUNT(*) > 1  )'+#13#10+
               'ORDER BY QADataID, QATestIndexID';

  sqlQAIndexWithWhere = 'SELECT *'+#13#10+'FROM QAData'+#13#10+
               'WHERE QATestID IN (SELECT QATestID FROM QAData GROUP BY QATestID HAVING COUNT(*) > 1  )'+#13#10+
               'AND Year(Accident_Date) = %S'+#13#10+
               'ORDER BY QADataID, QATestIndexID';


implementation

uses NCIniMod, Utilmod1, NCBenidx, NCClmWL0, NCOvrPay, NCChoice, NCIdxClm, NCCInRpt,
     NCBenRpt, NCWrkRpt, NCRevClm, QPreview, uGlobal, NCDatMod,
     uSavePrint, uADOSecurity, Utils, CrystalPrev, NCTaxableCollateral,
     NCNonTaxableCollateral, uSaveIndexReport, uSaveWageLossCalcFactors,
     Variants, ufrmQATestList, ValidateDate, ConvertDate;
     //,CICSApi1;

{$R *.DFM}


procedure LoadCombo(_sql :String; var Combo:TComboBox);
begin
  with dm1.Query1 do
  try
    Close;
    SQL.Text := '';
    SQL.Text := _sql;
    Open;
    Combo.Items.Clear;
    Combo.Text:='';
    Combo.Items.Add('All');
    while not Eof do begin
      Combo.Items.Add(Fields.Fields[0].AsString);
      Next;
    end;
    Close;
    SQL.Text:='';
  except
    //on E: Exception do ErrorDialog(E.Message, E.HelpContext);
  end;

end;


function CustomStrToDateStr(S: String): String;
var
  OutPutList: TStringList;
  i, d : Integer;
  dd,mm,yy : String;
begin
  if S <> '' then
     begin
     OutPutList := TStringList.Create;
     try
        OutPutList.Delimiter := '-';
        OutPutList.DelimitedText := Trim(S);
        mm := UpperCase(OutPutList[1]);

        for i := low(FormatSettings.ShortMonthNames)  to high(FormatSettings.ShortMonthNames) do
           begin
           if UpperCase(FormatSettings.ShortMonthNames[i]) = mm then
              begin
              mm := copy(IntToStr(100+i),2,2);
              break;
              end;
           end;

        d  := StrToInt(OutPutList[0]);
        dd := copy(IntToStr(100+d),2,2);
        yy := OutPutList[2];

        Result := dd+'/'+mm+'/'+yy;
     finally
        OutPutList.Free;
     end;
     end;
end;


(******************************************************************************)
(*                                                                            *)
(*  Form Close                                                                *)
(*                                                                            *)
(******************************************************************************)
procedure TWagelossBenefitCalcForm.FormClose(Sender: TObject;
  var Action: TCloseAction);
begin
  Action := caFree;

  with WagelossMainForm do
     begin
     isTestCalculator := False;
     isRunManualTest := False;
     isRunAutoTest := False;
     end;
end;

(******************************************************************************)
(*                                                                            *)
(*  Form Destroy                                                              *)
(*                                                                            *)
(******************************************************************************)
procedure TWagelossBenefitCalcForm.FormDestroy(Sender: TObject);
var
  Child: TWagelossBenefitCalcForm;
  lngIndex, i:Integer;
  blnFound:Boolean;
begin
  dataClaim.claimCalculated := false;
  ClearNCCLAIM( CalcFullClaim );
  ClearNCCLAIM( CalcPartClaim );
  ClearNCCLAIM( dataClaim );
  WagelossBenefitCalcForm := nil;
  WagelossMainForm.ShowInfoLine1('');
  WagelossMainForm.ShowInfoLine2('');

  //***
  WagelossMainForm.isTestCalculator := False;
  WagelossMainForm.inTesting := False;
  Screen.OnActiveControlChange := nil;
  //***

//
// Fix the menu's so that we can't select things we shouldn't when we are in the
// calculator
//
if lblAccident_Date.Visible Then
   Begin
   ResetMenuChoices;
   End
else
   Begin
   //
   // Check to see if we have an actual Wageloss calculation going on
   //
   lngIndex := WagelossMainForm.MDIChildCount;
   blnFound := False;

   For i := 0 to lngIndex - 1 do
      begin
      if WagelossMainForm.MDIChildren[i].ClassType = TWagelossBenefitCalcForm Then
         begin
         Child := WagelossMainForm.MDIChildren[i] as TWagelossBenefitCalcForm;
         If Child.lblAccident_Date.Visible = False then
            begin
            blnFound := True;
            Break;
            end;
         end;
      end;
   //
   // if we don't have a Wageloss Calc going on then reset the calc menu's
   // otherwise reset so that the wageloss Calc menu items are still available
   //
   if Not blnFound then
      ResetCalcMenuChoices
   else
      ResetMenuChoices;
   End;
end;


procedure TWagelossBenefitCalcForm.PressFunctionKey(_K: Word);
var
  K : Word;
begin
  K := _K + 111;
  Self.FormKeyDown(TObject(Self),K,[]);
end;


(******************************************************************************)
(*                                                                            *)
(*  CheckMaxLoaded - Determine if the max in the Max Adjustments field        *)
(*                   is set to the max as per the tables and max rules.       *)
(*                                                                            *)
(******************************************************************************)

Function TWagelossBenefitCalcForm.CheckMaxLoaded:Boolean;
var
   TestTax_Year, iii:Integer;
   iYear, iMonth, iDay, Test_Accident_Year:Word;
   iAccident_Date, iRecurrence_Date:TDateTime;
   Annual_Max, Annual_Min:Currency;
   strAnnualMax:String;
Begin
  result := true; // Assume success

//  if Not lblAccident_Date.Visible Then
//     begin
//     exit;
//     end;

  //
  // If we have an accident date between 2006 and 2022 and we don't have a self employeed
  // worker the skip this check
  //
  iAccident_Date := CalcFullClaim.Accident_Date;
  DecodeDate( iAccident_Date, iYear, iMonth, iDay );

  if ((iYear > 2005) and (iYear < 2022)) and (edSelf_Employed.Text = 'N') Then
     begin
     exit;
     end;

  //
  // LRC Bill 18 and changes to remove recurrence date in the determination of the max
  //
  Test_Accident_Year := Year(CalcFullClaim.Accident_Date);
  TestTax_Year := Max(Test_Accident_Year, CalcFullClaim.Indexation_Year);

  if (edRecurrence.Text = 'Y') then
     iRecurrence_Date := StrToDate(edRecurrenceDate.Text)
  else
     iRecurrence_Date := 0;

  Annual_Max := getMaxAdjustment(CalcFullClaim.Accident_Date, iRecurrence_Date, CalcFullClaim.Indexation_Year, edRecurrence.Text, edSelf_Employed.Text);
  Annual_Min := getMinAdjustment(CalcFullClaim.Accident_Date, iRecurrence_Date, CalcFullClaim.Indexation_Year, edRecurrence.Text, edSelf_Employed.Text);

  if (edSelf_Employed.Text <> 'Y') then
     begin
     // if not self employed then just set it. This will fix any existing data which has a
     // $0 for max adjustment when it's a regular worker
     edMax_Adjustments.Text := format('%.2n',[Annual_Max]);
     end
  else
     begin
     if Annual_Max > 0 then
        begin
        if (textAsCurrency(edMax_Adjustments) > Annual_Max) or
           (textAsCurrency(edMax_Adjustments) < Annual_Min) then
           begin
           result := false;
           end;
        end
     else
        begin
        if (textAsCurrency(edMax_Adjustments) < Annual_Min) then
           begin
           result := false;
           end;
        end;
     end;


  if not result then
     begin
     if Annual_Max > 0 then
        begin
        strAnnualMax := '*Max Adj amount must be >= $' + format('%.2n', [Annual_Min]) + ' and <= $' + format('%.2n',[Annual_Max]);
        end
     else
        begin
        strAnnualMax := '*Max Adj amount must be >= $' + format('%.2n', [Annual_Min]);
        end;
     setEditToNormal(edMax_Adjustments); // open the field so we can set focus to it
     edMax_Adjustments.SetFocus;
     WagelossMainForm.ShowInfoLine2(strAnnualMax);
     exit;
     end
  else
     begin
     setEditToRead(edMax_Adjustments);
     end;
end;

(******************************************************************************)
(*                                                                            *)
(*  Key Down - preview and process keypresses on form.                        *)
(*                                                                            *)
(******************************************************************************)
procedure TWagelossBenefitCalcForm.FormKeyDown(Sender: TObject; var Key: Word; Shift: TShiftState);
var
  stringClaim : String;
begin
  case Key of
    VK_F1: begin
           Key:=0;
           Application.HelpCommand(HELP_CONTENTS, 0);
           end;
    VK_F7: begin
           Key:=0;
           close;
           end;
    VK_F8: begin
           Key:=0;
           RptDestination := 'S';
           PrintBenCalcReport;
           end;
    VK_F9: begin
           Key := 0;
           SetInfoLine := True;
           //
           //***
           //
           if WagelossMainForm.isTestCalculator and allowQASave then
              begin
              edAccident_Date.SetFocus;
              if MyMessageDialog('Previous calculation has not been saved. '+
                                 'Do you want to save the previous calculation before doing this recalc ?',
                                 mtConfirmation, mbOKCancel,['Save It', 'No']) = mrOk then
                 begin
                 SaveQAData;
                 end;
              end;
           //
           //***
           //
           if CheckMaxLoaded Then
              begin
              if ValidateAndRecalcBen then
                 begin
                 if lblAccident_Date.Visible and not (CapabilityExists('Default')) Then
                    begin
                    PrintBenefitCalculationReport;
                    end;
                 scrollbox1.VertScrollBar.position := ScrollBox1.VertScrollBar.range;
                 end;
              end;
           //
           //***
           //
           if WagelossMainForm.isTestCalculator then
              begin
              SetInfoLine := True;
              allowQASave := True;
              ResetInfoLine2;
              end;

           if WagelossMainForm.isRunManualTest then
              begin
              CheckForMisMatchValues;
              end;
           //***
           end;


    VK_F10:
           begin
           //
           //*** Test Data Save ***
           //
           if WagelossMainForm.isTestCalculator and not blnRecalcNeeded then
              begin
              if MyMessageDialog('Do you want to save the calculated results into QA Test Data ?',
                                 mtConfirmation, mbOKCancel,
                                 ['Save It', 'No']) = mrOk then
                 if SaveQAData then
                    begin
                    resetControlsAfterQASave;
                    allowQASave := False;
                    ResetInfoLine2;
                    end;
                   //Key:=0;
              exit;
              end;
           //
           //***
           //
           dataClaim.claimCalculated := true;
           if lblAccident_Date.Visible and not (CapabilityExists('Default')) Then
              begin
              if CheckMaxLoaded Then
                 begin
                 Key := 0;
                 SetInfoLine := True;

                 if ValidateAndRecalcBen then
                    begin
                    copyNCCLAIM( CalcFullClaim, uSaveWageLossCalcFactors.CalcFullClaim);
                    copyNCCLAIM( CalcPartClaim, uSaveWageLossCalcFactors.CalcPartClaim);
                    //Writes WageLossCalcFactor record on setClaimInformation
                    stringClaim := CalcFullClaim.Claim_No;

                    if not (uGlobal.logActivity(stringClaim, uGlobal.LOG_TYPE_UPDATE, 'BenefitCalc')) then
                       begin
                       WagelossMainForm.ShowInfoLine2( '*Logging Failed.  Claim Save Not Allowed!*' );
                       exit;
                       end;

                    if setClaimInformation( CalcPartClaim ) then
                       begin
                       // put back in sync...
                       // First we need to update the uniqueness of the record since
                       // we don't actually go out and re-read the 04 trailer again
                       //
                       CalcPartClaim.Uniqueness := CalcPartClaim.Uniqueness + 1;
                       CalcFullClaim.Uniqueness := CalcPartClaim.Uniqueness;
                       copyNCCLAIM( CalcPartClaim, DataClaim );
                       SaveRecurrenceDate;
                       SaveYouthful_Worker;
                       SaveApprentice;
                       SaveTaxableCollateral;
                       SaveNonTaxableCollateral;

                       // if there are no Collateral Benefits && there are no Post Injury Earnings then
                       // ask Question 1: Would you like to display the benefit calculation factors in Emerge?
                       if ( ( edCollateral_Ben_Tax.Text = '0.00' ) and ( edCollateral_Ben_Non_Tax.Text = '0.00' ) and ( edPost_Injury_Earn.Text = '0.00' ) ) then
                          begin
                          DisplayBenefitCalculationInEmerge;
                          end
                       else
                          begin
                          PrintBenefitCalculationReport;
                          end;

                       // if there are Post Injury Earnings then
                       // do not display the benefit calculation factors in Emerge
                       if ( edPost_Injury_Earn.Text <> '0.00' ) then
                          begin
                          //PrintBenefitCalculationReport;
                          SetUpEmergeDisplayFlag( 'N' );
                          end;

                       // if there are Collateral Benefits then
                       // do not display the benefit calculation factors in Emerge
                       if ( ( edCollateral_Ben_Tax.Text <> '0.00' ) or ( edCollateral_Ben_Non_Tax.Text <> '0.00' ) ) then
                          begin
                          SetUpEmergeDisplayFlag ( 'N' );
                          end;

                       PrintWageLossLetter;
                       end;  //setClaimInformation( CalcPartClaim )
                    end;  //ValidateAndRecalcBen
                 end;  //CheckMaxLoaded
              end;  //lblAccident_Date.Visible
           end;
    VK_NEXT:
           begin
           Key:=0;
           scrollbox1.VertScrollBar.position:=scrollbox1.VertScrollBar.range;
           //***
           if WagelossMainForm.isRunManualTest then
              begin
              dm1.qryQAData.Next;
              DBNavigator1Click(DBNavigator1, nbNext);
              Application.ProcessMessages;
              end;
           //***
           end;
    VK_PRIOR:
           begin
           Key:=0;
           scrollbox1.VertScrollBar.position:=0;
           //***
           if WagelossMainForm.isRunManualTest then
              begin
              dm1.qryQAData.Prior;
              DBNavigator1Click(DBNavigator1, nbPrior);
              Application.ProcessMessages;
              end;
           //***
           end;
    VK_HOME :
           begin
           if Shift = [ssCtrl] then
              begin
              if WagelossMainForm.isRunManualTest then
                 begin
                 dm1.qryQAData.First;
                 DBNavigator1Click(DBNavigator1, nbFirst);
                 Application.ProcessMessages;
                 end;
              end;
           end;
    VK_END :
           begin
           if Shift = [ssCtrl] then
              begin
              if WagelossMainForm.isRunManualTest then
                 begin
                 dm1.qryQAData.Last;
                 DBNavigator1Click(DBNavigator1, nbLast);
                 Application.ProcessMessages;
                 end;
              end;
           end;
  end;
end;

(******************************************************************************)
(*                                                                            *)
(*  Key Press - preview and process keypresses on form.                       *)
(*                                                                            *)
(******************************************************************************)
procedure TWagelossBenefitCalcForm.FormKeyPress(Sender: TObject;
  var Key: Char);
begin
  case Key of
    Chr(VK_RETURN):
       begin
       Key:=#0;
       SelectNext(ActiveControl as tWinControl, true, true );
       end;
  end;
end;

(******************************************************************************)
(*                                                                            *)
(*  Form Create                                                               *)
(*                                                                            *)
(******************************************************************************)
procedure TWagelossBenefitCalcForm.FormCreate(Sender: TObject);
var
  showControl : Boolean;
begin
  //***
  if WagelossMainForm.isRunManualTest then
     begin
     Application.ShowHint := True;
     Application.OnShowHint := DoShowHint;
     end;

  showControl := True;
  isInTestEditMode := False;
  Screen.OnActiveControlChange := ActiveControlChanged;
  //***
  //
  // The claim spouse fields will always be hidden until we know that it is
  // possible to claim the deduction
  //
  edClaimSpouseForTaxPurposes.Visible := false;
  lblClaimSpouseForTaxPurposes.Visible := false;

// See if we are creating the calculator or the wageloss form. This is set
// when we select the type of form to use from the main menu.
//
  if Not WagelossMainForm.blnCreateCalculator Then
    begin
    SetValidate := False;
    blnSelfEmpTestDone := false;
    edAccident_Date.Visible := False;
    lblAccident_Date.Visible := True;
    edClmnts_Name.Visible := False;
    edClmnts_Add_No_1.Visible := False;
    edClmnts_Add_No_2.Visible := False;
    edClmnts_Post_Code.Visible := False;
    edSIN.Visible := False;
    edBirth_Date.Visible := False;
    edClmnts_Home_Phone.Visible := False;
    edClmnts_Work_Phone.Visible := False;
    lblClmnts_Name.Visible := True;
    lblClmnts_Add_No_1.Visible := True;
    lblClmnts_Add_No_2.Visible := True;
    lblClmnts_Post_Code.Visible := True;
    lblSIN.Visible := True;
    lblBirth_Date.Visible := True;
    lblClmnts_Home_Phone.Visible := True;
    lblClmnts_Work_Phone.Visible := True;
    SetUpdateInd(False);
    dataClaim.claimCalculated := False;

    if Check_Self_Assurer(DataClaim.Prime_Firm_No) then
       begin
       dataClaim.CFIO := 'Y';
       dataClaim.Firm_Name:=Find_Firm_Name(dataClaim.Prime_Firm_No);
       end
    else
       begin
       dataClaim.CFIO := 'N';
       end;

    copyNCCLAIM( DataClaim, CalcFullClaim);
    copyNCCLAIM( DataClaim, CalcPartClaim);

    if (dataclaim.Recurrence = 'Y') And (dataClaim.RecurrenceDate = 0) then
       begin
       fillInFormRecurrence
       end
    else
    begin
      //
      // Do a data compare on the Wkly Net salary to ensure that the
      // weekly net is the same as what is returned from the tax calculator
      // if the values are different display an error message
      //
      uglobal.RecalcBen(CalcFullClaim, CalcPartClaim, DeathBenefitCalc);
      fillInForm;
      ResetInfoLine2;
    end;
    SetMenuChoices;
    Set80pNetFields;
    //
    // Check for a accident year >= 2006
    //
    if Year(dataClaim.Accident_Date) >= 2006 then
       begin
       lbl80NetLoss.Visible := False;
       lblWeekly_80.Visible := False;
       end
    else
       begin
       lbl80NetLoss.Visible := True;
       lblWeekly_80.Visible := True;
       lblWkly_Clmt_Anty_Con_Amt.Visible := True;
       lblCalcWkly80p_Net_Clmt_Contr.Visible := True;
       lblCalcWkly_p_WCB_Contr.Visible := True;
       lblDaily80FullCompensationRate.Visible := True;
       lblnc_104_Wk_Clmt_p_Contrib.Visible := True;
       lblCalcnc_104_Wk_WCB_p_Contrib_Red.Visible := True;
       lbl80PercentClaimantContrib.Visible := True;
       lbl80PercentClaimContribution.Visible := True;
       lbl80PercentWCBContribution.Visible := True;
       lbl80DailyCompRate.Visible := True;
       end;
    end
  else
    begin
    ResetCalc;
    ResetInfoLine2;
    lblAccident_Date.Visible := False;
    edAccident_Date.Visible := True;
    edClmnts_Name.Visible := True;
    edClmnts_Add_No_1.Visible := True;
    edClmnts_Add_No_2.Visible := True;
    edClmnts_Post_Code.Visible := True;
    edSIN.Visible := True;
    edBirth_Date.Visible := True;
    edClmnts_Home_Phone.Visible := True;
    edClmnts_Work_Phone.Visible := True;
    lblClmnts_Name.Visible := False;
    lblClmnts_Add_No_1.Visible := False;
    lblClmnts_Add_No_2.Visible := False;
    lblClmnts_Post_Code.Visible := False;
    lblSIN.Visible := False;
    lblBirth_Date.Visible := False;
    lblClmnts_Home_Phone.Visible := False;
    lblClmnts_Work_Phone.Visible := False;

    SetEditToRead(edMax_Adjustments);

    SetEditToRead(edRecurrence);
    edRecurrence.Text := 'N';
    SetOldRecurrenceInd('N');
    SetCalcMenuChoices;
    end;

  //***
  if WagelossMainForm.isTestCalculator OR WagelossMainForm.isRunManualTest then
    begin
    showControl := not (WagelossMainForm.isTestCalculator OR WagelossMainForm.isRunManualTest );

    Label1.Visible  := showControl;
    Label2.Visible  := showControl;
    Label3.Visible  := showControl;
    Label8.Visible  := showControl;
    Label9.Visible  := showControl;
    Label10.Visible := showControl;
    Label13.Visible := showControl;
    lblClaim_No.Visible     := showControl;
    lblClaim_Suffix.Visible := showControl;
    edClmnts_Name.Visible   := showControl;
    edClmnts_Add_No_1.Visible   := showControl;
    edClmnts_Add_No_2.Visible   := showControl;
    edClmnts_Post_Code.Visible  := showControl;
    edClmnts_Home_Phone.Visible := showControl;
    edClmnts_Work_Phone.Visible := showControl;
    edSIN.Visible        := showControl;
    edBirth_Date.Visible := showControl;

    pnlTestHeader.Left := ScrollBox1.Left + 3;
    pnlTestHeader.Top := ScrollBox1.Top + 5;
    pnlTestHeader.Width := Bevel1.Width;
    pnlTestHeader.Height := lblClaim_No.Height * 6;

    DBNavigator1.Left := pnlTestHeader.Left + 2;
    DBNavigator1.Top := pnlTestHeader.Top + pnlTestHeader.Height - DBNavigator1.Height - 5;

    pnlTestHeader.Visible := not showControl;
    DBNavigator1.Visible := WagelossMainForm.isRunManualTest;
    edQATestID.Enabled := WagelossMainForm.isRunManualTest;
    lblAccidentYear.Visible := WagelossMainForm.isRunManualTest;
    cmbAccidentYear.Visible := WagelossMainForm.isRunManualTest;
    cbxRecurrance.Visible := WagelossMainForm.isTestCalculator;
    end;
  //***


  // set the calculation type default. We we have greater than 104 weeks of comp
  // then set the Calculation Type appropriately
  //
  If WagelossMainForm.blnCreateCalculator Then
    edCalculationType.ItemIndex := 0
  else if CalcFullClaim.week104StatusType = 'Post 104 Weeks' Then
    edCalculationType.ItemIndex := 1
  else
    edCalculationType.ItemIndex := 0;

  lblAverageEarningsBasedOn.Visible := True;
  DeathBenefitCalc := False;
  SetFont(Self);
end;

(******************************************************************************)
(*                                                                            *)
(*  Reset all Edit fields for the calculator only portion                                                     *)
(*                                                                            *)
(******************************************************************************)
procedure TWagelossBenefitCalcForm.ResetCalc;
begin
  ResetInfoLine2;
  edWkly_Sal_A.Clear;
  edDays_Worked_per_Week.Clear;
  edTax_Year.Clear;

  // New fields for 2000 policy changes
  edSelf_Employed.Clear;
  edRecurrence.Clear;
  edCPP_Exempt.Clear;
  edTax_Exempt.Clear;
  edChild_Care_Exp.Clear;
  edSpousal_Support.Clear;
  edMax_Adjustments.Clear;

  setEditToRead(edMax_Adjustments);

  edAccident_Date.Clear;
  edEI_Exempt.Clear;
  edNo_Of_Dependnts.Clear;
  edNo_Infirm.Clear;
  edCollateral_Ben_Tax.Clear;
  edCollateral_Ben_Non_Tax.Clear;
  edPost_Injury_Earn.Clear;
  edDeemed_Earnings.clear;
  setEditToNormal(edSpouse_Working);
  edSpouse_Working.Clear;
  edClaimSpouseForTaxPurposes.Clear;
  ClearNCCLAIM( CalcFullClaim );
  ClearNCCLAIM( CalcPartClaim );

  fillInForm;
end;


(******************************************************************************)
(*                                                                            *)
(*  Set active control after form create                                      *)
(*                                                                            *)
(******************************************************************************)
procedure TWagelossBenefitCalcForm.Loaded;
begin
  inherited;

  ActiveControl := edWkly_Sal_A;
  scrollbox1.VertScrollBar.position := 0;
end;

(******************************************************************************)
(*                                                                            *)
(*  Key press edit for integers                                               *)
(*                                                                            *)
(******************************************************************************)
procedure TWagelossBenefitCalcForm.IntegerKeyPress(Sender: TObject;
  var Key: Char);
begin
  case Key of
  #0..#31,'0'..'9':
     begin
     // accept the input
     end
  else
     // consume the keystroke
     Key := #0;
  end;
end;

(******************************************************************************)
(*                                                                            *)
(*  Ket press edit for doubles, floats, currencies                            *)
(*                                                                            *)
(******************************************************************************)
procedure TWagelossBenefitCalcForm.DoubleKeyPress(Sender: TObject;
  var Key: Char);
begin
  case Key of
  #0..#31,'0'..'9','.','+':
     begin

     end
  else
     Key:=#0;
  end;
end;

(******************************************************************************)
(*                                                                            *)
(*  Key press edit for dates                                                  *)
(*                                                                            *)
(******************************************************************************)
procedure TWagelossBenefitCalcForm.DateKeyPress(Sender: TObject;
  var Key: Char);
begin
  case Key of
  #0..#31,'0'..'9','/','.':
     begin

     end
  else
     Key:=#0;
  end;
end;

(******************************************************************************)
(*                                                                            *)
(*  Fill in form from claim record(s)                                         *)
(*                                                                            *)
(******************************************************************************)
procedure TWagelossBenefitCalcForm.fillInForm;
var
  strCaption, strPartialCaption : String;
begin
  with CalcFullClaim do
  begin
    lblClaim_No.caption := Claim_No;
    lblClaim_Suffix.caption :=Claim_Suffix;
    lblClmnts_Name.caption := pdoxTrim(Clmnts_1st_Name) + ' ' + pdoxTrim(Clmnts_Surname);
    lblClmnts_Add_No_1.caption := Clmnts_Add_No_1;
    lblClmnts_Add_No_2.caption := Clmnts_Add_No_3;
    lblSIN.caption := FormatMaskText( '000 000 000;0;*', SIN );
    if Birth_Date > 0 then
       begin
       //lblBirth_Date.caption := formatdatetime('c',Birth_Date);
       lblBirth_Date.caption := FormatDateTime('ddddd', Birth_Date);
       end
    else
      lblBirth_Date.caption := '';

    lblClmnts_Post_Code.caption := Clmnts_Post_Code;
    if Clmnts_Home_Phone <> '' then
      lblClmnts_Home_Phone.caption := FormatMaskText( '(000) 000-0000;0;*', Clmnts_Home_Phone )
    else
      lblClmnts_Home_Phone.Caption := '';
    if Clmnts_Work_Phone <> '' then
      lblClmnts_Work_Phone.caption := FormatMaskText( '(000) 000-0000;0;*', Clmnts_Work_Phone )
    else
      lblClmnts_Work_Phone.Caption := '';
    if Accident_Date > 0 then
      begin
      //lblAccident_Date.caption := formatdatetime('c',Accident_Date);
      lblAccident_Date.caption := FormatDateTime('ddddd', Accident_Date);
      end
    else
      lblAccident_Date.caption := '';
    if Loss_Earn_Date > 0 then
       begin
       //lblLoss_Earn_Date.caption := formatdatetime('c',Loss_Earn_Date);
       lblLoss_Earn_Date.caption := FormatDateTime('ddddd', Loss_Earn_Date);
       end
    else
      lblLoss_Earn_Date.caption := '';

    //Added Emerge R4
    if effectiveDate > 0 then
       begin
       //edEffectiveDate.Text := formatdatetime('c', effectiveDate);
       edEffectiveDate.Text := FormatDateTime('ddddd', effectiveDate);
       end
    else
       begin
       edEffectiveDate.Text := '';
       end;

    //
    // Modified to handle Recurrence date
    //
    if RecurrenceDate > 0 then
       begin
       //edRecurrenceDate.Text := FormatDateTime('c',RecurrenceDate);
       edRecurrenceDate.Text := FormatDateTime('ddddd',RecurrenceDate);
       edRecurrenceDate.Visible := True;
       end
    else
       edRecurrenceDate.Text := '';

    edWkly_Sal_A.text := format('%.2n', [ Wkly_Sal_A ] );
    edDays_Worked_per_Week.text := format('%.2n', [ Days_Worked_per_Week ] );
    cboAverageEarningsBasedOn.KeyValue := AverageEarningsBasedOn;
    edTax_Year.text := format('%d', [ Tax_Year ] );
    lblIndexation_Year.caption := format('%d', [ Indexation_Year ] );

    // New fields for 2000 policy changes
    edSelf_Employed.text := Self_Employed;
    edRecurrence.text := Recurrence;
    edYouthful_Worker.Text := Youthful_Worker;
    edApprentice.Text := Apprentice;
    edCPP_Exempt.text := CPP_Exempt;
    edTax_Exempt.text := Tax_Exempt;
    edChild_Care_Exp.text := format('%.2n', [ Child_Care_Exp ] );
    edSpousal_Support.text := format('%.2n', [ Spousal_Support ] );

    if year(Accident_Date ) < 2001 then
    begin
      setEditToRead(edChild_Care_Exp);
      setEditToRead(edSpousal_Support);
    end;

    edMax_Adjustments.Text := format('%.2n', [ Max_Adjustment ] );

    //if (Max_Adjustment = 0) or (Self_Employed = 'N') or (year( Accident_Date ) <= 2006) then
    //begin
    setEditToRead(edMax_Adjustments);
    //end;

    cboMaritalStatus.KeyValue := Marital_Status;
    edEI_Exempt.text := EI_Exempt;
    edNo_Of_Dependnts.text := format('%d',[No_Of_Dependnts]);
    edNo_Infirm.text := format('%d',[No_Infirm]);
    edSpouse_Working.Text := Spouse_Working;

    if Length(ClaimSpouseForTaxPurposes) > 0 then
       begin
       edClaimSpouseForTaxPurposes.Text := ClaimSpouseForTaxPurposes;
       end;
  //
  // set the visibility of the Claim Spouse for Tax Purposes field and label.
  // interogate the KeyValue since that's what was loaded into the combo box at
  // this point
  //
  if (upperCase(cboMaritalStatus.KeyValue) = 'DIVORCED')  or
     (upperCase(cboMaritalStatus.KeyValue) = 'SEPARATED') or
     (upperCase(cboMaritalStatus.KeyValue) = 'SINGLE')    or
     (upperCase(cboMaritalStatus.KeyValue) = 'WIDOWED')   then
     begin
     edClaimSpouseForTaxPurposes.Visible := false;
     lblClaimSpouseForTaxPurposes.Visible := false;
     end
  else if (upperCase(cboMaritalStatus.KeyValue) = 'MARRIED')    or
          (upperCase(cboMaritalStatus.KeyValue) = 'COMMON-LAW') then
     begin
     if (edSpouse_Working.Text =  'N') or (trim(edSpouse_Working.Text) =  '') then
        begin
        edClaimSpouseForTaxPurposes.Visible := true;
        lblClaimSpouseForTaxPurposes.Visible := true;
        end
     else if edSpouse_Working.Text =  'Y' then
        begin
        edClaimSpouseForTaxPurposes.Visible := false;
        lblClaimSpouseForTaxPurposes.Visible := false;
        end;
     end;


    lblInc_Tax_Fed.caption := format('%.2n', [ Inc_Tax_Fed ] );
    lblInc_Tax_Man.caption := format('%.2n', [ Inc_Tax_Man ] );
    lblCPP_Prem.caption := format('%.2n', [ CPP_Prem ] );
    lblCPP2_Prem.Caption := format('%.2n', [CPP2_Prem]);
    lblEI_Prem.caption := format('%.2n', [ EI_Prem ] );
    lblTotal_Deds.caption := format('%.2n', [ Total_Deds ] );
    lblWkly_Total_Deds.caption := format('%.2n', [ PdoxRound(Total_Deds / 52.0, 2 ) ] );
    edCollateral_Ben_Tax.text := format('%.2n', [ Collateral_Ben_Tax ] );
    edCollateral_Ben_Non_Tax.text := format('%.2n', [ Collateral_Ben_Non_Tax ] );
    edPost_Injury_Earn.text := format('%.2n', [ Post_Injury_Earn ] );

    if Length(Trim(Deemed_Earnings)) > 0 Then
       edDeemed_Earnings.text := Deemed_Earnings
    else
       edDeemed_Earnings.Text := 'N';

    if ( overPaymentBal <> 0 ) then
      lblOverpayment.caption := ''
    else
      lblOverpayment.caption := '';

    lblColl_Ben_Tax_Net.caption := format('%.2n', [ CalcPartClaim.Coll_Ben_Tax_Net ] );
    lblPost_Injury_Earn_Net.caption := format('%.2n', [ Post_Injury_Earn_Net ] );

    //check whether or not we're paying at minimum and set accordingly
    if Minimum_wage_Flag then
    begin
      lblWkly_Sal_A.caption := format('%.2n', [ Minimum_wage / 52 ] );
      lblWeekly_Net.caption := format('%.2n', [ Min_Wage_Annual_Net_A / 52 ] );
    end
    else
    begin
      lblWkly_Sal_A.caption := format('%.2n', [ Wkly_Sal_A ] );
      lblWeekly_Net.caption := format('%.2n', [ Weekly_Net ] );
    end;

    //set captions of labels here...can't do it in the exit event of Accident Date as the
    //flag as not been set yet
    if Minimum_wage_Flag then
      strCaption := '@ minimum'
    else if Pay_At_100_Flag then
      strCaption := '@ 100%'
    else
      strCaption := '';

    if (Minimum_wage_Flag) or (Pay_At_100_Flag) then
    begin
      lblNetLoss.Caption := '100% of Net Loss';
      lblNetSheltered.Caption := '100% Net Sheltered';
      lblNetLossPartial.Caption := '100% of Net Loss';
      lblNetShelteredPartial.Caption := '100% Net Sheltered';
      lblFullWageLoss.Caption := 'FULL WAGE LOSS BENEFITS ' + strCaption;
      lblPartialWageLoss.Caption := 'PARTIAL WAGE LOSS BENEFITS ' + strCaption;
    end
    else
    begin
      lblNetLoss.Caption := '90% of Net Loss';
      lblNetSheltered.Caption := '90% Net Sheltered';
      lblNetLossPartial.Caption := '90% of Net Loss';
      lblNetShelteredPartial.Caption := '90% Net Sheltered';
      lblFullWageLoss.Caption := 'FULL WAGE LOSS BENEFITS';
      lblPartialWageLoss.Caption := 'PARTIAL WAGE LOSS BENEFITS';
    end;

    if Year(Accident_Date) >= 2006 Then
    begin
      lbCalc90p_Wkly_Net_A.caption := format('%.2n', [ PdoxRound( ( Weekly_Net_A ) , 2)  ] );
      Label74.Caption := 'Effective Date of Annuity Entitlement:';
      lblNetActual.Caption := '100% Net Actual';
      lblWCBAnnuityContr.Caption := 'Employer Annuity Contribution:';
      ed_WCB_Annuity_Contr.Visible := true;
      lblCalc2nc_104_Wk_WCB_p_Contrib_Red.Visible := false;

      //set the caption of the partial claimant contribution labels as we know what year it is
      if (Minimum_wage_Flag) or (Pay_At_100_Flag) then
         begin
         lbl80PercentClaimContribution.Caption := '100% Net Worker Contrib.';
         end
      else
         begin
         lbl80PercentClaimContribution.Caption := '90% Net Worker Contrib.';
         end;
    end
    else
    begin
      lbCalc90p_Wkly_Net_A.caption := format('%.2n', [ PdoxRound( ( Weekly_Net_A * 0.90 ) , 2)  ] );
      Label74.Caption := 'Effective Date of 80% of Net:';
      lbl80PercentClaimContribution.Caption := '80% Net Worker Contrib.';
      lblNetActual.Caption := '90% Net Actual';
      lblWCBAnnuityContr.Caption := 'WCB Annuity Reduction:';
      ed_WCB_Annuity_Contr.Visible := false;
      lblCalc2nc_104_Wk_WCB_p_Contrib_Red.Visible := true;
    end;

    lblAnnual_Gross.caption := format('%.2n', [ Annual_Gross ] );

    if Minimum_wage_Flag then
      lblAnnual_Net.caption := format('%.2n', [ Min_Wage_Annual_Net_A ] )
    else
      lblAnnual_Net.caption := format('%.2n', [ Annual_Net ] );

    lblWeekly_90.caption := format('%.2n', [ Weekly_90 ] );
    if ( ( pdoxround( ( Weekly_90 - Weekly_90_S ) , 2) < 0 ) or ( Weekly_90 < 0 ) ) then
    begin
      lblCalcTaxSheltering.caption := '0.00';
    end
    else
    begin
      lblCalcTaxSheltering.caption := format('%.2n', [ pdoxround( ( Weekly_90 - Weekly_90_S ) , 2) ] );
    end;

    if ( ( pdoxround( ( Weekly_90 - Weekly_90_S ) , 2) < 0 ) ) then
    begin
      Weekly_90_S := Weekly_90;
      lblWeekly_90_S.caption := format( '%.2n', [ Weekly_90 ] );
    end
    else
    begin
      lblWeekly_90_S.caption := format( '%.2n', [ Weekly_90_S ] );
    end;

    if ( Days_Worked_per_Week <> 0 ) then
    begin
      lblDailyCompensationRate.caption := format('%.2n', [ Weekly_90_S / Days_Worked_per_Week]);

      //set next value whether or not it is a post 2006 claim
      if Year(Accident_Date) >= 2006 then
      begin
        lblDaily80FullCompensationRate.caption := format('%.2n', [ pdoxround( ( Weekly_90_S  - Wkly_Clmt_Anty_Con_Amt), 2) / Days_Worked_per_Week]);
      end
      else
      begin
        lblDaily80FullCompensationRate.caption := format('%.2n', [ pdoxround( ( Weekly_80  - Wkly_Clmt_Anty_Con_Amt), 2) / Days_Worked_per_Week]);
      end;
    end
    else
    begin
      lblDailyCompensationRate.caption := '';
      lblDaily80FullCompensationRate.caption := '';
    end;

    lblAnnual_90.caption := format('%.2n', [ Annual_90 ] );
    lblAnnual_90_S.caption := format('%.2n', [ Annual_90_S ] );
    lblWeekly_80.caption := format('%.2n', [ Weekly_80 ] );
    lblWkly_Clmt_Anty_Con_Amt.caption := format('%.2n', [ Wkly_Clmt_Anty_Con_Amt ] );

    //set next values whether or not it is a post 2006 claim
    if Year(Accident_Date) >= 2006 then
    begin
      lblCalcWkly80p_Net_Clmt_Contr.caption := format('%.2n', [ pdoxround( ( Weekly_90_S  - Wkly_Clmt_Anty_Con_Amt), 2) ] );
      lblCalcWkly_p_WCB_Contr.caption := format('%.2n', [ pdoxround( ( (((nc_104_Wk_WCB_p_Contrib)*Weekly_90_S)/100.00) ), 2) ] );
      lblCalcnc_104_Wk_WCB_p_Contrib_Red.caption := format('%.2n',
      [ pdoxround( (nc_104_Wk_WCB_p_Contrib ), 2) ] );
    end
    else
    begin
      lblCalcWkly80p_Net_Clmt_Contr.caption := format('%.2n',
        [ pdoxround( ( Weekly_80  - Wkly_Clmt_Anty_Con_Amt), 2) ] );
      lblCalcWkly_p_WCB_Contr.caption := format('%.2n',
        [ pdoxround( ( (((5 - nc_104_Wk_WCB_p_Contrib_Red)*Weekly_80)/100.00) ), 2) ] );
      lblCalcnc_104_Wk_WCB_p_Contrib_Red.caption := format('%.2n',
        [ pdoxround( ( 5 - nc_104_Wk_WCB_p_Contrib_Red ), 2) ] );
    end;

    if nc_104_Wk_Effective_Date > 0 then
       begin
       //ednc_104_Wk_Effective_Date.text := formatdatetime('c', nc_104_Wk_Effective_Date);
       ednc_104_Wk_Effective_Date.text := formatdatetime('ddddd', nc_104_Wk_Effective_Date);
       end
    else
       ednc_104_Wk_Effective_Date.text := '';

    ednc_104_Wk_Clmt_p_Contrib.text := format('%.2n',[ nc_104_Wk_Clmt_p_Contrib ]);

    if nc_104_Wk_Clmt_p_Eff_Date > 0 then
       begin
       //ednc_104_Wk_Clmt_p_Eff_Date.text := formatdatetime('c', nc_104_Wk_Clmt_p_Eff_Date);
       ednc_104_Wk_Clmt_p_Eff_Date.text := formatdatetime('ddddd', nc_104_Wk_Clmt_p_Eff_Date);
       end
    else
       ednc_104_Wk_Clmt_p_Eff_Date.text := '';

    lblnc_104_Wk_Clmt_p_Contrib.caption := format('%.2n', [ nc_104_Wk_Clmt_p_Contrib ] );

    // same as lblCalcnc_104_Wk_WCB_p_Contrib_Red
    if Year(Accident_Date) >= 2006 then
    begin
      lblCalc2nc_104_Wk_WCB_p_Contrib_Red.caption := format('%.2n',
        [ pdoxround( ( nc_104_Wk_WCB_p_Contrib ), 2) ] );
    end
    else
    begin
      lblCalc2nc_104_Wk_WCB_p_Contrib_Red.caption := format('%.2n',
        [ pdoxround( ( 5 - nc_104_Wk_WCB_p_Contrib_Red ), 2) ] );
    end;
    ednc_104_Wk_WCB_p_Contrib_Red.text := format('%.2n', [ nc_104_Wk_WCB_p_Contrib_Red ] );
    ed_WCB_Annuity_Contr.Text := format('%.2n', [ nc_104_Wk_WCB_p_Contrib ] );

    if ( CalcFullClaim.Post_Injury_Earn = 0.0 ) then
    begin
      lblPartPre_Weekly_Net.caption := '';
      lblPartPost_Injury_Earn_Net.caption := '';
      lblPost_Injury_Earn_Net.caption := format('%.2n', [ Post_Injury_Earn_Net ] );
      lblPartCalcNetLossEarnings.caption := '';
      lblPartWeekly_90.caption := '';
      lblPartCalcTaxSheltering.caption := '';
      lblPartWeekly_90_S.caption := '';
      lblPartDailyCompensationRate.caption := '';
      lblPartDaily80CompensationRate.caption := '';
      lblPartWeekly_80.caption := '';
      lblPartWkly_Clmt_Anty_Con_Amt.caption := '';
      lblPartCalcWkly80p_Net_Clmt_Contr.caption := '';
      lblPartCalcWkly_p_WCB_Contr.caption := '';
      lblPart_nc_104_Wk_Clmt_p_Contrib.caption := '';
      lblPart_Calcnc_104_Wk_WCB_p_Contrib_Red.caption := '';

      //make all the labels invisible
      lblPartPre_Weekly_Net.visible := false;
      lblPartPost_Injury_Earn_Net.visible := false;
      lblPost_Injury_Earn_Net.visible := false;
      lblPartCalcNetLossEarnings.visible := false;
      lblPartWeekly_90.visible := false;
      lblPartCalcTaxSheltering.visible := false;
      lblPartWeekly_90_S.visible := false;
      lblPartDailyCompensationRate.visible := false;
      lblPartDaily80CompensationRate.visible := false;
      lblPartWeekly_80.visible := false;
      lblPartWkly_Clmt_Anty_Con_Amt.visible := false;
      lblPartCalcWkly80p_Net_Clmt_Contr.visible := false;
      lblPartCalcWkly_p_WCB_Contr.visible := false;
      lblPart_nc_104_Wk_Clmt_p_Contrib.visible := false;
      lblPart_Calcnc_104_Wk_WCB_p_Contrib_Red.visible := false;
      lblPartialWageLoss.Visible := false;
      label77.Visible := false;
      label78.Visible := false;
      label79.Visible := false;
      label89.Visible := false;
      label56.Visible := false;
      label39.Visible := false;
      label80.Visible := false;
      lblNetLossPartial.Visible := false;
      lblNetShelteredPartial.Visible := false;
      lbl80NetLossPartial.Visible := false;
      lbl80PercentClaimantContribPartial.Visible := false;
      lbl80PercentClaimContributionPartial.Visible := false;
      lbl80PercentWCBContributionPartial.visible := false;
      lbl80DailyCompRatePartial.Visible := false;
    end
    else
    begin
      with CalcPartClaim do
      begin
        if Minimum_Wage_Flag_Partial then
          strPartialCaption := '@ minimum'
        else if Pay_At_100_Flag then
          strPartialCaption := '@ 100%'
        else
          strPartialCaption := '';

        if Year(Accident_Date) >= 2006 Then
        begin
          if (Minimum_Wage_Flag_Partial) or (Pay_At_100_Flag_Partial) then
          begin
            lblNetLossPartial.Caption := '100% of Net Loss';
            lblNetShelteredPartial.Caption := '100% Net Sheltered';
            lblPartialWageLoss.Caption := 'PARTIAL WAGE LOSS BENEFITS ' + strPartialCaption;
            lbl80PercentClaimContributionPartial.Caption := '100% Net Worker Contrib.';
          end
          else
          begin
            lblNetLossPartial.Caption := '90% of Net Loss';
            lblNetShelteredPartial.Caption := '90% Net Sheltered';
            lblPartialWageLoss.Caption := 'PARTIAL WAGE LOSS BENEFITS';
            lbl80PercentClaimContributionPartial.Caption := '90% Net Worker Contrib.';
          end;
        end
        else
        begin
      	  lblNetLossPartial.Caption := '90% of Net Loss';
          lblNetShelteredPartial.Caption := '90% Net Sheltered';
          lblPartialWageLoss.Caption := 'PARTIAL WAGE LOSS BENEFITS';
          lbl80PercentClaimContributionPartial.Caption := '90% Net Worker Contrib.';
          lbl80PercentClaimContributionPartial.Caption := '80% Net Worker Contrib.';
        end;

        lblPartPre_Weekly_Net.caption := format('%.2n', [ Weekly_Net ] );

        if ( pdoxround( ( Weekly_Net - Post_Injury_Earn_Net ) , 2) < 0 ) then
          lblPartCalcNetLossEarnings.caption := '0.00'
        else
          lblPartCalcNetLossEarnings.caption := format('%2n', [ pdoxround( ( Weekly_Net - Post_Injury_Earn_Net ) , 2) ] );

        lblPartPost_Injury_Earn_Net.caption := format('%.2n', [ Post_Injury_Earn_Net ] );
        lblPost_Injury_Earn_Net.caption := format('%.2n', [ Post_Injury_Earn_Net ] );

        if ( Weekly_90 < 0 ) then
          lblPartWeekly_90.caption := '0.00'
        else
          lblPartWeekly_90.caption := format('%.2n', [ Weekly_90 ] );

        //showmessage('Weekly_90 = ' + format('%.2n', [ Weekly_90 ] ) + '  Weekly_90_S = ' + format('%.2n', [ Weekly_90_S ] ));

        if ( Weekly_90_S <= 0 ) then
        begin
          if ( ( pdoxround( ( Weekly_90 + Weekly_90_S ) , 2) <= 0 ) or ( Weekly_90 <= 0 ) ) then
            //lblPartCalcTaxSheltering.caption := '0.00'
            lblPartCalcTaxSheltering.caption := lblCalcTaxSheltering.caption
          else
            if Collateral_Ben_Tax > 0.00 then
              lblPartCalcTaxSheltering.caption := format('%.2n', [ pdoxround( ( Weekly_90 + Weekly_90_S ) , 2) ] )
            else
              lblPartCalcTaxSheltering.caption := lblCalcTaxSheltering.caption
        end
        else
        begin
          if ( ( pdoxround( ( Weekly_90 - Weekly_90_S ) , 2) <= 0 ) or ( Weekly_90 <= 0 ) ) then
            lblPartCalcTaxSheltering.caption := '0.00'
          else
            if Collateral_Ben_Tax > 0.00 then
              lblPartCalcTaxSheltering.caption := format('%.2n', [ pdoxround( ( Weekly_90 - Weekly_90_S ) , 2) ] )
            else
              lblPartCalcTaxSheltering.caption := lblCalcTaxSheltering.caption
        end;

        if ( Weekly_90_S <= 0 ) then
        begin
          lblPartWeekly_90_S.caption := '0.00';
        end
        else
        begin
          lblPartWeekly_90_S.caption := format('%.2n', [ Weekly_90_S ] );
        end;

        if ( Days_Worked_per_Week <> 0 ) then
        begin
          if ( Weekly_90_S / Days_Worked_per_Week < 0 ) then
          begin
            lblPartDailyCompensationRate.caption := '0.00';
          end
          else
          begin
            lblPartDailyCompensationRate.caption := format('%.2n', [ Weekly_90_S / Days_Worked_per_Week]);
          end;

          if Year(Accident_Date) >= 2006 then
          begin
            if ( pdoxround( ( Weekly_90_S  - Wkly_Clmt_Anty_Con_Amt), 2) / Days_Worked_per_Week < 0 ) then
            begin
              lblPartDaily80CompensationRate.caption := '0.00';
            end
            else
            begin
              lblPartDaily80CompensationRate.caption := format('%.2n', [ pdoxround( ( Weekly_90_S  - Wkly_Clmt_Anty_Con_Amt), 2) / Days_Worked_per_Week]);
            end;
          end
          else
          begin
            lblPartDaily80CompensationRate.caption := format('%.2n', [ pdoxround( ( Weekly_80  - Wkly_Clmt_Anty_Con_Amt), 2) / Days_Worked_per_Week]);
          end;
        end
        else
        begin
          lblPartDaily80CompensationRate.caption := '';
          lblPartDailyCompensationRate.caption := '';
        end; //if Days_Worked_per_Week <> 0

        if ( Weekly_80 < 0 ) then
          lblPartWeekly_80.caption := '0.00'
        else
          lblPartWeekly_80.caption := format('%.2n', [ Weekly_80 ] );

        //set next values whether or not it is a post 2006 claim
        if Year(Accident_Date) >= 2006 then
        begin
          if ( pdoxround( ((nc_104_Wk_Clmt_p_Contrib*Weekly_90_S)/100.00), 2) < 0 ) then
          begin
            lblPartWkly_Clmt_Anty_Con_Amt.caption := '0.00';
          end
          else
          begin
            lblPartWkly_Clmt_Anty_Con_Amt.caption := format('%.2n', [ pdoxround( ((nc_104_Wk_Clmt_p_Contrib*Weekly_90_S)/100.00), 2) ] );
          end;

          if ( Weekly_90_S / Days_Worked_per_Week < 0 ) then
          begin
            lblPartCalcWkly80p_Net_Clmt_Contr.caption := '0.00';
          end
          else
          begin
            lblPartCalcWkly80p_Net_Clmt_Contr.caption := format( '%.2n', [ pdoxround( ( Weekly_90_S  - Wkly_Clmt_Anty_Con_Amt ), 2 ) ] );
          end;

          if ( pdoxround( ( ( ( ( nc_104_Wk_WCB_p_Contrib ) * Weekly_90_S ) / 100.00 ) ), 2) < 0 ) then
          begin
            lblPartCalcWkly_p_WCB_Contr.caption := '0.00';
          end
          else
          begin
            lblPartCalcWkly_p_WCB_Contr.caption := format('%.2n', [ pdoxround( ( ( ( ( nc_104_Wk_WCB_p_Contrib ) * Weekly_90_S )/100.00 ) ), 2) ] );
          end;
        end
        else
        begin
          lblPartWkly_Clmt_Anty_Con_Amt.caption := format('%.2n',
            [ pdoxround( ( ( nc_104_Wk_Clmt_p_Contrib * Weekly_80 ) / 100.00 ), 2 ) ] );
          lblPartCalcWkly80p_Net_Clmt_Contr.caption := format('%.2n',
            [ pdoxround( ( Weekly_80  - Wkly_Clmt_Anty_Con_Amt), 2) ] );
          lblPartCalcWkly_p_WCB_Contr.caption := format('%.2n',
            [ pdoxround( ( ( ( ( 5 - nc_104_Wk_WCB_p_Contrib_Red ) * Weekly_80 ) / 100.00 ) ), 2) ] );
        end;

        lblPart_nc_104_Wk_Clmt_p_Contrib.caption := lblnc_104_Wk_Clmt_p_Contrib.caption;
        lblPart_Calcnc_104_Wk_WCB_p_Contrib_Red.caption := lblCalcnc_104_Wk_WCB_p_Contrib_Red.caption;
      end; //with PartClaim

      //make all the labels visible
      lblPartPre_Weekly_Net.visible := true;
      lblPartPost_Injury_Earn_Net.visible := true;
      lblPost_Injury_Earn_Net.visible := true;
      lblPartCalcNetLossEarnings.visible := true;
      lblPartWeekly_90.visible := true;
      lblPartCalcTaxSheltering.visible := true;
      lblPartWeekly_90_S.visible := true;
      lblPartDailyCompensationRate.visible := true;
      lblPartialWageLoss.Visible := true;
      label77.Visible := true;
      label78.Visible := true;
      label79.Visible := true;
      label89.Visible := true;
      label56.Visible := true;
      label39.Visible := true;
      label80.Visible := true;
      if year(Accident_Date) < 2006 then begin
        lblPartWeekly_80.visible := true;
        lbl80NetLossPartial.Visible := true;
      end;
      lblNetLossPartial.Visible := true;
      lblNetShelteredPartial.Visible := true;
      lbl80PercentClaimantContribPartial.Visible := true;
      lbl80PercentClaimContributionPartial.Visible := true;
      lbl80PercentWCBContributionPartial.visible := true;
      lbl80DailyCompRatePartial.Visible := true;
      lblPartWkly_Clmt_Anty_Con_Amt.visible := true;
      lblPartCalcWkly80p_Net_Clmt_Contr.visible := true;
      lblPartCalcWkly_p_WCB_Contr.visible := true;
      lblPart_nc_104_Wk_Clmt_p_Contrib.visible := true;
      lblPart_Calcnc_104_Wk_WCB_p_Contrib_Red.visible := true;
      lblPartDaily80CompensationRate.Visible := true;
    end;
  end; //CalcFullClaim
end;


(******************************************************************************)
(*                                                                            *)
(*  Validate edit fields and recalculate benefits if no errors.               *)
(*                                                                            *)
(******************************************************************************)
function TWagelossBenefitCalcForm.ValidateAndRecalcBen: boolean;
var
  res: boolean;
  ws: shortstring;
  accidentYear : integer;
  totalWeeks: currency;
begin
  result := false;
  globalEditError := false;

  { make sure system date format hasn't changed }
  res := validateSystemDateFormat;
  if not res then exit;

  { validate all fields }
  setValidate := true;

  try
     res := validateAsCurrency( edWkly_Sal_A );
     if not res then exit;
     res := validateAsCurrency( edMax_Adjustments );
     if not res then exit;
     res := validateAsCurrency( edDays_Worked_per_Week );
     if not res then exit;
     res := validateAsInteger( edTax_Year );
     if not res then exit;
     res := validateAsInteger( edNo_Of_Dependnts );
     if not res then exit;
     res := validateAsInteger( edNo_Infirm );
     if not res then exit;
     res := validateAsCurrency( edCollateral_Ben_Tax );
     if not res then exit;
     res := validateAsCurrency( edCollateral_Ben_Non_Tax );
     if not res then exit;
     res := validateAsCurrency( edPost_Injury_Earn );
     if not res then exit;
     res := validateAsDate( ednc_104_Wk_Effective_Date );
     if not res then exit;
     res := validateAsDate( ednc_104_Wk_Clmt_p_Eff_Date );
     if not res then exit;
     res := validateAsCurrency( ednc_104_Wk_WCB_p_Contrib_Red );
     if not res then exit;
     res := validateAsCurrency( ed_WCB_Annuity_Contr );
     if not res then exit;
     res := validateAsCurrency( ednc_104_Wk_Clmt_p_Contrib );
     if not res then exit;
     res := validateAsCurrency( edChild_Care_Exp );
     if not res then exit;
     res := validateAsCurrency( edSpousal_Support );
     if not res then exit;
     res := validateAsDate( edRecurrenceDate );
     if not res then exit;
     res := validateAsDate( edEffectiveDate );
     if not res then exit;

     // do exit processing on all fields to enforce exit edits
     if edWkly_Sal_A.enabled then edWkly_Sal_AExit(edWkly_Sal_A);
     if globalEditError then exit;

     if edMax_Adjustments.enabled then edMax_AdjustmentsExit(edMax_Adjustments);
     if globalEditError then exit;

     if (edSelf_Employed.Text='Y') and (blnSelfEmpTestDone = false) then
        edSelf_EmployedExit(edSelf_Employed);

     if edDays_Worked_per_Week.enabled then edDays_Worked_per_WeekExit(edDays_Worked_per_Week);
     if globalEditError then exit;

     if edTax_Year.enabled then edTax_YearExit(edTax_Year);
     if globalEditError then exit;

     if edRecurrence.enabled then edRecurrenceExit(edRecurrence);
     if globalEditError then exit;

     if ((edRecurrenceDate.Visible) And (edRecurrenceDate.Enabled)) then edRecurrenceDateExit(edRecurrenceDate);
     if globalEditError then exit;

     if edYouthful_Worker.enabled then edYouthful_WorkerExit(edYouthful_Worker);
     if globalEditError then exit;

     if edApprentice.Enabled then edApprenticeExit(edApprentice);
     if globalEditError then exit;

     if edSelf_Employed.enabled then edSelf_EmployedExit(edSelf_Employed);
     if globalEditError then exit;

     if cboMaritalStatus.Enabled then cboMaritalStatusExit(cboMaritalStatus);
     if globalEditError then exit;

     if edSpouse_Working.enabled then edSpouse_WorkingExit(edSpouse_Working);
     if globalEditError then exit;

     if (edClaimSpouseForTaxPurposes.Enabled AND edClaimSpouseForTaxPurposes.Visible) then edClaimSpouseForTaxPurposesExit(edClaimSpouseForTaxPurposes);
     if globalEditError then exit;

     if edEI_Exempt.enabled then edEI_ExemptExit(edEI_Exempt);
     if globalEditError then exit;

     if edCPP_Exempt.enabled then edCPP_ExemptExit(edCPP_Exempt);
     if globalEditError then exit;

     if edTax_Exempt.enabled then edTax_ExemptExit(edTax_Exempt);
     if globalEditError then exit;

     if edNo_Of_Dependnts.enabled then edNo_Of_DependntsExit(edNo_Of_Dependnts);
     if globalEditError then exit;

     if edNo_Infirm.enabled then edNo_InfirmExit(edNo_Infirm);
     if globalEditError then exit;

     if edCollateral_Ben_Tax.enabled then edCollateral_Ben_TaxExit(edCollateral_Ben_Tax);
     if globalEditError then exit;

     if edCollateral_Ben_Non_Tax.enabled then edCollateral_Ben_Non_TaxExit(edCollateral_Ben_Non_Tax);
     if globalEditError then exit;

     if edPost_Injury_Earn.enabled then edPost_Injury_EarnExit(edPost_Injury_Earn);
     if globalEditError then exit;

     if ednc_104_Wk_Effective_Date.enabled then ednc_104_Wk_Effective_DateExit(ednc_104_Wk_Effective_Date);
     if globalEditError then exit;

     if ednc_104_Wk_Clmt_p_Contrib.enabled then ednc_104_Wk_Clmt_p_ContribExit(ednc_104_Wk_Clmt_p_Contrib);
     if globalEditError then exit;

     if ednc_104_Wk_WCB_p_Contrib_Red.enabled then ednc_104_Wk_WCB_p_Contrib_RedExit(ednc_104_Wk_WCB_p_Contrib_Red);
     if globalEditError then exit;

     if ed_WCB_Annuity_Contr.Enabled then ed_WCB_Annuity_ContrExit( ed_WCB_Annuity_Contr );
     if globalEditError then exit;

     if ednc_104_Wk_Clmt_p_Eff_Date.enabled then ednc_104_Wk_Clmt_p_Eff_DateExit(ednc_104_Wk_Clmt_p_Eff_Date);
     if globalEditError then exit;

     if edChild_Care_Exp.enabled then edChild_Care_ExpExit(edChild_Care_Exp);
     if globalEditError then exit;

     if edSpousal_Support.enabled then edSpousal_SupportExit(edSpousal_Support);
     if globalEditError then exit;

     if edEffectiveDate.Enabled then edEffectiveDateExit(edEffectiveDate);
     if globalEditError then exit;

     // make sure a wage was entered
     if ( textAsCurrency( edWkly_Sal_A ) < 0.01 ) then
        begin
        if edWkly_Sal_A.Enabled then
           edWkly_Sal_A.setfocus;
        WagelossMainForm.ShowInfoLine2('*Please enter a weekly wage.');
        exit;
        end;

     ws := copy(edSpouse_Working.Text,1,1);
     case ws[1] of 'Y','N':
        begin
        if (edSelf_Employed.Text='N') then
           begin
           setEditToRead(edMax_Adjustments);
           end;

        if (edRecurrence.text='Y') and (GetOldRecurrenceInd='N') then
  	       begin
           edRecurrenceDate.Visible :=  True;

           if Length(edRecurrenceDate.text) < 1 then
              begin
              if edRecurrenceDate.Enabled then
                 edRecurrenceDate.setfocus;
              WagelossMainForm.ShowInfoLine2('*Please enter a Recurrence Date.');
              exit;
    	        end;
           end;

        end
     else
        begin
        if edSpouse_Working.Enabled then
           edSpouse_Working.setFocus;
        WagelossMainForm.ShowInfoLine2('*Valid values for Spouse Working are Y N');
        globalEditError := true;
        end;
     end;

     ws := copy(edClaimSpouseForTaxPurposes.Text,1,1);
     case ws[1] of 'Y','N':
     else
        begin
        if edSpouse_Working.Text = 'N' then
           begin
           edClaimSpouseForTaxPurposes.Setfocus;
           WagelossMainForm.ShowInfoLine2('*Valid values for Claim Spouse for Tax Purposes are Y N');
           exit;
           end;
        end;
     end;


     ws := copy(edEI_Exempt.Text,1,1);
     case ws[1] of 'Y','N':
     else
        begin
        if edEI_Exempt.Enabled then
           edEI_Exempt.setfocus;
        WagelossMainForm.ShowInfoLine2('*Valid values for EI Exempt are Y N');
        exit;
        end;
     end;

     ws := copy(edCPP_Exempt.Text,1,1);
     case ws[1] of 'Y','N':
     else
        begin
        if edCPP_Exempt.Enabled then
           edCPP_Exempt.setfocus;
        WagelossMainForm.ShowInfoLine2('*Valid values for CPP Exempt are Y N');
        exit;
        end;
     end;

     ws := copy(edTax_Exempt.Text,1,1);
     case ws[1] of 'Y','N':
     else
        begin
        if edTax_Exempt.Enabled then
           edTax_Exempt.setfocus;
        WagelossMainForm.ShowInfoLine2('*Valid values for Income Tax Exempt are Y N');
        exit;
        end;
     end;

     if not validateAverageEarningsBasedOn then exit;

     if Not WagelossMainForm.blnCreateCalculator Then
        begin
        totalWeeks := getAnnuityEntitlementWeeks(CalcFullClaim.accident_date, CalcFullClaim.claim_no, CalcFullClaim.No_Weeks_of_Comp_Bnfts);

        if (totalWeeks < 96) and (edCalculationType.ItemIndex <> 0) then
           if Messagedlg('Annuity Entitlement weeks is ' +  format('%.2n', [totalWeeks]) + Chr(10) + Chr(13) + 'Do you want to change the calculation type to Pre 104?', mtConfirmation, [mbYes, mbNo],0) = mrYes Then
              edCalculationType.ItemIndex := 0;
        if (totalWeeks > 104) and (edCalculationType.ItemIndex <> 1) then
           if Messagedlg('Annuity Entitlement weeks is ' +  format('%.2n', [totalWeeks]) + Chr(10) + Chr(13) + 'Do you want to change the calculation type to Post 104?', mtConfirmation, [mbYes, mbNo],0) = mrYes Then
              edCalculationType.ItemIndex := 1;

        if (totalWeeks >= 96) and (totalWeeks <= 104) then
           begin
           SelectCalcType(totalWeeks);
           if (blnSetPre104 = false) and (blnSetPost104 = false) then
              begin
              globalEditError := displayError( '*A calculation type must be selected if Annuity Entitlement weeks are between 96 and 104.', edCalculationType );
              exit;
              end
           else
              if (blnSetPre104) then
                 edCalculationType.ItemIndex := 0
              else
                 edCalculationType.ItemIndex := 1;
           end;
        end;

     // Summary checking
     if lblAccident_Date.Visible Then
        accidentYear := Year(CalcFullClaim.Accident_Date)
     else
        accidentYear := Year(StrtoDate(edAccident_Date.Text));

     if ( StrToDate( edEffectiveDate.Text ) <= StrToDate( lblAccident_Date.Caption ) ) then
        begin
        globalEditError := displayError( '*Effective Date cannot be before or on the same day as the Injury Date', edEffectiveDate );
        exit;
        end;

     if ((ednc_104_Wk_Effective_Date.Enabled)           And
        (Trim(ednc_104_Wk_Effective_Date.Text) <> '')) Then
        begin
        if accidentYear >= 2006 then
           begin
           if (textAsCurrency(ed_WCB_Annuity_Contr) + textAsCurrency(ednc_104_Wk_WCB_p_Contrib_Red)) < 5 then
              begin
              globalEditError := displayError( '*Total WCB and Employer Contribution must be greater than or equal to 5%', ed_WCB_Annuity_Contr );
              exit;
              end;
           end
        else
           begin
           if ( textAsCurrency( ednc_104_Wk_Clmt_p_Contrib ) >
              ( 5 - textAsCurrency( ednc_104_Wk_WCB_p_Contrib_Red ))  ) then
              begin
              globalEditError := displayError( '*Client contribution cannot WCB Contribution', ednc_104_Wk_WCB_p_Contrib_Red );
              exit;
              end;
           end;
        end;

     //Get current loss of earnings date
     //Purpose, to re-load loss of earnings date after a payment has been made
     if dataClaim.Claim_No > IntToStr( 0 ) then
        begin
        try
           with dm1 do
              begin
              if qryGeneralEmerge.active then
                 qryGeneralEmerge.close;
              qryGeneralEmerge.sql.clear;
              qryGeneralEmerge.sql.add( 'SELECT lossOfEarningsDate ' );
              qryGeneralEmerge.sql.add( 'FROM Claim ' );
              qryGeneralEmerge.sql.add( 'WHERE claimNo = ' +  dataClaim.Claim_No );
              qryGeneralEmerge.open;
              qryGeneralEmerge.first;

              CalcFullClaim.Loss_Earn_Date := qryGeneralEmerge.FieldByName( 'lossOfEarningsDate' ).AsDateTime;
              qryGeneralEmerge.close;
              end;
        finally
           ;
        end;
        end;

     { fill in dataBenCalc record }
     with CalcFullClaim do
        begin
        Wkly_Sal_A := textAsCurrency(edWkly_Sal_A);
        Days_Worked_per_Week := textAsCurrency(edDays_Worked_per_Week);
        AverageEarningsBasedOn := cboAverageEarningsBasedOn.KeyValue;
        Tax_Year := textAsInteger(edTax_Year);
        Marital_Status := cboMaritalStatus.KeyValue;
        Spouse_Working := edSpouse_Working.text;
        ClaimSpouseForTaxPurposes := edClaimSpouseForTaxPurposes.Text;
        EI_Exempt := edEI_Exempt.text;
        No_Of_Dependnts := textAsInteger(edNo_Of_Dependnts);
        No_Infirm := textAsInteger(edNo_Infirm);
        Collateral_Ben_Tax :=textAsCurrency(edCollateral_Ben_Tax);
        Collateral_Ben_Non_Tax := textAsCurrency(edCollateral_Ben_Non_Tax);
        Post_Injury_Earn := textAsCurrency(edPost_Injury_Earn);
        Deemed_Earnings := edDeemed_Earnings.text;
        nc_104_Wk_Effective_Date := textAsDate( ednc_104_Wk_Effective_Date );
        nc_104_Wk_Clmt_p_Eff_Date := textAsDate( ednc_104_Wk_Clmt_p_Eff_Date );
        nc_104_Wk_WCB_p_Contrib_Red := textAsCurrency( ednc_104_Wk_WCB_p_Contrib_Red );
        nc_104_Wk_WCB_p_Contrib  := textAsCurrency( ed_WCB_Annuity_Contr );
        nc_104_Wk_Clmt_p_Contrib := textAsCurrency( ednc_104_Wk_Clmt_p_Contrib );
        Self_Employed := edSelf_Employed.text;
        Recurrence := edRecurrence.text;
        CPP_Exempt := edCPP_Exempt.text;
        Tax_Exempt := edTax_Exempt.text;
        Child_Care_Exp := textAsCurrency(edChild_Care_Exp);
        Spousal_Support := textAsCurrency(edSpousal_Support);
        Max_Adjustment := textAsCurrency(edMax_Adjustments);
        RecurrenceDate := textAsDate(edRecurrenceDate);
        ReturnCode := False;
        ReturnMessage := '';
        Youthful_Worker := edYouthful_Worker.Text;
        Apprentice := edApprentice.Text;
        Minimum_wage_Flag := false;
        Pay_At_100_Flag := false;
        week104StatusType := edCalculationType.Items.Strings[ edCalculationType.ItemIndex ];
        effectiveDate := textAsDate( edEffectiveDate);
        end;

     uglobal.RecalcBen(CalcFullClaim, CalcPartClaim, DeathBenefitCalc);
     Result := CalcFullClaim.ReturnCode;

     if (Not CalcFullClaim.ReturnCode) OR (CalcFullClaim.ReturnMessage <> '') Then
        begin
        if not (self.ActiveControl.Name = edWkly_Sal_A.Name) then
           WagelossMainForm.ShowInfoLine2( CalcFullClaim.ReturnMessage )
        else
           ResetInfoLine2;
        end;

     if CalcFullClaim.ReturnCode Then
        begin
        fillInForm;
        SetUpdateInd(True);
        ResetInfoLine2;
        setValidate := false;
        end
     else
        begin
        allowUpdateClaim := false;
        end;

     //blnSelfEmpTestDone := false;
     blnRecurrence_Set := True;
     blnRecalcNeeded := false;
  finally
     setValidate := false;
  end;
end;

(******************************************************************************)
(*                                                                            *)
(*  Key press edit for EI/UIC exempt                                             *)
(*                                                                            *)
(******************************************************************************)
procedure TWagelossBenefitCalcForm.edEI_ExemptKeyPress(Sender: TObject; var Key: Char);
begin
  case Key of #0..#31,'y','Y','n','N':
  else
    Key := #0;
    WagelossMainForm.ShowInfoLine2( '*Valid values for EI Exempt are Y N' );
  end;
end;

(******************************************************************************)
(*                                                                            *)
(*  Key press edit for Spouse Working                                         *)
(*                                                                            *)
(******************************************************************************)
procedure TWagelossBenefitCalcForm.edSpouse_WorkingKeyPress(Sender: TObject; var Key: Char);
begin
  case Key of #0..#31,'y','Y','n','N':
  else
    Key := #0;
    WagelossMainForm.ShowInfoLine2( '*Valid values for Spouse Working are Y N');
  end;
end;

(******************************************************************************)
(*                                                                            *)
(*  Key press edit for Deemed Earnings                                        *)
(*                                                                            *)
(******************************************************************************)
procedure TWagelossBenefitCalcForm.edDeemed_EarningsKeyPress(Sender: TObject; var Key: Char);
begin
  case Key of #0..#31,'y','Y','n','N':
  else
    Key := #0;
    WagelossMainForm.ShowInfoLine2('*Valid values for Deemed are Y N');
  end;
end;

(******************************************************************************)
(*                                                                            *)
(*  Validate Weekly Salary                                                    *)
(*                                                                            *)
(******************************************************************************)
//
// Modified April 2003
// Purpose: Modified to allow the Wageloss form to be used as both the calculator
//          and the wageloss form
//
//          Modifications denoted as //***
//
procedure TWagelossBenefitCalcForm.edWkly_Sal_AExit(Sender: TObject);
begin
  if not SetValidate then
     setinfoline := True;

  if not ValidateAsCurrency( edWkly_Sal_A ) then
  begin
    globalEditError := displayError( '*Invalid Weekly Wage.', edWkly_Sal_A );
    Exit;
  end;

  If Not (TextAsCurrency(edWkly_Sal_A) > 0) Then
  Begin
    globalEditError := displayError( '*Weekly Wage must be greater than $0.00', edWkly_Sal_A );
    Exit;
  end;
  //
  // Modified for Leg Amendment. We now check for an annual salary > 99,999.99
  // if so we prompt the user to verify the amount
  //

  // *** if ( TextAsCurrency( edWkly_Sal_A ) > 1923.08 ) Then
  if ( TextAsCurrency( edWkly_Sal_A ) > 1923.08 ) and (not WagelossMainForm.isRunManualTest) Then
  begin
    messagebeep(0);
    if ( MessageDlg( 'Please verify annual Salary > $99,999.00', mtInformation, [mbYes, mbNo], 0 ) <> mrYes ) Then
    begin
      if edWkly_Sal_A.Enabled then
        edWkly_Sal_A.setfocus;
      GlobalEditError := True;
      Exit;
    end;
  end;

  if ( CalcFullClaim.Wkly_Sal_A <> textAsCurrency( edWkly_Sal_A ) ) then
     SetUpdateInd(True);

  edWkly_Sal_A.text := Format( '%.2n',[textAsCurrency( edWkly_Sal_A )] );
  ResetInfoLine2;
end;

(******************************************************************************)
(*                                                                            *)
(*  Validate Days worked per week                                             *)
(*                                                                            *)
(*****************************************************************************
//
// Modified April 2003
// Purpose: Modified to allow the Wageloss form to be used as both the calculator
//          and the wageloss form
//
*****************************************************************************)
procedure TWagelossBenefitCalcForm.edDays_Worked_per_WeekExit(Sender: TObject);
var
  f:currency;
begin
  if not SetValidate then
    SetInfoLine := True;

  if not ValidateAsCurrency( edDays_Worked_per_Week ) then
  begin
    globalEditError := displayError( '*invalid DAYS WORKED/WEEK', edDays_Worked_per_Week );
    Exit;
  end;

  f := TextAsCurrency( edDays_Worked_per_Week );

  if (f < 0.5) or (f > 7.0) then
  begin
    globalEditError := displayError( '*DAYS WORKED/WEEK must be between 0.5 and 7', edDays_Worked_per_Week );
    Exit;
  end;

  if ( CalcFullClaim.Days_Worked_per_Week <> textAsCurrency( edDays_Worked_per_Week ) ) then
    SetUpdateInd(True);

  edDays_Worked_per_Week.text := format( '%.2n',[ textAsCurrency( edDays_Worked_per_Week ) ] );
  ResetInfoLine2;
end;

(******************************************************************************)
(*                                                                            *)
(*  Validate Tax Year                                                         *)
(*                                                                            *)
(******************************************************************************)
//
// Modified by D. Madill
// Date: March 5, 2003
// Purpose: modified to ensure that the field level check is being performed
// on the screen value
//
//
// Modified by A. Ghuman
// Date: April 24, 2026
// Purpose: modified to use NCTAXRAT instead of NCCODTAX
//
procedure TWagelossBenefitCalcForm.edTax_YearExit(Sender: TObject);
var
  isFound, RecurrenceDateChanged: boolean;
  Work_Year, Work_Month, Work_Day, Acc_Year, Acc_Month, Acc_Day, Test_Accident_Year : Word;
  iAccident_Year, iYear, iMonth, iDay, Accident_Year, Accident_Month, Accident_Day : Word;
  yy, iii, TestTax_Year, lngIndexation_Year, lngAccidentMonth, accidentYear, nc_Index_Year : Integer;
  iTax_Year, lngAccidentYear, nc_cnt : Integer;
  ts, Work_Date, iAccident_Date, iRecurrence_Date : TDateTime;
  TestMax_Adjustments, Annual_Max, Annual_Min, nc_index_amt : Currency;
  strAnnualMax:String;
begin
  blnCheck_Year := False;

  if not setvalidate then
     setinfoline := true;

  try
     //
     // if the lblAccident_Date is visible that means we are editing an actual claim
     // so we can get the accident year from the claim accident date
     //
     if lblAccident_Date.Visible Then
        begin
        if length(pdoxtrim(edTax_Year.text)) = 0 then
           begin
           edTax_Year.Text := IntToStr(Year(CalcFullClaim.Accident_Date));
           end
        end
     else
        begin
        if length(pdoxtrim(edTax_Year.text)) = 0 then
           begin
           if Length(edAccident_Date.Text) > 0 Then
              begin
              edTax_Year.Text := IntToStr(Year(StrToDate(edAccident_Date.Text)));
              end
           else
              begin
              edTax_Year.Text := IntToStr(Year(utilmod1.getEmergeBusinessDate()));
              end;
           end;
        end;
  finally
     begin
     end;
  end; //try

  isFound := False;
  //
  // Get values from TAX CODE TABLE
  //
	TestTax_Year := TextAsInteger(edTax_Year);
  //
  //if the TaxYear is blank then throw error
  //
  if TestTax_Year <= 0 then
     begin
     globalEditError := displayError( '*Tax Year must not be blank.', edTax_Year );
     exit;
     end;

  SetTaxYear(CalcFullClaim.Accident_Date, CalcFullClaim.RecurrenceDate,
             TestTax_Year, CalcFullClaim.Indexation_Year);

  //
  // Test the on screen tax year contained in the TestTax_Year variable
  //
  // First check to see if we have a future date
  //

  Work_Date := 0;
  lngIndexation_Year := StrToInt(lblIndexation_Year.Caption);

  if (Length(edRecurrence.Text) > 0) AND (lngIndexation_Year = 0) then
     begin
     if UpperCase(edRecurrence.Text) = 'Y' then
        begin
        if Length(edRecurrenceDate.Text) > 0 then
           begin
           Work_Date := StrtoDate(edRecurrenceDate.Text);
           end;
        end;
     end;

  if not (Work_Date > 0) then
     begin
     Work_Date := StrToDate(lblAccident_Date.Caption);
     DecodeDate(Work_Date, Work_Year, Work_Month, Work_Day);

     if (lngIndexation_Year > 0) then
        begin
        Work_Month := (Work_Month + 1) Mod 13;
        if Work_Month = 0 then
           Work_Month := 1;
        Work_Year := lngIndexation_Year;
        end;

     Work_Date := Encodedate( Work_Year, Work_Month, 1 );

     if (Length(edRecurrence.Text) > 0) AND (lngIndexation_Year <> 0) Then
        begin
        if UpperCase(edRecurrence.Text) = 'Y' then
           begin
           if Length(edRecurrenceDate.Text) > 0 then
              begin
              iRecurrence_Date := StrtoDate( edRecurrenceDate.Text );

              if (Year(iRecurrence_Date) > lngIndexation_Year)  OR
                 ((Year(iRecurrence_Date) = lngIndexation_Year) AND
                 (Month(iRecurrence_Date) > Work_Month))        Then
                 begin
                 Work_Date := StrtoDate(edRecurrenceDate.Text);
                 end;
              end;
           end;
        end;
     end; //not ( Work_Date > 0 )

  DecodeDate(Work_Date, Work_Year, Work_Month, Work_Day);

  if ((Work_Year = NCMain.cnst_Max_Tax_Year) And (Work_Month > NCMain.cnst_Max_Tax_Month)) OR
      (testTax_Year > NCMain.cnst_Max_Tax_Year) Then
     begin
     globalEditError := displayError( '*Please enter a valid tax year', edTax_Year );
     exit;
     end;

  //
  // Now check to see if we have tax table entries for the tax year
  //

  for iii := low(arrayNCTAXRAT) to high(arrayNCTAXRAT) do
     begin
     if (arrayNCTAXRAT[iii].Tax_Year = TestTax_Year) and
        (arrayNCTAXRAT[iii].Tax_Year > 1991) then
        begin
        isFound := True;
        break;
        end
     end;

  //
  // check the value of the Internal Taxyear to that contained on the
  // screen. They should match. Otherwise a failure has occured within
  // the SetTaxYear routine. This was removed since a 2002 entered tax year actually
  // comes out as a 2003 tax year from the GetTaxYear routine so they wouldn't be equal
  //

  if not isFound then
     begin
     globalEditError := displayError('*Please enter a valid tax year', edTax_Year);
     exit;
     end;

  //
  // for claims side only - cross check Tax Year against Accident Year
  // Tax year must be greater than or equal to the year
  // of the accident
  //
//  if (UPPERCASE(edRecurrence.text) <> 'Y') then
  iii := testTax_Year - year(StrtoDate(lblAccident_Date.Caption));
//  else
//     iii := testTax_Year - year(textAsDate(edRecurrenceDate));

  if (iii  < 0) then
     begin
     if (UPPERCASE(edRecurrence.text) <> 'Y') then
        globalEditError := displayError('*Tax year must be on or after the incident year', edTax_Year)
     else
        globalEditError := displayError('*Tax year must be on or after year of the recurrence', edTax_Year);
     exit;
     end;

  //
  // Check to see if the tax year is equal to the indexation
  // year if the recurrence is 'N' and the claim has been indexed
  //
  if ((lngIndexation_Year  > 0)              And
      (UpperCase(edRecurrence.text) = 'N'))  Then
     begin
     if (TextAsInteger(edTax_Year) <> lngIndexation_Year) then
        begin
        globalEditError := displayError( '*Tax Year must be equal to the Indexation Year when no Recurrence specified.', edTax_Year );
        exit;
        end;
     end
  else if ((lngIndexation_Year  = 0)             And
           (UpperCase(edRecurrence.text) = 'N')  And
           (TextAsInteger(edTax_Year) <> year(StrtoDate(lblAccident_Date.Caption)))) Then
     begin
     globalEditError := displayError( '*Tax Year must be equal to the Incident Year when no Recurrence or Indexation specified.', edTax_Year );
     exit;
     end;

  if (iii = 1) and (UPPERCASE(edRecurrence.text) <> 'Y') then
     begin
     globalEditError := displayError('*Tax year cannot be the year following the incident', edTax_Year);
     exit;
     end;

  TestMax_Adjustments := TextAsCurrency(edMax_Adjustments);

  //
  // LRC Bill 18
  //
  if (edRecurrence.Text = 'Y') then
     iRecurrence_Date := StrToDate(edRecurrenceDate.Text)
  else
     iRecurrence_Date := 0;

  Annual_Max := getMaxAdjustment(CalcFullClaim.Accident_Date, iRecurrence_Date, CalcFullClaim.Indexation_Year, edRecurrence.Text, edSelf_Employed.Text);
  Annual_Min := getMinAdjustment(CalcFullClaim.Accident_Date, iRecurrence_Date, CalcFullClaim.Indexation_Year, edRecurrence.Text, edSelf_Employed.Text);
  strAnnualMax := '';

  if (edSelf_Employed.Text <> 'Y') then
     begin
     edMax_Adjustments.text := format('%.2n',[Annual_Max]);
     end
  else
     begin
     if Annual_Max > 0 then
        begin
        if (TestMax_Adjustments < Annual_Min) OR (TestMax_Adjustments > Annual_Max) then
           begin
           blnSelfEmpTestDone := false;
           strAnnualMax := '*Max Adj amount must be >= $' + format('%.2n', [Annual_Min]) + ' and <= $' + format('%.2n',[Annual_Max]);
           end;
        end
     else
        begin
        if (TestMax_Adjustments < Annual_Min) then
           begin
           blnSelfEmpTestDone := false;
           strAnnualMax := '*Max Adj amount must be >= $' + format('%.2n', [Annual_Min]);
           end;
        end;

     if Length(strAnnualMax) > 0 then
        begin
        if not setValidate then
           begin
           setEditToNormal(edMax_Adjustments);
           end;
        globalEditError := displayError(strAnnualMax, edMax_Adjustments);
        exit;
        end;

     end;

  //
  // A valid tax year has been entered and the data has changed. Allow an update
  //
  if ((CalcFullClaim.Tax_Year <> textAsInteger(edTax_Year)) And
      (lblAccident_Date.Visible))                           then
     begin
     SetUpdateInd(True);
     end;

  globalEditError := false; // we passed

  ResetInfoLine2;
end;


(******************************************************************************)
(*                                                                            *)
(*  Validate Spouse Working                                                   *)
(*                                                                            *)
(******************************************************************************)
//
// Modified April 2003
// Purpose: Modified to allow the Wageloss form to be used as both the calculator
//          and the wageloss form
//
procedure TWagelossBenefitCalcForm.edSpouse_WorkingExit(Sender: TObject);
begin
  if not SetValidate then
     SetInfoLine := True;

  edSpouse_Working.text := UpperCase( edSpouse_Working.Text );
  //
  // set the defaults if the field is blank
  //
  if (edSpouse_Working.Text = '') and
      ((upperCase(cboMaritalStatus.Text) = 'DIVORCED')  or
       (upperCase(cboMaritalStatus.Text) = 'SEPARATED') or
       (upperCase(cboMaritalStatus.Text) = 'SINGLE')    or
       (upperCase(cboMaritalStatus.Text) = 'WIDOWED'))  then
     begin
     edSpouse_Working.Text := 'N';
     end
  else
     begin
     if (edSpouse_Working.text = '')                        And
        ((upperCase(cboMaritalStatus.Text) = 'MARRIED')     or
         (upperCase(cboMaritalStatus.Text) = 'COMMON-LAW')) then
        edSpouse_Working.Text := 'Y';
     end;

  if ((upperCase(cboMaritalStatus.Text) = 'DIVORCED')  or
      (upperCase(cboMaritalStatus.Text) = 'SEPARATED') or
      (upperCase(cboMaritalStatus.Text) = 'SINGLE')    or
      (upperCase(cboMaritalStatus.Text) = 'WIDOWED'))  and
      (edSpouse_Working.text <>'N' )                   then
     begin
     edSpouse_Working.Text := 'N';
     globalEditError := displayError( '*Spouse Working changed to "N" for Marital Status Single, Divorced, Separated, or Widowed', edSpouse_Working );
     exit;
     end;

  if (CalcFullClaim.Spouse_Working <> edSpouse_Working.Text) then
     SetUpdateInd(True);

  if ((upperCase(cboMaritalStatus.Text) = 'MARRIED')         or
      (upperCase(cboMaritalStatus.Text) = 'COMMON-LAW'))     and
     (edSpouse_Working.Text = 'N') and Not edClaimSpouseForTaxPurposes.Visible and
     (not setValidate) then
     begin
     lblClaimSpouseForTaxPurposes.Visible := true;
     edClaimSpouseForTaxPurposes.Visible := true;
     edClaimSpouseForTaxPurposes.Text := '';
     edClaimSpouseForTaxPurposes.setfocus;
     exit;
     end
  else
     begin
     if (edSpouse_Working.Text = 'Y') And edClaimSpouseForTaxPurposes.Visible and
        (not setValidate) Then
        begin
        edClaimSpouseForTaxPurposes.text := '';
        lblClaimSpouseForTaxPurposes.Visible := false;
        edClaimSpouseForTaxPurposes.Visible := false;
        edNo_Of_Dependnts.SetFocus;
        exit;
        end;
     end;

  ResetInfoLine2;
end;

(******************************************************************************)
(*                                                                            *)
(*  Validate EI/UIC Exempt                                                       *)
(*                                                                            *)
(******************************************************************************)
//
// Modified April 2003
// Purpose: Modified to allow the Wageloss form to be used as both the calculator
//          and the wageloss form
//
procedure TWagelossBenefitCalcForm.edEI_ExemptExit(Sender: TObject);
begin
  if not SetValidate then
    SetInfoLine := True;

  if edEI_Exempt.Text = '' then
  begin
    if edSelf_Employed.text = 'Y' then
      edEI_Exempt.text := 'Y'
    else
      edEI_Exempt.text := 'N';
  end;

  edEI_Exempt.text := UpperCase( edEI_Exempt.text );

  if ( CalcFullClaim.EI_Exempt <> edEI_Exempt.text ) then
    SetUpdateInd(True);

  ResetInfoLine2;
end;

(******************************************************************************)
(*                                                                            *)
(*  Validate Number of Dependents                                             *)
(*                                                                            *)
(******************************************************************************)
//
// Modified April 2003
// Purpose: Modified to allow the Wageloss form to be used as both the calculator
//          and the wageloss form
//
procedure TWagelossBenefitCalcForm.edNo_Of_DependntsExit(Sender: TObject);
var
  i: integer;
begin
  if not SetValidate then
    SetInfoLine := True;

  if edNo_Of_Dependnts.Text = '' then
    edNo_Of_Dependnts.Text := '0';

  if not ValidateAsInteger( edNo_Of_Dependnts ) then
  begin
    globalEditError := displayError( '*Invalid Number Of Dependents', edNo_Of_Dependnts );
    Exit;
  end;

  i := TextAsInteger( edNo_Of_Dependnts );

  if ( i < 0 ) or ( i > 99 ) then
  begin
    globalEditError := displayError( '*Number Of Dependents must be between 0 and 99', edNo_Of_Dependnts );
    exit;
  end;

  if ( CalcFullClaim.No_Of_Dependnts <> textAsInteger( edNo_Of_Dependnts ) ) then
    SetUpdateInd(True);

  edNo_Of_Dependnts.text := format( '%d', [TextAsInteger( edNo_Of_Dependnts )] );

  ResetInfoLine2;
end;

(******************************************************************************)
(*                                                                            *)
(*  Validate Number of Infirm dependents                                      *)
(*                                                                            *)
(******************************************************************************)
//
// Modified April 2003
// Purpose: Modified to allow the Wageloss form to be used as both the calculator
//          and the wageloss form
//
procedure TWagelossBenefitCalcForm.edNo_InfirmExit(Sender: TObject);
var
  i: integer;
begin
  if not setvalidate then
    SetInfoLine := True;

  if edNo_Infirm.Text = '' then
    edNo_Infirm.Text := '0';

  if not ValidateAsInteger(edNo_Infirm) then
  begin
    globalEditError := displayError( '*Invalid Number Of Infirm Dependents', edNo_Infirm );
    Exit;
  end;

  i := TextAsInteger(edNo_Infirm);

  if ( i < 0 ) or ( i > 99 ) then
  begin
    globalEditError := displayError( '*Number Of Infirm Dependents must be between 0 and 99', edNo_Infirm );
    Exit;
  end;

  if ( CalcFullClaim.No_Infirm <> textAsInteger( edNo_Infirm ) ) then
    SetUpdateInd(True);

  edNo_Infirm.text := format( '%d', [ textAsInteger( edNo_Infirm ) ] );
  
  ResetInfoLine2;
end;

(******************************************************************************)
(*                                                                            *)
(*  Validate Collateral Benefit Tax                                           *)
(*                                                                            *)
(******************************************************************************)
//
// Modified April 2003
// Purpose: Modified to allow the Wageloss form to be used as both the calculator
//          and the wageloss form
//
procedure TWagelossBenefitCalcForm.edCollateral_Ben_TaxExit(Sender: TObject);
begin
  if not SetValidate then
    SetInfoLine := True;

  if edCollateral_Ben_Tax.Text = '' then
    edCollateral_Ben_Tax.Text := '0';

  if ( CalcFullClaim.Collateral_Ben_Tax <> textAsCurrency( edCollateral_Ben_Tax ) ) then
    SetUpdateInd(True);

  edCollateral_Ben_Tax.Text := Format( '%.2n', [TextAsCurrency( edCollateral_Ben_Tax )] );

  ResetInfoLine2;

  edDeemed_EarningsExit( edDeemed_Earnings );
end;

(******************************************************************************)
(*                                                                            *)
(*  Validate Collateral Benefit Non-Tax                                       *)
(*                                                                            *)
(******************************************************************************)
//
// Modified April 2003
// Purpose: Modified to allow the Wageloss form to be used as both the calculator
//          and the wageloss form
//
procedure TWagelossBenefitCalcForm.edCollateral_Ben_Non_TaxExit(Sender: TObject);
begin
  if not SetValidate then
    SetInfoLine := True;

  if edCollateral_Ben_Non_Tax.Text = '' then
    edCollateral_Ben_Non_Tax.Text := '0';

  if ( CalcFullClaim.Collateral_Ben_Non_Tax <> textAsCurrency( edCollateral_Ben_Non_Tax ) ) then
    SetUpdateInd(True);

  edCollateral_Ben_Non_Tax.text := format( '%.2n', [textAsCurrency( edCollateral_Ben_Non_Tax )] );

  ResetInfoLine2;

  edDeemed_EarningsExit( edDeemed_Earnings );
end;

(******************************************************************************)
(*                                                                            *)
(*  Validate Post Injury Earnings                                             *)
(*                                                                            *)
(******************************************************************************)
//
// Modified April 2003
// Purpose: Modified to allow the Wageloss form to be used as both the calculator
//          and the wageloss form
//
procedure TWagelossBenefitCalcForm.edPost_Injury_EarnExit(Sender: TObject);
begin
  if not SetValidate then
    SetInfoLine := True;

  if edPost_Injury_Earn.Text = '' then
    edPost_Injury_Earn.Text := '0';

  if ( CalcFullClaim.Post_Injury_Earn <> textAsCurrency( edPost_Injury_Earn ) ) then
    SetUpdateInd(True);

  edPost_Injury_Earn.text := Format( '%.2n', [TextAsCurrency( edPost_Injury_Earn )] );

  ResetInfoLine2;

  edDeemed_EarningsExit( edDeemed_Earnings );
end;

(******************************************************************************)
(*                                                                            *)
(*  Validate Deemed Earnings                                                  *)
(*                                                                            *)
(******************************************************************************)
procedure TWagelossBenefitCalcForm.edDeemed_EarningsExit(Sender: TObject);
begin
  if edDeemed_Earnings.text = '' then
    edDeemed_Earnings.text := 'N';

  edDeemed_Earnings.text := UpperCase( edDeemed_Earnings.text );

  //
  // check to see if the post accident earnings and collateral benefits are
  // not 0 if the deemed flag to set to 'Y'
  //
  if ( edDeemed_earnings.Text = 'Y' ) Then
    if ( ( TextAsCurrency( edPost_Injury_Earn ) = 0 ) AND
         ( TextAsCurrency( edCollateral_Ben_Tax ) = 0 ) AND
         ( TextAsCurrency( edCollateral_Ben_Non_Tax ) = 0 ) ) Then
    Begin
      globalEditError := displayError( '*Deemed Earnings must be N when no post injury earnings present.', edDeemed_Earnings );
      edDeemed_Earnings.Text := 'N';
      Exit;
    end;

  if ( dataclaim.Deemed_Earnings <> edDeemed_Earnings.text ) then
    SetUpdateInd(True);

  CalcFullClaim.Deemed_Earnings := edDeemed_Earnings.Text;

  ResetInfoLine2;
end;

(******************************************************************************)
(*                                                                            *)
(*  Validate 104 week effective date                                          *)
(*                                                                            *)
(******************************************************************************)
//
// Modified April 2003
// Purpose: Modified to allow the Wageloss form to be used as both the calculator
//          and the wageloss form
//
procedure TWagelossBenefitCalcForm.ednc_104_Wk_Effective_DateExit(Sender: TObject);
begin
  if not SetValidate then
    SetInfoLine := True;

  if not validateAsDate( ednc_104_Wk_Effective_Date ) then
  begin
    globalEditError := displayError( '*Invalid Effective date of 80% of Net', ednc_104_Wk_Effective_Date );
    exit;
  end;
  //
  // check first that date was changed...
  //
  if ( CalcFullClaim.nc_104_Wk_Clmt_Reply_Date <> textAsDate( ednc_104_Wk_Effective_Date ) ) then
  begin
    // jwd  changed to use annuity entitlement weeks
    //if CalcFullClaim.No_Weeks_of_Comp_Bnfts > 95.99 Then
    if (getAnnuityEntitlementWeeks(CalcFullClaim.accident_date, CalcFullClaim.claim_no, CalcFullClaim.No_Weeks_of_Comp_Bnfts) > 95.99) then
    begin
      CalcFullClaim.nc_104_Wk_Clmt_Reply_Date := textAsDate( ednc_104_Wk_Effective_Date ) + 91;
      //
      // reminder - update is done using CalcPartClaim record
      //
      CalcPartClaim.nc_104_Wk_Clmt_Reply_Date := CalcFullClaim.nc_104_Wk_Clmt_Reply_Date;
      SetUpdateInd(True);
    end
    else
    begin
      WagelossMainForm.ShowInfoLine2( '*Cannot update 80% Effective date - weeks paid less than 96.' );
      //
      // else restore nc_104_Wk_Effective_Date to original date valuie
      //
      if CalcFullClaim.nc_104_Wk_Effective_Date > 0 Then
        ednc_104_Wk_Effective_Date.text := FormatDateTime( 'c', CalcFullClaim.nc_104_Wk_Effective_Date )
      else
        ednc_104_Wk_Effective_Date.Text := '';
      if ednc_104_Wk_Effective_Date.Enabled then
        ednc_104_Wk_Effective_Date.SetFocus;
      globalEditError := True;
      exit;
    end;
  end;

  if ( ( dataclaim.nc_104_Wk_Effective_Date <> textAsDate( ednc_104_Wk_Effective_Date ) ) AND
       ( lblAccident_Date.Visible ) ) then
    SetUpdateInd(True);

  // ensure Effective date is > 2 years after accident date
  if ( textAsDate( ednc_104_Wk_Effective_Date ) ) > 0 then
    if ( textAsDate( ednc_104_Wk_Effective_Date ) < ( CalcFullClaim.Accident_Date + 727 ) ) then
    begin
      globalEditError := displayError( '*80% Effective date must be > 2 years past date of incident', ednc_104_Wk_Effective_Date );
      Exit;
    end;

  if ( textAsDate( ednc_104_Wk_Effective_Date ) ) > 0 then
    ednc_104_Wk_Effective_Date.text := FormatDateTime( 'c', TextAsDate( ednc_104_Wk_Effective_Date ) )
  else
    ednc_104_Wk_Effective_Date.text := '';

  ResetInfoLine2;
end;

(******************************************************************************)
(*                                                                            *)
(*  Validate 104 week Claimant % contribution                                 *)
(*                                                                            *)
(******************************************************************************)
//
// Modified April 2003
// Purpose: Modified to allow the Wageloss form to be used as both the calculator
//          and the wageloss form
//
procedure TWagelossBenefitCalcForm.ednc_104_Wk_Clmt_p_ContribExit(Sender: TObject);
var
  f, g:currency;
  Accident_Date:TDateTime;
begin
	if not SetValidate then
    SetInfoLine := True;

  if ednc_104_Wk_Clmt_p_Contrib.text = '' then
    ednc_104_Wk_Clmt_p_Contrib.text := '0';

  if not ValidateAsCurrency( ednc_104_Wk_Clmt_p_Contrib ) then
  begin
    globalEditError := displayError( '*Invalid Worker % Annuity Contribution', ednc_104_Wk_Clmt_p_Contrib );
    Exit;
  end;

  if ( ( dataclaim.nc_104_Wk_Clmt_p_Contrib <> textAsCurrency( ednc_104_Wk_Clmt_p_Contrib ) ) AND
       ( lblAccident_Date.Visible ) ) then
    allowUpdateClaim:=true;

  f := TextAsCurrency( ednc_104_Wk_Clmt_p_Contrib );
  g := TextAsCurrency( ed_WCB_Annuity_Contr );

  if lblAccident_Date.Visible Then
    Accident_Date := CalcFullClaim.Accident_Date
  else
    Accident_Date := StrtoDate( edAccident_Date.Text );

  if year( Accident_Date ) >= 2006 then
  begin
    //2 checks
    //1) Claimant contr must be between 0 an 7
    //2) Claimant contr cannot exceed WCB contr

    if ( f < 0.0 ) or ( f > 7.0 ) then
    begin
      globalEditError := displayError( '*Worker % Annuity Contribution must be between 0 and 7.0', ednc_104_Wk_Clmt_p_Contrib );
      Exit;
    end;

    if ( f > g ) then
    begin
      globalEditError := displayError( '*Worker Contribution cannot exceed WCB Contribution', ednc_104_Wk_Clmt_p_Contrib );
      Exit;
    end;

    // if nc_104_Wk_Clmt_p_Contrib was changed
    if ( textAsCurrency( ednc_104_Wk_Clmt_p_Contrib ) <> CalcFullClaim.nc_104_Wk_Clmt_p_Contrib ) then
    begin
      CalcFullClaim.nc_104_Wk_Clmt_p_Eff_Date := utilmod1.getEmergeBusinessDate();
      //
      // update fields so nccanty works
      //
      CalcFullClaim.nc_104_Wk_Clmt_p_Contrib :=  textAsCurrency( ednc_104_Wk_Clmt_p_Contrib );
      CalcFullClaim.nc_104_Wk_WCB_p_Contrib_Red :=  textAsCurrency( ednc_104_Wk_WCB_p_Contrib_Red );
      CalcFullClaim.nc_104_Wk_WCB_p_Contrib := textAsCurrency( ed_WCB_Annuity_Contr );
      //
      // reminder - update is done using CalcPartClaim record
      //
      CalcPartClaim.nc_104_Wk_Clmt_p_Eff_Date := CalcFullClaim.nc_104_Wk_Clmt_p_Eff_Date;
      CalcPartClaim.nc_104_Wk_Clmt_p_Contrib :=  CalcFullClaim.nc_104_Wk_Clmt_p_Contrib;
      CalcPartClaim.nc_104_Wk_WCB_p_Contrib_Red := CalcFullClaim.nc_104_Wk_WCB_p_Contrib_Red;
      CalcPartClaim.nc_104_Wk_WCB_p_Contrib := CalcFullClaim.nc_104_Wk_WCB_p_Contrib;
      Calc_Annuity( CalcPartClaim );
      Calc_Annuity( CalcFullClaim );
      SetUpdateInd(True);
    end
    else
    begin
      // else restore to original values
      if lblAccident_Date.Visible Then
      begin
        CalcFullClaim.nc_104_Wk_Clmt_p_Eff_Date := dataClaim.nc_104_Wk_Clmt_p_Eff_Date;
        CalcFullClaim.nc_104_Wk_Clmt_p_Contrib :=  dataClaim.nc_104_Wk_Clmt_p_Contrib;
        CalcFullClaim.nc_104_Wk_WCB_p_Contrib_Red := dataClaim.nc_104_Wk_WCB_p_Contrib_Red;
        CalcFullClaim.nc_104_Wk_WCB_p_Contrib := dataClaim.nc_104_Wk_WCB_p_Contrib;
        CalcPartClaim.nc_104_Wk_Clmt_p_Eff_Date := CalcFullClaim.nc_104_Wk_Clmt_p_Eff_Date;
        CalcPartClaim.nc_104_Wk_Clmt_p_Contrib :=  dataClaim.nc_104_Wk_Clmt_p_Contrib;
        CalcPartClaim.nc_104_Wk_WCB_p_Contrib_Red := dataClaim.nc_104_Wk_WCB_p_Contrib_Red;
        CalcPartClaim.nc_104_Wk_WCB_p_Contrib := dataClaim.nc_104_Wk_WCB_p_Contrib;
        Calc_Annuity( CalcPartClaim );
        Calc_Annuity( CalcFullClaim );
      end;
    end;
  end
  else
  begin
    // check range 0 to 5%
    if ( f < 0.0 ) or ( f > 5.0 ) then
    begin
      globalEditError := displayError( '*Worker % Annuity Contribution must be between 0 and 5.0', ednc_104_Wk_Clmt_p_Contrib );
      Exit;
    end;

    // Check sum of claimant and WCB reduction  can not exceed 5%
    if not ValidateAsCurrency( ednc_104_Wk_Clmt_p_Contrib ) then
    begin
      globalEditError := displayError( '*Invalid Worker % Annuity Contribution', ednc_104_Wk_Clmt_p_Contrib );
      Exit;
    end;

    if not ValidateAsCurrency( ednc_104_Wk_WCB_p_Contrib_Red ) then
    begin
      globalEditError := displayError( '*Invalid WCB % Annuity Reduction', ednc_104_Wk_WCB_p_Contrib_Red );
      Exit;
    end;

    if ( textAsCurrency( ednc_104_Wk_Clmt_p_Contrib ) +
         textAsCurrency( ednc_104_Wk_WCB_p_Contrib_Red ) > 5 ) then
    begin
      globalEditError := displayError( '*Total contribution cannot exceed 5 %', ednc_104_Wk_Clmt_p_Contrib );
      Exit;
    end;

    // if nc_104_Wk_Clmt_p_Contrib was changed
    if ( textAsCurrency( ednc_104_Wk_Clmt_p_Contrib ) <> CalcFullClaim.nc_104_Wk_Clmt_p_Contrib ) then
    begin
      CalcFullClaim.nc_104_Wk_Clmt_p_Eff_Date := utilmod1.getEmergeBusinessDate();
      //
      // update fields so nccanty works
      //
      CalcFullClaim.nc_104_Wk_Clmt_p_Contrib :=  textAsCurrency( ednc_104_Wk_Clmt_p_Contrib );
      CalcFullClaim.nc_104_Wk_WCB_p_Contrib_Red :=  textAsCurrency( ednc_104_Wk_WCB_p_Contrib_Red );
      //
      // reminder - update is done using CalcPartClaim record
      //
      CalcPartClaim.nc_104_Wk_Clmt_p_Eff_Date := CalcFullClaim.nc_104_Wk_Clmt_p_Eff_Date;
      CalcPartClaim.nc_104_Wk_Clmt_p_Contrib :=  CalcFullClaim.nc_104_Wk_Clmt_p_Contrib;
      CalcPartClaim.nc_104_Wk_WCB_p_Contrib_Red := CalcFullClaim.nc_104_Wk_WCB_p_Contrib_Red;
      Calc_Annuity( CalcPartClaim );
      Calc_Annuity( CalcFullClaim );
      SetUpdateInd(True);
    end
    else
    begin
      // else restore to original values
      if lblAccident_Date.Visible Then
      Begin
        CalcFullClaim.nc_104_Wk_Clmt_p_Eff_Date := dataClaim.nc_104_Wk_Clmt_p_Eff_Date;
        CalcFullClaim.nc_104_Wk_Clmt_p_Contrib :=  dataClaim.nc_104_Wk_Clmt_p_Contrib;
        CalcFullClaim.nc_104_Wk_WCB_p_Contrib_Red := dataClaim.nc_104_Wk_WCB_p_Contrib_Red;
        CalcPartClaim.nc_104_Wk_Clmt_p_Eff_Date := CalcFullClaim.nc_104_Wk_Clmt_p_Eff_Date;
        CalcPartClaim.nc_104_Wk_Clmt_p_Contrib :=  dataClaim.nc_104_Wk_Clmt_p_Contrib;
        CalcPartClaim.nc_104_Wk_WCB_p_Contrib_Red := dataClaim.nc_104_Wk_WCB_p_Contrib_Red;
        Calc_Annuity( CalcPartClaim );
        Calc_Annuity( CalcFullClaim );
      end;
    end;
  end;

  ednc_104_Wk_Clmt_p_Contrib.Text := Format( '%.2n',[TextAsCurrency( ednc_104_Wk_Clmt_p_Contrib )] );
  ResetInfoLine2;
end;

(******************************************************************************)
(*                                                                            *)
(*  Validate 104 week WCB % Contribution Reduction                            *)
(*                                                                            *)
(******************************************************************************)
//
// Modified April 2003
// Purpose: Modified to allow the Wageloss form to be used as both the calculator
//          and the wageloss form
//
procedure TWagelossBenefitCalcForm.ednc_104_Wk_WCB_p_Contrib_RedExit(Sender: TObject);
var
  f, g : currency;
  Accident_Date : TDateTime;
begin
  if not SetValidate then
    SetInfoLine := true;

  if ednc_104_Wk_WCB_p_Contrib_Red.text = '' then
    ednc_104_Wk_WCB_p_Contrib_Red.text := '0';

  if lblAccident_Date.Visible Then
    Accident_Date := CalcFullClaim.Accident_Date
  else
    Accident_Date := StrtoDate( edAccident_Date.Text );

  if ( year( Accident_Date ) >= 2006 ) then
  begin
    if not ValidateAsCurrency( ednc_104_Wk_WCB_p_Contrib_Red ) then
    begin
      globalEditError := displayError( '*Invalid Employer % Annuity Contribution', ednc_104_Wk_WCB_p_Contrib_Red );
      Exit;
    end;

    //3 checks
    //1) Employer contr must be between 0 an 7
    //2) WCB contr + Emp contr cannot exceed 7
    f := TextAsCurrency( ednc_104_Wk_WCB_p_Contrib_Red );
    g := TextAsCurrency( ed_WCB_Annuity_Contr );

    if ( f < 0.0 ) or ( f > 7.0 ) then
    begin
      globalEditError := displayError( '*Employer % Annuity Contribution must be between 0 and 7.0', ednc_104_Wk_WCB_p_Contrib_Red );
      Exit;
    end;

    if ( f + g ) > 7 then
    begin
      globalEditError := displayError( '*Total WCB Contribution and Employer Contribution cannot exceed 7 %', ednc_104_Wk_WCB_p_Contrib_Red );
      Exit;
    end;

    //
    // if nc_104_Wk_WCB_p_Contrib_Red was changed
    //
    if ( textAsCurrency( ednc_104_Wk_WCB_p_Contrib_Red ) <> CalcFullClaim.nc_104_Wk_WCB_p_Contrib_Red ) then
    begin
      CalcFullClaim.nc_104_Wk_Clmt_p_Eff_Date := utilmod1.getEmergeBusinessDate();
      // update fields so nccanty works
      CalcFullClaim.nc_104_Wk_Clmt_p_Contrib :=  textAsCurrency( ednc_104_Wk_Clmt_p_Contrib );
      CalcFullClaim.nc_104_Wk_WCB_p_Contrib_Red :=  textAsCurrency( ednc_104_Wk_WCB_p_Contrib_Red );
      CalcFullClaim.nc_104_Wk_WCB_p_Contrib := textAsCurrency( ed_WCB_Annuity_Contr );
      // reminder - update is done using CalcPartClaim record
      CalcPartClaim.nc_104_Wk_Clmt_p_Eff_Date := CalcFullClaim.nc_104_Wk_Clmt_p_Eff_Date;
      CalcPartClaim.nc_104_Wk_Clmt_p_Contrib :=  CalcFullClaim.nc_104_Wk_Clmt_p_Contrib;
      CalcPartClaim.nc_104_Wk_WCB_p_Contrib_Red := CalcFullClaim.nc_104_Wk_WCB_p_Contrib_Red;
      CalcPartClaim.nc_104_Wk_WCB_p_Contrib := CalcFullClaim.nc_104_Wk_WCB_p_Contrib;
      Calc_Annuity( CalcPartClaim );
      Calc_Annuity( CalcFullClaim );
      SetUpdateInd(True);
    end
    else
    begin
      if lblAccident_Date.Visible Then
      Begin
        // else restore to original values
        CalcFullClaim.nc_104_Wk_Clmt_p_Eff_Date := dataClaim.nc_104_Wk_Clmt_p_Eff_Date;
        CalcFullClaim.nc_104_Wk_Clmt_p_Contrib :=  dataClaim.nc_104_Wk_Clmt_p_Contrib;
        CalcFullClaim.nc_104_Wk_WCB_p_Contrib_Red := dataClaim.nc_104_Wk_WCB_p_Contrib_Red;
        CalcFullClaim.nc_104_Wk_WCB_p_Contrib := dataClaim.nc_104_Wk_WCB_p_Contrib;
        CalcPartClaim.nc_104_Wk_Clmt_p_Eff_Date := CalcFullClaim.nc_104_Wk_Clmt_p_Eff_Date;
        CalcPartClaim.nc_104_Wk_Clmt_p_Contrib :=  dataClaim.nc_104_Wk_Clmt_p_Contrib;
        CalcPartClaim.nc_104_Wk_WCB_p_Contrib_Red := dataClaim.nc_104_Wk_WCB_p_Contrib_Red;
        CalcPartClaim.nc_104_Wk_WCB_p_Contrib := dataClaim.nc_104_Wk_WCB_p_Contrib;
        Calc_Annuity( CalcPartClaim );
        Calc_Annuity( CalcFullClaim );
      end;
    end;
  end
  else
  begin
    if not ValidateAsCurrency( ednc_104_Wk_WCB_p_Contrib_Red ) then
    begin
      globalEditError := displayError( '*Invalid WCB % Annuity Reduction', ednc_104_Wk_WCB_p_Contrib_Red );
      Exit;
    end;
    //
    // check range 0 to 5%
    //
    f := TextAsCurrency( ednc_104_Wk_WCB_p_Contrib_Red );

    if ( f < 0.0 ) or ( f > 5.0 ) then
    begin
      globalEditError := displayError( '*WCB % Annuity Reduction must be between 0 and 5.0', ednc_104_Wk_WCB_p_Contrib_Red );
      Exit;
    end;
    //
    // Check sum of claimant and WCB reduction  can not exceed 5%
    //
    if Not ValidateAsCurrency( ednc_104_Wk_Clmt_p_Contrib ) then
    begin
      globalEditError := displayError( '*Invalid Worker % Annuity Contribution', ednc_104_Wk_Clmt_p_Contrib );
      Exit;
    end;

    if not ValidateAsCurrency( ednc_104_Wk_WCB_p_Contrib_Red ) then
    begin
      globalEditError := displayError( '*Invalid WCB % Annuity Reduction', ednc_104_Wk_WCB_p_Contrib_Red );
      Exit;
    end;

    if ( textAsCurrency( ednc_104_Wk_Clmt_p_Contrib ) +
         textAsCurrency( ednc_104_Wk_WCB_p_Contrib_Red ) > 5 ) then
    begin
      globalEditError := displayError( '*Total contribution cannot exceed 5 %', ednc_104_Wk_WCB_p_Contrib_Red );
      Exit;
    end;

    //
    // if nc_104_Wk_WCB_p_Contrib_Red was changed
    //
    if ( textAsCurrency( ednc_104_Wk_WCB_p_Contrib_Red ) <> CalcFullClaim.nc_104_Wk_WCB_p_Contrib_Red ) then
    begin
      CalcFullClaim.nc_104_Wk_Clmt_p_Eff_Date := utilmod1.getEmergeBusinessDate();
      // update fields so nccanty works
      CalcFullClaim.nc_104_Wk_Clmt_p_Contrib :=  textAsCurrency( ednc_104_Wk_Clmt_p_Contrib );
      CalcFullClaim.nc_104_Wk_WCB_p_Contrib_Red :=  textAsCurrency( ednc_104_Wk_WCB_p_Contrib_Red );
      // reminder - update is done using CalcPartClaim record
      CalcPartClaim.nc_104_Wk_Clmt_p_Eff_Date := CalcFullClaim.nc_104_Wk_Clmt_p_Eff_Date;
      CalcPartClaim.nc_104_Wk_Clmt_p_Contrib :=  CalcFullClaim.nc_104_Wk_Clmt_p_Contrib;
      CalcPartClaim.nc_104_Wk_WCB_p_Contrib_Red := CalcFullClaim.nc_104_Wk_WCB_p_Contrib_Red;
      Calc_Annuity( CalcPartClaim );
      Calc_Annuity( CalcFullClaim );
      SetUpdateInd(True);
    end
    else
    begin
      if lblAccident_Date.Visible Then
      Begin
        // else restore to original values
        CalcFullClaim.nc_104_Wk_Clmt_p_Eff_Date := dataClaim.nc_104_Wk_Clmt_p_Eff_Date;
        CalcFullClaim.nc_104_Wk_Clmt_p_Contrib :=  dataClaim.nc_104_Wk_Clmt_p_Contrib;
        CalcFullClaim.nc_104_Wk_WCB_p_Contrib_Red := dataClaim.nc_104_Wk_WCB_p_Contrib_Red;
        CalcPartClaim.nc_104_Wk_Clmt_p_Eff_Date := CalcFullClaim.nc_104_Wk_Clmt_p_Eff_Date;
        CalcPartClaim.nc_104_Wk_Clmt_p_Contrib :=  dataClaim.nc_104_Wk_Clmt_p_Contrib;
        CalcPartClaim.nc_104_Wk_WCB_p_Contrib_Red := dataClaim.nc_104_Wk_WCB_p_Contrib_Red;
        Calc_Annuity( CalcPartClaim );
        Calc_Annuity( CalcFullClaim );
      end;
    end;
  end;

  ednc_104_Wk_WCB_p_Contrib_Red.text := Format( '%.2n',[textAsCurrency( ednc_104_Wk_WCB_p_Contrib_Red )] );

  ResetInfoLine2;
end;

Function TWagelossBenefitCalcForm.Calc_New_Max(Indexation_Year:Integer;
                      Self_Employed:Boolean;
                      Recurrence:Boolean;
                      Recurrence_Date:TDateTime;
                      Accident_Date:TDateTime;
                      NewIndexation_Year:Integer;
                      Max_Adjustment:Currency
                      ):Currency;
Var
   Annual_Max, Annual_Min:Currency;
   iRecurrence_Date, eAccident_Date: TDateTime;
   sSelf_Employed, sRecurrence:String;
   NewTaxYear, eAccident_Year, eAccident_Month, eTax_Year, BaseIndexationYear:integer;
Begin
  if (Recurrence) then
     iRecurrence_Date := StrToDate(edRecurrenceDate.Text)
  else
     iRecurrence_Date := 0;

  if Recurrence then
     sRecurrence := 'Y'
  else
     sRecurrence := 'N';

  if Self_Employed then
     sSelf_Employed := 'Y'
  else
     sSelf_Employed := 'N';


  if (Self_Employed) and
     (Max_Adjustment > 0) then
     begin
     //
     // Must manually index because there is no table entry for this
     //
     getEffectiveAccidentDate(Accident_Date, Recurrence_Date, NewIndexation_Year, sRecurrence,
                              eAccident_Date, eAccident_Year, eAccident_Month, eTax_Year);
     BaseIndexationYear := Max(Indexation_Year, eAccident_Year);
     Annual_Max := getNewIndexedAmount(eAccident_Date, BaseIndexationYear, NewIndexation_Year, Max_Adjustment);
     end
  else
     begin
     Annual_Max := getMaxAdjustment(Accident_Date, iRecurrence_Date, NewIndexation_Year, sRecurrence, sSelf_Employed);
     end;

  Result := Annual_Max;
End;

procedure TWagelossBenefitCalcForm.WagelossIndexation;
var
   nc_accident_year, nc_curr_year, nc_Min_Index, nc_Max_Index : Integer;
   nc_claim_elig_index, oneMonthEarly: Boolean;
   MSG : Tmessage;
   WorkDate, recurDate, effectDate : TDateTime;
   Work_Year, Work_Month, Work_Day : Word;
   fltNew_Max, fltMax_Adjustment : Currency;

   Acc_Year, Acc_Month, Acc_Day, Idx_Month:Word;
   K : Word;
   btnSelected : Integer;
begin
  nc_Max_Index := 0;
  nc_Min_Index := 0;
  oneMonthEarly := False;

  //*** Check
  if (Not dataClaim.isClaimCurrent) and (not WagelossMainForm.isTestCalculator) then
     begin
     exit;
     end;

  ResetInfoLine2;

  with CalcFullClaim do
     begin
     // Check for a blank accident date, indexation requires a valid accident
     // date to determine the earliest possible date that they can index on.
     if Accident_Date < 1 then
        begin
        WagelossMainForm.ShowInfoLine2( '*Blank Incident Date Encountered - Indexation Cancelled.' );
        globalEditError:=true;
        exit;
        end;

     //
     // We now use the year of the accident date to determine if we can index a claim.
     // This replaces the logic above which looks at the claim number to see if the
     // claim is 91 or less and not > 20 (or 2020)
     //
     if year(Accident_Date) < 1992 then
        begin
        WagelossMainForm.ShowInfoLine2('Injury date not eligible for indexing.');
        globalEditError := true;
        exit;
        end;

     if Month( Accident_Date ) < 12 then
        nc_accident_year := year(Accident_Date)
     else
        nc_accident_year := year(Accident_Date) + 1;

     if Month( Accident_Date ) < 12 then
        nc_curr_year := Year(utilmod1.getEmergeBusinessDate())
     else
        nc_curr_year := Year(utilmod1.getEmergeBusinessDate()) + 1;

     nc_claim_elig_index := (nc_curr_year >= ( nc_accident_year + 2 ));
     //
     // 1. Determine the earliest day that this claim can be indexed.
     // 2. Determine if we have passed that date
     //
     WorkDate := Accident_Date;
     WorkDate := EncodeDate(Year( WorkDate ), Month( WorkDate ), 1);
     WorkDate := utilmod1.AddMonths(WorkDate, 25);
     DecodeDate(WorkDate, Work_Year, Work_Month, Work_Day);

     //
     // Check to see if we have a valid tax table enty for the possible
     // indexation date. If we have no valid tax table entry then cancel the indexation
     // process.
     //
     if ((Work_Year >= NCMain.cnst_Max_Tax_Year)   and
         (Work_Month > NCMain.cnst_Max_Tax_Month)) then
        begin
        // We don't have a valid index tax entry
        nc_claim_elig_index := False;
        globalEditError := True;
        end
     else
        begin
        //
        // Make sure we have 2 years plus 1 month from the
        // accident date. We will allow the claim to be indexed
        // if it is within one month of the indexation limit. This will
        // allow claims to be indexed if the pay does not fall on the
        // indexation date. Note that this will only be triggered if the claim has
        // not passed an indexation date and the date is prior to the one month window
        //

        if ((IncMonth(WorkDate, - 1) > utilmod1.getEmergeBusinessDate())) then
           begin
           oneMonthEarly := True;
           globalEditError := True;
           end
        else
           begin
           //
           // determine the min and max indexation years that are possible
           // for this claim
           //

           //
           // Set the min indexation year. This is the first year that we are
           // eligible for indexing. Note that we can back off indexing so we must
           // set the min indexation year to be the first eligible year.
           nc_Min_Index := Work_Year;
           //
           // Set the max indexation year. Note that we have backed off 1 month
           // since we need to allow the pay specialist to index just before the
           // indexation date. The max is the max year we can index at this point.
           // We need to check to see if we are within 14 days of the indexation date.
           // If we are outside the 14 days we will set the indexation year back 1 year.
           //

           if (Work_Month = 1) AND (Month(utilmod1.getEmergeBusinessDate()) = 12) Then
              Work_Year := Max(Year(utilmod1.getEmergeBusinessDate()) + 1, nc_Min_Index)
           else
              Work_Year := Max(Year(utilmod1.getEmergeBusinessDate()), nc_Min_Index);

           WorkDate := EncodeDate(Work_Year, Work_Month, Work_Day);

           if ((IncMonth(WorkDate, - 1) > utilmod1.getEmergeBusinessDate())) then
              begin
              DecodeDate( WorkDate, Work_Year, Work_Month, Work_Day );
              Work_Year := Work_Year - 1;
              WorkDate := EncodeDate( Work_Year, Work_Month, Work_Day );
              end;

           DecodeDate( WorkDate, Work_Year, Work_Month, Work_Day );

           nc_Max_Index := Work_Year;
           end;
        end;

     if not nc_claim_elig_index then
        begin
        MessageDlg('       Indexation Cancelled.' + #10#10 +
                   'Claim is not eligible for indexing.', mtError, [mbOK], 0);
        globalEditError := True;
        exit;
        end;

     if oneMonthEarly then
        begin
        MessageDlg('                   Indexation Cancelled.' + #10#10 +
                   'Claim is not within one month of the valid indexation date.', mtError, [mbOK], 0);
        globalEditError := True;
        exit;
        end;

     try
        WagelossIndexationForm := TWagelossIndexationForm.create( Application );

        WagelossIndexationForm.CurrentIndexation_Year := Indexation_Year;
        WagelossIndexationForm.CurrentWeekly_Salary := Wkly_Sal_A;
        WagelossIndexationForm.MinIndexation_Year := nc_Min_Index;
        WagelossIndexationForm.MaxIndexation_Year := nc_Max_Index;
        WagelossIndexationForm.Indexation_Month := Work_Month;
        WagelossIndexationForm.Youthful_Worker := Youthful_Worker;
        WagelossIndexationForm.Apprentice := Apprentice;
        WagelossIndexationForm.NewIndexation_Year := nc_Max_Index;

        if WagelossIndexationForm.ShowModal = mrOK then
           begin
           if (WagelossIndexationForm.NewWeekly_Salary > 0) Then
              begin
              with CalcFullClaim do
                 begin
                 //
                 // Determine the new max to use. This will depend on whether the
                 // worker is self employed or not.
                 //
                 fltMax_Adjustment := TextAsCurrency(edMax_Adjustments);
                 fltNew_Max := Calc_New_Max(Indexation_Year,
                                            Self_Employed = 'Y',
                                            Recurrence = 'Y',
                                            RecurrenceDate,
                                            Accident_Date,
                                            WageLossIndexationForm.NewIndexation_Year,
                                            fltMax_Adjustment
                                           );

                 Max_Adjustment := fltNew_Max;
                 //*** Check
                 //if ( WagelossIndexationForm.NewWeekly_Salary >= WagelossIndexationForm.CurrentWeekly_Salary ) then
                 if (WagelossIndexationForm.NewWeekly_Salary >= WagelossIndexationForm.CurrentWeekly_Salary) and
                    (not WagelossMainForm.isTestCalculator)                                                  then
                    begin
                    Save_Weekly_Sal_History(CalcFullClaim.Claim_No,
                                            WagelossIndexationForm.NewIndexation_Year,
                                            WagelossIndexationForm.NewWeekly_Salary,
                                            WagelossIndexationForm.CurrentWeekly_Salary);
                    end;

                 Wkly_Sal_A := WagelossIndexationForm.NewWeekly_Salary;
                 Indexation_Year := WagelossIndexationForm.NewIndexation_Year;

                 if (Indexation_Year <> 0) then
                    cboAverageEarningsBasedOn.KeyValue := 'Indexing'
                 else
                    cboAverageEarningsBasedOn.KeyValue := '';

                 // save the indexation amount in the history table
                 Indexation_Calc_Date := utilmod1.getEmergeBusinessDate();

                 Tax_Year := Max(Max(Year(Accident_Date), Year(RecurrenceDate)), WagelossIndexationForm.NewIndexation_Year);

                 edWkly_Sal_A.text := format( '%.2n', [ Wkly_Sal_A ] );
                 lblIndexation_Year.caption := format( '%d', [ Indexation_Year ] );

                 DecodeDate(CalcFullClaim.Accident_Date, Acc_Year, Acc_Month, Acc_Day);
                 if ((CalcFullClaim.Indexation_Year > 0) AND (CalcFullClaim.Tax_Year <> Acc_Year)) Then
                    Idx_Month := Max(((Acc_Month+1) Mod 13),1)
                 else
                    Idx_Month := Acc_Month;
                 WorkDate := EncodeDate(Min(Max(CalcFullClaim.Indexation_Year,Acc_Year), CalcFullClaim.Tax_Year), Idx_Month, 1);

                 Indexation_Calc_Date := WorkDate;

                 if (edEffectiveDate.Text <> '') then
                    effectDate := StrToDate( edEffectiveDate.Text )
                 else
                    effectDate := 0;

                 if (edRecurrenceDate.Text <> '') then
                    recurDate := StrToDate(edRecurrenceDate.Text)
                 else
                   recurDate := 0;

                 if Indexation_Calc_Date < effectDate then
                    effectDate := Indexation_Calc_Date;

                 try
                    if (CalcFullClaim.Indexation_Year > 0) then
                       begin
                       edEffectiveDate.Text := FormatDateTime( 'dd/mm/yyyy', Max( Indexation_Calc_Date, Max( effectDate, recurDate ) ) );
                       end
                    else
                       begin
                       edEffectiveDate.Text := '';
                       end;
                 except
                    on e:Exception do
                       begin  //ignore error
                       end;
                 end;

                 edTax_Year.text := format( '%d', [Tax_Year] );

                 if (((Year(CalcFullClaim.Accident_Date) < 2006) OR (Year(CalcFullClaim.Accident_Date) > 2021)) or
                     (edSelf_Employed.Text = 'Y')) Then
                    begin
                    edMax_Adjustments.Text := format('%.2n', [ Max_Adjustment ] );
                    end;

                 SetUpdateInd(True);

                 ResetInfoLine2;

                 uGlobal.RecalcBen(CalcFullClaim, CalcPartClaim, DeathBenefitCalc);
                 //
                 // ask about indexation report
                 //
                 with MSG do
                    begin
                    Msg:=0;
                    WParam:=0;
                    LParam:=0;
                    end;
                 //*** Check
                 //***  PrintINDEXATION(MSG);
                 if (not WagelossMainForm.isTestCalculator) then
                    PrintINDEXATION(MSG);

                 //***
                 if WagelossMainForm.isTestCalculator and (WagelossIndexationForm.NewIndexation_Year > 0) then
                    begin
                    PressFunctionKey(9);

                    if allowQASave then
                       begin
                       btnSelected := MyMessageDialog('Do you want to Save current results and Continue to Next Indexation ?'+
                                                      ' Else Save and Stop Indexation ?',
                                                      mtConfirmation, mbYesNoCancel,
                                                      ['Continue', 'Stop', 'Cancel']);
                       //
                       // I think this code is bad as the else if will never work...
                       //
                       if btnSelected = mrYes then
                          if SaveQAData then
                             begin
                             resetControlsAfterIndexation;
                             allowQASave := False;
                             WagelossIndexationForm.free;
                             ResetInfoLine2;
                             btnIndexationClick(btnIndexation);
                             end
                          else if btnSelected = mrNo then
                             if SaveQAData then
                                begin
                                //resetControlsAfterIndexation;
                                resetControlsAfterQASave;
                                allowQASave := False;
                                ResetInfoLine2;
                                FnextQATestID := 0;
                                end
                             else if btnSelected = mrCancel then
                                begin
                                resetControlsAfterIndexation;
                                allowQASave := False;
                                ResetInfoLine2;
                                FnextQATestID := 0;
                                end;
                       end;
                    end
                 else
                    begin
                    ResetInfoLine2;
                    isIndexation := False;
                    FnextQATestID := 0;
                    end;
                 //***
                 end;
              end;
           end;
     finally
        WagelossIndexationForm.free;
        ResetInfoLine2;
        FnextQATestID := 0;
     end;
     end;
end;

(******************************************************************************)
(*                                                                            *)
(*  Display Payment Form                                                      *)
(*                                                                            *)
(******************************************************************************)
procedure TWagelossBenefitCalcForm.WagelossPayment( paymentType: iPaymentType );
var
  rc: integer;
  WLTop, WLLeft:Integer;
begin
  Calc_Annuity( dataclaim );
  if dataClaim.isClaimCurrent = false then exit;
  ResetInfoLine2;

  (****************************************************************************)
  (* Check for valid birthdate.                                               *)
  (****************************************************************************)
  if ( dataClaim.Birth_Date < 1 ) then
  begin
    try
      rc := 1;
      GetChoiceForm := TGetChoiceForm.create( application );
      GetChoiceForm.Caption := 'Proceed with payment selection';
      GetChoiceForm.Message := 'Claimants Birth Date is blank';
      GetChoiceForm.AddChoice( 'Y - Proceed with payment' );
      GetChoiceForm.AddChoice( 'N - Do NOT proceed with payment' );
      GetChoiceForm.showmodal;
      rc := GetChoiceForm.Selected;
    finally
      GetChoiceForm.free;
    end;
    if ( rc <> 0 ) then
    begin
      WagelossMainForm.ShowInfoLine2( '*Payment process cancelled by user.' );
      exit;
    end;
  end;

  (****************************************************************************)
  (* Check if Benefit Level needs to be reviewed. This calls the Review       *)
  (* Benefit Level Form and may force change to dataClaim and a corresponding *)
  (* forceSetClaimInformation to keep data in sync.                           *)
  (****************************************************************************)
  //if ( dataClaim.nc_104_Wk_Effective_Date < 1 )and
  //   ( dataClaim.No_Weeks_of_Comp_Bnfts > 95.99 ) and
  //   ( dataClaim.No_Weeks_of_Comp_Bnfts <= 104 ) then
  if (doReviewClaim104( dataClaim.accident_date, dataClaim.nc_104_Wk_Effective_Date, dataClaim.Claim_No, dataClaim.No_Weeks_of_Comp_Bnfts)) then
  begin
    ResetInfoLine2;
    try
      ReviewBenefitLevelForm:=TReviewBenefitLevelForm.create( application );
      ReviewBenefitLevelForm.showmodal;
      fillInForm;
    finally
      ReviewBenefitLevelForm.free;
    end;
  end;

  //; if calculation date is blank ;calculation has not been done
  if ( dataClaim.Calc_Date = 0 ) then
  begin
    WagelossMainForm.ShowInfoLine2( '*No Benefit Calculation for this claim.' );
    messagebeep(0);
    exit;
  end;

  (****************************************************************************)
  (* Finally create the payment form...                                       *)
  (****************************************************************************)
  try
    WLTop := Self.Top;
    WLLeft := Self.Left;
    WagelossPaymentForm := TWagelossPaymentForm.CreateExtended( paymentType, application );
    WagelossPaymentForm.Top := WLTop + 20;   // position slightly down and to the right from
    WagelossPaymentForm.Left := WLLeft + 20; // the main wageloss form. This will allow us to see
                                             // the status line if an error is displayed
    copyNCCLAIM( CalcFullClaim, WagelossPaymentForm.FullClaim );
    WagelossPaymentForm.ShowModal;
  finally
    WagelossPaymentForm.free;
  end;
end;

(******************************************************************************)
(*                                                                            *)
(*  Sets claim information.                                                   *)
(*                                                                            *)
(******************************************************************************)
function TWagelossBenefitCalcForm.setClaimInformation( var r: recNCCLAIM ):boolean;
begin
  result:=false;
  if not allowUpdateClaim  or (CapabilityExists('Default')) then
    exit;

    SetUpdateInd(False);
    uSaveWageLossCalcFactors.SaveWageLossCalcFactors;
    result := true;
end;

(******************************************************************************)
(*                                                                            *)
(*  Special update procedure to allow NCRevClm to do                          *)
(*  setClaimInformation update.                                               *)
(*                                                                            *)
(******************************************************************************)
function TWagelossBenefitCalcForm.forceSetClaimInformation( var r: recNCCLAIM ):boolean;
begin
  CalcFullClaim.nc_104_Wk_Effective_Date := dataClaim.nc_104_Wk_Effective_Date;
  CalcFullClaim.nc_104_Wk_Clmt_Reply_Date := dataClaim.nc_104_Wk_Clmt_Reply_Date;
  copyNCCLAIM( CalcFullClaim, uSaveWageLossCalcFactors.CalcFullClaim);
  copyNCCLAIM( CalcPartClaim, uSaveWageLossCalcFactors.CalcPartClaim);
  uSaveWageLossCalcFactors.SaveWageLossCalcFactors;

  result := true;
end;

(******************************************************************************)
(*                                                                            *)
(*  Display default Info message                                              *)
(*                                                                            *)
(******************************************************************************)
procedure TWagelossBenefitCalcForm.ResetInfoLine2;
begin

  if setinfoline then
  begin
    if allowUpdateClaim and not (CapabilityExists('Default')) then
    Begin
      if lblAccident_Date.Visible Then
         WagelossMainForm.ShowInfoLine2( 'F7 - Exit F9 - Recalc  F10 - Recalc/Update Claim' )
      else
         WagelossMainForm.ShowInfoLine2( 'F7 - Exit F8 - Print F9 - Recalc' );
    end
    else
      if (CapabilityExists('Default')) then
        WagelossMainForm.ShowInfoLine2( 'F7 - Exit F8 - Print F9 - Recalc' )
      else
        WagelossMainForm.ShowInfoLine2( 'F7 - Exit F9 - Recalc' );

    //***
    if WagelossMainForm.isTestCalculator then
       if allowQASave then
          WagelossMainForm.ShowInfoLine2( 'F7 - Exit F8 - Print F9 - Recalc  F10 - Save Test Data Results' )
       else
          WagelossMainForm.ShowInfoLine2( 'F7 - Exit F8 - Print F9 - Recalc' );
    //***

    setinfoline:=false;
  end;



end;

(******************************************************************************)
(*                                                                            *)
(*  Set Wageloss Menu choices to enabled where appropriate.                   *)
(*                                                                            *)
(******************************************************************************)
procedure TWagelossBenefitCalcForm.SetMenuChoices;
var
  nc_num_weeks : currency;
  nc_80_eff_date : tdatetime;
begin
  with WagelossMainForm do
  begin
    WagelossBenefitsCalcMenu.Enabled := True;
    SelectClaimMenu.enabled := False;
    N90ShelteredMenu.enabled := False;
    N90ofNetMenu.enabled := False;
    N80ShelteredMenu.enabled := False;
    N80ofNetMenu.enabled := False;
    OverrideMenu.enabled := False;
    ReviewBenefitsLevelMenu.enabled := False;
    SearchOverpaymentsMenu.enabled := False;
    SRCycle1EditClaimsMenu.Enabled := True;
    SRCycle3PayClaimsMenu.Enabled := True;
    SRInitialInformationLoadMenu.Enabled := True;
    BenefitIndexationMenu.Enabled := True;
    IndexationReportMenu.enabled := True;
    ClaimInformationReportMenu.enabled := False;
    WagelossCalculationWorksheetMenu.enabled := True;
    BlankWagelossCalculationWorkSheet.Enabled := True;
    //nc_num_weeks := dataclaim.No_Weeks_of_Comp_Bnfts;
    nc_num_weeks := getAnnuityEntitlementWeeks(dataclaim.accident_date, dataclaim.claim_no, dataclaim.No_Weeks_of_Comp_Bnfts);
    nc_80_eff_date := dataclaim.nc_104_Wk_Effective_Date;
    //
    // Changed for Leg Ammendment 2006. DM
    //
    // If this is a 2006 and later claim then the flag will actually hold the
    // weeks pd to 61. Also we will need to check for 208 weeks past 61 since we can
    // now go 48 months.
    //
    // *** Start Change ***
    //
    if ( Year( DataClaim.Accident_Date ) >= 2006 ) Then
    begin
      if ( dataclaim.Comp_Wks_Pd_to_63_Flag = 'Y' ) and
           ( ( dataclaim.Comp_Wks_Pd_to_63 + 208 ) < nc_num_weeks ) then
      begin
        OverrideMenu.enabled := True;
        SearchOverpaymentsMenu.enabled := False;
      end;
    end
    else
    begin
      if ( dataclaim.Comp_Wks_Pd_to_63_Flag = 'Y' ) and
           ( ( dataclaim.Comp_Wks_Pd_to_63 + 104 ) < nc_num_weeks ) then
      begin
        OverrideMenu.enabled := True;
        SearchOverpaymentsMenu.enabled := False;
      end;
    end;
    //
    // *** End change for Leg Ammendment ***
    //
    //if ( dataClaim.nc_104_Wk_Effective_Date > 0 ) or
    //   ( dataClaim.No_Weeks_of_Comp_Bnfts > 95.99 ) then
    if ( dataClaim.nc_104_Wk_Effective_Date > 0 ) or
       ( getAnnuityEntitlementWeeks(dataClaim.accident_date, dataClaim.claim_no, dataClaim.No_Weeks_of_Comp_Bnfts) > 95.99 ) then
      ReviewBenefitsLevelMenu.enabled:=true;

    if ( nc_num_weeks < 104 ) and ( nc_80_eff_date < 1 ) then
    begin
      N90ShelteredMenu.enabled := true;
      N90ofNetMenu.enabled := true;
      OverrideMenu.enabled := true;
      SearchOverpaymentsMenu.enabled := False;
    end;

    if ( nc_num_weeks < 104 ) and ( nc_80_eff_date >= 1 ) then
    begin
      N90ShelteredMenu.enabled := true;
      N90ofNetMenu.enabled := true;
      N80ShelteredMenu.enabled := false;
      N80ofNetMenu.enabled := true;
      OverrideMenu.enabled := true;
      SearchOverpaymentsMenu.enabled := False;
    end;

    if ( nc_num_weeks >= 104 ) and ( nc_80_eff_date >= 1 ) then
    begin
      N80ShelteredMenu.enabled := false;
      N80ofNetMenu.enabled := true;
      OverrideMenu.enabled := true;
      SearchOverpaymentsMenu.enabled := False;
    end;

    if ( nc_num_weeks >= 104 ) and ( nc_80_eff_date < 1 ) then
    begin
      OverrideMenu.enabled := true;
      SearchOverpaymentsMenu.enabled := False;
    end;
  end;
end;

(******************************************************************************)
(*                                                                            *)
(*  Set Wageloss Calc Menu choices to enabled where appropriate.              *)
(*                                                                            *)
(******************************************************************************)
procedure TWagelossBenefitCalcForm.SetCalcMenuChoices;
begin
  with WagelossMainForm do
  begin
    BenefitIndexationMenu.Enabled := False;
    SearchOverpaymentsMenu.Enabled := False;
    N90ShelteredMenu.Enabled := False;
    N80ofNetMenu.Enabled := False;
    OverrideMenu.Enabled := False;
    N90ofNetMenu.Enabled := False;
    N80ShelteredMenu.Enabled := False;
    ReviewBenefitsLevelMenu.Enabled := False;
    SearchOverpaymentsMenu.Enabled := False;
    SRCycle1EditClaimsMenu.Enabled := False;
    SRCycle3PayClaimsMenu.Enabled := False;
    SRInitialInformationLoadMenu.Enabled := False;
    ClaimInformationReportMenu.Enabled := False;
    IndexationReportMenu.Enabled := False;
    WagelossCalculationWorksheetMenu.Enabled := True;
    BlankWagelossCalculationWorkSheet.Enabled := True;
  end;
end;

(******************************************************************************)
(*                                                                            *)
(*  Reset wageloss menu choices to disabled.                                  *)
(*                                                                            *)
(******************************************************************************)
procedure TWagelossBenefitCalcForm.ResetMenuChoices;
begin
  with WagelossMainForm do
  begin
    SelectClaimMenu.Enabled := True;
    WagelossBenefitsCalcMenu.Enabled := False;
    N90ShelteredMenu.Enabled := False;
    N90ofNetMenu.Enabled := False;
    N80ShelteredMenu.Enabled := False;
    N80ofNetMenu.Enabled := False;
    OverrideMenu.Enabled := False;
    ReviewBenefitsLevelMenu.Enabled := False;
    SearchOverpaymentsMenu.Enabled := False;
    BenefitIndexationMenu.Enabled := False;
    IndexationReportMenu.Enabled := False;
    ClaimInformationReportMenu.Enabled := False;
    WagelossCalculationWorksheetMenu.Enabled := True;
    BlankWagelossCalculationWorkSheet.Enabled := True;
    SRCycle1EditClaimsMenu.Enabled := True;
    SRCycle3PayClaimsMenu.Enabled := True;
    SRInitialInformationLoadMenu.Enabled := True;
  end;
end;

(******************************************************************************)
(*                                                                            *)
(*  Reset wageloss Calc menu choices to disabled.                             *)
(*                                                                            *)
(******************************************************************************)
procedure TWagelossBenefitCalcForm.ReSetCalcMenuChoices;
begin
  with WagelossMainForm do
  begin
    BenefitIndexationMenu.Enabled := True;
    SearchOverpaymentsMenu.enabled := False;
    N90ShelteredMenu.Enabled := True;
    N80ofNetMenu.Enabled := True;
    OverrideMenu.Enabled := True;
    N90ofNetMenu.Enabled := True;
    ReviewBenefitsLevelMenu.Enabled := True;
    SearchOverpaymentsMenu.enabled := False;
    SRCycle1EditClaimsMenu.Enabled := True;
    SRCycle3PayClaimsMenu.Enabled := True;
    SRInitialInformationLoadMenu.Enabled := True;
    ClaimInformationReportMenu.enabled := False;
    IndexationReportMenu.Enabled := True;
    WagelossCalculationWorksheetMenu.Enabled := True;
    BlankWagelossCalculationWorkSheet.Enabled := True;
  end;
end;

(******************************************************************************)
(*                                                                            *)
(*  Process Wageloss Payment at 90% Sheltered.                                *)
(*                                                                            *)
(******************************************************************************)
procedure TWagelossBenefitCalcForm.ProcessPAY90SHELTERED(var MSG: Tmessage);
begin
  if allowUpdateClaim then
  begin
    WagelossMainForm.ShowInfoLine2( '*Update Claim is pending. Please update claim before paying.' );
    messagebeep(0);
    exit;
  end;

  with dataclaim do
  begin
    Benefit_Type_Code:='1';
    if year(Accident_Date) < 2006 then
    begin
       Benefit_Type:='90% Net Sheltered';
       if dataClaim.Post_Injury_Earn > 0 then
       begin
        Weekly_Benefit := CalcPartClaim.Weekly_90_S;
        if Weekly_Benefit < 0 then
          Weekly_Benefit := 0;
       end
       else
       begin
        Weekly_Benefit := CalcFullClaim.Weekly_90_S;
       end;
    end
    else
    begin
      Benefit_Type:='Pre 104 Weeks Sheltered';
      if dataClaim.Post_Injury_Earn > 0 then
      begin
       Weekly_Benefit := CalcPartClaim.Weekly_90_S;
       if Weekly_Benefit < 0 then
          Weekly_Benefit := 0;
      end
      else
      begin
       Weekly_Benefit := Weekly_90_S;
      end;
    end;
  end;
  WagelossPayment( i90Sheltered );
end;

(******************************************************************************)
(*                                                                            *)
(*  Process Wageloss Payment at 90% Net.                                      *)
(*                                                                            *)
(******************************************************************************)
procedure TWagelossBenefitCalcForm.ProcessPAY90NET(var MSG: Tmessage);
begin
  if allowUpdateClaim then
  begin
    WagelossMainForm.ShowInfoLine2( '*Update Claim is pending. Please update claim before paying.' );
    messagebeep(0);
    exit;
  end;

  with dataclaim do
  begin
    Weekly_Benefit := Weekly_90;
    Benefit_Type_Code := '2';
    Benefit_Type := '90% of Net';
  end;

  WagelossPayment( i90Net );
end;

(******************************************************************************)
(*                                                                            *)
(*  Process Wageloss Payment at 80% Sheltered.                                *)
(*                                                                            *)
(******************************************************************************)
procedure TWagelossBenefitCalcForm.ProcessPAY80SHELTERED(var MSG: Tmessage);
begin
  if allowUpdateClaim then
  begin
    WagelossMainForm.ShowInfoLine2( '*Update Claim is pending. Please update claim before paying.' );
    messagebeep(0);
    exit;
  end;

  with dataclaim do
  begin
    Weekly_Benefit := Weekly_80_S;
    Benefit_Type_Code := '3';
    Benefit_Type := '80% Net Sheltered';
  end;

  WagelossPayment( i80Sheltered );
end;

(******************************************************************************)
(*                                                                            *)
(*  Process Wageloss Payment at 80% Net.                                      *)
(*                                                                            *)
(******************************************************************************)
procedure TWagelossBenefitCalcForm.ProcessPAY80NET(var MSG: Tmessage);
begin
  if allowUpdateClaim then
  begin
    WagelossMainForm.ShowInfoLine2('*Update Claim is pending. Please update claim before paying.');
    messagebeep(0);
    exit;
  end;
  with dataclaim do
  begin
    Benefit_Type_Code:='4';
    if year(Accident_Date) < 2006 then
    begin
       Benefit_Type:='80% of Net';
      if dataClaim.Post_Injury_Earn > 0 then
      begin
        Weekly_Benefit := CalcPartClaim.Weekly_80;
        if Weekly_Benefit < 0 then
          Weekly_Benefit := 0;
      end
      else
      begin
       Weekly_Benefit := Weekly_80;
      end;
    end
    else
    begin
      Benefit_Type:='Post 104 Weeks';
      if dataClaim.Post_Injury_Earn > 0 then
      begin
        Weekly_Benefit := CalcPartClaim.Weekly_80_S;
        if Weekly_Benefit < 0 then
          Weekly_Benefit := 0;
      end
      else
      begin
       Weekly_Benefit := Weekly_80_S;
      end;
    end;
  end;
  WagelossPayment( i80Net );
end;

(******************************************************************************)
(*                                                                            *)
(*  Process Wageloss Payment at 80% or 90% Override.                          *)
(*                                                                            *)
(******************************************************************************)
procedure TWagelossBenefitCalcForm.ProcessPAYOVERRIDE(var MSG: Tmessage);
begin
  if allowUpdateClaim then
  begin
    WagelossMainForm.ShowInfoLine2( '*Update Claim is pending. Please update claim before paying.' );
    messagebeep(0);
    exit;
  end;

  with dataclaim do
  begin
    Benefit_Type_Code:='9';
    Benefit_Type:='Manual Calculation';
    if year(Accident_Date) < 2006 then
    begin
      if ( nc_104_Wk_Effective_Date > 1 ) then
      begin
        // use 80% net for weekly benefit
        Weekly_Benefit:=Weekly_80;
        WagelossPayment( i80Override );
      end
      else
      begin
        Weekly_Benefit:=Weekly_90_S;
        WagelossPayment( i90Override );
      end;
    end
    else
    begin
      if dataClaim.Post_Injury_Earn > 0 then
      begin
        //Weekly_Benefit:=Weekly_80_S;
        Weekly_Benefit := CalcPartClaim.Weekly_80_S;
        if Weekly_Benefit < 0 then
          Weekly_Benefit := 0;
      end
      else
      begin
        Weekly_Benefit := Weekly_90_S;
      end;

      if ( nc_104_Wk_Effective_Date > 1 ) then
      begin
        WagelossPayment( i80Override );
      end
      else
      begin
        WagelossPayment( i90Override );
      end;
    end;
  end;
end;

(******************************************************************************)
(*                                                                            *)
(*  Show Wageloss Indexation Form.                                            *)
(*                                                                            *)
(******************************************************************************)
procedure TWagelossBenefitCalcForm.ProcessINDEXATION(var MSG: Tmessage);
begin
  WagelossIndexation;
end;

(******************************************************************************)
(*                                                                            *)
(*  Print Indexation Report.                                                  *)
(*                                                                            *)
(******************************************************************************)
procedure TWagelossBenefitCalcForm.PrintINDEXATION(var MSG: Tmessage);
var
  rc: integer;
  isEmerge : boolean;
begin
  try
    if IsEmergeUp then
    begin
      isEmerge := isClaimEmerge( lblClaim_No.Caption )
    end
    else
      isEmerge := False;
  except
    isEmerge := False; // if we have failed to this point assume Emerge is not there
  end;

  try
    rc := 0;
    GetChoiceForm := TGetChoiceForm.create( application );
    GetChoiceForm.Caption := 'Display Indexation Calculation in Emerge';
    GetChoiceForm.Message := 'Do You Wish to Produce an Indexation Calculation Report?';
    if isEmerge then
      GetChoiceForm.AddChoice( 'Y - Print Report To Emerge File' )
    else
      GetChoiceForm.AddChoice( 'Y - Print Report' );
    GetChoiceForm.AddChoice( 'P - Preview to Screen' );
    GetChoiceForm.AddChoice( 'N - Do NOT produce report' );
    GetChoiceForm.showmodal;
    rc := GetChoiceForm.Selected;
  finally
     GetChoiceForm.free;
  end;

  screen.cursor:=crHourGlass;

  try
    if ( rc in [0,1] ) then
    begin
      if ( rc = 0 ) then
      begin
        if isEmerge then
        begin
          RptDestination := 'E';
          setRecIndexReport( 'WLI1', CalcFullClaim, CalcPartClaim, RptDestination );
        end
        else
        begin
          if ( IsEmergeSet ) and not( IsEmergeUp ) then
            MessageDlg( 'An Emerge Connection Was Not Found.' + chr(10) + chr(13) + 'Report Will Be Sent To The Printer.', mtWarning, [mbOK], 0 );
          RptDestination := 'P';
          PrintIndexReport;
        end;
      end
      else
      begin
        RptDestination := 'S';
        PrintIndexReport;
      end;
    end;
  finally
    screen.cursor := crDefault;
  end;
end;

(******************************************************************************)
(*                                                                            *)
(*  Print Claim Information Report.                                           *)
(*                                                                            *)
(******************************************************************************)
procedure TWagelossBenefitCalcForm.PrintCLAIM_INFO(var MSG: Tmessage);
var
  MyPreview: TQRCustomPreviewForm;
  MyReport: TPrintClaimInfoForm;
begin
  screen.cursor := crHourGlass;

  try
    MyPreview := TQRCustomPreviewForm.create( Nil );
    MyReport := TPrintClaimInfoForm.create( Nil );
    MyPreview.ParentQuickReportForm := MyReport;
    MyPreview.ParentQuickReport := MyReport.QRClaimInfo;
    MyPreview.caption := 'Claim Information Report';
    screen.cursor := crDefault;
    try
      MyReport.QRClaimInfo.OnPreview := MyPreview.CustomPreview;
      MyReport.QRClaimInfo.Preview;
    finally
      screen.cursor := crDefault;
    end;
  finally
    screen.cursor := crDefault;
  end;
end;

(******************************************************************************)
(*                                                                            *)
(*  Print Wageloss Calculation Worksheet                                      *)
(*                                                                            *)
(******************************************************************************)
procedure TWagelossBenefitCalcForm.PrintCALC_WORKSHEET(var MSG: Tmessage);
begin
  Screen.Cursor := crHourGlass;
  NCWrkRptBase.OpenWrkSheet( CalcPartClaim, Self );
end;

(******************************************************************************)
(*                                                                            *)
(*  Form Close Query                                                          *)
(*                                                                            *)
(******************************************************************************)
procedure TWagelossBenefitCalcForm.FormCloseQuery(Sender: TObject; var CanClose: Boolean);
begin
  CanClose := True;
  if lblAccident_Date.Visible and not (CapabilityExists('Default')) Then
     begin
     if allowUpdateClaim then
        begin
        WagelossMainForm.ShowInfoLine2( '*Update Claim is pending.' );
        messagebeep(0);
        if (MessageDlg('Update Claim is pending.' + #10#10 + 'Are you sure you want to close the' + #10 +
                       'Benefits Calculation Screen?', mtConfirmation, mbOkCancel, 0)) <> mrOK then
           begin
           CanClose := false;
           end;
        end;
     end;

  //***
  if WagelossMainForm.isTestCalculator and allowQASave then
  begin
    edAccident_Date.SetFocus;
                if MyMessageDialog('Do you want to save the calculated results into QA Test Data ?', mtConfirmation, mbOKCancel,
                   ['Save It', 'No']) = mrOk then
    begin
      SaveQAData;
    end;
  end;
  //***

end;

(******************************************************************************)
(*                                                                            *)
(*  Display Benefit Calculation in Emerge                                     *)
(*                                                                            *)
(******************************************************************************)
procedure TWagelossBenefitCalcForm.DisplayBenefitCalculationInEmerge;
var
  rc: integer;
  isEmerge : boolean;
begin
  if IsEmergeUp then
  begin
    isEmerge := isClaimEmerge( lblClaim_No.Caption )
  end
  else
    isEmerge := false;

  try
    rc := 0;
    GetChoiceForm := TGetChoiceForm.create( application );
    GetChoiceForm.Caption := 'Display Benefit Calculation in Emerge';
    GetChoiceForm.Message := 'Would you like to display the benefit calculation factors in Emerge?';
    if isEmerge then
      GetChoiceForm.AddChoice( 'Y - Display on Wage Loss Tab' )
    else
      GetChoiceForm.AddChoice( 'Y - Display on Wage Loss Tab' );
    GetChoiceForm.AddChoice( 'N - Do Not Display on Wage Loss Tab' );
    GetChoiceForm.ShowModal;
    rc := GetChoiceForm.Selected;
  finally
    GetChoiceForm.free;
  end;

  if ( rc = 0 ) then
  begin
    //Set emerge display flag to yes in WageLossCalcFactor (emergeDisplayFlag)
    SetUpEmergeDisplayFlag( 'Y' );

    //Automatically send Wageloss Calculation Report to Emerge
    RptDestination := 'P';
    if isEmerge then
    begin
      setRecReport( 'WLF1', CalcFullClaim, CalcPartClaim );
    end
    else
    begin
      if ( IsEmergeSet ) and not( IsEmergeUp ) then
        MessageDlg( 'An Emerge Connection Was Not Found.' + chr(10) + chr(13) + 'Report Will Be Sent To The Printer.', mtWarning, [mbOK], 0 );
      PrintBenCalcReport;
    end;
  end
  else
  begin
    SetUpEmergeDisplayFlag( 'N' );

    //Ask to send Wageloss Calculation Report to Emerge
    PrintBenefitCalculationReport;
  end;

end;

(******************************************************************************)
(*                                                                            *)
(*  Set up the value for Emerge Display Flag.                                 *)
(*                                                                            *)
(******************************************************************************)
procedure TWagelossBenefitCalcForm.SetUpEmergeDisplayFlag( aFlag : String );
begin
  //Set emerge display flag to no in WageLossCalcFactor (emergeDisplayFlag)
  try
     with dm1.qWageLossFactors do
        begin
        close;
        SQL.Clear;
        SQL.Add( 'UPDATE WageLossCalcFactor SET');
  			SQL.Add( '		emergeDisplayFlag = ' + '''' + aFlag + '''');
        SQL.Add( 'WHERE wageLossCalcFactorId = ' + wr.Uniquness );
        execSQL; //Execute Update
        end;
  except
     on e:Exception do
        begin
        applog('TWagelossBenefitCalcForm.SetUpEmergeDisplayFlag - Exception - Message: ' + e.Message);
        MessageDlg('Emerge Display Flag Update Failed. ' + Chr(10) + Chr(13) +  E.Message +
                   Chr(10) + Chr(13) +  'Please notify help desk at 4573.', mtError, [mbOK], 0 );
        end;
  end;
end;

(******************************************************************************)
(*                                                                            *)
(*  Print Wageloss Calculation Report.                                         *)
(*                                                                            *)
(******************************************************************************)
procedure TWagelossBenefitCalcForm.PrintBenefitCalculationReport;
var
  rc: integer;
  isEmerge : boolean;
begin
  if IsEmergeUp then
  begin
    isEmerge := isClaimEmerge( lblClaim_No.Caption )
  end
  else
    isEmerge := false;

  try
    rc := 0;
    GetChoiceForm := TGetChoiceForm.create( application );
    GetChoiceForm.Caption := 'Display Wageloss Calculation Report in Emerge';
    GetChoiceForm.Message := 'Do you wish to produce a Wageloss Calculation Report?';
    if isEmerge then
      GetChoiceForm.AddChoice( 'Y - Print Report To Emerge File' )
    else
      GetChoiceForm.AddChoice( 'Y - Print Report' );
    GetChoiceForm.AddChoice( 'P - Preview to Screen' );
    GetChoiceForm.AddChoice( 'N - Do NOT produce report' );
    GetChoiceForm.showmodal;
    rc := GetChoiceForm.Selected;
  finally
    GetChoiceForm.free;
  end;

  if ( rc in [0,1] ) then
  begin
    if ( rc = 0 ) then
    begin
      RptDestination := 'P';
      if isEmerge then
      begin
        setRecReport( 'WLF1', CalcFullClaim, CalcPartClaim );
      end
      else
      begin
        if ( IsEmergeSet ) and not( IsEmergeUp ) then
          MessageDlg( 'An Emerge Connection Was Not Found.' + chr(10) + chr(13) + 'Report Will Be Sent To The Printer.', mtWarning, [mbOK], 0 );
        PrintBenCalcReport;
      end;
    end
    else
    begin
      RptDestination := 'S';
      PrintBenCalcReport;
    end;
  end;
end;

(******************************************************************************)
(*                                                                            *)
(*  Print Index Calculation Report                                            *)
(*                                                                            *)
(******************************************************************************)
procedure TWagelossBenefitCalcForm.PrintIndexReport;
var
  ChildRpt: TfCrystalPrev;
  RptName, RptTitle : String;
  lngIndex, i : Integer;
  Child : TForm;
begin
  screen.cursor := crHourGlass;
  try
    // create a new MDI child window
    //
    // See if we can find a Crystal Report form already loaded
    //
    lngIndex := WagelossMainForm.MDIChildCount;
    for i := 0 to lngIndex - 1 do
       begin
       if WagelossMainForm.MDIChildren[i].ClassType = TfCrystalPrev Then
          begin
          Child := WagelossMainForm.MDIChildren[i] as TfCrystalPrev;
          Child.Close; // Force the close
          break;
          end;
       end;

    ChildRpt := TfCrystalPrev.Create(Application);
    //ChildRpt := TfCrystalPrev.Create(Self);
    ChildRpt.Caption := 'Indexation Report';
    uSaveIndexReport.formId := 'WLI1';
    RptName := 'IndexationReport.rpt';
    RptTitle := 'Benefit Indexation Report';

    copyNCCLAIM( CalcFullClaim, uSaveIndexReport.CalcFullClaim );
    copyNCCLAIM( CalcPartClaim, uSaveIndexReport.CalcPartClaim );
    //
    // If the report creation is successful then preview the report, otherwise clean up
    // the report window.
    //

    if SavePrint( RptDestination ) Then
       begin
       ChildRpt.Rpt_Prev(RptName,
	                       RptTitle,
                         RptDestination,
                         [(CalcFullClaim.Claim_No ),
                           uSaveIndexReport.Reporting_User,
                           uSaveIndexReport.Report_Time,
                           uSaveIndexReport.Report_Date]);
       end
    else
       ChildRpt.Close;
  finally
     screen.cursor := crDefault;
  end;
end;

(******************************************************************************)
(*                                                                            *)
(*  Print Wageloss Calculation Report                                          *)
(*                                                                            *)
(******************************************************************************)
procedure TWagelossBenefitCalcForm.PrintBenCalcReport;
var
  ChildRpt : TfCrystalPrev;
  RptName, RptTitle : String;
  lngIndex, i : Integer;
  Child : TForm;
begin
  screen.cursor := crHourGlass;
  try
    // create a new MDI child window
    //
    // See if we can find a Crystal Report form already loaded
    //
    lngIndex := WagelossMainForm.MDIChildCount;
    For i := 0 to lngIndex - 1 do
    Begin
      if WagelossMainForm.MDIChildren[i].ClassType = TfCrystalPrev Then
      Begin
        Child := WagelossMainForm.MDIChildren[i] as TfCrystalPrev;
        Child.Close; // Force the close
        Break;
      End;
    End;

    ChildRpt := TfCrystalPrev.Create( Application );
    ChildRpt.Caption := 'Wageloss Calculation Report';
    uSavePrint.formId := 'WLF1';
    RptName := 'WagelossBenefitCalculationForFile.rpt';
    RptTitle := 'Wageloss Calculation Report';

    if Not lblAccident_Date.Visible then
    begin
      CalcFullClaim.Claim_No := '00000000';
      CalcFullClaim.Claim_Suffix := '0000';
    end;

    copyNCCLAIM( CalcFullClaim, uSavePrint.CalcFullClaim );
    copyNCCLAIM( CalcPartClaim, uSavePrint.CalcPartClaim );

    FullClaim;
    CheckForPartial;
    //
    // If the report creation is successful then preview the report, otherwise clean up
    // the report window.
    //
    if UpdateReport Then
    begin
      ChildRpt.Rpt_Prev( RptName,
	                       RptTitle,
                         RptDestination,
                         [wrpt.Claim_No,
                          wrpt.ReportId,
                          wrpt.Reporting_User,
                          wrpt.Report_Time,
                          wrpt.Report_Date] );
    end
    else
      ChildRpt.Close;

    screen.cursor:=crDefault;
  finally
    screen.cursor:=crDefault;
  end;
end;

(******************************************************************************)
(*                                                                            *)
(*  Print Wageloss Letter.                                                    *)
(*                                                                            *)
(******************************************************************************)
procedure TWagelossBenefitCalcForm.PrintWageLossLetter;
var
  rc, PRINT_LETTER : integer;
 begin
  try
    rc := 0;
    GetChoiceForm := TGetChoiceForm.create(application);
    GetChoiceForm.Caption := 'Display Benefit Explanation letter in Emerge';
    GetChoiceForm.Message := 'Do you wish to produce a Benefit Explanation letter?';
    GetChoiceForm.AddChoice( 'Y - Request Benefit Explanation letter' );
    GetChoiceForm.AddChoice( 'N - Do NOT Request Benefit Explanation letter' );
    GetChoiceForm.showmodal;
    rc := GetChoiceForm.Selected;
  finally
    GetChoiceForm.free;
  end;

  if ( rc = 1 ) then exit;

  with dataForm do
  begin
    Claim_No := dataClaim.Claim_No;
    Firm_Number := copy( dataClaim.Prime_Firm_No, 1, 7 );
    Firm_Suffix := copy( dataClaim.Prime_Firm_No, 8, 2 );
    Form_Number := WL01;
    Clinic_Number := '';
    Doctor_Number := '';
  end;

  // WCB Policy Changes for "accident year" 2001 onward
  if year( dataClaim.Accident_Date ) < 2001 then
  begin
    //x 1st payment
    if ( dataClaim.nc_104_Wk_Effective_Date < 1 ) then
      dataForm.Form_Number := WL01;

    //x Not 1st payment  and   >2yrs  (80% letter)
    if ( dataClaim.nc_104_Wk_Effective_Date > 0 ) and ( getAnnuityEntitlementWeeks(dataclaim.accident_date, dataclaim.claim_no, dataclaim.No_Weeks_of_Comp_Bnfts) >= 104 ) then
    begin
      //x Pension letter?
      if ( dataClaim.Wkly_Clmt_Anty_Con_Amt > 0 ) then
        dataForm.Form_Number := WL02
      else
        dataForm.Form_Number := WL03;
    end;

    //x Not 1st payment   and      <2yrs
    if ( dataClaim.nc_104_Wk_Effective_Date > 0 ) and ( getAnnuityEntitlementWeeks(dataclaim.accident_date, dataclaim.claim_no, dataclaim.No_Weeks_of_Comp_Bnfts) < 104 ) then
    begin
      try
        PRINT_LETTER := 8;
        GetChoiceForm := TGetChoiceForm.create( application );
        GetChoiceForm.Caption := 'Select Letter Type';
        GetChoiceForm.Message := 'Please select 80% or 90% Letter (8 or 9) :';
        GetChoiceForm.AddChoice( '8 - 80% Letter' );
        GetChoiceForm.AddChoice( '9 - 90% Letter' );
        GetChoiceForm.showmodal;
        PRINT_LETTER := 8 + GetChoiceForm.Selected;
      finally
        GetChoiceForm.free;
      end;
      case PRINT_LETTER of
      8: begin
        if ( dataClaim.Wkly_Clmt_Anty_Con_Amt > 0 ) then
          dataForm.Form_Number:= WL02
        else
          dataForm.Form_Number:= WL03;
         end;
      9: begin
          dataForm.Form_Number:= WL01;
         end;
      end;
    end;
  end
  else
  begin   // Post 2000 claims
    //x 1st payment
    if ( dataClaim.nc_104_Wk_Effective_Date < 1 ) then
    begin
      try
        PRINT_LETTER := 9;
        GetChoiceForm := TGetChoiceForm.create( application );
        GetChoiceForm.Caption := 'Select Tax Deduction Letter Option';
        GetChoiceForm.Message := 'Please select Letter (A or B) :';
        GetChoiceForm.AddChoice( 'A - Request for tax deductions' );
        GetChoiceForm.AddChoice( 'B - Tax deductions included' );
        GetChoiceForm.showmodal;
        PRINT_LETTER := 9 + GetChoiceForm.Selected;
      finally
        GetChoiceForm.free;
      end;
      case PRINT_LETTER of
      9: begin
          dataForm.Form_Number := WL04;
         end;
     10: begin
          dataForm.Form_Number := WL05;
         end;
      end;
    end;

    //x Not 1st payment  and   >2yrs  (80% letter)
    if ( dataClaim.nc_104_Wk_Effective_Date > 0 ) and ( getAnnuityEntitlementWeeks(dataclaim.accident_date, dataclaim.claim_no, dataclaim.No_Weeks_of_Comp_Bnfts) >= 104 ) then
    begin
      //x Pension letter?
      if ( dataClaim.Wkly_Clmt_Anty_Con_Amt > 0 ) then
        dataForm.Form_Number := WL06
      else
        dataForm.Form_Number := WL07;
    end;

    //x Not 1st payment   and      <2yrs
    if ( dataClaim.nc_104_Wk_Effective_Date > 0 ) and ( getAnnuityEntitlementWeeks(dataclaim.accident_date, dataclaim.claim_no, dataclaim.No_Weeks_of_Comp_Bnfts) < 104 ) then
    begin
      try
        PRINT_LETTER := 8;
        GetChoiceForm := TGetChoiceForm.create( application );
        GetChoiceForm.Caption := 'Select Tax Deduction Letter Option';
        GetChoiceForm.Message := 'Please select Letter (8, A or B) :';
        GetChoiceForm.AddChoice( '8 - 80% Letter' );
        GetChoiceForm.AddChoice( 'A - Request for tax deductions' );
        GetChoiceForm.AddChoice( 'B - Tax deductions included' );
        GetChoiceForm.showmodal;
        PRINT_LETTER := 8 + GetChoiceForm.Selected;
      finally
        GetChoiceForm.free;
      end;
      case PRINT_LETTER of
      8: begin
        if ( dataClaim.Wkly_Clmt_Anty_Con_Amt > 0 ) then
          dataForm.Form_Number:= WL06
        else
          dataForm.Form_Number:= WL07;
         end;
      9: begin
          dataForm.Form_Number:= WL04;
         end;
     10: begin
          dataForm.Form_Number:= WL05;
         end;
      end;
    end;
  end;

  //
  // Changes for Leg Amendment. We need to alter the Form_Number for the Leg Ammendment
  // 4 new letters have been developed to correspond to the WL05 to WL07
  //
  if (Year( dataClaim.Accident_Date ) >= 2006) AND
     (Year( dataClaim.Accident_Date ) <= 2021) Then
     begin
     if dataForm.Form_Number = WL04 then
        dataForm.Form_Number := WL08
     else if dataForm.Form_Number = WL05 then
        dataForm.Form_Number := WL09
     else if dataForm.Form_Number = WL06 then
        dataForm.Form_Number := WL10
     else if dataForm.Form_Number = WL07 then
        dataForm.Form_Number := WL11;
     end
  else   if (Year( dataClaim.Accident_Date ) >= 2022) Then
     begin
     if dataForm.Form_Number = WL04 then
        dataForm.Form_Number := WL12
     else if dataForm.Form_Number = WL05 then
        dataForm.Form_Number := WL13
     else if dataForm.Form_Number = WL06 then
        dataForm.Form_Number := WL14
     else if dataForm.Form_Number = WL07 then
        dataForm.Form_Number := WL15;
     end;

  triggerSendDocumentEvent( dataForm.Form_Number );
end;

(******************************************************************************)
(*                                                                            *)
(*  104 Week Claimant % Effective Date Exit Routine                           *)
(*                                                                            *)
(******************************************************************************)
//
// Modified April 2003
// Purpose: Modified to allow the Wageloss form to be used as both the calculator
//          and the wageloss form
//
procedure TWagelossBenefitCalcForm.ednc_104_Wk_Clmt_p_Eff_DateExit(Sender: TObject);
begin
  if not SetValidate then
    SetInfoLine := True;

  if not ValidateAsDate( ednc_104_Wk_Clmt_p_Eff_Date ) then
  begin
    globalEditError := displayError( '*Invalid Effective date of 80% of Worker Contribution.', ednc_104_Wk_Clmt_p_Eff_Date );
    Exit;
  end;

  if ( textAsDate( ednc_104_Wk_Clmt_p_Eff_Date ) ) > 0 then
  begin
    // ensure effective date of 80% of Net has been entered already
    if ( textAsDate( ednc_104_Wk_Effective_Date ) < 1 ) then
    begin
      globalEditError := displayError( '*Effective date of 80% of Net not entered yet', ednc_104_Wk_Clmt_p_Eff_Date );
      Exit;
    end;
    // ensure Claimant Contrib date is > effective date of 80% of Net
    if (textAsDate(ednc_104_Wk_Clmt_p_Eff_Date) < textAsDate(ednc_104_Wk_Effective_Date) ) then
    begin
      globalEditError := displayError( '*Effective date of Worker Contribution must be > 80% Net Date:', ednc_104_Wk_Clmt_p_Eff_Date );
      Exit;
    end;
    // ensure Claimant Contrib date is > 2 years after accident date
    if ( textAsDate( ednc_104_Wk_Clmt_p_Eff_Date ) < ( CalcFullClaim.Accident_Date + 727 ) ) then
    begin
      globalEditError := displayError( '*Effective date of Worker Contribution must be > 2 years past date of incident', ednc_104_Wk_Clmt_p_Eff_Date );
      exit;
    end;
  end;

  if ( textAsDate( ednc_104_Wk_Clmt_p_Eff_Date ) ) > 0 then
    ednc_104_Wk_Clmt_p_Eff_Date.Text := FormatDateTime( 'c', TextAsDate( ednc_104_Wk_Clmt_p_Eff_Date ) )
  else
    ednc_104_Wk_Clmt_p_Eff_Date.text := '';

  ResetInfoLine2;
end;

(******************************************************************************)
(*                                                                            *)
(*  Set 80% fields to active or read-only depending on 80% info               *)
(*                                                                            *)
(******************************************************************************)
procedure TWagelossBenefitCalcForm.set80pNetFields;
begin
  //if ( dataclaim.No_Weeks_of_Comp_Bnfts > 95.99 ) or
  if ( getAnnuityEntitlementWeeks(dataClaim.accident_date, dataClaim.claim_no, dataClaim.No_Weeks_of_Comp_Bnfts) > 95.99 ) or
     ( dataclaim.nc_104_Wk_Effective_Date > 0 ) or
     ( dataclaim.nc_104_Wk_WCB_p_Contrib_Red > 0 ) or
     ( dataclaim.nc_104_Wk_Clmt_p_Eff_Date > 0 ) or
     ( dataclaim.nc_104_Wk_Clmt_p_Contrib > 0 ) then
  begin
    setEditToNormal( ednc_104_Wk_Effective_Date );
    setEditToNormal( ednc_104_Wk_WCB_p_Contrib_Red );
    setEditToNormal( ednc_104_Wk_Clmt_p_Eff_Date );
    setEditToNormal( ednc_104_Wk_Clmt_p_Contrib );
    //EC Oct 12 - new field for Leg review
    setEditToNormal( ed_WCB_Annuity_Contr );
  end
  else
  begin
    // set fields to read
    setEditToRead( ednc_104_Wk_Effective_Date );
    setEditToRead( ednc_104_Wk_WCB_p_Contrib_Red );
    setEditToRead( ednc_104_Wk_Clmt_p_Eff_Date );
    setEditToRead( ednc_104_Wk_Clmt_p_Contrib );
    //EC Oct 12 - new field for Leg review
    setEditToRead( ed_WCB_Annuity_Contr );
    if ( activecontrol<> nil ) then
      if ( activecontrol.name = 'ednc_104_Wk_Effective_Date' ) or
         ( activecontrol.name = 'ednc_104_Wk_WCB_p_Contrib_Red' ) or
         ( activecontrol.name = 'ednc_104_Wk_Clmt_p_Eff_Date' ) or
         ( activecontrol.name = 'ednc_104_Wk_Clmt_p_Contrib' ) or
         ( activecontrol.name = 'ed_WCB_Annuity_Contr' ) then
      selectNext( activecontrol as tWinControl, true, true );
   end;
end;

(******************************************************************************)
(*                                                                            *)
(*  Display Review Benefits Level Form                                        *)
(*                                                                            *)
(******************************************************************************)
procedure TWagelossBenefitCalcForm.ProcessREVIEW_BENEFITS_LEVEL(var MSG: Tmessage);
begin
  ResetInfoLine2;
  try
    ReviewBenefitLevelForm := TReviewBenefitLevelForm.create( application );
    ReviewBenefitLevelForm.showmodal;
    fillInForm;
  finally
    ReviewBenefitLevelForm.free;
  end;
end;

(******************************************************************************)
(*                                                                            *)
(*  Display Death Benefit Report                                              *)
(*                                                                            *)
(******************************************************************************)
procedure TWagelossBenefitCalcForm.ProcessDEATH_BENEFIT_REPORT(var MSG: Tmessage);
var
  ChildRpt : TfCrystalPrev;
  RptName, RptTitle : String;
  lngIndex, rc : Integer;
  Child : TForm;
  SaveFullClaim, SavePartClaim : recNCClaim;
  ClaimCopied, isEmerge : boolean;

  procedure PrintReport;
  var
    i:Integer;

    begin
    // create a new MDI child window
    //
    // See if we can find a Crystal Report form already loaded
    //
    lngIndex := WagelossMainForm.MDIChildCount;
    For i := 0 to lngIndex - 1 do
    Begin
      if WagelossMainForm.MDIChildren[i].ClassType = TfCrystalPrev Then
      Begin
        Child := WagelossMainForm.MDIChildren[i] as TfCrystalPrev;
        Child.Close; // Force the close
        Break;
      End;
    End;

    ChildRpt := TfCrystalPrev.Create(Application);
    ChildRpt.Caption := 'Wageloss Calculation Report';
    uSavePrint.formId := 'WLF1';
    RptName := 'WagelossBenefitCalculationForFile.rpt';
    RptTitle := 'Wageloss Calculation Report';

    if Not lblAccident_Date.Visible then
    begin
      CalcFullClaim.Claim_No := '00000000';
      CalcFullClaim.Claim_Suffix := '0000';
    end;

    CalcFullClaim.DeathBenefit := 'Y';
    CalcPartClaim.DeathBenefit := 'Y';
    copyNCCLAIM( CalcFullClaim, uSavePrint.CalcFullClaim);
    copyNCCLAIM( CalcPartClaim, uSavePrint.CalcPartClaim);

    FullClaim;
    CheckForPartial;
    //
    // If the report creation is successful then preview the report, otherwise clean up
    // the report window.
    //
    if UpdateReport Then
      ChildRpt.Rpt_Prev( RptName,
	                       RptTitle,
                         RptDestination,
                         [wrpt.Claim_No,
                          wrpt.ReportId,
                          wrpt.Reporting_User,
                          wrpt.Report_Time,
                          wrpt.Report_Date] )
    else
      ChildRpt.Close;

  end; // end procedure PrintReport
begin
  ResetInfoLine2;
  ClaimCopied := False;

  If Year( CalcFullClaim.Accident_Date ) < 2006 Then
  begin
    WagelossMainForm.ShowInfoLine2( '*Death Benefit Report only valid for 2006+ Claims.' );
  end
  else
  begin
    screen.cursor := crHourGlass;
    if IsEmergeUp then
    begin
      isEmerge := isClaimEmerge( lblClaim_No.Caption )
    end
    else
      isEmerge := false;

    try
      rc := 0;
      GetChoiceForm := TGetChoiceForm.create( application );
      GetChoiceForm.Caption := 'Display Death Benefit Report in Emerge';
      GetChoiceForm.Message := 'Do you wish to produce a Death Benefit Report?';
      if isEmerge then
        GetChoiceForm.AddChoice( 'Y - Print Report To Emerge File' )
      else
        GetChoiceForm.AddChoice( 'Y - Print Report' );
      GetChoiceForm.AddChoice( 'P - Preview to Screen' );
      GetChoiceForm.AddChoice( 'N - Do NOT produce report' );
      GetChoiceForm.showmodal;
      rc := GetChoiceForm.Selected;
    finally
      GetChoiceForm.free;
    end;

    try
      if ( rc in [0,1] ) then
      begin
        //
        // First we need to perform a recalc of the claim with a minwage of 0 dollars
        // Save the current claim
        //
        copyNCCLAIM( CalcFullClaim, SaveFullClaim );
        copyNCCLAIM( CalcPartClaim, SavePartClaim );
        ClaimCopied := True;
        DeathBenefitCalc := True;
        CalcFullClaim.Post_Injury_Earn := 0;
        CalcPartClaim.Post_Injury_Earn := 0;
        CalcFullClaim.Collateral_Ben_Tax := 0;
        CalcFullClaim.Collateral_Ben_Non_Tax := 0;
        CalcPartClaim.Collateral_Ben_Tax := 0;
        CalcPartClaim.Collateral_Ben_Non_Tax := 0;
        CalcFullClaim.Minimum_wage_Flag := False;
        CalcFullClaim.Minimum_Wage_Flag_Partial := False;
        CalcPartClaim.Minimum_wage_Flag := False;
        CalcPartClaim.Minimum_Wage_Flag_Partial := False;
        DeathBenefitCalc := False;
        if ( rc = 0 ) then
        begin
          RptDestination := 'P';

          CalcFullClaim.DeathBenefit := 'Y';
          CalcPartClaim.DeathBenefit := 'Y';
          copyNCCLAIM( CalcFullClaim, uSavePrint.CalcFullClaim);
          copyNCCLAIM( CalcPartClaim, uSavePrint.CalcPartClaim);

          if isEmerge then
          begin
            setRecReport( 'WLF1', CalcFullClaim, CalcPartClaim );
          end
          else
          begin
            if ( IsEmergeSet ) and not( IsEmergeUp ) then
              MessageDlg( 'An Emerge Connection Was Not Found.' + chr(10) + chr(13) + 'Report Will Be Sent To The Printer.', mtWarning, [mbOK], 0 );
            PrintReport;
          end;
        end
        else
        begin
          RptDestination := 'S';
          PrintReport;
        end;
      end;

      screen.cursor:=crDefault;

    finally
      screen.cursor:=crDefault;
      //
      // if we successfully copied the claims out then copy them back
      //
      if ClaimCopied Then
      begin
        copyNCCLAIM( SaveFullClaim, CalcFullClaim );
        copyNCCLAIM( SavePartClaim, CalcPartClaim );
      end;
    end;
  end;
end;
(******************************************************************************)
(*                                                                            *)
(*  Form Activate                                                             *)
(*                                                                            *)
(******************************************************************************)
procedure TWagelossBenefitCalcForm.FormActivate(Sender: TObject);
begin
  if ( edRecurrence.Text = 'Y' ) And ( Length( edRecurrenceDate.Text ) = 0 ) Then
     if edRecurrenceDate.Enabled then
        edRecurrenceDate.SetFocus;

  if (upperCase(cboMaritalStatus.Text) = 'DIVORCED')  or
     (upperCase(cboMaritalStatus.Text) = 'SEPARATED') or
     (upperCase(cboMaritalStatus.Text) = 'SINGLE')    or
     (upperCase(cboMaritalStatus.Text) = 'WIDOWED')   then
     begin
     edClaimSpouseForTaxPurposes.Visible := false;
     lblClaimSpouseForTaxPurposes.Visible := false;
     end;

  if lblAccident_Date.Visible Then
     begin
     SetMenuChoices;
     end
  else
     begin
     SetCalcMenuChoices;
     //
     // if the Accident Date on the calculator is blank then assume that we
     // are displaying the form for the first time. Set focus to the acident
     // date and clear any messages.
     //
     if Length( edAccident_Date.Text ) = 0 Then
        begin
        ResetInfoLine2;
        if edAccident_Date.Enabled then
           edAccident_Date.SetFocus;
        end;
     end;

  dm1.qryAverageEarningsBasedOn.Active := True;
  dm1.qryMaritalStatus.Active := True;

end;

//
// Modified April 2003
// Purpose: Modified to allow the Wageloss form to be used as both the calculator
//          and the wageloss form
//
procedure TWagelossBenefitCalcForm.edChild_Care_ExpExit(Sender: TObject);
begin
  if not SetValidate then
    SetInfoLine := True;

  if edChild_Care_Exp.text = '' then
    edChild_Care_Exp.text := '0';

  if ( CalcFullClaim.Child_Care_Exp <> textAsCurrency( edChild_Care_Exp ) ) then
    SetUpdateInd(True);

  edChild_Care_Exp.text := format( '%.2n', [textAsCurrency( edChild_Care_Exp )] );

  ResetInfoLine2;
end;

//
// Modified April 2003
// Purpose: Modified to allow the Wageloss form to be used as both the calculator
//          and the wageloss form
//
procedure TWagelossBenefitCalcForm.edSpousal_SupportExit(Sender: TObject);
begin
  if not SetValidate then
    SetInfoLine := True;

  if edSpousal_Support.Text = '' then
    edSpousal_Support.Text := '0';

  if (CalcFullClaim.Spousal_Support <> textAsCurrency( edSpousal_Support ) ) then
    SetUpdateInd(True);

  edSpousal_Support.text := format( '%.2n',[textAsCurrency( edSpousal_Support )] );

  ResetInfoLine2;
end;

//
// Modified April 2003
// Purpose: Modified to allow the Wageloss form to be used as both the calculator
//          and the wageloss form
//
procedure TWagelossBenefitCalcForm.edCPP_ExemptExit(Sender: TObject);
var
   age: Integer;
   actualBirthYear: Integer;
begin
  if not SetValidate then
    SetInfoLine := true;

  if edCPP_Exempt.Text = '' then
    edCPP_Exempt.Text := 'N';

  edCPP_Exempt.Text := UpperCase( edCPP_Exempt.Text );

  if edCPP_Exempt.Text = 'N' then
  begin
    If lblAccident_Date.Visible Then
    Begin
      actualBirthYear := year( DataClaim.Birth_Date );

      if actualBirthYear <> 1899 then
      begin
        age := year( utilmod1.getEmergeBusinessDate() - DataClaim.Birth_Date ) - 1900;

        if ( age < 18 ) or ( age > 69 ) then
        begin
          MessageDlg( 'Worker is ' + IntToStr( age ) + ' years old.  Confirm CPP exempt status.',
            mtWarning, [mbOK], 0 );
        end;
      end;
    end;
  end;

  if ( CalcFullClaim.CPP_Exempt <> edCPP_Exempt.text ) then
    SetUpdateInd(True);

  ResetInfoLine2;
end;

procedure TWagelossBenefitCalcForm.edCPP_ExemptKeyPress(Sender: TObject; var Key: Char);
begin
  case Key of #0..#31,'y','Y','n','N':
  else
    Key:=#0;
    WagelossMainForm.ShowInfoLine2( '*Valid values for CPP Exempt are Y N' );
  end;
end;

//
// Modified April 2003
// Purpose: Modified to allow the Wageloss form to be used as both the calculator
//          and the wageloss form
//
procedure TWagelossBenefitCalcForm.edTax_ExemptExit(Sender: TObject);
begin
  if not SetValidate then
    SetInfoLine := True;

  if edTax_Exempt.Text = '' then
    edTax_Exempt.text:='N';

  edTax_Exempt.Text := UpperCase( edTax_Exempt.text );

  if ( CalcFullClaim.Tax_Exempt <> edTax_Exempt.text ) then
    SetUpdateInd(True);

  ResetInfoLine2;
end;

procedure TWagelossBenefitCalcForm.edTax_ExemptKeyPress(Sender: TObject; var Key: Char);
begin
  case Key of #0..#31,'y','Y','n','N':
  else
    Key:=#0;
    WagelossMainForm.ShowInfoLine2( '*Valid values for Income Tax Exempt are Y N' );
  end;
end;

//
// Modified April 2003
// Purpose: Modified to allow the Wageloss form to be used as both the calculator
//          and the wageloss form
//
procedure TWagelossBenefitCalcForm.edMax_AdjustmentsExit(Sender: TObject);
var
   TestMax_Adjustments, Annual_Max, Annual_Min, Self_Employed_Max_Adj, nc_index_amt : Currency;
   iii, TestTax_Year, accidentYear, nc_cnt, nc_Index_Year : Integer;
   theYear, Month, Day, Test_Accident_Year : Word;
   Accident_Month, Accident_Day, Accident_Year : Word;
   iAccident_Date, iRecurrence_Date : TDateTime;
   strAnnualMax : String;
begin
  if not SetValidate then
    SetInfoLine := True;

  if edMax_Adjustments.Text = '' then
    edMax_Adjustments.Text := '0';
  //
  // Added to test the Max adjustments on exit
  //
  TestMax_Adjustments := TextAsCurrency(edMax_Adjustments);
  //
  // LRC Bill 18
  //
  if (edRecurrence.Text = 'Y') then
     iRecurrence_Date := StrToDate(edRecurrenceDate.Text)
  else
     iRecurrence_Date := 0;

  isIndexation := CalcFullClaim.Indexation_Year <> 0;

  if (Year(CalcFullClaim.Accident_Date) < 2006)  OR
     (Year(CalcFullClaim.Accident_Date) >= 2022) then
     begin
     Annual_Max := getMaxAdjustment(CalcFullClaim.Accident_Date, iRecurrence_Date, CalcFullClaim.Indexation_Year, edRecurrence.Text, edSelf_Employed.Text);
     Annual_Min := getMinAdjustment(CalcFullClaim.Accident_Date, iRecurrence_Date, CalcFullClaim.Indexation_Year, edRecurrence.Text, edSelf_Employed.Text);
     if (TestMax_Adjustments > Annual_Max) then
        begin
        strAnnualMax := '*Max Adj amount must be >= $' + format('%.2n', [Annual_Min]) + ' and <= $' + format('%.2n',[Annual_Max]);
        globalEditError := displayError(strAnnualMax, edMax_Adjustments);
        exit;
        end;
     if (TestMax_Adjustments < Annual_Min) then
        begin
        strAnnualMax := '*Max Adj amount must be >= $' + format('%.2n', [Annual_Min]) + ' and <= $' + format('%.2n',[Annual_Max]);
        globalEditError := displayError(strAnnualMax, edMax_Adjustments);
        exit;
        end;
     end
  else
     begin
     strAnnualMax := isSelfEmployedAdjInRange(TestMax_Adjustments, CalcFullClaim,
                                              isIndexation, edMax_Adjustments,
                                              Trim(edRecurrence.Text), Trim(edSelf_Employed.Text),
                                              CalcFullClaim.Indexation_Year, iRecurrence_Date);
     if strAnnualMax <> EmptyStr  then
        begin
        globalEditError := displayError(strAnnualMax , edMax_Adjustments );
        globalEditError := True;
        exit;
        end;

     end;

  //
  // iof we've successfully tested for the max then the self employed check has been done
  //
  blnSelfEmpTestDone := true;
  //
  // End Modification
  //
  if (CalcFullClaim.Max_Adjustment <> textAsCurrency(edMax_Adjustments)) then
    SetUpdateInd(True);

  edMax_Adjustments.text := format('%.2n',[textAsCurrency(edMax_Adjustments)]);

  if NextMaxAdjTab <> nil then
     begin
     if NextMaxAdjTab.Enabled then
        NextMaxAdjTab.SetFocus;
     NextMaxAdjTab := nil;
     end;

  ResetInfoLine2;

  if blnCheck_Year Then
     edTax_YearExit( edTax_Year );

end;

//
// Modified April 2003
// Purpose: Modified to allow the Wageloss form to be used as both the calculator
//          and the wageloss form
//
procedure TWagelossBenefitCalcForm.edRecurrenceExit(Sender: TObject);
begin
  if not SetValidate then
    SetInfoLine := True;

  edRecurrence.Text := UpperCase( edRecurrence.text );

  // Force the Default
  if edRecurrence.Text='' then
    edRecurrence.Text:='N';

  //
  // data has changed so allow an update
  //
  if ( CalcFullClaim.Recurrence <> edRecurrence.text ) then
    SetUpdateInd(True);

  if ( edRecurrence.Text = 'Y' ) and Not edRecurrenceDate.Visible then
  begin
    edRecurrenceDate.Visible := True;
    If Length( edRecurrenceDate.text ) < 1 then
    begin
      if edRecurrenceDate.Enabled then
        edRecurrenceDate.setfocus;
      WagelossMainForm.ShowInfoLine2( '?Please enter a Recurrence Date.' );
      exit;
    end;
  end
  else
  begin
    if (edRecurrence.Text = 'N') And edRecurrenceDate.Visible Then
    begin
      edRecurrenceDate.text := '';
      edRecurrenceDate.Visible := False;
    end;
  end;

  ResetInfoLine2;
  //
  // Force an edit of the tax year if we have set the Recurrence to false
  //
  if ( edRecurrence.text = 'N' ) Then
  Begin
    edTax_YearExit( edTax_Year );
  End;
end;

//
// Modified April 2003
// Purpose: Modified to allow the Wageloss form to be used as both the calculator
//          and the wageloss form
//
procedure TWagelossBenefitCalcForm.edSelf_EmployedExit(Sender: TObject);
var
  strMessage, S, strAnnualMax : String;
  bValid, SaveGlobalErrorStatus : boolean;
  Annual_Max, Annual_Min: Currency;
  iAccident_Year, iYear, iAccident_Month, iAccident_Day, K : Word;
  iAccident_Date, iRecurrence_Date : TDateTime;
  iTax_Year, lngAccidentMonth : Integer;
begin
  if not SetValidate then
    SetInfoLine := True;

  edSelf_Employed.Text := UpperCase(edSelf_Employed.Text);

  if edSelf_Employed.Text = '' then
    edSelf_Employed.Text := 'N';

  if (CalcFullClaim.Self_Employed <> edSelf_Employed.Text) then
     begin
     SetUpdateInd(True);
     end;

  if (edSelf_Employed.Text = 'N') then
     begin
     setEditToRead(edMax_Adjustments);
     end;

  strMessage := 'Do you wish to change the Max Adjustment amount?';
  
  if (edSelf_Employed.text = 'Y') and
     (not blnSelfEmpTestDone)     and
     (not setValidate)            then
     begin
     blnSelfEmpTestDone := true;
     if MessageDlg(strMessage, mtInformation, [mbYes, mbNo], 0, mbNo) = mrYes then
        begin
        //
        // LRC Bill 18
        //
        if (edRecurrence.Text = 'Y') then
           iRecurrence_Date := StrToDate(edRecurrenceDate.Text)
        else
           iRecurrence_Date := 0;

        Annual_Max := getMaxAdjustment(CalcFullClaim.Accident_Date, iRecurrence_Date, CalcFullClaim.Indexation_Year, edRecurrence.Text, edSelf_Employed.Text);
        Annual_Min := getMinAdjustment(CalcFullClaim.Accident_Date, iRecurrence_Date, CalcFullClaim.Indexation_Year, edRecurrence.Text, edSelf_Employed.Text);

        strAnnualMax := '?Max Adj amount must be >= ' + format('%.2n', [Annual_Min]);
        if (Annual_Max > 0) then
           begin
           strAnnualMax := strAnnualMax + ' and <= ' + format('%.2n', [Annual_Max]);
           end;

        WagelossMainForm.ShowInfoLine2(strAnnualMax);
        edMax_Adjustments.Text := '0.00';

        S := '';
        if WagelossMainForm.isRunManualTest then
           if not isIndexation then
              S := FloatToStr(dm1.qryQAData.FieldByName('Full_Annual_Gross').AsFloat);

        setEditToNormal(edMax_Adjustments);
        NextMaxAdjTab := FindNextControl(Sender as TWinControl, true, true, false);
        if edMax_Adjustments.Enabled then
           edMax_Adjustments.SetFocus;
        globalEditError := true;
        //***
        if WagelossMainForm.isRunManualTest then
           if not isIndexation then
              edMax_Adjustments.Text := format('%.2n', [dm1.qryQAData.FieldByName('Full_Annual_Gross').AsFloat]);
        //***
        end // Message mrYes
     else
        begin
        setEditToRead(edMax_Adjustments);
        end;
     end
  else if (allowUpdateClaim) then
     begin
     blnRecurrence_Set := true;
     edTax_YearExit(edTax_Year);
     end; //end of self employed

  //ResetInfoLine2;
end;

//
// Modified to set the blnRecurrence_Set flag to indicate that the recurence date has been
// set to a Y. this will indicate whether we should allow a change to the max
//
procedure TWagelossBenefitCalcForm.edRecurrenceKeyPress(Sender: TObject; var Key: Char);
begin
  case Key of
  #0..#31:
     ;
  'y','Y','n','N':
        begin
        blnRecurrence_Set := ( Key = 'y' ) OR ( Key = 'Y' );
          if ( Key = 'n' ) or ( Key = 'N' )then
          begin
            edEffectiveDate.Text := '';
          end;
        end;
  else
    Key := #0;
    WagelossMainForm.ShowInfoLine2( '*Valid values for Recurrence are Y N' );
  end;
end;

procedure TWagelossBenefitCalcForm.edSelf_EmployedKeyPress(Sender: TObject;
  var Key: Char);
begin
  case Key of #0..#31,'y','Y','n','N':
     begin
     if Key in ['y', 'Y', 'n', 'N'] then
        begin
        if (TEdit(Sender).Text <> 'Y') And (UpperCase(Key) = 'Y') then
           begin
           edMax_Adjustments.Text := '0.00';
           end;
        blnSelfEmpTestDone := false;
        end;
     end
  else
    Key := #0;
    WagelossMainForm.ShowInfoLine2( '*Valid values for Self Employed are Y N' );
  end;
end;

//
// Modified by D. Madill
// Date: March 5, 2003
// Purpose: Modified to ensure that the Recurrence date cannot be a future date
//
procedure TWagelossBenefitCalcForm.edRecurrenceDateExit(Sender: TObject);
var
   Work_Date, Test_Accident_Date : TDateTime;
   iTax_Year, lngAccidentYear, lngAccidentMonth : Integer;
   iAccident_Year, iYear, iMonth, iDay : Word;
   TestMax_Adjustments, Annual_Max, Annual_Min: Currency;
   strAnnualMax:String;
   SaveGlobalErrorStatus:Boolean;
Begin
  if not setvalidate then
    setinfoline := true;
  //
  // make sure a recurrence date was entered
  //
  if Length(edRecurrenceDate.Text) < 1 then
     begin
     globalEditError := displayError( '*Please enter a Recurrence Date.', edRecurrenceDate );
     exit;
     end;

  if not ValidateAsDate(edRecurrenceDate) then
     begin
     globalEditError := displayError( '*Invalid Recurrence Date', edRecurrenceDate );
     exit;
     end;

  //
  // If we have a valid date then format the field to conform to a proper
  // datetime format in the text box
  //

  if (TextAsDate(edRecurrenceDate) > 0) then
     edRecurrenceDate.text := formatdatetime( 'c',textAsDate( edRecurrenceDate ) )
  else
     edRecurrenceDate.text := '';
  //
  // Ensure the Recurrence date is less than or equal to the current date
  // We can't plan accidents
  //
  Work_Date := StrtoDate( edRecurrenceDate.Text );

  if (Work_Date > utilmod1.getEmergeBusinessDate()) Then
     Begin
     globalEditError := displayError( '*Recurrence Date must be less than or equal to the current date', edRecurrenceDate );
     exit;
     end;
  //
  // Ensure the Recurrence date is greater than or equal to the accident date
  // We can't have a recurrence before the original accident
  //
  Work_Date := StrtoDate(edRecurrenceDate.Text);
  if (Work_Date <= StrtoDate(lblAccident_Date.Caption)) Then
     begin
     globalEditError := displayError( '*Recurrence Date must be after the Incident Date', edRecurrenceDate );
     exit;
     end;

  //
  // Make sure the tax year is on or after the recurrence year
  //
  if Length(edTax_Year.Text) > 0 then
     begin
     if ( StrtoInt(edTax_Year.Text) < Year(StrtoDate(edRecurrenceDate.Text))) Then
        begin
        globalEditError := displayError( '*Tax year must be on or after year of the recurrence', edTax_Year );
        exit;
        end;

     if (StrToInt(edTax_Year.Text) > Year(StrtoDate(edRecurrenceDate.Text)))   And
        (StrToInt(edTax_Year.Text) > Year(CalcFullClaim.Accident_Date))        And
        ((StrtoInt(lblIndexation_Year.Caption) = 0)                            OR
         (StrToInt(edTax_Year.Text) > (StrtoInt(lblIndexation_Year.Caption)))) then
        begin
        globalEditError := displayError( '*Invalid Tax year/Incident year/recurrence year combination', edTax_Year );
        exit;
        end;
     end;

  if ((edRecurrence.Text = 'Y') and (edRecurrenceDate.Text <> '')) then
     begin
     if edEffectiveDate.Enabled then
        edEffectiveDateExit(edEffectiveDate);
     if globalEditError then
        exit;
     edEffectiveDate.Text := FormatDateTime( 'dd/mm/yyyy', Max( CalcFullClaim.Indexation_Calc_Date, Max( StrToDate( edEffectiveDate.Text ), StrToDate( edRecurrenceDate.Text ) ) ) );
     end;

  //
  // if we've changed the recurrence date then allow for a change to the
  // max of the claim
  //

  TestMax_Adjustments := TextAsCurrency(edMax_Adjustments);
  Annual_Max := getMaxAdjustment(CalcFullClaim.Accident_Date, StrToDate(edRecurrenceDate.Text), CalcFullClaim.Indexation_Year, edRecurrence.Text, edSelf_Employed.Text);
  Annual_Min := getMinAdjustment(CalcFullClaim.Accident_Date, StrToDate(edRecurrenceDate.Text), CalcFullClaim.Indexation_Year, edRecurrence.Text, edSelf_Employed.Text);

  if (edSelf_Employed.Text = 'Y') then
     begin
     strAnnualMax := '';

     if Annual_Max > 0 then
        begin
        if (TestMax_Adjustments < Annual_Min) OR (TestMax_Adjustments > Annual_Max) then
           begin
           strAnnualMax := '?Max Adj amount must be >= ' + format('%.2n', [Annual_Min]) + ' and <= ' + format('%.2n', [Annual_Max]);
           end;
        end
     else
        begin
        if (TestMax_Adjustments < Annual_Min) then
           begin
           strAnnualMax := '?Max Adj amount must be >= ' + format('%.2n', [Annual_Min]);
           end;
        end;

     if setValidate and (Length(strAnnualMax) > 0) then
        begin
        setEditToNormal(edMax_Adjustments);
        displayError(strAnnualMax, edMax_Adjustments);
        exit;
        end
     else if (Length(strAnnualMax) > 0) then
        begin
        if MessageDlg('Do you wish to change the Max Adjustment amount?', mtConfirmation, [mbYes, mbNo], 0, mbNo) = mrYes then
           begin
           WagelossMainForm.ShowInfoLine2(strAnnualMax);
           setEditToNormal(edMax_Adjustments);
           edMax_Adjustments.Text := format('%.2n',[TestMax_Adjustments]);
           edMax_Adjustments.SetFocus;
           exit;
           end
        else
           begin
           setEditToRead(edMax_Adjustments);
           end
        end;
     end
  else
     begin
     edMax_Adjustments.Text := format('%.2n',[Annual_Max]);
     end;


  if (CalcFullClaim.RecurrenceDate <> StrtoDate(edRecurrenceDate.Text)) then
    begin
    SetUpdateInd(True);
    end;

  blnCheck_Year := True;

  ResetInfoLine2;
end;

(******************************************************************************)
(*                                                                            *)
(*  Fill in form from claim record(s) for recurrences                         *)
(*                                                                            *)
(******************************************************************************)
procedure TWagelossBenefitCalcForm.fillInFormRecurrence;
begin
  with CalcFullClaim do
  begin
    lblClaim_No.caption := Claim_No;
    lblClaim_Suffix.caption := Claim_Suffix;
    lblClmnts_Name.caption := pdoxTrim( Clmnts_1st_Name ) + ' ' + pdoxTrim( Clmnts_Surname );
    lblClmnts_Add_No_1.caption := Clmnts_Add_No_1;
    lblClmnts_Add_No_2.caption := Clmnts_Add_No_3;
    lblSIN.caption := SIN;
    if Birth_Date > 0 then
      lblBirth_Date.caption := formatdatetime( 'c', Birth_Date )
    else
      lblBirth_Date.caption := '';
    lblClmnts_Post_Code.caption := Clmnts_Post_Code;
    lblClmnts_Home_Phone.caption := Clmnts_Home_Phone;
    lblClmnts_Work_Phone.caption := Clmnts_Work_Phone;
    if Accident_Date > 0 then
      lblAccident_Date.caption := formatdatetime( 'c',Accident_Date )
    else
      lblAccident_Date.caption := '';
    if Loss_Earn_Date > 0 then
      lblLoss_Earn_Date.caption := formatdatetime( 'c',Loss_Earn_Date )
    else
      lblLoss_Earn_Date.caption := '';

    //Added Emerge R4
    if effectiveDate > 0 then
      edEffectiveDate.Text := formatdatetime( 'c',effectiveDate )
    else
      edEffectiveDate.Text := '';

    edWkly_Sal_A.text := format( '%.2n', [ Wkly_Sal_A ] );
    edDays_Worked_per_Week.text := format( '%.2n', [ Days_Worked_per_Week ] );
    cboAverageEarningsBasedOn.KeyValue := AverageEarningsBasedOn;
    edTax_Year.text := format( '%d', [ Tax_Year ] );
    lblIndexation_Year.caption := format( '%d', [ Indexation_Year ] );

    // New fields for 2000 policy changes
    edSelf_Employed.text := Self_Employed;
    edRecurrence.text := Recurrence;
    edYouthful_Worker.Text := Youthful_Worker;
    edApprentice.Text := Apprentice;
    edCPP_Exempt.text := CPP_Exempt;
    edTax_Exempt.text := Tax_Exempt;
    edChild_Care_Exp.text := format( '%.2n', [ Child_Care_Exp ] );
    edSpousal_Support.text := format( '%.2n', [ Spousal_Support ] );

    if year( Accident_Date ) < 2001 then
       begin
       setEditToRead( edChild_Care_Exp );
       setEditToRead( edSpousal_Support );
       end;

    edMax_Adjustments.text := format( '%.2n', [ Max_Adjustment ] );

    if (Max_Adjustment = 0) or (Self_Employed = 'N') or (year( Accident_Date ) <= 2006) then
       begin
       setEditToRead(edMax_Adjustments);
       end;

    cboMaritalStatus.KeyValue := Marital_Status;
    edEI_Exempt.text := EI_Exempt;
    edNo_Of_Dependnts.text := format( '%d',[No_Of_Dependnts] );
    edNo_Infirm.text := format( '%d',[No_Infirm] );
    edSpouse_Working.text := Spouse_Working;
    edClaimSpouseForTaxPurposes.Text := ClaimSpouseForTaxPurposes;
    if nc_104_Wk_Effective_Date > 0 then
      ednc_104_Wk_Effective_Date.text := formatdatetime( 'c', nc_104_Wk_Effective_Date )
    else
      ednc_104_Wk_Effective_Date.text := '';
    ednc_104_Wk_Clmt_p_Contrib.text := format( '%.2n',[ nc_104_Wk_Clmt_p_Contrib ] );
    if nc_104_Wk_Clmt_p_Eff_Date > 0 then
      ednc_104_Wk_Clmt_p_Eff_Date.text := formatdatetime( 'c', nc_104_Wk_Clmt_p_Eff_Date )
    else
      ednc_104_Wk_Clmt_p_Eff_Date.text := '';
    lblnc_104_Wk_Clmt_p_Contrib.caption := format( '%.2n', [ nc_104_Wk_Clmt_p_Contrib ] );
    ednc_104_Wk_WCB_p_Contrib_Red.text := format( '%.2n', [ nc_104_Wk_WCB_p_Contrib_Red ] );
    ed_WCB_Annuity_Contr.Text := format( '%.2n', [ nc_104_Wk_WCB_p_Contrib ] );
  end;

  RecurrenceExitProc;
end;

procedure TWagelossBenefitCalcForm.RecurrenceExitProc;
Begin
  if not setvalidate then
     setinfoline := true;
  SetOldRecurrenceInd( 'N' );
  if ( edRecurrence.text = 'Y' ) and ( GetOldRecurrenceInd = 'N' ) then
  begin
    edRecurrenceDate.Visible := True;
    If Length( edRecurrenceDate.text ) < 1 then
    begin
      WagelossMainForm.ShowInfoLine2( '*Please enter a Recurrence Date.' );
    end;
  end;
end;

procedure TWagelossBenefitCalcForm.ScrollBox1MouseWheelUp(Sender: TObject;
  Shift: TShiftState; MousePos: TPoint; var Handled: Boolean);
Const
   iScroll_Increment = 15;
var
   iScroll:Integer;
begin
  If scrollbox1.VertScrollBar.position > 0 Then
  Begin
    if  scrollbox1.VertScrollBar.position > iScroll_Increment Then
      iScroll := scrollbox1.VertScrollBar.position - 15
    else
      iScroll := 0;
    scrollbox1.VertScrollBar.position := iScroll;
  End;

  Handled := True;
end;

procedure TWagelossBenefitCalcForm.ScrollBox1MouseWheelDown(
  Sender: TObject; Shift: TShiftState; MousePos: TPoint; var Handled: Boolean);
Const
   iScroll_Increment = 15;
var
   iScroll:Integer;
begin
  if scrollbox1.VertScrollBar.position < scrollbox1.VertScrollBar.range Then
  Begin
    if scrollbox1.VertScrollBar.position <  (scrollbox1.VertScrollBar.range - iScroll_Increment) Then
      iScroll := scrollbox1.VertScrollBar.position + 15
    else
      iScroll := scrollbox1.VertScrollBar.range;
    scrollbox1.VertScrollBar.position := iScroll;
  End;

  Handled := True;
end;

procedure TWagelossBenefitCalcForm.edAccident_DateKeyPress(Sender: TObject;
  var Key: Char);
begin
  case Key of #0..#31,'0'..'9','/','.':
  else
    Key:=#0;
  end;
end;

procedure TWagelossBenefitCalcForm.edAccident_DateExit(Sender: TObject);
Begin
  if not SetValidate then
     begin
     SetInfoLine := True;
     end;
  //
  // make sure an Accident date was entered
  //
  if Length(edAccident_Date.text) < 1 then
     begin
     globalEditError := displayError('*Please enter an Incident Date.', edAccident_Date);
     exit;
     end;

  if not ValidateAsDate(edAccident_Date) Then
     begin
     globalEditError := displayError('*Invalid Incident Date', edAccident_Date);
     exit;
     end;

  //
  // If we have a valid date then format the field to conform to a proper
  // datetime format in the text box
  //
  if (TextAsDate(edAccident_Date) > 0) then
     begin
     //edAccident_Date.Text := FormatDateTime('c',textAsDate(edAccident_Date));
     edAccident_Date.Text := FormatDateTime('ddddd',textAsDate(edAccident_Date));
     end
  else
     begin
     edAccident_Date.text := '';
     end;

  // fill in the fields for the calculation
  lblAccident_Date.Caption := edAccident_Date.Text; // set the label
  CalcFullClaim.Accident_Date := StrtoDate(edAccident_Date.Text);

  //***
  if WagelossMainForm.isTestCalculator then
     edClaimPrefix.Text := RightStr(Trim(edAccident_Date.Text),2);
  //***

  //
  // if we are in the calculator and the user enters an accident date that
  // if after 2001, then enable the Child Care, Spousal Support and Child Support
  // payment boxes and vica versa. Ensure that if we are changing the
  // status of the edit box make sure we clear the contents of the box
  //
  if year( StrtoDate( edAccident_Date.Text ) ) < 2001 then
  begin
    if Not edChild_Care_Exp.ReadOnly then
    Begin
      edChild_Care_Exp.Text := '0';
      edSpousal_Support.Text := '0';
    end;
    setEditToRead( edChild_Care_Exp );
    setEditToRead( edSpousal_Support );
  end
  else
  Begin
    if edChild_Care_Exp.ReadOnly then
    Begin
      edChild_Care_Exp.Text := '0';
      edSpousal_Support.Text := '0';
    end;
    setEditToNormal( edChild_Care_Exp );
    setEditToNormal( edSpousal_Support );
  End;

  //
  // check to see if we have an accident date after Jan 1, 2006. If we do
  // then set the Net Actual Label to read 100% otherwise 90%
  //
  if year( StrtoDate( edAccident_Date.Text ) ) >= 2006 then
  begin
    lbl80NetLoss.Visible := False;
    lblWeekly_80.Visible := False;
    lbl80NetLossPartial.Visible := False;
    lblPartWeekly_80.Visible := False;
    lblWCBAnnuityContr.Caption := 'Employer Annuity Contribution:';
    ed_WCB_Annuity_Contr.Visible := true;
    lblCalc2nc_104_Wk_WCB_p_Contrib_Red.Visible := false;
  end
  else
  begin
    lblNetActual.Caption := '90% Net Actual';
    lblNetLoss.Caption := '90% Net Actual';
    lblNetSheltered.Caption := '90% Net Actual';
    lblWCBAnnuityContr.Caption := 'WCB Annuity Reduction:';
    ed_WCB_Annuity_Contr.Visible := false;
    lblCalc2nc_104_Wk_WCB_p_Contrib_Red.Visible := true;
    lbl80NetLoss.Visible := True;
    lblWeekly_80.Visible := True;
    lblWkly_Clmt_Anty_Con_Amt.Visible := True;
    lblCalcWkly80p_Net_Clmt_Contr.Visible := True;
    lblCalcWkly_p_WCB_Contr.Visible := True;
    lblDaily80FullCompensationRate.Visible := True;
    lblnc_104_Wk_Clmt_p_Contrib.Visible := True;
    lblCalcnc_104_Wk_WCB_p_Contrib_Red.Visible := True;
    lbl80PercentClaimantContrib.Visible := True;
    lbl80PercentClaimContribution.Visible := True;
    lbl80PercentWCBContribution.Visible := True;
    lbl80DailyCompRate.Visible := True;
    { //***

    lblPart_Calcnc_104_Wk_WCB_p_Contrib_Red.Visible := True;
    lbl80NetLossPartial.Visible := True;
    lbl80PercentClaimantContribPartial.Visible := True;
    lbl80PercentClaimContributionPartial.Visible := True;
    lbl80PercentWCBContributionPartial.Visible := True;
    lbl80DailyCompRatePartial.Visible := True;
    lblPart_nc_104_Wk_Clmt_p_Contrib.Visible := True;
    lblPartWeekly_80.Visible := True;
    lblPartWkly_Clmt_Anty_Con_Amt.Visible := True;
    lblPartCalcWkly80p_Net_Clmt_Contr.Visible := True;
    lblPartCalcWkly_p_WCB_Contr.Visible := True;
    lblPartDaily80CompensationRate.Visible := True;
    *** }
    if not WagelossMainForm.isRunManualTest then //***
    begin
      lblPart_Calcnc_104_Wk_WCB_p_Contrib_Red.Visible := True;
      lbl80NetLossPartial.Visible := True;
      lbl80PercentClaimantContribPartial.Visible := True;
      lbl80PercentClaimContributionPartial.Visible := True;
      lbl80PercentWCBContributionPartial.Visible := True;
      lbl80DailyCompRatePartial.Visible := True;
      lblPart_nc_104_Wk_Clmt_p_Contrib.Visible := True;
      lblPartWeekly_80.Visible := True;
      lblPartWkly_Clmt_Anty_Con_Amt.Visible := True;
      lblPartCalcWkly80p_Net_Clmt_Contr.Visible := True;
      lblPartCalcWkly_p_WCB_Contr.Visible := True;
      lblPartDaily80CompensationRate.Visible := True;
    end;

  end;
  //***
  //if  not WagelossMainForm.isRunManualTest then
  if  WagelossMainForm.isTestCalculator then
     if not isInTestEditMode  then
        edQATestID.Text := IntToStr( uSavePrint.GetNextQATestID( year( StrtoDate( edAccident_Date.Text ) ) ) );
  //***
  ResetInfoLine2;
end;

procedure TWagelossBenefitCalcForm.SaveRecurrenceDate;
begin
  try
    With dm1.usp_Save_Recurrence_Date do
    begin
      Parameters.ParamByName( '@Claim_No' ).Value := dataClaim.Claim_No;
      Parameters.ParamByName( '@Recurrence_Date' ).Value := dataClaim.RecurrenceDate;
      Parameters.ParamByName( '@Active' ).Value := dataClaim.Recurrence;
      Parameters.ParamByName( '@Current_User' ).Value := CurrUserName;
      ExecProc;
    end;
  except
    begin
      WagelossMainForm.ShowInfoLine2( '*Failure to Save Recurrence Date' );
      if edRecurrenceDate.Enabled then
        edRecurrenceDate.SetFocus;
      globalEditError := True;
    end;
  end;
end;

procedure TWagelossBenefitCalcForm.SaveYouthful_Worker;
begin
  try
    With dm1.usp_Save_Youthful_Worker do
    begin
      Parameters.ParamByName( '@Claim_No' ).Value := dataClaim.Claim_No;
      Parameters.ParamByName( '@Youthful_Worker' ).Value := dataClaim.Youthful_Worker;
      Parameters.ParamByName( '@Active' ).Value := 'Y';
      Parameters.ParamByName( '@Current_User' ).Value := CurrUserName;
      ExecProc;
    end;
  except
    Begin
      WagelossMainForm.ShowInfoLine2( '*Failure to Save Youthful Worker' );
      if edYouthful_Worker.Enabled then
        edYouthful_Worker.SetFocus;
      globalEditError := True;
    end;
  end;
end;

procedure TWagelossBenefitCalcForm.SaveApprentice;
begin
  try
    With dm1.usp_Save_Apprentice do
    begin
      Parameters.ParamByName( '@Claim_No' ).Value := dataClaim.Claim_No;
      Parameters.ParamByName( '@Apprentice' ).Value := dataClaim.Apprentice;
      Parameters.ParamByName( '@Active' ).Value := 'Y';
      Parameters.ParamByName( '@Current_User' ).Value := CurrUserName;
      ExecProc;
    end;
  except
    Begin
      WagelossMainForm.ShowInfoLine2( '*Failure to Save Apprentice' );
      if edApprentice.Enabled then
        edApprentice.SetFocus;
      globalEditError := True;
    end;
  end;
end;

procedure TWagelossBenefitCalcForm.SaveTaxableCollateral;
begin
  try
    With dm1.usp_Save_TaxableCollateralSource do
    begin
      Parameters.ParamByName( '@Claim_No' ).Value := dataClaim.Claim_No;
      Parameters.ParamByName( '@CPPQPP' ).Value := dataClaim.TaxCollBen_CPPQPP;
      Parameters.ParamByName( '@EI' ).Value := DataClaim.TaxCollBen_EI;
      Parameters.ParamByName( '@DisabilityInsurance' ).Value := DataClaim.TaxCollBen_DisabilityIns;
      Parameters.ParamByName( '@EmployerTopUp' ).Value := DataClaim.TaxCollBen_EmpTopUp;
      Parameters.ParamByName( '@Combination' ).Value := DataClaim.TaxCollBen_Combination;
      Parameters.ParamByName( '@Current_User' ).Value := CurrUserName;
      ExecProc;
    end;
  except
    Begin
      WagelossMainForm.ShowInfoLine2( '*Failure to Save Taxable Collateral Benefits' );
      globalEditError := True;
    end;
  end;
end;

procedure TWagelossBenefitCalcForm.SaveNonTaxableCollateral;
begin
  try
    With dm1.usp_Save_NonTaxableCollateralSource do
    begin
      Parameters.ParamByName( '@Claim_No' ).Value := dataClaim.Claim_No;
      Parameters.ParamByName( '@EmpTopUp' ).Value := dataClaim.NonTaxCollBen_EmpTopUp;
      Parameters.ParamByName( '@PrivateIns' ).Value := DataClaim.NonTaxCollBen_PrivateIns;
      Parameters.ParamByName( '@Current_User' ).Value := CurrUserName;
      ExecProc;
    end;
  except
    Begin
      WagelossMainForm.ShowInfoLine2( '*Failure to Save Non-Taxable Collateral Benefits' );
      globalEditError := True;
    end;
  end;
end;


procedure TWagelossBenefitCalcForm.Save_Weekly_Sal_History(Claim_No:String;
                                                           Index_Year:integer;
                                                           New_Weekly_Wage,
                                                           Old_Weekly_Wage:Currency);
begin
  try
    With dm1.usp_Save_Weekly_Sal_History do
    begin
      Parameters.ParamByName( '@Claim_No' ).Value := dataClaim.Claim_No;
      Parameters.ParamByName( '@Index_Year' ).Value := Index_Year;
      Parameters.ParamByName( '@New_Weekly_Wage' ).Value := New_Weekly_Wage;
      Parameters.ParamByName( '@Old_Weekly_Wage' ).Value := Old_Weekly_Wage;
      Parameters.ParamByName( '@Current_User' ).Value := CurrUserName;
      ExecProc;
    end;
  except
    Begin
      WagelossMainForm.ShowInfoLine2( '*Failure to Save Indexed Weekly Salary' );
      globalEditError := True;
    end;
  end;
end;

procedure TWagelossBenefitCalcForm.edClmnts_NameExit(Sender: TObject);
begin
  lblClmnts_Name.Caption := edClmnts_Name.Text;
  CalcFullClaim.Clmnts_1st_Name := edClmnts_Name.Text;
  CalcPartClaim.Clmnts_1st_Name := edClmnts_Name.Text;
end;

procedure TWagelossBenefitCalcForm.edClaimSpouseForTaxPurposesExit(Sender: TObject);
begin
  if not SetValidate then
     SetInfoLine := True;

  edClaimSpouseForTaxPurposes.Text := UpperCase(edClaimSpouseForTaxPurposes.Text);

  if (edSpouse_Working.Text = 'N') AND (Trim(edClaimSpouseForTaxPurposes.Text) = '')then
     begin
     globalEditError := displayError( '*Claim Spouse as a Dependent for Income Tax Purposes must be either Y or N.', edClaimSpouseForTaxPurposes);
     exit;
     end;

  if (CalcFullClaim.ClaimSpouseForTaxPurposes <> edClaimSpouseForTaxPurposes.Text) then
     begin
     SetUpdateInd(True);
     CalcFullClaim.ClaimSpouseForTaxPurposes := edClaimSpouseForTaxPurposes.Text;
     end;

  ResetInfoLine2;
end;

procedure TWagelossBenefitCalcForm.edClaimSpouseForTaxPurposesKeyPress(
  Sender: TObject; var Key: Char);
begin
  case Key of
  #0..#31:
     ;
  'y','Y','n','N':
     ;
  else
    Key:=#0;
    WagelossMainForm.ShowInfoLine2( '*Valid values for Claim Spouse For Tax Purposes are Y N' );
  end;
end;

procedure TWagelossBenefitCalcForm.edClmnts_Add_No_1Exit(Sender: TObject);
begin
  lblClmnts_Add_No_1.Caption := edClmnts_Add_No_1.Text;
  CalcFullClaim.Clmnts_Add_No_1 := edClmnts_Add_No_1.Text;
  CalcPartClaim.Clmnts_Add_No_1 := edClmnts_Add_No_1.Text;
end;

procedure TWagelossBenefitCalcForm.edClmnts_Add_No_2Exit(Sender: TObject);
begin
  lblClmnts_Add_No_2.Caption := edClmnts_Add_No_2.Text;
  CalcFullClaim.Clmnts_Add_No_2 := edClmnts_Add_No_2.Text;
  CalcPartClaim.Clmnts_Add_No_2 := edClmnts_Add_No_2.Text;
end;

procedure TWagelossBenefitCalcForm.edClmnts_Post_CodeExit(Sender: TObject);
begin
  lblClmnts_Post_Code.Caption := edClmnts_Post_Code.Text;
  CalcFullClaim.Clmnts_Post_Code := edClmnts_Post_Code.Text;
  CalcPartClaim.Clmnts_Post_Code := edClmnts_Post_Code.Text;
end;

procedure TWagelossBenefitCalcForm.edSINExit(Sender: TObject);
begin
  lblSIN.Caption := edSIN.Text;
  CalcFullClaim.SIN := edSIN.Text;
  CalcPartClaim.SIN := edSIN.Text;
end;

procedure TWagelossBenefitCalcForm.edBirth_DateExit(Sender: TObject);
begin
  if Length( edBirth_Date.text ) < 1 then
  begin
    Exit;
  end;

  if not ValidateAsDate( edBirth_Date ) then
  begin
    globalEditError := displayError( '*Invalid Birth Date', edBirth_Date );
    Exit;
  end;

  if ( TextAsDate( edBirth_Date ) > 0 ) then
    edBirth_Date.text := formatdatetime( 'c', textAsDate( edBirth_Date ) )
  else
    edBirth_Date.text := '';

  lblBirth_Date.Caption := edBirth_Date.Text;
  CalcFullClaim.Birth_Date := StrtoDate( edBirth_Date.Text );
  CalcPartClaim.Birth_Date := StrtoDate( edBirth_Date.Text );
end;

procedure TWagelossBenefitCalcForm.edClmnts_Home_PhoneExit(Sender: TObject);
begin
  lblClmnts_Home_Phone.Caption := edClmnts_Home_Phone.Text;
  CalcFullClaim.Clmnts_Home_Phone := edClmnts_Home_Phone.Text;
  CalcPartClaim.Clmnts_Home_Phone := edClmnts_Home_Phone.Text;
end;

procedure TWagelossBenefitCalcForm.edClmnts_Work_PhoneExit(Sender: TObject);
begin
  lblClmnts_Work_Phone.Caption := edClmnts_Work_Phone.Text;
  CalcFullClaim.Clmnts_Work_Phone := edClmnts_Work_Phone.Text;
  CalcPartClaim.Clmnts_Work_Phone := edClmnts_Work_Phone.Text;
end;

procedure TWagelossBenefitCalcForm.edYouthful_WorkerExit(Sender: TObject);
begin
  if not SetValidate then
    SetInfoLine := True;

  edYouthful_Worker.Text := UpperCase( edYouthful_Worker.text );

  // Force the Default
  if edYouthful_Worker.Text = '' then
    edYouthful_Worker.Text := 'N';

  //
  // data has changed so allow an update
  //
  if ( CalcFullClaim.Youthful_Worker <> edYouthful_Worker.text ) then
    SetUpdateInd(True);

  // set the Flag in the CalcFullClaim record to be the same as the edit field
  // so that an indexation will occur properly
  //
  CalcFullClaim.Youthful_Worker := edYouthful_Worker.Text;
  ResetInfoLine2;
end;

procedure TWagelossBenefitCalcForm.edYouthful_WorkerKeyPress(Sender: TObject; var Key: Char);
begin
  case Key of
  #0..#31:
     ;
  'y','Y','n','N':
     ;
  else
    Key:=#0;
    WagelossMainForm.ShowInfoLine2( '*Valid values for Youthful Worker are Y N' );
  end;
end;

function TWagelossBenefitCalcForm.isClaimEmerge(claimNo : String):Boolean;
var
  isEmerge: boolean;
begin
  isEmerge := false;
  if length( trim( claimNo ) ) > 0 then
  begin
    isEmerge := true;
    dm1.usp_EmergeCancelTest.close;
    dm1.usp_EmergeCancelTest.Parameters.ParamByName( '@claimNo' ).value := StrToInt( claimNo );
    //dm1.usp_EmergeCancelTest.Prepare;
    dm1.usp_EmergeCancelTest.open;
    if Not( dm1.usp_EmergeCancelTest.eof ) then
    begin
      if dm1.usp_EmergeCancelTest.FieldByName( 'ClaimNo' ).asString = '-1' then
      begin
        isEmerge := false; //claim is not in emerge
      end
      else if ( StrToInt( claimNo ) <> strToInt( dm1.usp_EmergeCancelTest.fieldbyname( 'ClaimNo' ).asString ) ) then
        raise exception.create( chr( 10 ) + chr( 13 )
          + 'The Emerge claim selected has been cancelled into '
          + format( '%8.8d', [strToInt( dm1.usp_EmergeCancelTest.fieldbyname( 'ClaimNo' ).asString )] ) + '.'
          + chr( 10 ) + chr( 13 ) + 'Please do any modifications to claim '
          + format( '%8.8d', [strToInt( dm1.usp_EmergeCancelTest.fieldbyname( 'ClaimNo' ).asString )] ) + '.' )
      else if ( StrToInt( claimNo ) = strToInt( dm1.usp_EmergeCancelTest.fieldbyname( 'ClaimNo' ).asString ) ) and
        ( dm1.usp_EmergeCancelTest.fieldbyname( 'ReallocsEmergeClmFlag' ).asString = 'N' ) then
        isEmerge:= false;
    end;
  end;
  result := isEmerge;
end;

procedure TWagelossBenefitCalcForm.edApprenticeExit(Sender: TObject);
begin
  if not SetValidate then
    SetInfoLine := True;

  edApprentice.Text := UpperCase( edApprentice.text );

  // Force the Default
  if edApprentice.Text='' then
    edApprentice.Text:='N';

  //
  // data has changed so allow an update
  //
  if ( CalcFullClaim.Apprentice <> edApprentice.text ) then
    SetUpdateInd(True);

  // set the Flag in the CalcFullClaim record to be the same as the edit field
  // so that an indexation will occur properly
  //
  CalcFullClaim.Apprentice := edApprentice.Text;
  ResetInfoLine2;
end;

procedure TWagelossBenefitCalcForm.edApprenticeKeyPress(Sender: TObject; var Key: Char);
begin
  case Key of #0..#31,'y','Y','n','N':
  else
    Key:=#0;
    WagelossMainForm.ShowInfoLine2( '*Valid values for Apprentice are Y N' );
  end;
end;

procedure TWagelossBenefitCalcForm.btnUpdateCollateralBenefitsClick(Sender: TObject);
var
  Modal:TTaxableCollateral;
begin
  //
  // Display the collateral benefit form to update the source of the benefits
  //
  Modal := TTaxableCollateral.Create( Application );
  try
    try
      with DataClaim do
      begin
        Modal.edCPPQPP.Text := format( '%.2n', [CalcFullClaim.TaxCollBen_CPPQPP] );
        Modal.edEI.Text := format( '%.2n', [CalcFullClaim.TaxCollBen_EI] );
        Modal.edDisabilityInsurance.Text := format( '%.2n', [CalcFullClaim.TaxCollBen_DisabilityIns] );
        Modal.edCombination.Text := format( '%.2n', [CalcFullClaim.TaxCollBen_Combination] );
        if Modal.ShowModal = mrOk Then
        begin
          if ( CalcFullClaim.TaxCollBen_CPPQPP <> TextAsCurrency( Modal.edCPPQPP ) ) then
            SetUpdateInd(True);
          if ( CalcFullClaim.TaxCollBen_EI <> TextAsCurrency( Modal.edEI ) ) then
            SetUpdateInd(True);
          if ( CalcFullClaim.TaxCollBen_DisabilityIns <> TextAsCurrency( Modal.edDisabilityInsurance ) ) then
            SetUpdateInd(True);
          if ( CalcFullClaim.TaxCollBen_Combination <> TextAsCurrency( Modal.edCombination ) ) then
            SetUpdateInd(True);
          CalcFullClaim.TaxCollBen_CPPQPP := TextAsCurrency( Modal.edCPPQPP );
          CalcFullClaim.TaxCollBen_EI := TextAsCurrency( Modal.edEI );
          CalcFullClaim.TaxCollBen_DisabilityIns := TextAsCurrency( Modal.edDisabilityInsurance );
          CalcFullClaim.TaxCollBen_Combination := TextAsCurrency( Modal.edCombination );
          CalcFullClaim.Collateral_Ben_Tax := CalcFullClaim.TaxCollBen_CPPQPP +
                                              CalcFullClaim.TaxCollBen_EI +
                                              CalcFullClaim.TaxCollBen_DisabilityIns +
                                              CalcFullClaim.TaxCollBen_Combination;
          edCollateral_Ben_Tax.Text := format( '%.2n', [CalcFullClaim.Collateral_Ben_Tax] );
        end;
      end;
    except
      MessageDlg( 'Retreival of taxable collateral failed.  Please notify help desk at 4573.', mtError, [mbOK], 0 );
    end;
  finally
    Modal.Free;
  end;
end;

procedure TWagelossBenefitCalcForm.btnCollNonTaxClick(Sender: TObject);
var
  Modal:TNonTaxableCollateral;
begin
  //
  // Display the non taxable collateral benefit form to update the source of the benefits
  //
  Modal := TNonTaxableCollateral.Create( Application );
  try
    try
      with DataClaim do
      begin
        Modal.edEmpTopUp.Text := format( '%.2n', [CalcFullClaim.NonTaxCollBen_EmpTopUp] );
        Modal.edPrivateIns.Text := format( '%.2n', [CalcFullClaim.NonTaxCollBen_PrivateIns] );
        if Modal.ShowModal = mrOk Then
        begin
          if ( CalcFullClaim.NonTaxCollBen_EmpTopUp <> TextAsCurrency( Modal.edEmpTopUp ) ) then
            SetUpdateInd(True);
          if ( CalcFullClaim.NonTaxCollBen_PrivateIns <> TextAsCurrency( Modal.edPrivateIns ) ) then
            SetUpdateInd(True);
          CalcFullClaim.NonTaxCollBen_EmpTopUp := TextAsCurrency( Modal.edEmpTopUp );
          CalcFullClaim.NonTaxCollBen_PrivateIns := TextAsCurrency( Modal.edPrivateIns );
          CalcFullClaim.Collateral_Ben_Non_Tax := CalcFullClaim.NonTaxCollBen_EmpTopUp +
                                                  CalcFullClaim.NonTaxCollBen_PrivateIns;
          edCollateral_Ben_Non_Tax.Text := format( '%.2n', [CalcFullClaim.Collateral_Ben_Non_Tax] );
        end;
      end;
    except
      MessageDlg( 'Retreival of non-taxable collateral failed.  Please notify help desk at 4573.', mtError, [mbOK], 0 );
    end;
  finally
    Modal.Free;
  end;
end;

//function TWagelossBenefitCalcForm.getSelfEmployedMaxAdjustment(iTaxYear, iAccidentYear, iAccidentMonth:Integer; AccidentDate:TDateTime): Currency;
//var
//  lngReturn, i, nc_Index_Year: Integer;
//  AnnualMax, nc_index_amt:Currency;
//begin
//  result := 0;
//
//  try
//     dm1.usp_Get_Self_Employed_Max.Parameters.ParamByName( '@accidentDate' ).Value := AccidentDate;
//     dm1.usp_Get_Self_Employed_Max.Open;
//     lngReturn := dm1.usp_Get_Self_Employed_Max.Parameters.ParamByName( '@RETURN_VALUE' ).Value;
//
//     if lngReturn = 0 Then
//        begin
//        if Not dm1.usp_Get_Self_Employed_Max.Eof Then
//           begin
//           AnnualMax := dm1.usp_Get_Self_Employed_Max.FieldByName( 'maxSelfEmployed' ).Value;
//           end;
//
//        dm1.usp_Get_Self_Employed_Max.Close;
//        end;
//
//     //
//     // If the claim has been indexed then perform the indexation to get the proper indexed max
//     //
//     if iTaxYear > iAccidentYear then
//        begin
//        //
//        // index the new max adjustment to the current year
//        //
//        nc_index_amt := AnnualMax;
//
//        for i := (iAccidentYear + 1) to iTaxYear do
//           begin
//           nc_index_amt := pdoxRound(nc_index_amt * uGlobal.valueNCINDEXF(i),2)
//           end;
//
//        AnnualMax := nc_index_amt;
//        end;
//
//     result := AnnualMax;
//  except
//     on e:Exception do
//        begin
//        result := 0;
//        dm1.usp_Get_Self_Employed_Max.Close;
//        MessageDlg( '*Retrieve of Self Employed Max Adjustment failed. Please notify help desk at 4573', mtError, [mbOK], 0 );
//        end;
//  end;
//end;
//
//
//function TWagelossBenefitCalcForm.getSelfEmployedMinAdjustment(iTaxYear, iAccidentYear, iAccident_Month:integer; iAccident_Date:TDateTime): currency;
//var
//  lngReturn, i: Integer;
//  AnnualMin, nc_index_amt:currency;
//begin
//  result := 0;
//
//  try
//     dm1.usp_Get_Self_Employed_Max.Parameters.ParamByName( '@accidentDate' ).Value := iAccident_Date;
//     dm1.usp_Get_Self_Employed_Max.Open;
//     lngReturn := dm1.usp_Get_Self_Employed_Max.Parameters.ParamByName( '@RETURN_VALUE' ).Value;
//
//     if lngReturn = 0 Then
//        begin
//        if Not dm1.usp_Get_Self_Employed_Max.Eof Then
//           begin
//           AnnualMin := dm1.usp_Get_Self_Employed_Max.FieldByName( 'minSelfEmployed' ).Value;
//           end;
//        dm1.usp_Get_Self_Employed_Max.Close;
//        end;
//
//     //
//     // If the claim has been indexed then perform the indexation to get the proper indexed max
//     //
//     if iTaxYear > iAccidentYear then
//        begin
//        //
//        // index the new max adjustment to the current year
//        //
//        nc_index_amt := AnnualMin;
//
//        for i := (iAccidentYear + 1) to iTaxYear do
//           begin
//           nc_index_amt := pdoxRound(nc_index_amt * uGlobal.valueNCINDEXF(i),2)
//           end;
//
//        AnnualMin := nc_index_amt;
//        end;
//
//     result := AnnualMin;
//
//  except
//     on e:Exception do
//        begin
//        applog('TWagelossBenefitCalcForm.getSelfEmployedMinAdjustment - Exception - Message: ' + e.Message);
//        result := 0;
//        dm1.usp_Get_Self_Employed_Max.Close;
//        MessageDlg( '*Retrieve of Self Employed Min Adjustment failed. Please notify help desk at 4573', mtError, [mbOK], 0 );
//        end;
//  end;
//end;
//
//function TWagelossBenefitCalcForm.isSelfEmployedAdjInRange(adjAmount : Currency): String;
//var
//  lngReturn, iTax_Year, i: Integer;
//  iAccident_Year, iAccident_Month, iAccident_Day: Word;
//  nMax, nMin, index_amt_max, index_amt_min : Currency;
//begin
//  result := '';
//
//  try
//     dm1.usp_Get_Self_Employed_Max.Parameters.ParamByName( '@accidentDate' ).Value := CalcFullClaim.Accident_Date;
//     dm1.usp_Get_Self_Employed_Max.Open;
//     lngReturn := dm1.usp_Get_Self_Employed_Max.Parameters.ParamByName( '@RETURN_VALUE' ).Value;
//
//     if lngReturn = 0 Then
//        begin
//        if Not dm1.usp_Get_Self_Employed_Max.Eof Then
//           begin
//           nMax := dm1.usp_Get_Self_Employed_Max.FieldByName( 'maxSelfEmployed' ).Value;
//           nMin := dm1.usp_Get_Self_Employed_Max.FieldByName( 'minSelfEmployed' ).Value;
//           //
//           // If the claim has been indexed then perform the indexation to get the proper indexed max
//           //
//           DecodeDate(CalcFullClaim.Accident_Date, iAccident_Year, iAccident_Month, iAccident_Day);
//           iTax_Year := CalcFullClaim.Indexation_Year;
//
//           if iTax_Year > iAccident_Year then
//              begin
//              //
//              // index the new max adjustment to the current year
//              //
//              index_amt_max := nMax;
//              index_amt_min := nMin;
//
//              for i := (iAccident_Year + 1) to iTax_Year do
//                 begin
//                 index_amt_max := pdoxRound(index_amt_max * uGlobal.valueNCINDEXF(i),2);
//                 index_amt_min := pdoxRound(index_amt_min * uGlobal.valueNCINDEXF(i),2);
//                 end;
//
//              nMax := index_amt_max;
//              nMin := index_amt_min;
//              end;
//
//
//           if nMax > 0 then
//              begin
//              if (adjAmount >= nMin) AND (adjAmount <= nMax) then
//                 begin
//                 // all good
//                 end
//              else
//                 begin
//                 Result := Format('*Max Adj amount must be >= $ %.2n and <= $ %.2n',
//                                  [nMin,nMax]);
//                 //***
//                 if WagelossMainForm.isRunManualTest then
//                    if not isIndexation then
//                       edMax_Adjustments.Text := format('%.2n',[nMin]);
//                 //***
//                 end
//              end
//           else
//              begin
//              if (adjAmount < nMin) then
//                 begin
//                 Result := Format('*Max Adj amount must be >= Min: $ %.2n',
//                                  [nMin]);
//                 //***
//                 if WagelossMainForm.isRunManualTest then
//                    if not isIndexation then
//                       edMax_Adjustments.Text := format( '%.2n',[nMin] )
//                 //***
//                 end
//              end;
//           end;
//        dm1.usp_Get_Self_Employed_Max.Close;
//        end;
//  except
//     on e:Exception do
//        begin
//        applog('TWagelossBenefitCalcForm.isSelfEmployedAdjInRange - Exception - Message: ' + e.Message);
//        Result := 'Error';
//        dm1.usp_Get_Self_Employed_Max.Close;
//        MessageDlg( '*Retrieve of Self Employed Adjustment Amounts failed. Please notify help desk at 4573', mtError, [mbOK], 0 );
//        end;
//  end;
//end;

procedure TWagelossBenefitCalcForm.ed_WCB_Annuity_ContrExit(Sender: TObject);
var
  f, g, h : currency;
  Accident_Date : TDateTime;
begin
  //
  // This exit routine will only make sense for 2006+claims since previously
  // the WCB portion was calculated from the annuity reduction
  //

  if lblAccident_Date.Visible Then
    Accident_Date := CalcFullClaim.Accident_Date
  else
    Accident_Date := StrtoDate( edAccident_Date.Text );

  if Year( Accident_Date ) >= 2006 Then
  begin
    if not SetValidate then
      SetInfoLine := true;

    if ed_WCB_Annuity_Contr.text = '' then
      ed_WCB_Annuity_Contr.text := '0';

    if not ValidateAsCurrency( ed_WCB_Annuity_Contr ) then
    begin
      globalEditError := displayError( '*Invalid WCB % Annuity Contribution', ed_WCB_Annuity_Contr );
      Exit;
    end;

    if ( ( ednc_104_Wk_Effective_Date.Enabled ) And
         ( Trim( ednc_104_Wk_Effective_Date.Text ) <> '' ) ) Then
    Begin
      //3 checks
      //1) WCB contr must be between 0 an 7
      //2) WCB contr + Emp contr cannot exceed 7
      //3) Claimant contr cannot exceed WCB contr
      g := TextAsCurrency( ednc_104_Wk_WCB_p_Contrib_Red );
      f := TextAsCurrency( ed_WCB_Annuity_Contr );
      h := TextAsCurrency( ednc_104_Wk_Clmt_p_Contrib );

      if ( f < 0.0 ) or ( f > 7.0 ) then
      begin
        globalEditError := displayError( '*WCB % Annuity Contribution must be between 0 and 7.0', ed_WCB_Annuity_Contr );
        Exit;
      end;

      if ( f + g ) > 7 then
      begin
        globalEditError := displayError( '*Total WCB Contribution and Employer Contribution cannot exceed 7 %', ed_WCB_Annuity_Contr );
        Exit;
      end;

      if ( h > f ) then
      begin
        globalEditError := displayError( '*Worker Contribution cannot exceed WCB Contribution', ed_WCB_Annuity_Contr );
        Exit;
      end;

      //
      // if nc_104_Wk_WCB_p_Contrib was changed
      //
      if ( textAsCurrency( ed_WCB_Annuity_Contr ) <> CalcFullClaim.nc_104_Wk_WCB_p_Contrib ) then
      begin
        CalcFullClaim.nc_104_Wk_Clmt_p_Eff_Date := utilmod1.getEmergeBusinessDate();
        // update fields so nccanty works
        CalcFullClaim.nc_104_Wk_Clmt_p_Contrib :=  textAsCurrency( ednc_104_Wk_Clmt_p_Contrib );
        CalcFullClaim.nc_104_Wk_WCB_p_Contrib_Red :=  textAsCurrency( ednc_104_Wk_WCB_p_Contrib_Red );
        CalcFullClaim.nc_104_Wk_WCB_p_Contrib := textAsCurrency( ed_WCB_Annuity_Contr );
        // reminder - update is done using CalcPartClaim record
        CalcPartClaim.nc_104_Wk_Clmt_p_Eff_Date := CalcFullClaim.nc_104_Wk_Clmt_p_Eff_Date;
        CalcPartClaim.nc_104_Wk_Clmt_p_Contrib :=  CalcFullClaim.nc_104_Wk_Clmt_p_Contrib;
        CalcPartClaim.nc_104_Wk_WCB_p_Contrib_Red := CalcFullClaim.nc_104_Wk_WCB_p_Contrib_Red;
        CalcPartClaim.nc_104_Wk_WCB_p_Contrib := CalcFullClaim.nc_104_Wk_WCB_p_Contrib;
        Calc_Annuity( CalcPartClaim );
        Calc_Annuity( CalcFullClaim );
        SetUpdateInd(True);
      end
      else
      begin
        if lblAccident_Date.Visible Then
        Begin
          // else restore to original values
          CalcFullClaim.nc_104_Wk_Clmt_p_Eff_Date := dataClaim.nc_104_Wk_Clmt_p_Eff_Date;
          CalcFullClaim.nc_104_Wk_Clmt_p_Contrib :=  dataClaim.nc_104_Wk_Clmt_p_Contrib;
          CalcFullClaim.nc_104_Wk_WCB_p_Contrib_Red := dataClaim.nc_104_Wk_WCB_p_Contrib_Red;
          CalcFullClaim.nc_104_Wk_WCB_p_Contrib := dataClaim.nc_104_Wk_WCB_p_Contrib;
          CalcPartClaim.nc_104_Wk_Clmt_p_Eff_Date := CalcFullClaim.nc_104_Wk_Clmt_p_Eff_Date;
          CalcPartClaim.nc_104_Wk_Clmt_p_Contrib :=  dataClaim.nc_104_Wk_Clmt_p_Contrib;
          CalcPartClaim.nc_104_Wk_WCB_p_Contrib_Red := dataClaim.nc_104_Wk_WCB_p_Contrib_Red;
          CalcPartClaim.nc_104_Wk_WCB_p_Contrib := dataClaim.nc_104_Wk_WCB_p_Contrib;
          Calc_Annuity( CalcPartClaim );
          Calc_Annuity( CalcFullClaim );
        end;
      end;
    end;

    ed_WCB_Annuity_Contr.Text := Format( '%.2n',[TextAsCurrency( ed_WCB_Annuity_Contr )] );
    ResetInfoLine2;
  end;
end;

procedure TWagelossBenefitCalcForm.cboAverageEarningsBasedOnExit(Sender: TObject);
begin
  if not validateAverageEarningsBasedOn then exit;
end;

function TWagelossBenefitCalcForm.validateAverageEarningsBasedOn:Boolean;
begin
  result := false;
  if not SetValidate then
    SetInfoLine := True;
  if cboAverageEarningsBasedOn.Text = '' then
  begin
    globalEditError := displayError( '*You must select Rate Based On Type.', cboAverageEarningsBasedOn );
    if cboAverageEarningsBasedOn.Enabled then
      cboAverageEarningsBasedOn.SetFocus;
    exit;
  end;
  ResetInfoLine2;
  result := true;
end;

procedure TWagelossBenefitCalcForm.edEffectiveDateExit(Sender: TObject);
var
   InjuryDate:String;
   AccidentDate:TDateTime;
Begin
  if not SetValidate then
     SetInfoLine := True;
  //
  // make sure an Accident date was entered
  //
  if Length(edEffectiveDate.text) < 1 then
     begin
     globalEditError := displayError( '*Please enter an Effective Date.', edEffectiveDate );
     exit;
     end;

  if not ValidateAsDate(edEffectiveDate) Then
     begin
     globalEditError := displayError('*Invalid Effective Date', edEffectiveDate);
     exit;
     end;

  //
  // If we have a valid date then format the field to conform to a proper
  // datetime format in the text box
  //
  if (TextAsDate(edEffectiveDate) > 0) then
     edEffectiveDate.Text := FormatDateTime( 'c',textAsDate( edEffectiveDate ) )
  else
     edEffectiveDate.text := '';

  InjuryDate := lblAccident_Date.Caption;
  if (Length(Trim(lblAccident_Date.Caption)) > 0) AND (TryStrToDate(InjuryDate, AccidentDate)) then
     begin
     if (StrToDate(edEffectiveDate.Text) <= AccidentDate) then
        begin
        globalEditError := displayError('*Effective Date cannot be before or on the same day as the Injury Date', edEffectiveDate );
        exit;
        end;
     end;

  if (CalcFullClaim.effectiveDate <> StrtoDate(edEffectiveDate.Text)) then
     SetUpdateInd(True);

  ResetInfoLine2;
end;

procedure TWagelossBenefitCalcForm.edEffectiveDateKeyPress(Sender: TObject;
  var Key: Char);
begin
  case Key of #0..#31,'0'..'9','/','.':
  else
    Key:=#0;
  end;
end;


procedure TWagelossBenefitCalcForm.cboMaritalStatusExit(Sender: TObject);
begin
  if not SetValidate then
    Setinfoline := True;

  //
  // Set to default if blank
  //
  if cboMaritalStatus.Text = '' then
     begin
     cboMaritalStatus.KeyValue := 'SINGLE';
     edSpouse_Working.text := 'N';
     blnMarital_Status_Change := true;
     end;

  //
  // Default the Spouse Working Flag
  //
  if (upperCase(cboMaritalStatus.Text) = 'MARRIED')    OR
     (upperCase(cboMaritalStatus.Text) = 'COMMON-LAW') Then
     begin
     if blnMarital_Status_Change then
        edSpouse_Working.text := 'Y';
     end;

  if (upperCase(cboMaritalStatus.Text) = 'DIVORCED')  or
     (upperCase(cboMaritalStatus.Text) = 'SEPARATED') or
     (upperCase(cboMaritalStatus.Text) = 'SINGLE')    or
     (upperCase(cboMaritalStatus.Text) = 'WIDOWED')   then
     begin
     edClaimSpouseForTaxPurposes.Visible := false;
     lblClaimSpouseForTaxPurposes.Visible := false;
     edClaimSpouseForTaxPurposes.Text := '';
     if blnMarital_Status_Change then
        begin
        edSpouse_Working.text := 'N';
        setEditToRead( edSpouse_Working );
        selectNext(Sender as tWinControl, true, true);
        end;
     end
  else
     begin
     if blnMarital_Status_Change then
        begin
        setEditToNormal(edSpouse_Working);
        selectNext(Sender as tWinControl, true, true);
        end;
     end;

  blnMarital_Status_Change := False;

  ResetInfoLine2;
end;

procedure TWagelossBenefitCalcForm.cboMaritalStatusKeyDown(Sender: TObject;
  var Key: Word; Shift: TShiftState);
begin
  blnMarital_Status_Change := True;
end;

procedure TWagelossBenefitCalcForm.cboMaritalStatusClick(Sender: TObject);
begin
  blnMarital_Status_Change := True;

  if ( CalcFullClaim.Marital_Status <> cboMaritalStatus.text ) then
    SetUpdateInd(True);
end;

procedure TWagelossBenefitCalcForm.triggerSendDocumentEvent(const aFormName, aPropertyExtension: String);
var
	ep:TEventPublisher;
begin
  try
     ep := TEventPublisher.create( dm1.dbSharedLookup, dm1.dbEmerge, HTTPHOST, 'WAGELOSS', userProfile.loginName, '');
     ep.publishSendDocumentEvent( MQMANAGERNAME, aFormName, CalcFullClaim.Claim_No, aPropertyExtension );
	except
     on e:Exception do
        begin
		    showAppMessage(e.Message, 2);
        end;
	end;
end;

procedure TWagelossBenefitCalcForm.triggerSendDocumentEvent(const aFormName: String);
begin
	triggerSendDocumentEvent(aFormName, '');
end;

procedure TWagelossBenefitCalcForm.edCalculationTypeExit(Sender: TObject);
begin
  if ( CalcFullClaim.week104StatusType <> edCalculationType.Text ) then
    SetUpdateInd(True);
end;

procedure TWagelossBenefitCalcForm.cboAverageEarningsBasedOnClick( Sender: TObject );
begin
  if ( CalcFullClaim.AverageEarningsBasedOn <> cboAverageEarningsBasedOn.Text ) then
    SetUpdateInd(True);
end;

procedure TWagelossBenefitCalcForm.edCalculationTypeClick(Sender: TObject);
begin
  if ( CalcFullClaim.week104StatusType <> edCalculationType.Text ) then
    SetUpdateInd(True);
end;

procedure TWagelossBenefitCalcForm.SelectCalcType(numWeeks: currency);
var
  aMsgDialog: TForm;
  aRadioGroup: TRadioGroup;
begin
  //format('%.2n', [Annual_Max]), edMax_Adjustments );
  aMsgDialog := CreateMessageDialog('Annuity Entitlement weeks is ' +  format('%.2n', [numWeeks]), mtWarning, [mbOK]) ;
  aRadioGroup := TRadioGroup.Create(aMsgDialog) ;
  blnSetPre104 := false;
  blnSetPost104 := false;
  with AMsgDialog do
  try
   Caption := 'Set Calculation Type';
   Height := 270;
   Width := 400;
   Controls[2].Top := 170;
   Controls[2].Left := 120;

   with aRadioGroup do
   begin
    Parent := aMsgDialog;
    //Caption := 'Set Calculation Type';
    Top := 45;
    Left := 55;
    Width := 250;
    Items.Add('Set to Pre 104 Weeks');
    Items.Add('Set to Post 104 Weeks');
    ItemIndex := -1;
   end;

   if (ShowModal = ID_YES) then
   begin
     //  Waiting for Ok button to be pressed!!!!
   end
   else
   begin
    if aRadioGroup.ItemIndex = 0 then
      blnSetPre104 := true;
    if aRadioGroup.ItemIndex = 1 then
      blnSetPost104 := true;
   end;

  finally
   Free;
  end;
end;

procedure TWagelossBenefitCalcForm.SetUpdateInd(value:boolean);
begin
  allowUpdateClaim := value;
  blnRecalcNeeded := value;
end;



procedure TWagelossBenefitCalcForm.FormResize(Sender: TObject);
begin
{
  ScrollBox1.left := (Self.width div 2) - ScrollBox1.width div 2;
  if Self.Height > ScrollBox1.Height then
     ScrollBox1.top := (Self.height div 2) - ScrollBox1.height div 2
  else
     ScrollBox1.top := (ScrollBox1.height div 2) - (Self.height div 2);
}
end;

procedure TWagelossBenefitCalcForm.btnIndexationClick(Sender: TObject);
var
  btnSelected : Integer;
begin
  //***
  if blnRecalcNeeded then
     begin
     WagelossMainForm.ShowInfoLine2( '*Recalc claim prior to indexing.' );
     messagebeep(0);
     exit;
     end;

  if allowQASave then
     begin
     if MyMessageDialog('Do you want to save current results into QA Test Data ?', mtConfirmation, mbOKCancel,
                        ['Save It', 'No']) = mrOk then
        if SaveQAData then
           begin
           resetControlsAfterIndexation;
           allowQASave := False;
           ResetInfoLine2;
           end;
     end;

  isIndexation := True;
  WagelossIndexation;

end;

function TWagelossBenefitCalcForm.SaveQAData: Boolean;
var
  intQADataID, intQATestID, intQATestIndexID : Integer;
  S : String;
begin
  Result := False;

  if allowQASave then
     begin
     try
        copyNCCLAIM( CalcFullClaim, uSaveWageLossCalcFactors.CalcFullClaim);
        copyNCCLAIM( CalcPartClaim, uSaveWageLossCalcFactors.CalcPartClaim);

        if Not lblAccident_Date.Visible then
           begin
           CalcFullClaim.Claim_No := '00000000';
           CalcFullClaim.Claim_Suffix := '0000';
           end;

        copyNCCLAIM( CalcFullClaim, uSavePrint.CalcFullClaim );
        copyNCCLAIM( CalcPartClaim, uSavePrint.CalcPartClaim );
        FullClaim;
        CheckForPartial;

        if not isIndexation then
           FnextQATestID := 0;

        if isInTestEditMode then
           begin
           intQADataID := FqryEditTestRecord.FieldByname('QADataID').AsInteger;
           intQATestIndexID := FqryEditTestRecord.FieldByname('QATestIndexID').AsInteger;

           intQATestID := FqryEditTestRecord.FieldByname('QATestID').AsInteger;
           S := Copy(IntToStr(intQATestID),1,4);

           if S <> EmptyStr then
              begin
              if StrToInt(S) <> year( StrtoDate( edAccident_Date.Text )) then
                 intQATestID := 0;
              end;
           // Update existing Record
           if uSavePrint.UpdateQADataRecord(Trim(edClaimDescription.Text),StrToInt(edClaimPrefix.Text),
                                            intQADataID, intQATestID, intQATestIndexID ) then
              Result := True;
           end
        else
           begin
           // New Record
           if isInTestIndexationEditMode then
              FnextQATestID := FqryEditTestRecord.FieldByname('QATestID').AsInteger;
           if uSavePrint.NewQADataRecord(Trim(edClaimDescription.Text),StrToInt(edClaimPrefix.Text),FnextQATestID) then
              Result := True;
           end;
        isInTestEditMode := False;
     except
        on e:Exception do
           begin
           applog('TWagelossBenefitCalcForm.SaveQAData - Exception - Message: ' + e.Message);
           raise;
           end;
     end;
     end;

end;


procedure TWagelossBenefitCalcForm.resetControlsAfterQASave;
var
  btnSelected : Integer;
begin

  allowQASave := False;
  btnSelected := MyMessageDialog('Record saved successfully. If you want to continue creating new entries,'+ //+#13#10+
                                'How do you want the screen to be set ?', mtConfirmation, mbYesNoCancel,
      ['Reset', 'As It is', 'Close']);

  Try
    LockWindowUpdate(Handle);
    if btnSelected = mrYes then // Reset
    begin
       edAccident_Date.SetFocus;
       ResetCalc;
       edClaimPrefix.Clear;
       edClaimDescription.Clear;
       edQATestID.Clear;
       edRecurrence.Text := 'N';
       edRecurrenceDate.Visible := False;
       edAccident_Date.SetFocus;
       edAccident_Date.SetFocus;

    end
    else if btnSelected = mrNo then // As It Is
    begin
      ClearNCCLAIM( CalcFullClaim );
      ClearNCCLAIM( CalcPartClaim );
      lblInc_Tax_Fed.caption := format('%.2n', [ 0.00 ] );
      lblInc_Tax_Man.caption := format('%.2n', [ 0.00 ] );
      lblCPP_Prem.caption := format('%.2n', [ 0.00 ] );
      lblCPP2_Prem.caption := format('%.2n', [ 0.00 ] );
      lblEI_Prem.caption := format('%.2n', [ 0.00 ] );
      lblTotal_Deds.caption := format('%.2n', [ 0.00] );
      lblWkly_Total_Deds.caption := format('%.2n', [ 0.00 ] );
      edCollateral_Ben_Tax.text := format('%.2n', [ 0.00 ] );
      edCollateral_Ben_Non_Tax.text := format('%.2n', [ 0.00 ] );
      edPost_Injury_Earn.text := format('%.2n', [ 0.00 ] );
      lblColl_Ben_Tax_Net.caption := format('%.2n', [ 0.00 ] );
      lblPost_Injury_Earn_Net.caption := format('%.2n', [ 0.00 ] );
      lblWkly_Sal_A.caption := format('%.2n', [ 0.00 ] );
      lblWeekly_Net.caption := format('%.2n', [ 0.00 ] );
      lblAnnual_Gross.caption := format('%.2n', [ 0.00 ] );
      lblAnnual_Net.caption := format('%.2n', [ 0.00 ] );
      lblWeekly_90.caption := format('%.2n', [ 0.00 ] );
      lblCalcTaxSheltering.caption := '0.00';
      lblWeekly_90_S.caption := format( '%.2n', [ 0.00 ] );
      lblDailyCompensationRate.caption := '';
      lblDaily80FullCompensationRate.caption := '';
      lblAnnual_90.caption := format('%.2n', [ 0.00 ] );
      lblAnnual_90_S.caption := format('%.2n', [ 0.00 ] );
      lblWeekly_80.caption := format('%.2n', [ 0.00 ] );
      lblWkly_Clmt_Anty_Con_Amt.caption := format('%.2n', [ 0.00 ] );
      lblCalcWkly80p_Net_Clmt_Contr.caption := format('%.2n', [ 0.00 ] );
      lblCalcWkly_p_WCB_Contr.caption := format('%.2n', [ 0.00 ] );
      lblCalcnc_104_Wk_WCB_p_Contrib_Red.caption := format('%.2n',[ 0.00 ] );
      ednc_104_Wk_Effective_Date.text := '';
      ednc_104_Wk_Clmt_p_Contrib.text := format('%.2n',[ 0.00 ]);
      ednc_104_Wk_Clmt_p_Eff_Date.text := '';
      lblnc_104_Wk_Clmt_p_Contrib.caption := format('%.2n', [ 0.00 ] );
      lblCalc2nc_104_Wk_WCB_p_Contrib_Red.caption := format('%.2n',[ 0.00 ] );
      ednc_104_Wk_WCB_p_Contrib_Red.text := format('%.2n', [ 0.00 ] );
      ed_WCB_Annuity_Contr.Text := format('%.2n', [ 0.00 ] );
      lbCalc90p_Wkly_Net_A.caption := format('%.2n', [ 0.00 ] );

      lblPartPre_Weekly_Net.caption := '';
      lblPartPost_Injury_Earn_Net.caption := '';
      lblPost_Injury_Earn_Net.caption := format('%.2n', [ 0.00 ] );
      lblPartCalcNetLossEarnings.caption := '';
      lblPartWeekly_90.caption := '';
      lblPartCalcTaxSheltering.caption := '';
      lblPartWeekly_90_S.caption := '';
      lblPartDailyCompensationRate.caption := '';
      lblPartDaily80CompensationRate.caption := '';
      lblPartWeekly_80.caption := '';
      lblPartWkly_Clmt_Anty_Con_Amt.caption := '';
      lblPartCalcWkly80p_Net_Clmt_Contr.caption := '';
      lblPartCalcWkly_p_WCB_Contr.caption := '';
      lblPart_nc_104_Wk_Clmt_p_Contrib.caption := '';
      lblPart_Calcnc_104_Wk_WCB_p_Contrib_Red.caption := '';

      //make all the labels invisible
      lblPartPre_Weekly_Net.visible := false;
      lblPartPost_Injury_Earn_Net.visible := false;
      lblPost_Injury_Earn_Net.visible := false;
      lblPartCalcNetLossEarnings.visible := false;
      lblPartWeekly_90.visible := false;
      lblPartCalcTaxSheltering.visible := false;
      lblPartWeekly_90_S.visible := false;
      lblPartDailyCompensationRate.visible := false;
      lblPartDaily80CompensationRate.visible := false;
      lblPartWeekly_80.visible := false;
      lblPartWkly_Clmt_Anty_Con_Amt.visible := false;
      lblPartCalcWkly80p_Net_Clmt_Contr.visible := false;
      lblPartCalcWkly_p_WCB_Contr.visible := false;
      lblPart_nc_104_Wk_Clmt_p_Contrib.visible := false;
      lblPart_Calcnc_104_Wk_WCB_p_Contrib_Red.visible := false;
      lblPartialWageLoss.Visible := false;
      label77.Visible := false;
      label78.Visible := false;
      label79.Visible := false;
      label89.Visible := false;
      label56.Visible := false;
      label39.Visible := false;
      label80.Visible := false;
      lblNetLossPartial.Visible := false;
      lblNetShelteredPartial.Visible := false;
      lbl80NetLossPartial.Visible := false;
      lbl80PercentClaimantContribPartial.Visible := false;
      lbl80PercentClaimContributionPartial.Visible := false;
      lbl80PercentWCBContributionPartial.visible := false;
      lbl80DailyCompRatePartial.Visible := false;
      edRecurrence.Text := 'N';
      edRecurrenceDate.text := '';
      edRecurrenceDate.Visible := False;
      edAccident_Date.SetFocus;
    end
  Finally
    LockWindowUpdate(0);
  End;

  if btnSelected = mrCancel then
    Close;

end;

procedure TWagelossBenefitCalcForm.resetControlsAfterIndexation;
begin

  Try
    LockWindowUpdate(Handle);

    if cbxIndexationOnly.Checked then
      edMax_Adjustments.Text := format('%.2n', [ 0.00 ] );

    lblInc_Tax_Fed.caption := format('%.2n', [ 0.00 ] );
    lblInc_Tax_Man.caption := format('%.2n', [ 0.00 ] );
    lblCPP_Prem.caption := format('%.2n', [ 0.00 ] );
    lblCPP2_Prem.caption := format('%.2n', [ 0.00 ] );
    lblEI_Prem.caption := format('%.2n', [ 0.00 ] );
    lblTotal_Deds.caption := format('%.2n', [ 0.00] );
    lblWkly_Total_Deds.caption := format('%.2n', [ 0.00 ] );
    //edCollateral_Ben_Tax.text := format('%.2n', [ 0.00 ] );
    //edCollateral_Ben_Non_Tax.text := format('%.2n', [ 0.00 ] );
    //edPost_Injury_Earn.text := format('%.2n', [ 0.00 ] );
    lblColl_Ben_Tax_Net.caption := format('%.2n', [ 0.00 ] );
    lblPost_Injury_Earn_Net.caption := format('%.2n', [ 0.00 ] );
    lblWkly_Sal_A.caption := format('%.2n', [ 0.00 ] );
    lblWeekly_Net.caption := format('%.2n', [ 0.00 ] );
    lblAnnual_Gross.caption := format('%.2n', [ 0.00 ] );
    lblAnnual_Net.caption := format('%.2n', [ 0.00 ] );
    lblWeekly_90.caption := format('%.2n', [ 0.00 ] );
    lblCalcTaxSheltering.caption := '0.00';
    lblWeekly_90_S.caption := format( '%.2n', [ 0.00 ] );
    lblDailyCompensationRate.caption := '';
    lblDaily80FullCompensationRate.caption := '';
    lblAnnual_90.caption := format('%.2n', [ 0.00 ] );
    lblAnnual_90_S.caption := format('%.2n', [ 0.00 ] );
    lblWeekly_80.caption := format('%.2n', [ 0.00 ] );
    lblWkly_Clmt_Anty_Con_Amt.caption := format('%.2n', [ 0.00 ] );
    lblCalcWkly80p_Net_Clmt_Contr.caption := format('%.2n', [ 0.00 ] );
    lblCalcWkly_p_WCB_Contr.caption := format('%.2n', [ 0.00 ] );
    lblCalcnc_104_Wk_WCB_p_Contrib_Red.caption := format('%.2n',[ 0.00 ] );
    //ednc_104_Wk_Effective_Date.text := '';
    //ednc_104_Wk_Clmt_p_Contrib.text := format('%.2n',[ 0.00 ]);
    //ednc_104_Wk_Clmt_p_Eff_Date.text := '';
    lblnc_104_Wk_Clmt_p_Contrib.caption := format('%.2n', [ 0.00 ] );
    lblCalc2nc_104_Wk_WCB_p_Contrib_Red.caption := format('%.2n',[ 0.00 ] );
    //ednc_104_Wk_WCB_p_Contrib_Red.text := format('%.2n', [ 0.00 ] );
    //ed_WCB_Annuity_Contr.Text := format('%.2n', [ 0.00 ] );
    lbCalc90p_Wkly_Net_A.caption := format('%.2n', [ 0.00 ] );

    lblPartPre_Weekly_Net.caption := '';
    lblPartPost_Injury_Earn_Net.caption := '';
    lblPost_Injury_Earn_Net.caption := format('%.2n', [ 0.00 ] );
    lblPartCalcNetLossEarnings.caption := '';
    lblPartWeekly_90.caption := '';
    lblPartCalcTaxSheltering.caption := '';
    lblPartWeekly_90_S.caption := '';
    lblPartDailyCompensationRate.caption := '';
    lblPartDaily80CompensationRate.caption := '';
    lblPartWeekly_80.caption := '';
    lblPartWkly_Clmt_Anty_Con_Amt.caption := '';
    lblPartCalcWkly80p_Net_Clmt_Contr.caption := '';
    lblPartCalcWkly_p_WCB_Contr.caption := '';
    lblPart_nc_104_Wk_Clmt_p_Contrib.caption := '';
    lblPart_Calcnc_104_Wk_WCB_p_Contrib_Red.caption := '';

    //make all the labels invisible
    lblPartPre_Weekly_Net.visible := false;
    lblPartPost_Injury_Earn_Net.visible := false;
    lblPost_Injury_Earn_Net.visible := false;
    lblPartCalcNetLossEarnings.visible := false;
    lblPartWeekly_90.visible := false;
    lblPartCalcTaxSheltering.visible := false;
    lblPartWeekly_90_S.visible := false;
    lblPartDailyCompensationRate.visible := false;
    lblPartDaily80CompensationRate.visible := false;
    lblPartWeekly_80.visible := false;
    lblPartWkly_Clmt_Anty_Con_Amt.visible := false;
    lblPartCalcWkly80p_Net_Clmt_Contr.visible := false;
    lblPartCalcWkly_p_WCB_Contr.visible := false;
    lblPart_nc_104_Wk_Clmt_p_Contrib.visible := false;
    lblPart_Calcnc_104_Wk_WCB_p_Contrib_Red.visible := false;
    lblPartialWageLoss.Visible := false;
    label77.Visible := false;
    label78.Visible := false;
    label79.Visible := false;
    label89.Visible := false;
    label56.Visible := false;
    label39.Visible := false;
    label80.Visible := false;
    lblNetLossPartial.Visible := false;
    lblNetShelteredPartial.Visible := false;
    lbl80NetLossPartial.Visible := false;
    lbl80PercentClaimantContribPartial.Visible := false;
    lbl80PercentClaimContributionPartial.Visible := false;
    lbl80PercentWCBContributionPartial.visible := false;
    lbl80DailyCompRatePartial.Visible := false;

    edAccident_Date.SetFocus;
  Finally
    LockWindowUpdate(0);
  End;

end;

procedure TWagelossBenefitCalcForm.fillInFormQATestData;
var
  K : Word;
begin

  if cbxIndexationOnly.Checked and (dm1.qryQAData.FieldByname('Indexed_Year').AsInteger <= 0) then
  begin
    dataClaim.claimCalculated := false;
    ClearNCCLAIM( CalcFullClaim );
    ClearNCCLAIM( CalcPartClaim );
    ClearNCCLAIM( dataClaim );
  end;

  Try
     LockWindowUpdate(Handle);
     edAccident_Date.Text := dm1.qryQAData.FieldByname('Accident_Date').AsString;
     ednc_104_Wk_Clmt_p_Contrib.Text := FormatFloat('#,##0.00',dm1.qryQAData.FieldByname('Full_Clmnt_Percent_Contrib').AsCurrency);
     ed_WCB_Annuity_Contr.Text := FormatFloat('#,##0.00',dm1.qryQAData.FieldByname('Full_WCB_Percent_Contrib').AsCurrency);

     edClaimPrefix.Text      := dm1.qryQAData.FieldByname('claim_year').AsString;
     edClaimDescription.Text := dm1.qryQAData.FieldByname('QADataDescription').AsString;
     edAccident_Date.Text    := CustomStrToDateStr( dm1.qryQAData.FieldByname('Accident_Date').AsString );
     edEffectiveDate.Text    := CustomStrToDateStr( dm1.qryQAData.FieldByname('EffectiveDate').AsString );
     edWkly_Sal_A.Text       := dm1.qryQAData.FieldByname('Weekly_Wage').AsString;
     edDays_Worked_per_Week.Text := dm1.qryQAData.FieldByname('Days_Week').AsString;
     lblIndexation_Year.Caption  := dm1.qryQAData.FieldByname('Indexed_Year').AsString;
     CalcFullClaim.Indexation_Year := StrToInt(dm1.qryQAData.FieldByname('Indexed_Year').AsString);
     edTax_Year.Text         := dm1.qryQAData.FieldByname('Tax_Year').AsString;
     edRecurrence.Text       := dm1.qryQAData.FieldByname('Recurence').AsString;
     if edRecurrence.Text = 'Y' then
     begin
       edRecurrenceDate.Visible := True;
       edRecurrenceDate.Text   := CustomStrToDateStr(dm1.qryQAData.FieldByname('Recurrence_Date').AsString);
     end
     else
     begin
       edRecurrenceDate.Visible := False;
       edRecurrenceDate.Text   := '';
     end;
     edYouthful_Worker.Text  := dm1.qryQAData.FieldByname('Youthful_Worker').AsString;
     edApprentice.Text       := dm1.qryQAData.FieldByname('Apprentice').AsString;
     edSelf_Employed.Text       := dm1.qryQAData.FieldByname('Self_Employed').AsString;
     cboMaritalStatus.KeyValue  := dm1.qryQAData.FieldByname('Marital_Status').AsString;
     edSpouse_Working.Text      := dm1.qryQAData.FieldByname('Spouse_Working').AsString;
     edClaimSpouseForTaxPurposes.Text := dm1.qryQAData.FieldByname('ClaimSpouseForTaxPurposes').AsString;
     edNo_Of_Dependnts.Text     := dm1.qryQAData.FieldByname('Nbr_Of_Dependants').AsString;
     edNo_Infirm.Text           := dm1.qryQAData.FieldByname('Nbr_Of_Infirm_Deps').AsString;
     edEI_Exempt.Text           := dm1.qryQAData.FieldByname('Uic_Exempt').AsString; //???
     edCPP_Exempt.Text          := dm1.qryQAData.FieldByname('CPP_Exempt').AsString;
     edTax_Exempt.Text          := dm1.qryQAData.FieldByname('Income_Tax_Exempt').AsString;
     ednc_104_Wk_Effective_Date.Text  := CustomStrToDateStr( dm1.qryQAData.FieldByname('Accident_Date').AsString );
     ednc_104_Wk_Clmt_p_Eff_Date.Text := CustomStrToDateStr( dm1.qryQAData.FieldByname('Accident_Date').AsString );

     edChild_Care_Exp.Text      := FormatFloat('#,##0.00',dm1.qryQAData.FieldByname('Child_Care_Expense').AsCurrency);
     edSpousal_Support.Text     := FormatFloat('#,##0.00',dm1.qryQAData.FieldByname('Spousal_Support').AsCurrency);

     edCollateral_Ben_Tax.Text     := FormatFloat('#,##0.00',dm1.qryQAData.FieldByname('Collateral_Taxable').AsCurrency);
     lblColl_Ben_Tax_Net.Caption   := FormatFloat('#,##0.00',dm1.qryQAData.FieldByname('Collateral_Taxable_Net').AsCurrency);
     edCollateral_Ben_Non_Tax.Text := FormatFloat('#,##0.00',dm1.qryQAData.FieldByname('Collateral_Non_Taxable').AsCurrency);

     cboAverageEarningsBasedOn.KeyValue := dm1.qryQAData.FieldByname('AvgEarningsBasedOn').AsString;
     lblInc_Tax_Fed.Hint        := FormatFloat('#,##0.00',dm1.qryQAData.FieldByname('Inc_Tax_Fed').AsCurrency);
     lblInc_Tax_Man.Hint        := FormatFloat('#,##0.00',dm1.qryQAData.FieldByname('Inc_Tax_Prov').AsCurrency);
     lblCPP_Prem.Hint           := FormatFloat('#,##0.00',dm1.qryQAData.FieldByname('Cpp_Prem').AsCurrency);
     lblCPP2_Prem.Hint           := FormatFloat('#,##0.00',dm1.qryQAData.FieldByname('Cpp2_Prem').AsCurrency);
     lblEI_Prem.Hint            := FormatFloat('#,##0.00',dm1.qryQAData.FieldByname('UIC_Prem').AsCurrency);
     lblTotal_Deds.Hint         := FormatFloat('#,##0.00',dm1.qryQAData.FieldByname('Total_Deds').AsCurrency);
     lblWkly_Total_Deds.Hint    := FormatFloat('#,##0.00',dm1.qryQAData.FieldByname('Weekly_Deds').AsCurrency);

     edPost_Injury_Earn.Text    := FormatFloat('#,##0.00',dm1.qryQAData.FieldByname('Post_Earn_Weekly_Gross').AsCurrency);
     edDeemed_Earnings.Text     := dm1.qryQAData.FieldByname('Deemed').AsString;
     lblPost_Injury_Earn_Net.Caption   := FormatFloat('#,##0.00',dm1.qryQAData.FieldByname('Post_Earn_Weekly_Net').AsCurrency);

     ednc_104_Wk_Effective_Date.Text   := CustomStrToDateStr( dm1.qryQAData.FieldByname('80_Effective_Date').AsString);
     ednc_104_Wk_Clmt_p_Eff_Date.Text  := CustomStrToDateStr( dm1.qryQAData.FieldByname('Clmnt_Contrib_Effective_Date').AsString);

     lblWkly_Sal_A.Hint      :=  FormatFloat('#,##0.00',dm1.qryQAData.FieldByname('Full_Weekly_Gross').AsCurrency);
     lblWeekly_Net.Hint      :=  FormatFloat('#,##0.00',dm1.qryQAData.FieldByname('Full_Weekly_Net_Loss_Earn').AsCurrency);
     lbCalc90p_Wkly_Net_A.Hint := FormatFloat('#,##0.00',dm1.qryQAData.FieldByname('Full_Weekly_90_Net_Actual').AsCurrency);
     lblAnnual_Gross.Hint    := FormatFloat('#,##0.00',dm1.qryQAData.FieldByname('Full_Annual_Gross').AsCurrency);
     lblAnnual_Net.Hint      := FormatFloat('#,##0.00',dm1.qryQAData.FieldByname('Full_Annual_Net_Loss_Earn').AsCurrency);

     lblWeekly_90.Hint          := FormatFloat('#,##0.00',dm1.qryQAData.FieldByname('Full_Weekly_90_Net_Loss').AsCurrency);
     lblCalcTaxSheltering.Hint  := FormatFloat('#,##0.00',dm1.qryQAData.FieldByname('Full_Weekly_Tax_Sheltering').AsCurrency);
     lblWeekly_90_S.Hint        := FormatFloat('#,##0.00',dm1.qryQAData.FieldByname('Full_Weekly_90_Net_Sheltered').AsCurrency);
     lblDailyCompensationRate.Hint := FormatFloat('#,##0.00',dm1.qryQAData.FieldByname('Full_Weekly_Daily_Comp_Rate').AsCurrency);

     lblWeekly_80.Hint                   := FormatFloat('#,##0.00',dm1.qryQAData.FieldByname('Full_Weekly_80_Net_Loss').AsCurrency);
     lblnc_104_Wk_Clmt_p_Contrib.Hint    := FormatFloat('#,##0.00',dm1.qryQAData.FieldByname('Full_Clmnt_Percent_Contrib').AsCurrency);
     lblWkly_Clmt_Anty_Con_Amt.Hint      := FormatFloat('#,##0.00',dm1.qryQAData.FieldByname('Full_Clmnt_Contrib').AsCurrency);
     lblCalcWkly80p_Net_Clmt_Contr.Hint  := FormatFloat('#,##0.00',dm1.qryQAData.FieldByname('Full_Weekly_80_Clmnt_Net_Contrib').AsCurrency);

     lblCalcnc_104_Wk_WCB_p_Contrib_Red.Hint := FormatFloat('#,##0.00',dm1.qryQAData.FieldByname('Full_WCB_Percent_Contrib').AsCurrency);
     lblCalcWkly_p_WCB_Contr.Hint := FormatFloat('#,##0.00',dm1.qryQAData.FieldByname('Full_WCB_Contrib').AsCurrency);
     lblDaily80FullCompensationRate.Hint := FormatFloat('#,##0.00',dm1.qryQAData.FieldByname('Full_Weekly_Adjusted_Daily_Comp_Rate').AsCurrency);

     lblPartPre_Weekly_Net.Hint       := FormatFloat('#,##0.00',dm1.qryQAData.FieldByname('Partial_Net_Pre_Injury').AsCurrency);
     lblPartPost_Injury_Earn_Net.Hint := FormatFloat('#,##0.00',dm1.qryQAData.FieldByname('Partial_Net_Post_Injury').AsCurrency);
     // lblPartCalcNetLossEarnings.Hint  := FormatFloat('#,##0.00',dm1.qryQAData.FieldByname('').AsCurrency);

     lblPartWeekly_90.Hint          := FormatFloat('#,##0.00',dm1.qryQAData.FieldByname('Partial_90_Net_Loss_Earn').AsCurrency);
     lblPartCalcTaxSheltering.Hint  := FormatFloat('#,##0.00',dm1.qryQAData.FieldByname('Partial_Tax_Sheltering').AsCurrency);
     lblPartWeekly_90_S.Hint        := FormatFloat('#,##0.00',dm1.qryQAData.FieldByname('Partial_90_Net_Sheltered').AsCurrency);
     lblPartDailyCompensationRate.Hint  := FormatFloat('#,##0.00',dm1.qryQAData.FieldByname('Partial_Daily_Comp_Rate').AsCurrency);



     lblPartWeekly_80.Hint                  := FormatFloat('#,##0.00',dm1.qryQAData.FieldByname('Partial_80_Net_Loss').AsCurrency);
     lblPart_nc_104_Wk_Clmt_p_Contrib.Hint  := FormatFloat('#,##0.00',dm1.qryQAData.FieldByname('Partial_Clmnt_Percent_Contrib').AsCurrency);
     lblPartWkly_Clmt_Anty_Con_Amt.Hint     := FormatFloat('#,##0.00',dm1.qryQAData.FieldByname('Partial_Clmnt_Contrib').AsCurrency);
     lblPartCalcWkly80p_Net_Clmt_Contr.Hint := FormatFloat('#,##0.00',dm1.qryQAData.FieldByname('Partial_80_Net_Contrib').AsCurrency);
     lblPart_Calcnc_104_Wk_WCB_p_Contrib_Red.Hint := FormatFloat('#,##0.00',dm1.qryQAData.FieldByname('Partial_WCB_Percent_Contrib').AsCurrency);
     lblPartCalcWkly_p_WCB_Contr.Hint       := FormatFloat('#,##0.00',dm1.qryQAData.FieldByname('Partial_WCB_Contrib').AsCurrency);
     lblPartDaily80CompensationRate.Hint    := FormatFloat('#,##0.00',dm1.qryQAData.FieldByname('Partial_80_Daily_Comp_Rate').AsCurrency);


       edAccident_Date.SetFocus;
       SelectNext(ActiveControl as TWinControl,True,True);  // Tab to Next control
       SelectNext(ActiveControl as TWinControl,False,True); // Tab to previous control

       if cboAverageEarningsBasedOn.Text = 'Indexing' then
          begin
          QAWagelossIndexation;
          edQATestID.Text := dm1.qryQAData.FieldByName('QATestID').AsString;
          end
       else
          begin
          PressFunctionKey(9);
          edQATestID.Text := dm1.qryQAData.FieldByName('QATestID').AsString;
          end;

       with lblWeekly_Net do
       if Caption <> Hint then
       begin
          Color := clRed;
          Font.Color := clYellow;
       end
       else
       begin
          Color := clWhite;
          Font.Color := clWindowText;
       end;
  Finally
    LockWindowUpdate(0);
  End;
end;


procedure TWagelossBenefitCalcForm.DBNavigator1Click(Sender: TObject;
  Button: TNavigateBtn);
var
  isIndex : String;
  Q : TADOQuery;
begin

  Q := (DBNavigator1.DataSource.DataSet as TADOQuery);
  if Q.Fields[0].IsNull then
     Exit;

  if (cbxIndexationOnly.Checked) and (Button = nbPrior) and (lblIndexation_Year.Caption = '0') then
  begin
    if Q.Bof and not isYearChange then
    begin
       MyMessageDialog(Format('Starting point ! No entries of %S to process prior to this !',[cmbAccidentYear.Text]),
                    mtInformation,[mbOK] ,['OK']);
    end;
    edQATestID.Text := dm1.qryQAData.FieldByName('QATestID').AsString;
    edQATestIDExit(edQATestID);
  end;

  resetControlsAfterIndexation;
  fillInFormQATestData;

  if Q.Eof then
  begin
    if cbxIndexationOnly.Checked then isIndex := 'Indexation';
    MyMessageDialog(Format('Done! No more entries of %S %S to process!',[cmbAccidentYear.Text,isIndex]),
                    mtInformation,[mbOK] ,['OK'])
  end;
end;

procedure TWagelossBenefitCalcForm.DoShowHint(var HintStr: string;
  var CanShow: Boolean; var HintInfo: THintInfo);
var
  i : integer;
begin
  if WagelossMainForm.isRunManualTest then
  for i := 0 to Application.ComponentCount - 1 do
      if Application.Components[i] is THintWindow then
      with THintWindow(Application.Components[i]).Canvas do
      begin
          Font.Name   := 'Arial';
          Font.Size   := Self.Canvas.Font.Size + 5;
          //Font.Style  := [fsBold];
          Brush.Color := clWhite;
          HintInfo.HintColor := clYellow;
      end;
end;

procedure TWagelossBenefitCalcForm.FormShow(Sender: TObject);
var
  S : String;
begin
    //***
    if WagelossMainForm.isTestCalculator or WagelossMainForm.isRunManualTest then
    begin
      btnIndexation.Visible := True;
      cbxIndexationOnly.Visible := False;
      cbxRecurrance.Visible := True;

      if WagelossMainForm.isRunManualTest then
      begin
        S := 'select distinct Year(Accident_Date) from QAData order by Year(Accident_Date) DESC';
        LoadCombo(S, cmbAccidentYear);
        cmbAccidentYear.Text := cmbAccidentYear.Items[1];
        cmbAccidentYearChange(cmbAccidentYear);
        btnIndexation.Visible := False;
        cbxIndexationOnly.Visible := True;
        cbxRecurrance.Visible := False;
      end;
    end;
    //***
end;


procedure TWagelossBenefitCalcForm.MarkMisMatchLabels(lArray: array of TLabel);
var
  i : Integer;
  C, H : String;
  L : TLabel;
begin
  for i := Low(lArray) to High(lArray) do
  begin
    if lArray[i] is TLabel then
    begin
       L := (lArray[i] as TLabel);
       C := LeftStr( L.Caption,Pos('.',L.Caption)-1);
       H := LeftStr( L.Hint,Pos('.',L.Hint)-1);
       C := cleanNumber(C);
       H := cleanNumber(H);
       if C <> H then
       begin
         L.Transparent := false;
         L.Color := clRed;
         L.Font.Color := clWindowText;
       end
       else
       begin
         L.Transparent := true;
         L.Color := clWhite;
         L.Font.Color := clWindowText;
       end;
    end;
  end;
end;

procedure TWagelossBenefitCalcForm.CheckForMisMatchValues;
var
 lblArray : array of TLabel;
begin

  SetLength(lblArray,0);
  SetLength(lblArray,36);

  lblArray[0]       := lblInc_Tax_Fed;
  lblArray[1]       := lblInc_Tax_Man;
  lblArray[2]       := lblCPP_Prem;
  lblArray[3]       := lblEI_Prem;
  lblArray[4]       := lblTotal_Deds;
  lblArray[5]       := lblWkly_Total_Deds;

  lblArray[6]       := lblWkly_Sal_A;
  lblArray[7]       := lblWeekly_Net;
  lblArray[8]       := lbCalc90p_Wkly_Net_A;
  lblArray[9]       := lblAnnual_Gross;
  lblArray[10]      := lblAnnual_Net;

  lblArray[11]      := lblWeekly_90;
  lblArray[12]      := lblCalcTaxSheltering;
  lblArray[13]      := lblWeekly_90_S;
  lblArray[14]      := lblDailyCompensationRate;

  lblArray[15]      := lblWeekly_80;
  lblArray[16]      := lblnc_104_Wk_Clmt_p_Contrib;
  lblArray[17]      := lblWkly_Clmt_Anty_Con_Amt;
  lblArray[18]      := lblCalcWkly80p_Net_Clmt_Contr;

  lblArray[19]      := lblCalcnc_104_Wk_WCB_p_Contrib_Red;
  lblArray[20]      := lblCalcWkly_p_WCB_Contr;
  lblArray[21]      := lblDaily80FullCompensationRate;

  lblArray[22]      := lblPartPre_Weekly_Net;
  lblArray[23]      := lblPartPost_Injury_Earn_Net;

  lblArray[24]      := lblPartWeekly_90;
  lblArray[25]      := lblPartCalcTaxSheltering;
  lblArray[26]      := lblPartWeekly_90_S;
  lblArray[27]      := lblPartDailyCompensationRate;

  lblArray[28]      := lblPartWeekly_80;
  lblArray[29]      := lblPart_nc_104_Wk_Clmt_p_Contrib;
  lblArray[30]      := lblPartWkly_Clmt_Anty_Con_Amt;
  lblArray[31]      := lblPartCalcWkly80p_Net_Clmt_Contr;
  lblArray[32]      := lblPart_Calcnc_104_Wk_WCB_p_Contrib_Red;
  lblArray[33]      := lblPartCalcWkly_p_WCB_Contr;
  lblArray[34]      := lblPartDaily80CompensationRate;

  lblArray[35]       := lblCPP2_Prem;

  MarkMisMatchLabels(lblArray);

end;


procedure TWagelossBenefitCalcForm.btnListClick(Sender: TObject);
begin
  if frmQATestList = nil then
     frmQATestList := TfrmQATestList.Create(Application);
  Try
    LockWindowUpdate(frmQATestList.Handle);
    frmQATestList.Show;
  Finally
    LockWindowUpdate(0);
  End;
end;


procedure TWagelossBenefitCalcForm.SetEditTestRecord(qryTestRecord: TADOQuery);
begin
   FqryEditTestRecord := qryTestRecord;

   btnIndexation.Visible := isInTestIndexationEditMode;

   isInTestEditMode := True;

   if isInTestIndexationEditMode then
      isInTestEditMode := False;

   edAccident_Date.Text := qryTestRecord.FieldByname('Accident_Date').AsString;
   edClaimPrefix.Text      := qryTestRecord.FieldByname('claim_year').AsString;
   edClaimDescription.Text := qryTestRecord.FieldByname('QADataDescription').AsString;
   edAccident_Date.Text    := CustomStrToDateStr( qryTestRecord.FieldByname('Accident_Date').AsString );
   edEffectiveDate.Text    := CustomStrToDateStr( qryTestRecord.FieldByname('EffectiveDate').AsString );
   edWkly_Sal_A.Text       := qryTestRecord.FieldByname('Weekly_Wage').AsString;
   edDays_Worked_per_Week.Text := qryTestRecord.FieldByname('Days_Week').AsString;
   lblIndexation_Year.Caption  := qryTestRecord.FieldByname('Indexed_Year').AsString;
   CalcFullClaim.Indexation_Year := StrToInt(qryTestRecord.FieldByname('Indexed_Year').AsString);
   edTax_Year.Text         := qryTestRecord.FieldByname('Tax_Year').AsString;
   edRecurrence.Text       := qryTestRecord.FieldByname('Recurence').AsString;
   edRecurrenceDate.Text   := qryTestRecord.FieldByname('Recurrence_Date').AsString;
   edYouthful_Worker.Text  := qryTestRecord.FieldByname('Youthful_Worker').AsString;
   edApprentice.Text       := qryTestRecord.FieldByname('Apprentice').AsString;
   edSelf_Employed.Text       := qryTestRecord.FieldByname('Self_Employed').AsString;
   cboMaritalStatus.KeyValue  := qryTestRecord.FieldByname('Marital_Status').AsString;
   edSpouse_Working.Text      := qryTestRecord.FieldByname('Spouse_Working').AsString;
   edClaimSpouseForTaxPurposes.Text := qryTestRecord.FieldByname('ClaimSpouseForTaxPurposes').AsString;
   edNo_Of_Dependnts.Text     := qryTestRecord.FieldByname('Nbr_Of_Dependants').AsString;
   edNo_Infirm.Text           := qryTestRecord.FieldByname('Nbr_Of_Infirm_Deps').AsString;
   edEI_Exempt.Text           := qryTestRecord.FieldByname('Uic_Exempt').AsString; //???
   edCPP_Exempt.Text          := qryTestRecord.FieldByname('CPP_Exempt').AsString;
   edTax_Exempt.Text          := qryTestRecord.FieldByname('Income_Tax_Exempt').AsString;
   ednc_104_Wk_Effective_Date.Text  := CustomStrToDateStr( qryTestRecord.FieldByname('Accident_Date').AsString );
   ednc_104_Wk_Clmt_p_Eff_Date.Text := CustomStrToDateStr( qryTestRecord.FieldByname('Accident_Date').AsString );

   edChild_Care_Exp.Text      := FormatFloat('#,##0.00',qryTestRecord.FieldByname('Child_Care_Expense').AsCurrency);
   edSpousal_Support.Text     := FormatFloat('#,##0.00',qryTestRecord.FieldByname('Spousal_Support').AsCurrency);

   if StrToFloat(edChild_Care_Exp.Text) <> 0 then
      begin
      edChild_Care_Exp.ReadOnly := False;
      setEditToNormal( edChild_Care_Exp );
      setEditToNormal( edSpousal_Support );
      end;


   edCollateral_Ben_Tax.Text     := FormatFloat('#,##0.00',qryTestRecord.FieldByname('Collateral_Taxable').AsCurrency);
   lblColl_Ben_Tax_Net.Caption   := FormatFloat('#,##0.00',qryTestRecord.FieldByname('Collateral_Taxable_Net').AsCurrency);
   edCollateral_Ben_Non_Tax.Text := FormatFloat('#,##0.00',qryTestRecord.FieldByname('Collateral_Non_Taxable').AsCurrency);
   cboAverageEarningsBasedOn.KeyValue := qryTestRecord.FieldByname('AvgEarningsBasedOn').AsString;

   lblInc_Tax_Fed.Caption        := FormatFloat('#,##0.00',qryTestRecord.FieldByname('Inc_Tax_Fed').AsCurrency);
   lblInc_Tax_Man.Caption        := FormatFloat('#,##0.00',qryTestRecord.FieldByname('Inc_Tax_Prov').AsCurrency);
   lblCPP_Prem.Caption           := FormatFloat('#,##0.00',qryTestRecord.FieldByname('Cpp_Prem').AsCurrency);
   lblCPP2_Prem.Caption           := FormatFloat('#,##0.00',qryTestRecord.FieldByname('Cpp2_Prem').AsCurrency);
   lblEI_Prem.Caption            := FormatFloat('#,##0.00',qryTestRecord.FieldByname('UIC_Prem').AsCurrency);
   lblTotal_Deds.Caption         := FormatFloat('#,##0.00',qryTestRecord.FieldByname('Total_Deds').AsCurrency);
   lblWkly_Total_Deds.Caption    := FormatFloat('#,##0.00',qryTestRecord.FieldByname('Weekly_Deds').AsCurrency);

   edPost_Injury_Earn.Text    := FormatFloat('#,##0.00',qryTestRecord.FieldByname('Post_Earn_Weekly_Gross').AsCurrency);
   edDeemed_Earnings.Text     := qryTestRecord.FieldByname('Deemed').AsString;
   lblPost_Injury_Earn_Net.Caption   := FormatFloat('#,##0.00',qryTestRecord.FieldByname('Post_Earn_Weekly_Net').AsCurrency);

   ednc_104_Wk_Effective_Date.Text   := CustomStrToDateStr( qryTestRecord.FieldByname('80_Effective_Date').AsString);
   ednc_104_Wk_Clmt_p_Eff_Date.Text  := CustomStrToDateStr( qryTestRecord.FieldByname('Clmnt_Contrib_Effective_Date').AsString);

   if isInTestIndexationEditMode then
   begin
     isInTestEditMode := False;
     isInTestIndexationEditMode := False;
     edAccident_Date.SetFocus;
     SelectNext(ActiveControl as TWinControl,True,True);  // Tab to Next control
     SelectNext(ActiveControl as TWinControl,False,True); // Tab to previous control
     Exit;
   end;

   lblWkly_Sal_A.Caption      :=  FormatFloat('#,##0.00',qryTestRecord.FieldByname('Full_Weekly_Gross').AsCurrency);
   lblWeekly_Net.Caption      :=  FormatFloat('#,##0.00',qryTestRecord.FieldByname('Full_Weekly_Net_Loss_Earn').AsCurrency);
   lbCalc90p_Wkly_Net_A.Caption := FormatFloat('#,##0.00',qryTestRecord.FieldByname('Full_Weekly_90_Net_Actual').AsCurrency);
   lblAnnual_Gross.Caption    := FormatFloat('#,##0.00',qryTestRecord.FieldByname('Full_Annual_Gross').AsCurrency);
   lblAnnual_Net.Caption      := FormatFloat('#,##0.00',qryTestRecord.FieldByname('Full_Annual_Net_Loss_Earn').AsCurrency);

   lblWeekly_90.Caption          := FormatFloat('#,##0.00',qryTestRecord.FieldByname('Full_Weekly_90_Net_Loss').AsCurrency);
   lblCalcTaxSheltering.Caption  := FormatFloat('#,##0.00',qryTestRecord.FieldByname('Full_Weekly_Tax_Sheltering').AsCurrency);
   lblWeekly_90_S.Caption        := FormatFloat('#,##0.00',qryTestRecord.FieldByname('Full_Weekly_90_Net_Sheltered').AsCurrency);
   lblDailyCompensationRate.Caption := FormatFloat('#,##0.00',qryTestRecord.FieldByname('Full_Weekly_Daily_Comp_Rate').AsCurrency);

   lblWeekly_80.Caption                   := FormatFloat('#,##0.00',qryTestRecord.FieldByname('Full_Weekly_80_Net_Loss').AsCurrency);
   lblnc_104_Wk_Clmt_p_Contrib.Caption    := FormatFloat('#,##0.00',qryTestRecord.FieldByname('Full_Clmnt_Percent_Contrib').AsCurrency);
   lblWkly_Clmt_Anty_Con_Amt.Caption      := FormatFloat('#,##0.00',qryTestRecord.FieldByname('Full_Clmnt_Contrib').AsCurrency);
   lblCalcWkly80p_Net_Clmt_Contr.Caption  := FormatFloat('#,##0.00',qryTestRecord.FieldByname('Full_Weekly_80_Clmnt_Net_Contrib').AsCurrency);
   lblCalcnc_104_Wk_WCB_p_Contrib_Red.Caption := FormatFloat('#,##0.00',qryTestRecord.FieldByname('Full_WCB_Percent_Contrib').AsCurrency);
   lblCalcWkly_p_WCB_Contr.Caption := FormatFloat('#,##0.00',qryTestRecord.FieldByname('Full_WCB_Contrib').AsCurrency);
   lblDaily80FullCompensationRate.Caption := FormatFloat('#,##0.00',qryTestRecord.FieldByname('Full_Weekly_Adjusted_Daily_Comp_Rate').AsCurrency);

   lblPartPre_Weekly_Net.Caption       := FormatFloat('#,##0.00',qryTestRecord.FieldByname('Partial_Net_Pre_Injury').AsCurrency);
   lblPartPost_Injury_Earn_Net.Caption := FormatFloat('#,##0.00',qryTestRecord.FieldByname('Partial_Net_Post_Injury').AsCurrency);
   // lblPartCalcNetLossEarnings.Hint  := FormatFloat('#,##0.00',qryTestRecord.FieldByname('').AsCurrency);

   lblPartWeekly_90.Caption          := FormatFloat('#,##0.00',qryTestRecord.FieldByname('Partial_90_Net_Loss_Earn').AsCurrency);
   lblPartCalcTaxSheltering.Caption  := FormatFloat('#,##0.00',qryTestRecord.FieldByname('Partial_Tax_Sheltering').AsCurrency);
   lblPartWeekly_90_S.Caption        := FormatFloat('#,##0.00',qryTestRecord.FieldByname('Partial_90_Net_Sheltered').AsCurrency);
   lblPartDailyCompensationRate.Caption  := FormatFloat('#,##0.00',qryTestRecord.FieldByname('Partial_Daily_Comp_Rate').AsCurrency);



   lblPartWeekly_80.Caption                  := FormatFloat('#,##0.00',qryTestRecord.FieldByname('Partial_80_Net_Loss').AsCurrency);
   lblPart_nc_104_Wk_Clmt_p_Contrib.Caption  := FormatFloat('#,##0.00',qryTestRecord.FieldByname('Partial_Clmnt_Percent_Contrib').AsCurrency);
   lblPartWkly_Clmt_Anty_Con_Amt.Caption     := FormatFloat('#,##0.00',qryTestRecord.FieldByname('Partial_Clmnt_Contrib').AsCurrency);
   lblPartCalcWkly80p_Net_Clmt_Contr.Caption := FormatFloat('#,##0.00',qryTestRecord.FieldByname('Partial_80_Net_Contrib').AsCurrency);
   lblPart_Calcnc_104_Wk_WCB_p_Contrib_Red.Caption := FormatFloat('#,##0.00',qryTestRecord.FieldByname('Partial_WCB_Percent_Contrib').AsCurrency);
   lblPartCalcWkly_p_WCB_Contr.Caption       := FormatFloat('#,##0.00',qryTestRecord.FieldByname('Partial_WCB_Contrib').AsCurrency);
   lblPartDaily80CompensationRate.Caption    := FormatFloat('#,##0.00',qryTestRecord.FieldByname('Partial_80_Daily_Comp_Rate').AsCurrency);

   if qryTestRecord.FieldByname('Post_Earn_Weekly_Gross').AsCurrency <> 0.0 then
   begin
      lblPartPre_Weekly_Net.visible := true;
      lblPartPost_Injury_Earn_Net.visible := true;
      lblPost_Injury_Earn_Net.visible := true;
      lblPartCalcNetLossEarnings.visible := true;
      lblPartWeekly_90.visible := true;
      lblPartCalcTaxSheltering.visible := true;
      lblPartWeekly_90_S.visible := true;
      lblPartDailyCompensationRate.visible := true;
      lblPartialWageLoss.Visible := true;
      label77.Visible := true;
      label78.Visible := true;
      label79.Visible := true;
      label89.Visible := true;
      label56.Visible := true;
      label39.Visible := true;
      label80.Visible := true;
      //if year(Accident_Date) < 2006 then begin
        lblPartWeekly_80.visible := true;
        lbl80NetLossPartial.Visible := true;
      //end;
      lblNetLossPartial.Visible := true;
      lblNetShelteredPartial.Visible := true;
      lbl80PercentClaimantContribPartial.Visible := true;
      lbl80PercentClaimContributionPartial.Visible := true;
      lbl80PercentWCBContributionPartial.visible := true;
      lbl80DailyCompRatePartial.Visible := true;
      lblPartWkly_Clmt_Anty_Con_Amt.visible := true;
      lblPartCalcWkly80p_Net_Clmt_Contr.visible := true;
      lblPartCalcWkly_p_WCB_Contr.visible := true;
      lblPart_nc_104_Wk_Clmt_p_Contrib.visible := true;
      lblPart_Calcnc_104_Wk_WCB_p_Contrib_Red.visible := true;
      lblPartDaily80CompensationRate.Visible := true;
   end;

   edAccident_Date.SetFocus;
   SelectNext(ActiveControl as TWinControl,True,True);  // Tab to Next control
   SelectNext(ActiveControl as TWinControl,False,True); // Tab to previous control

   edQATestID.Text := qryTestRecord.FieldByname('QATestID').AsString; //avoid the InjuryDate OnExit which will avoid
end;

procedure TWagelossBenefitCalcForm.cbxRecurranceClick(Sender: TObject);
begin
  if WagelossMainForm.isTestCalculator then
  begin
    if (Sender as TCheckBox).Checked then
      setEditToNormal(edRecurrence)
    else
      SetEditToRead(edRecurrence);
    wcPrevious.SetFocus;
  end;
end;

procedure TWagelossBenefitCalcForm.cmbAccidentYearChange(Sender: TObject);
begin
  isYearChange := True;
  LockWindowUpdate(Handle);
  Try

    with dm1.qryQAData do
    begin
      DisableControls;
      Close;
      if cmbAccidentYear.Text = 'All' then
         if cbxIndexationOnly.Checked then
            SQL.Text := sqlQAIndex
         else
           SQL.Text := sqlQA
      else if cmbAccidentYear.Text <> '' then
         if cbxIndexationOnly.Checked then
           SQL.Text := Format(sqlQAIndexWithWhere,[cmbAccidentYear.Text])
         else
           SQL.Text := Format(sqlQAwithWhere,[cmbAccidentYear.Text]);
      if cbxIndexationOnly.Checked then
        DBNavigator1.VisibleButtons := [nbPrior,nbNext]
      else
        DBNavigator1.VisibleButtons := [nbFirst,nbPrior,nbNext,nbLast];
      Application.ProcessMessages;
      Open;

      resetControlsAfterIndexation;
      if (RecordCount > 0)  then
      begin
        DBNavigator1Click(DBNavigator1,nbFirst);
        DBNavigator1Click(DBNavigator1,nbNext);
        DBNavigator1Click(DBNavigator1,nbPrior);
        edQATestID.Text := dm1.qryQAData.FieldByName('QATestID').AsString;
      end;
      EnableControls;
    end;
  Finally
    LockWindowUpdate(0);
  End;
  isYearChange := False;

end;

procedure TWagelossBenefitCalcForm.QAWagelossIndexation;
var
   nc_accident_year, nc_curr_year, nc_Min_Index, nc_Max_Index : Integer;
   nc_claim_elig_index, oneMonthEarly: Boolean;
   MSG : Tmessage;
   WorkDate, recurDate, effectDate : TDateTime;
   Work_Year, Work_Month, Work_Day : Word;
   fltNew_Max, fltMax_Adjustment : Currency;

   Acc_Year, Acc_Month, Acc_Day, Idx_Month:Word;
   K : Word;
   btnSelected : Integer;
begin
  nc_Max_Index := 0;
  nc_Min_Index := 0;
  oneMonthEarly := False;

  if not WagelossMainForm.isRunManualTest then
     exit;

  ResetInfoLine2;

  with CalcFullClaim do
     begin
//     if  WagelossMainForm.isTestCalculator then
//     begin
//      if ( edClaimPrefix.Text < '91' ) and ( edClaimPrefix.Text > '20' ) then
//      begin
//        WagelossMainForm.ShowInfoLine2( 'Injury date not eligible for indexing.' );
//        globalEditError:=true;
//        exit;
//      end;
//    end;

     if Accident_Date < 1 then
        begin
        WagelossMainForm.ShowInfoLine2( '*Blank Incident Date Encountered - Indexation Cancelled.' );
        globalEditError := true;
        exit;
        end;

     if year(Accident_Date) < 1992 then
        begin
        WagelossMainForm.ShowInfoLine2( 'Injury date not eligible for indexing.' );
        globalEditError:=true;
        exit;
        end;

     if Month(Accident_Date) < 12 then
        nc_accident_year := year( Accident_Date )
     else
        nc_accident_year := year( Accident_Date ) + 1;

     if Month( Accident_Date ) < 12 then
        nc_curr_year := Year( utilmod1.getEmergeBusinessDate() )
     else
        nc_curr_year := Year( utilmod1.getEmergeBusinessDate() ) + 1;

     nc_claim_elig_index := ( nc_curr_year >= ( nc_accident_year + 2 ) );

     WorkDate := Accident_Date;
     WorkDate := EncodeDate( Year( WorkDate ), Month( WorkDate ), 1);
     WorkDate := utilmod1.AddMonths( WorkDate, 25 );
     DecodeDate( WorkDate, Work_Year, Work_Month, Work_Day );

     if ( ( Work_Year >= NCMain.cnst_Max_Tax_Year ) and
          ( Work_Month > NCMain.cnst_Max_Tax_Month ) ) then
        begin
        nc_claim_elig_index := False;
        globalEditError := True;
        end
     else
        begin
        if ( ( IncMonth( WorkDate, - 1 ) > utilmod1.getEmergeBusinessDate() ) ) then
           begin
           oneMonthEarly := True;
           globalEditError := True;
           end
        else
           begin
           nc_Min_Index := Work_Year;

           if ( Work_Month = 1 ) AND ( Month( utilmod1.getEmergeBusinessDate() ) = 12 ) Then
              Work_Year := Max(Year( utilmod1.getEmergeBusinessDate() ) + 1, nc_Min_Index)
           else
              Work_Year := Max( Year( utilmod1.getEmergeBusinessDate() ), nc_Min_Index );

           WorkDate := EncodeDate( Work_Year, Work_Month, Work_Day );

           if ((IncMonth(WorkDate, - 1) > utilmod1.getEmergeBusinessDate())) then
              begin
              DecodeDate( WorkDate, Work_Year, Work_Month, Work_Day );
              Work_Year := Work_Year - 1;
              WorkDate := EncodeDate( Work_Year, Work_Month, Work_Day );
              end;

           DecodeDate( WorkDate, Work_Year, Work_Month, Work_Day );

           nc_Max_Index := Work_Year;
           end;
        end;

     if not nc_claim_elig_index then
        begin
        MessageDlg('       Indexation Cancelled.' + #10#10 +
                   'Claim is not eligible for indexing.', mtError, [mbOK], 0);
        globalEditError := True;
        exit;
        end;

     if oneMonthEarly then
        begin
        MessageDlg('                   Indexation Cancelled.' + #10#10 +
                   'Claim is not within one month of the valid indexation date.', mtError, [mbOK], 0);
        globalEditError := True;
        exit;
        end;

     try
        WagelossIndexationForm := TWagelossIndexationForm.create( Application );

        //if (edApprentice.Text = 'Y') then //or (edYouthful_Worker.Text = 'Y')  then
        //   begin
           Wkly_Sal_A := dm1.qryQAData.FieldByName('Weekly_Wage').AsCurrency;
        //   end;

        WagelossIndexationForm.CurrentIndexation_Year := Indexation_Year;
        WagelossIndexationForm.CurrentWeekly_Salary := Wkly_Sal_A;
        WagelossIndexationForm.MinIndexation_Year := nc_Min_Index;
        WagelossIndexationForm.MaxIndexation_Year := nc_Max_Index;
        WagelossIndexationForm.Indexation_Month := Work_Month;
        WagelossIndexationForm.Youthful_Worker := dm1.qryQAData.FieldByName('Youthful_Worker').AsString; //Youthful_Worker;
        WagelossIndexationForm.Apprentice := Apprentice;
        WagelossIndexationForm.NewIndexation_Year := StrToInt( lblIndexation_Year.Caption );//nc_Max_Index;

        if edYouthful_Worker.Text = 'Y' then
           begin
           WagelossIndexationForm.edNewWkly_Sal_A.Text := format('%.2n', [dm1.qryQAData.FieldByName('Weekly_Wage').AsCurrency]);
           end;

        WagelossIndexationForm.edNewWkly_Sal_AExit(WagelossIndexationForm.edNewWkly_Sal_A);

        if ( WagelossIndexationForm.NewWeekly_Salary > 0 ) Then
           begin
           with CalcFullClaim do
              begin
              fltMax_Adjustment := TextAsCurrency(edMax_Adjustments);
              fltNew_Max := Calc_New_Max(Indexation_Year,
                                         Self_Employed = 'Y',
                                         Recurrence = 'Y',
                                         RecurrenceDate,
                                         Accident_Date,
                                         WageLossIndexationForm.NewIndexation_Year,
                                         fltMax_Adjustment
                                        );

              Max_Adjustment := fltNew_Max;
              Wkly_Sal_A := WagelossIndexationForm.NewWeekly_Salary;
              Indexation_Year := WagelossIndexationForm.NewIndexation_Year;

              if (Indexation_Year <> 0) then
                 cboAverageEarningsBasedOn.KeyValue := 'Indexing'
              else
                 cboAverageEarningsBasedOn.KeyValue := '';

              Indexation_Calc_Date := utilmod1.getEmergeBusinessDate();

              Tax_Year := Max(Max(Year(Accident_Date), Year(RecurrenceDate)),
                              WagelossIndexationForm.NewIndexation_Year);

              edWkly_Sal_A.text := format( '%.2n', [ Wkly_Sal_A ] );
              lblIndexation_Year.caption := format( '%d', [ Indexation_Year ] );

              DecodeDate(CalcFullClaim.Accident_Date, Acc_Year, Acc_Month, Acc_Day);

              if ((CalcFullClaim.Indexation_Year > 0) AND (CalcFullClaim.Tax_Year <> Acc_Year)) Then
                 Idx_Month := Max(((Acc_Month+1) Mod 13),1)
              else
                 Idx_Month := Acc_Month;

              WorkDate := EncodeDate(Min(Max(CalcFullClaim.Indexation_Year,Acc_Year), CalcFullClaim.Tax_Year), Idx_Month, 1);

              Indexation_Calc_Date := WorkDate;

              if (edEffectiveDate.Text <> '') then
                 effectDate := StrToDate(edEffectiveDate.Text)
              else
                 effectDate := 0;

              if (edRecurrenceDate.Text <> '') then
                 recurDate := StrToDate( edRecurrenceDate.Text )
              else
                 recurDate := 0;

              if  Indexation_Calc_Date < effectDate then
                 effectDate := Indexation_Calc_Date;

              try
                 if (CalcFullClaim.Indexation_Year > 0) then
                    begin
                    edEffectiveDate.Text := FormatDateTime('dd/mm/yyyy', Max(Indexation_Calc_Date,
                                                                             Max( effectDate, recurDate)));
                    end
                 else
                    begin
                    edEffectiveDate.Text := '';
                    end;
              except
                 on E:Exception do
                    begin  //ignore error
                    end;
              end;

              edTax_Year.text := format( '%d', [Tax_Year] );

              if ((Year(CalcFullClaim.Accident_Date) < 2006) or (edSelf_Employed.Text = 'Y')) Then
                 begin
                 edMax_Adjustments.Text := format('%.2n', [ Max_Adjustment ] );
                 end;

              SetUpdateInd(True);

              ResetInfoLine2;

              uGlobal.RecalcBen(CalcFullClaim, CalcPartClaim, DeathBenefitCalc);

              with MSG do
                 begin
                 Msg := 0;
                 WParam := 0;
                 LParam := 0;
                 end;

              if WagelossIndexationForm.NewIndexation_Year > 0 then
                 begin
                 PressFunctionKey(9);
                 ResetInfoLine2;
                 isIndexation := False;
                 FnextQATestID := 0;
                 end;

              end;
           end;
     finally
        WagelossIndexationForm.free;
        ResetInfoLine2;
        FnextQATestID := 0;
     end;
     end;

end;



procedure TWagelossBenefitCalcForm.ActiveControlChanged(Sender: TObject);
begin
  wcPrevious := wcActive;
  wcActive := Self.ActiveControl;
end;

procedure TWagelossBenefitCalcForm.edQATestIDExit(Sender: TObject);
begin
  if WagelossMainForm.isRunManualTest then
  begin
    if dm1.qryQAData.Locate('QATestID',edQATestID.Text,[loPartialKey]) then
    begin
      resetControlsAfterIndexation;
      fillInFormQATestData;
    end;
  end;
end;

procedure TWagelossBenefitCalcForm.edMax_AdjustmentsEnter(Sender: TObject);
begin
 PostMessage(edMax_Adjustments.Handle, EM_SETSEL, 0, -1);


end;

end.



