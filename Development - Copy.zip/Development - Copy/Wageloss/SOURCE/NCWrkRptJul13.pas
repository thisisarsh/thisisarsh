unit NCWrkRptJul13;

interface

uses
  Windows, Messages, SysUtils, Variants, Classes, Graphics, Controls, Forms,
  Dialogs, NCWrkRptJan13;

type
  TWrkRptJul13 = class(TWrkRptJan13)
  function getDateHeading():String; Override;
  private
    { Private declarations }
  public
    { Public declarations }
  end;

var
  WrkRptJul13: TWrkRptJul13;

implementation

{$R *.dfm}
(******************************************************************************)
(*                                                                            *)
(*  override this function for each class to avoid having to bring in all of  *)
(*    the methods that contain the date in the heading.                       *)
(*   IE:  the jan 09 class should return  2008/2009                           *)
(*        the july 09 class should return 2009                                *)
(*                                                                            *)
(******************************************************************************)

function TWrkRptJul13.getDateHeading():String;
begin
  result:='2013'
end;

end.
