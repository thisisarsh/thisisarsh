inherited WrkRptJan15: TWrkRptJan15
  Left = 413
  Top = 215
  Caption = 'WrkRptJan15'
  PixelsPerInch = 96
  TextHeight = 13
end
