unit NCWrkRptJan01;

interface

uses NCWrkRptJan00, quickrpt, SysUtils;

type
  TWrkRptJan01 = class(TWrkRptJan00)
  Function Set_nc_bc_mbt(sIncType: shortString): currency;
  procedure TaxCalculationBand1( const income: currency; sIncomeType: shortstring );Override;
  Function  TaxCalculationBand1P5b(Nc_Bc_Ann_Sal_Net: currency;
                                   Nc_Bc_Mb_Nrtc: currency;
                                   Nc_Bc_Mbt: currency): currency; Dynamic;
  procedure TaxCalculationBand1P4( Nc_Bc_Bft: Currency;
    															 Nc_Bc_Fst: Currency); Override;
  private
    { Private declarations }
  public
    { Public declarations }
  end;

var
  WrkRptJan01: TWrkRptJan01;

implementation

uses NCIniMod, UtilMod1, NCBencal, NCRecdef;

{$R *.DFM}

(******************************************************************************)
(*                                                                            *)
(*  Create Tax Calculation Band                                               *)
(*                                                                            *)
(******************************************************************************)
procedure TWrkRptJan01.TaxCalculationBand1( const income: currency;
																					  sIncomeType: shortstring );
var
  t2: currency;
  a: currency;
  b: currency;
  ws_Work_nc_bc_ann_sal_net: currency;
  ws_Work_nc_bc_bft: currency;
  ws_Work_nc_bc_cpp: currency;
  ws_Work_nc_bc_uic: currency;
  ws_Work_nc_bc_nrtc: currency;
  ws_Work_nc_bc_fst: currency;
  ws_Work_nc_bc_mbt: currency;
  ws_Work_nc_bc_mb_nrtc: currency;
  ws_Work_nc_bc_mb_tax: currency;
  ws_Work_nc_bc_netinc: currency;
  ws_Work_nc_bc_td: currency;
  //federalCanadaEmploymentCredit: currency;
  mbFamilyTaxBenefitAmt: currency;
begin
  ws_Work_nc_bc_ann_sal_net := Set_nc_bc_ann_sal_net(sIncomeType);
  ws_Work_nc_bc_bft := Set_nc_bc_bft(sIncomeType);
  ws_Work_nc_bc_cpp := Set_nc_bc_cpp(sIncomeType);
  ws_Work_nc_bc_uic := Set_nc_bc_uic(sIncomeType);
  ws_Work_nc_bc_nrtc := Set_nc_bc_nrtc(sIncomeType);
  ws_Work_nc_bc_fst := Set_nc_bc_fst(sIncomeType);
  ws_Work_nc_bc_mbt := Set_nc_bc_mbt(sIncomeType);
  ws_Work_nc_bc_mb_nrtc	:= Set_nc_bc_mb_nrtc(sIncomeType);
  ws_Work_nc_bc_mb_tax := Set_nc_bc_mb_tax(sIncomeType);
  ws_Work_nc_bc_netinc := Set_nc_bc_netinc(sIncomeType);
  ws_Work_nc_bc_td := Set_nc_bc_td(sIncomeType);
  //federalCanadaEmploymentCredit := Set_federalCanadaEmploymentCredit(sIncomeType);
  mbFamilyTaxBenefitAmt    := Set_mbFamilyTaxBenefitAmt(sIncomeType);
  TaxCalculationBand1P1(income, sIncomeType, ws_Work_nc_bc_ann_sal_net);
  //TaxCalculationBand1P2(income, ws_Work_nc_bc_ann_sal_net,
  //                      ws_Work_nc_bc_uic, ws_Work_nc_bc_cpp,
  //                      ws_Work_nc_bc_nrtc, ws_Work_nc_bc_mb_nrtc, federalCanadaEmploymentCredit);
  TaxCalculationBand1P2(income, ws_Work_nc_bc_ann_sal_net,
                        ws_Work_nc_bc_uic, ws_Work_nc_bc_cpp,
                        ws_Work_nc_bc_nrtc, ws_Work_nc_bc_mb_nrtc, mbFamilyTaxBenefitAmt);
  t2 := TaxCalculationBand1P3(ws_Work_nc_bc_ann_sal_net, ws_Work_nc_bc_nrtc);
  TaxCalculationBand1P4(ws_Work_nc_bc_bft, ws_Work_nc_bc_fst);
  a := TaxCalculationBand1P5b(ws_Work_nc_bc_ann_sal_net, ws_Work_nc_bc_mb_nrtc,
  														ws_Work_nc_bc_mbt);
  b := TaxCalculationBand1P6(ws_Work_nc_bc_ann_sal_net);
  TaxCalculationBand1P7(ws_Work_nc_bc_ann_sal_net, ws_Work_nc_bc_mb_tax, a, b);
  TaxCalculationBand1P8(ws_Work_nc_bc_cpp, ws_Work_nc_bc_uic, t2);
  TaxCalculationBand1P9(ws_Work_nc_bc_fst);
  TaxCalculationBand1P10(income, sIncomeType, ws_Work_nc_bc_mb_tax, ws_Work_nc_bc_td,
                         ws_Work_nc_bc_cpp, ws_Work_nc_bc_uic, ws_Work_nc_bc_bft,
                         ws_Work_nc_bc_fst, ws_Work_nc_bc_netinc, ws_Work_nc_bc_mbt);
end;

Function TWrkRptJan01.Set_nc_bc_mbt(sIncType: shortString): currency;
begin
   if sIncType = 'Actual' then
      begin
      result := fWorking.Work_nc_bc_mbt_a;
      end
   else if sIncType = 'Maximum' then
      begin
      result := fWorking.Work_nc_bc_mbt_b;
      end
   else if sIncType = 'Sheltered' then
      begin
      result := fWorking.Work_nc_bc_mbt_c;
      end
   else if sIncType = 'Minimum Annual Earnings (AA)' then
  begin
    result := fWorking.Work_nc_bc_mbt_m;
  end
  else if sIncType = 'Collateral Benefits - Only' then
  begin
    result := fWorking.Work_nc_bc_mbt_d;
  end
  else if sIncType = 'Sheltered (CC)' then
  begin
    result := fWorking.Work_nc_bc_mbt_s;
  end
  else
      begin
      result := fWorking.Work_nc_bc_mbt_e;
      end;
end;

procedure TWrkRptJan01.TaxCalculationBand1P4(Nc_Bc_Bft: Currency;
																						 Nc_Bc_Fst: Currency);
begin
  sRpt.add('Federal Surtax:');
  sRpt.add(' ');
  with arrayNCTAXRAT[indexNCTAXRAT] do
  begin
    sRpt.add( format('%-56s %-14s %-14s', [
      formatF( Nc_Bc_Bft, 12, 2 ) + ' - ' + formatF(FED_surtax_limit_ii, 12, 2) +
      ' x ' +
      format( '%.2n', [ ( FED_surtax_rate_ii * 100.00 ) ] ) + '%',
      formatF( Nc_Bc_Fst, 12, 2 ),
      ' '
      ]));
    sRpt.add( format('%-56s %-14s %-14s', [
      'Basic Federal Tax: (O)',
      ' ',
      ' '
    ]));
  end;
  sRpt.add( format('%-56s %-14s %-14s', [ ' ',  dash(12), ' '       ]));
  sRpt.add( format('%-56s %-14s %-14s', [
    '    Federal Surtax ',
    formatF( Nc_Bc_Fst, 12, 2 ),
    ' (P1)'
    ] ));
  sRpt.add( format('%-56s %-14s %-14s', [ ' ', dDash(12), ' '       ]));
  sRpt.add(' ');
End;

Function  TWrkRptJan01.TaxCalculationBand1P5b( Nc_Bc_Ann_Sal_Net: currency;
                                               Nc_Bc_Mb_Nrtc: currency;
                                               Nc_Bc_Mbt: currency): currency;
var
  const1:currency;
  const2:currency;
  f2p	:currency;
  f1i	:currency;
  work	:currency;

begin
  sRpt.add(' ');
  sRpt.add(formatI(wrkClaim.Tax_Year,4) + ' Manitoba Income Tax Rates (WCB):');
  sRpt.add(' ');
  with arrayNCTAXRAT[indexNCTAXRAT] do
    begin
    sRpt.add('    +'+ dash(76) + '+');
    sRpt.add( format('    | %-28s | %-20s | %-20s |', [
      'Taxable Income Amount',
      'Rate',
      'Constant'
      ]));
    sRpt.add('    +'+ dash(76) + '+');
    sRpt.add( format('    | %-28s | %-20s | %-20s |', [
      format('%.0n',[MB_income_level_i]) + ' or less',
      format('%.2n',[(MB_tax_rate_i*100.00)]) + '%',
      format('%.2n',[0.00])
      ]));
    const1 := Round((MB_income_level_i * (MB_tax_rate_ii - MB_tax_rate_i)) * 100)/100;
    sRpt.add( format('    | %-28s | %-20s | %-20s |', [
      '> ' + format('%.0n',[MB_income_level_i]),
      format('%.2n',[(MB_tax_rate_ii*100.00)]) + '%',
      format('%.2n',[const1])
      ]));
    const2 := Round((MB_income_level_ii * (MB_tax_rate_iii - MB_tax_rate_ii)
      + const1)*100)/100;
    sRpt.add( format('    | %-28s | %-20s | %-20s |', [
      '> ' + format('%.0n',[MB_income_level_ii]),
      format('%.2n',[(MB_tax_rate_iii*100.00)]) + '%',
      format('%.2n',[const2])
      ]));
    sRpt.add('    +'+ dash(76) + '+');
    sRpt.add(' ');
    sRpt.add('Manitoba Income Tax:');
    sRpt.add(' ');
    sRpt.add('    For ' + formatF(Nc_Bc_Ann_Sal_Net, 11, 2 ) +' (Amount (LK) above):' );

    if ( Nc_Bc_Ann_Sal_Net > MB_income_level_ii ) then
       begin
       f2p:=MB_tax_rate_iii;
       f1i:=const2;
       end
    else if ( Nc_Bc_Ann_Sal_Net > MB_income_level_i ) then
       begin
       f2p:=MB_tax_rate_ii;
       f1i:=const1;
       end
    else
       begin
       f2p:=MB_tax_rate_i;
       f1i:=0.0;
       end;
    end;

    if (wrkClaim.Claim_No = '00000000') Then
     begin
     f2p := 0; // set the tax rate to be a blank
     end;

  sRpt.add(' ');
  sRpt.add( format('%-56s %-14s %-14s', [
    '    Multiply by tax rate from above table ' + format('%.2n',[f2p * 100]){FormatF((f2p * 100), 6, 2)} + '%',
    formatF((Nc_Bc_Ann_Sal_Net * f2p), 12, 2 ), ' '
    ] ));
  sRpt.add(' ');
  sRpt.add( format('%-56s %-14s %-14s', [
    '    Less:  Constant from above table',
    formatF(f1i, 12, 2 ), ' '
    ] ));
  work := (Nc_Bc_Ann_Sal_Net * f2p) - f1i;

  if work < 0 then
     work := 0;

  sRpt.add( format('%-56s %-14s %-14s', [ ' ', dash(12), ' ']));
  sRpt.add( format('%-56s %-14s %-14s (Q)', [
    '    Manitoba Income Tax ',
    formatF( work, 12, 2 ),
    ' '
    ] ));
  sRpt.add(' ');
  if (wrkClaim.Claim_No <> '00000000') Then
     sRpt.add( format('%-56s %-14s %-14s', [
         '    Less: Non Refundable Tax Credit (M) above ',
         formatF( Nc_Bc_Mb_Nrtc, 12, 2 ),
  	 ' '
         ] ))
  else
     sRpt.add( format('%-56s %-14s %-14s', [
         '    Less: Non Refundable Tax Credit (M) above ',
         formatF(0.00, 12, 2 ),
  	 ' '
         ] ));
  result := Nc_Bc_Mbt;
	sRpt.add( format('%-56s %-14s %-14s', [ ' ', dash(12), ' ' ]));
  sRpt.add( format('%-56s %-14s %-14s (a)', [
  	'    Manitoba Provincial Tax ',
    ' ',
    formatF( result, 12, 2 )
    ] ));
  sRpt.add( format('%-56s %-14s %-14s', [ ' ', ' ', dDash(12)]));
end;

end.
