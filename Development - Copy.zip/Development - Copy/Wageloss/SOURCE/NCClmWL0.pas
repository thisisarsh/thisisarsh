(******************************************************************************)
(*  Wageloss System                                                           *)
(*                                                                            *)
(*  Get Claim Number Dialog                                                   *)
(*                                                                            *)
(*                                                                            *)
(*  Author: Brad Trupp  / Capella Systems Group, Inc.                         *)
(*  Date:   July 1997                                                         *)
(*                                                                            *)
(*  Nov 98 - BT - year 2000 windowing fixes                                   *)
(*                                                                            *)
(******************************************************************************)

unit NCCLMWL0;

interface

uses Windows, SysUtils, Classes, Graphics, Forms, Controls, StdCtrls, 
  Buttons, ExtCtrls;

type
  TSelectClaimForm = class(TForm)
    OKBtn: TButton;
    CancelBtn: TButton;
    Label1: TLabel;
    edClaimNumber: TEdit;
    procedure edClaimNumberKeyPress(Sender: TObject; var Key: Char);
    procedure OKBtnClick(Sender: TObject);
    procedure CancelBtnClick(Sender: TObject);
    procedure FormKeyDown(Sender: TObject; var Key: Word;
      Shift: TShiftState);
    procedure FormCreate(Sender: TObject);
  private
    { Private declarations }
  public
    { Public declarations }
    procedure Loaded; override;
  end;

var
  SelectClaimForm: TSelectClaimForm;

implementation

uses NCMain, Utils;

{$R *.DFM}

(******************************************************************************)
(*                                                                            *)
(*  Set claim number field rather than active button as the active control    *)
(*  at form creation.                                                         *)
(*                                                                            *)
(******************************************************************************)
procedure TSelectClaimForm.Loaded;
begin
  inherited;

  ActiveControl := edClaimNumber;
end;

(******************************************************************************)
(*                                                                            *)
(*  Edit key presses and make sure claim number is numeric.                   *)
(*                                                                            *)
(******************************************************************************)
procedure TSelectClaimForm.edClaimNumberKeyPress(Sender: TObject;
  var Key: Char);
begin
  case Key of
     #0..#31,'0'..'9':

     else
        Key := #0;
  end;
end;

(******************************************************************************)
(*                                                                            *)
(*  Process OK button click.                                                  *)
(*                                                                            *)
(******************************************************************************)
procedure TSelectClaimForm.OKBtnClick(Sender: TObject);
begin
  // Nov 98 - BT - year 2000 windowing fixes
//  if ( copy(SelectClaimForm.edClaimNumber.text,1,2) < '92' ) and
//     ( copy(SelectClaimForm.edClaimNumber.text,1,2) > '20' ) then
//  begin
//    WagelossMainForm.ShowInfoLine2('*Claim number must be 1992 or greater.');
//    exit;
//  end;
  if ( length(SelectClaimForm.edClaimNumber.text) <> 8 ) then
     begin
     WagelossMainForm.ShowInfoLine2('*Incomplete Claim number entered.');
     exit;
     end;

  modalResult := mrOK;
end;

(******************************************************************************)
(*                                                                            *)
(*  Process Cancel Buttom click.                                              *)
(*                                                                            *)
(******************************************************************************)
procedure TSelectClaimForm.CancelBtnClick(Sender: TObject);
begin
  modalresult := mrCancel;
end;

(******************************************************************************)
(*                                                                            *)
(*  Key Down - preview and process keypresses on form.                        *)
(*                                                                            *)
(******************************************************************************)
procedure TSelectClaimForm.FormKeyDown(Sender: TObject; var Key: Word;
  Shift: TShiftState);
begin
  case Key of
     27, VK_F7:
        begin
        Key:=0;
        modalresult:=mrCancel;
        end;
     VK_F1:
        begin
        Key:=0;
        Application.HelpCommand(HELP_CONTENTS, 0);
        end;
  end;
end;

procedure TSelectClaimForm.FormCreate(Sender: TObject);
begin
  SetFont(Self);
end;

end.
