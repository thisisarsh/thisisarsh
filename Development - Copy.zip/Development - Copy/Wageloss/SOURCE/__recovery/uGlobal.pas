unit uGlobal;

interface

Uses SysUtils, Forms, Inifiles, Messages, Dialogs, Windows, Utils, Math, ncrecdef,
     Variants, System.UITypes, StdCtrls;

var
	//CurrRegion,
  CurrUserName,
  CurrUserPassword,
  CurrComputerName,
  CurrServer1,
  CurrDataBaseName1,
  CurrServer2,
  CurrDataBaseName2,
  CurrServer3,
  CurrDataBaseName3,
  CurrServer4,
  CurrDataBaseName4: string;
  CurrServer5,
  CurrDataBaseName5: string;
  CurrServer6,
  CurrDataBaseName6: string;
  CurrServer7,
  CurrDataBaseName7: string;
  TheTaxYear: Integer;
  OldRecurrenceInd: ShortString;
  IsEmergeSet, IsEmergeUp, blnRecalcNeeded: boolean;
  HTTPHOST, MQMANAGERNAME, PAYMENTS_WEB_SERVICE_LOCATION: String;
  LOG_TYPE_UPDATE, LOG_TYPE_SELECT, LOG_TYPE_PAYMENT : string;

  RemittanceChequeMessages: array[1..35] of recNCCHQMSG;

  function GetINIDir: boolean;

  procedure SetTaxYear(TaxYear:Integer);Overload;
  Procedure SetTaxYear(AccidentDate: tdatetime;
  	RecurrenceDate: tdatetime; TaxYear: Integer);overload;
  Procedure SetTaxYear(AccidentDate: tdatetime; RecurrenceDate: tdatetime;
  	TaxYear: Integer; IndexYear: integer); overload;

  function GetTaxYear():Integer;
  Procedure SetOldRecurrenceInd(TheIndicator:ShortString);
  Function GetOldRecurrenceInd():ShortString;
  Function RecalcBen(var aCalcFullClaim, aCalcPartClaim: recNCCLAIM; aDeathBenefitCalc: boolean): boolean;
  function getMinimumWage (var recurrence: shortString; recurrenceDate, accidentDate: TDatetime; aDeathBenefitCalc: boolean): currency;
  function valueNCINDEXF( y: integer ): double;
  procedure minWageCalculation(var aCalcFullClaim, aCalcFullMinWageClaim, aCalcPartClaim: recNCCLAIM; aDeathBenefitCalc: boolean);
  function getFullShelteredAmount(var aCalcFullClaim: recNCCLAIM):currency;
  function getMinShelteredAmount(var aCalcFullMinWageClaim: recNCCLAIM):currency;
  procedure CopyMinWageClaim(var aCalcFullClaim, aCalcFullMinWageClaim: recNCCLAIM );
  procedure minWagePartCalculation( var aCalcFullClaim, aCalcPartClaim, aCalcFullMinWageClaim, aCalcPartMinWageClaim: recNCCLAIM; aDeathBenefitCalc: boolean );
  function getApprovedPendingWeeks(var claimNo: shortString):currency;
  function StrIsReal(AString: string): Boolean;
  procedure SetUpAndRecalcBen(var fSRClaim : recWLREBDTL; isActualShelterDeductEnabled : Boolean; actualShelterDeduct : currency);
  procedure PrintRecord(var fSRClaim : recWLREBDTL);
  function logActivity(var aClaimNumber, aLogType: String; aComponent : String): boolean;
  function getNextKey( aSequenceName : String; aIncreaseValue, aReservationId : Integer ):Integer;
  function doReviewClaim104(var accidentDate, week104EffectiveDate : TDateTime; claimNo : Shortstring; durationWeeks : currency): boolean;
  function getAnnuityEntitlementWeeks(var accidentDate : TDateTime;claimNo : Shortstring; durationWeeks : currency): currency;
  function getYearFromAccidentDate(var accidentDate : TDateTime): Word;
  procedure GetRemitChequeMessages(var tb: array of recNCCHQMSG);
  //function FindMaxAdjustmentIndex(Tax_Year:Integer; Accident_Year:Integer):integer;
  function getMaxAdjustment(Accident_Date, Recurrence_Date:TDateTime; Indexation_Year:Integer;Recurrence_Date_Status, Self_Employed_Status:String):Currency;
  function getMinAdjustment(Accident_Date, Recurrence_Date:TDateTime; Indexation_Year:Integer;Recurrence_Date_Status, Self_Employed_Status:String):Currency;
  procedure getEffectiveAccidentDate(Accident_Date, Recurrence_Date:TDateTime; Indexation_Year:Integer;
                                   Recurrence_Date_Status:String;
                                   var eAccident_Date:TDateTime;
                                   var eAcc_Year, eAcc_Month, eTax_Year:Integer);
  function LoadMaxAdjustment(eTax_Year:Integer; eAccident_Year:Integer; eAccident_Month:Integer; eAccident_Date, iAccident_Date:TDateTime):Currency;
  function getSelfEmployedMaxAdjustment(iTaxYear, iAccidentYear, iAccidentMonth:Integer; AccidentDate:TDateTime): Currency;
  function getSelfEmployedMinAdjustment(iTaxYear, iAccidentYear, iAccident_Month:integer; iAccident_Date:TDateTime): Currency;
  function isSelfEmployedAdjInRange(adjAmount : Currency; CalcFullClaim:recNCCLAIM;
                                    isIndexation:Boolean; edMax_Adjustments:TEdit;
                                    Recurrence_Status, Self_Employed_Status:String;
                                    eIndexationYear:integer;eRecurrenceDate:TDateTime): String;
  function getNewIndexedAmount(Accident_Date:TDateTime; Indexation_Year, NewIndexation_Year:integer; Max_Adjustment:Currency):Currency;

implementation

uses NCIniMod, NCDatMod, NCMain;

function GetINIDir: Boolean;
var
  TheCurrDir,
  WorkFileName,
  TheIniFileName: string;
begin
  IsEmergeSet := true;
  TheCurrDir			:= ExtractFilePath(Application.ExeName);
  WorkFileName		:= (ChangeFileExt(ExtractFilename(Application.ExeName),'.INI'));
  TheIniFileName	:= TheCurrDir + WorkFileName;
  with TInifile.Create(TheIniFileName) do
  Begin
    CurrServer1					:= ReadString('SQL','servername1','');
    CurrDatabaseName1		:= ReadString('SQL','databasename1','');
    CurrServer2					:= ReadString('SQL','servername2','');
    CurrDatabaseName2		:= ReadString('SQL','databasename2','');
    //CurrServer3					:= ReadString('SQL','servername3','');
    //CurrDatabaseName3		:= ReadString('SQL','databasename3','');
    CurrServer4					:= ReadString('SQL','servername4','');
    CurrDatabaseName4		:= ReadString('SQL','databasename4','');
    CurrServer5					:= ReadString('SQL','servername5','');
    CurrDatabaseName5		:= ReadString('SQL','databasename5','');
    CurrServer6					:= ReadString('SQL','servername6','');
    CurrDatabaseName6		:= ReadString('SQL','databasename6','');
    CurrServer7					:= ReadString('SQL','servername7','');
    CurrDatabaseName7		:= ReadString('SQL','databasename7','');
    //CurrRegion					:= ReadString('SQL','region','');
    HTTPHOST            := ReadString('HTTP','HOST','');
    MQMANAGERNAME       := ReadString('HTTP','MQMANAGERNAME','');
    PAYMENTS_WEB_SERVICE_LOCATION := ReadString('HTTP','PAYMENTS_WEB_SERVICE_LOCATION','');
  end;
  if ((CurrServer4 = '') or (CurrDatabaseName4 = '') or
      (CurrServer5 = '') or (CurrDatabaseName5 = '') or
      (HTTPHOST = '') or (MQMANAGERNAME = '')) then
    IsEmergeSet := false;
  if ((CurrServer1 = '') or (CurrDatabaseName1 = '') or
      (CurrServer2 = '') or (CurrDatabaseName2 = '') or
    //  (CurrServer3 = '') or (CurrDatabaseName3 = '') or
      (CurrServer6 = '') or (CurrDatabaseName6 = '') or
      (CurrServer7 = '') or (CurrDatabaseName7 = '')) then
    //  (CurrRegion = '')) then
  begin
    MessageBeep(0);
    MessageDlg('The initialization file is missing or incorrect.'
      +#13+ 'Please contact the help desk.',mtError,[mbOk],0);
    Result:= false;
  end
  else
    Result:= True;

  LOG_TYPE_UPDATE := 'BenefitCalcWindow';
  LOG_TYPE_SELECT := 'SelectWindow';
  LOG_TYPE_PAYMENT := 'PaymentWindow';

end;

procedure SetTaxYear(TaxYear:Integer);
Begin
  If(TaxYear = null) then
    TheTaxYear := 0
  else
    TheTaxYear := TaxYear;
end;

function GetTaxYear():Integer;
Begin
  If (TheTaxYear = null) then
  	Result := 0
  else
    Result := TheTaxYear;
End;
//
// Modified by D. Madill
// Date: March 5, 2003
// Purpose: Check for a TaxYear greater that the max and default to the most
// current
//
Procedure SetTaxYear(AccidentDate: tdatetime; RecurrenceDate: tdatetime; TaxYear: integer);
var
   WorkDate: TDateTime;
   Year, Month, Day: Word;
Begin
   try
      If RecurrenceDate > 0 then
         WorkDate := RecurrenceDate
      else
         WorkDate := AccidentDate;

      DecodeDate(WorkDate, Year, Month, Day);

      if TaxYear < 2000 then
         begin
         TheTaxYear := TaxYear
         end
      else if TaxYear = 2000 then
         begin
         TheTaxYear := 2000
         end
      else if TaxYear = 2001 then
         begin
         TheTaxYear := 2001
         end
      else if (TaxYear = 2002) and (month < 7) then
         begin
	       TheTaxYear := 2002
  	     end
      else if ((TaxYear = 2002) and (Month > 6))  OR
              ((TaxYear = 2003) and (Month <= 6)) then
         begin
	       TheTaxYear := 2003
  	     end
      else if ((TaxYear = 2003) and (Month > 6))  OR
              ((TaxYear = 2004) and (Month <= 6)) Then
         begin
	       TheTaxYear := 2004
  	     end
      else if ((TaxYear = 2004) and (Month > 6))  OR
              ((TaxYear = 2005) and (Month <= 6)) Then
         begin
	       TheTaxYear := 2005
  	     end
      else if ((TaxYear = 2005) and (Month > 6))  OR
              ((TaxYear = 2006) and (Month <= 6)) Then
         begin
	       TheTaxYear := 2006
  	     end
      else if ((TaxYear = 2006) and (Month > 6))  OR
              ((TaxYear = 2007) and (Month <= 6)) Then
         begin
	       TheTaxYear := 2007
  	     end
      else if ((TaxYear = 2007) and (Month > 6))  OR
              ((TaxYear = 2008) and (Month <= 6)) Then
         begin
	       TheTaxYear := 2008
  	     end
      else if ((TaxYear = 2008) and (Month > 6)) or
             ((TaxYear = 2009) and (month < 7)) then
          begin
	        TheTaxYear := 2009;
          End
      else if ((TaxYear = 2009) and (Month > 6)) or
             ((TaxYear = 2010) and (month < 7)) then
          begin
	        TheTaxYear := 2010;
          End
      else if ((TaxYear = 2010) and (Month > 6)) or
             ((TaxYear = 2011) and (month < 7)) then
          begin
	        TheTaxYear := 2011;
          End
      else if ((TaxYear = 2011) and (Month > 6)) or
             ((TaxYear = 2012) and (month < 7)) then
          begin
	        TheTaxYear := 2012;
          End
      else if ((TaxYear = 2012) and (Month > 6)) or
             ((TaxYear = 2013) and (month < 7)) then
          begin
	        TheTaxYear := 2013;
          End
      else if ((TaxYear = 2013) and (Month > 6)) or
             ((TaxYear = 2014) and (month < 7)) then
          begin
	        TheTaxYear := 2014;
          End
      else if ((TaxYear = 2014) and (Month > 6)) or
             ((TaxYear = 2015) and (month < 7)) then
          begin
	        TheTaxYear := 2015;
          end
      else if ((TaxYear = 2015) and (Month > 6)) or
             ((TaxYear = 2016) and (month < 7)) then
          begin
	        TheTaxYear := 2016;
          end
      else if ((TaxYear = 2016) and (Month > 6)) or
             ((TaxYear = 2017) and (month < 7)) then
          begin
	        TheTaxYear := 2017;
          end
      else if ((TaxYear = 2017) and (Month > 6)) or
             ((TaxYear = 2018) and (month < 7)) then
          begin
	        TheTaxYear := 2018;
          end
      else if ((TaxYear = 2018) and (Month > 6)) or
             ((TaxYear = 2019) and (month < 7)) then
          begin
	        TheTaxYear := 2019;
          end
      else if ((TaxYear = 2019) and (Month > 6)) or
             ((TaxYear = 2020) and (month < 7)) then
          begin
	        TheTaxYear := 2020;
          end
      else if ((TaxYear = 2020) and (Month > 6)) or
             ((TaxYear = 2021) and (month < 7)) then
          begin
	        TheTaxYear := 2021;
          end
      else if ((TaxYear = 2021) and (Month > 6)) or
             ((TaxYear = 2022) and (month < 7)) then
          begin
	        TheTaxYear := 2022;
          end
      else if ((TaxYear = 2022) and (Month > 6)) or
             ((TaxYear = 2023) and (month < 7)) then
          begin
	        TheTaxYear := 2023;
          end
      else if ((TaxYear = 2023) and (Month > 6)) or
             ((TaxYear = 2024) and (month < 7)) then
          begin
	        TheTaxYear := 2024;
          end
      else if ((TaxYear = 2024) and (Month > 6)) or
             ((TaxYear = 2025) and (month < 7)) then
          begin
	        TheTaxYear := 2025;
          end
      else if ((TaxYear = 2025) and (Month > 6)) or
             ((TaxYear = 2026) and (month < 7)) then
          begin
	        TheTaxYear := 2026;
          end
      else if ((TaxYear = 2026) and (Month > 6)) or
             ((TaxYear = 2027) and (month < 7)) then
          begin
	        TheTaxYear := 2027;
          end;

   except
      on e:Exception do
         begin
     	   messageDlg('.'+CRLF+'Error message: '+ e.Message,mtError,[mbCancel],0);
         raise;
         end;
   end;
end;
//
// Modified by D. Madill
// Date: March 5, 2003
// Purpose: Check for a TaxYear greater that the max and default to the most
// current
//
Procedure SetTaxYear(AccidentDate: tdatetime; RecurrenceDate: tdatetime;
	TaxYear: Integer; IndexYear: integer);
var
  Year, Month, Day: Word;
  Acc_Year, Acc_Month, Acc_Day: Word;
  WorkDate:TDatetime;
begin
  try
     //get accident year, month, day
     DecodeDate(AccidentDate, Acc_Year, Acc_Month, Acc_Day);

     //if the claim has been indexed AND the Tax Year is different than the accident year then
     if ((IndexYear > 0) AND (TaxYear <> Acc_Year)) Then
        Month := Max(((Acc_Month+1) Mod 13),1)
     else
        Month := Acc_Month;

     WorkDate := Max(RecurrenceDate, EncodeDate(Min(Max(IndexYear, Acc_Year), TaxYear), Month, 1));
     DecodeDate(WorkDate, Year, Month, Day);

     if TaxYear < 2000 then
     begin
        TheTaxYear := TaxYear
     end
     else if TaxYear = 2000 then
     begin
	      TheTaxYear := 2000
     end
     else if TaxYear = 2001 then
     begin
	      TheTaxYear := 2001
     end
     else if (TaxYear = 2002) and (month < 7) then
     begin
	      TheTaxYear := 2002
     end
     else if ((TaxYear = 2002) and (month > 6))  or
             ((TaxYear = 2003) and (month <= 6)) then
     begin
	      TheTaxYear := 2003
     end
     else if ((TaxYear = 2003) and (month > 6))  or
             ((TaxYear = 2004) and (month <= 6)) then
     begin
	      TheTaxYear := 2004
     end
     else if ((TaxYear = 2004) and (month > 6))  or
             ((TaxYear = 2005) and (month <= 6)) then
     begin
	      TheTaxYear := 2005
     end
     else if ((TaxYear = 2005) and (month > 6))  or
             ((TaxYear = 2006) and (month <= 6)) then
     begin
	      TheTaxYear := 2006
     end
     else if ((TaxYear = 2006) and (month > 6))  or
             ((TaxYear = 2007) and (month <= 6)) then
     begin
	      TheTaxYear := 2007
     end
     else if ((TaxYear = 2007) and (month > 6))  or
             ((TaxYear = 2008) and (month <= 6)) then
     begin
	      TheTaxYear := 2008
     end
     else if ((TaxYear = 2008) and (month > 6))  or
             ((TaxYear = 2009) and (month <= 6)) then
     begin
	      TheTaxYear := 2009
     end
     else if ((TaxYear = 2009) and (month > 6))  or
             ((TaxYear = 2010) and (month <= 6)) then
     begin
	      TheTaxYear := 2010
     end
     else if ((TaxYear = 2010) and (month > 6))  or
             ((TaxYear = 2011) and (month <= 6)) then
     begin
	      TheTaxYear := 2011
     end
     else if ((TaxYear = 2011) and (month > 6))  or
             ((TaxYear = 2012) and (month <= 6)) then
     begin
	      TheTaxYear := 2012
     end
     else if ((TaxYear = 2012) and (month > 6))  or
             ((TaxYear = 2013) and (month <= 6)) then
     begin
	      TheTaxYear := 2013
     end
     else if ((TaxYear = 2013) and (month > 6))  or
             ((TaxYear = 2014) and (month <= 6)) then
     begin
	      TheTaxYear := 2014
     end
     else if ((TaxYear = 2014) and (month > 6))  or
             ((TaxYear = 2015) and (month <= 6)) then
     begin
	      TheTaxYear := 2015
     end
     else if ((TaxYear = 2015) and (month > 6))  or
             ((TaxYear = 2016) and (month <= 6)) then
     begin
	      TheTaxYear := 2016
     end
     else if ((TaxYear = 2016) and (month > 6))  or
             ((TaxYear = 2017) and (month <= 6)) then
     begin
	      TheTaxYear := 2017
     end
     else if ((TaxYear = 2017) and (month > 6))  or
             ((TaxYear = 2018) and (month <= 6)) then
     begin
	      TheTaxYear := 2018
     end
     else if ((TaxYear = 2018) and (month > 6))  or
             ((TaxYear = 2019) and (month <= 6)) then
     begin
	      TheTaxYear := 2019
     end
     else if ((TaxYear = 2019) and (month > 6))  or
             ((TaxYear = 2020) and (month <= 6)) then
     begin
	      TheTaxYear := 2020
     end
     else if ((TaxYear = 2020) and (month > 6))  or
             ((TaxYear = 2021) and (month <= 6)) then
     begin
	      TheTaxYear := 2021
     end
     else if ((TaxYear = 2021) and (month > 6))  or
             ((TaxYear = 2022) and (month <= 6)) then
     begin
	      TheTaxYear := 2022
     end
     else if ((TaxYear = 2022) and (month > 6))  or
             ((TaxYear = 2023) and (month <= 6)) then
     begin
	      TheTaxYear := 2023
     end
     else if ((TaxYear = 2023) and (month > 6))  or
             ((TaxYear = 2024) and (month <= 6)) then
     begin
	      TheTaxYear := 2024
     end
     else if ((TaxYear = 2024) and (month > 6))  or
             ((TaxYear = 2025) and (month <= 6)) then
     begin
	      TheTaxYear := 2025
     end
     else if ((TaxYear = 2025) and (month > 6))  or
             ((TaxYear = 2026) and (month <= 6)) then
     begin
	      TheTaxYear := 2026
     end
     else if ((TaxYear = 2026) and (month > 6))  or
             ((TaxYear = 2027) and (month <= 6)) then
     begin
	      TheTaxYear := 2027
     end;

  except
     on e:Exception do
        begin
     	messageDlg('.'+CRLF+'Error message: '+ e.Message,mtError,[mbCancel],0);
        raise;
        end;
     end;
end;

Procedure SetOldRecurrenceInd(TheIndicator:ShortString);
Begin
  If (TheIndicator = 'Y') or (TheIndicator = 'y') then
    OldRecurrenceInd := TheIndicator
  else
  	OldRecurrenceInd := 'N';
End;

Function GetOldRecurrenceInd():ShortString;
Begin
	Result := OldRecurrenceInd;
end;

(******************************************************************************)
(*                                                                            *)
(*  Recalculate Benefits                                                      *)
(*                                                                            *)
(******************************************************************************)

//
// Modified March 5, 2003
// Modified by D. Madill
// modified to add return code checking from the TaxCalculator.dll
// and to display a Return Message if there is an error from the
// dll
//
Function RecalcBen(var aCalcFullClaim, aCalcPartClaim: recNCCLAIM; aDeathBenefitCalc: boolean): boolean;
var
  ReturnMessage : ShortString;
  yearlyMinWage, wklyMinWage, nc_index_amt, savePost_Injury_Earn : currency;
  nc_cnt, accidentYear : integer;
  ReturnCode, yearlyWageLessThenMin, yearlyWageLessThenMinPartial : Boolean;
  aCalcFullMinWageClaim, aCalcPartMinWageClaim: recNCCLAIM;
  fWorking: recConst;
begin
  if Year( aCalcFullClaim.Accident_Date ) >= 2006 Then // This is the 2006+ Calculation
    begin
    copyNCCLAIM( aCalcFullClaim, aCalcPartClaim );
    savePost_Injury_Earn := aCalcFullClaim.Post_Injury_Earn;
    aCalcFullClaim.Post_Injury_Earn := 0.0;
    yearlyWageLessThenMin := false;
    yearlyWageLessThenMinPartial := false;
    aCalcPartClaim.Pay_At_100_Flag := False;
    aCalcFullClaim.Pay_At_100_Flag := False;
    aCalcPartClaim.Pay_At_100_Flag_Partial := False;
    aCalcFullClaim.Pay_At_100_Flag_Partial := False;

    //first get min wage and set it in CalcFullClaim...need this to set fWorking properly
    yearlyMinWage := getMinimumWage(aCalcFullClaim.Recurrence, aCalcFullClaim.RecurrenceDate, aCalcFullClaim.Accident_Date, aDeathBenefitCalc );

    //original
    //CalcFullClaim.Minimum_wage := yearlyMinWage;
    //*********************************************************************//
    // Added Oct, 2006 - bcooper                                           //
    //*********************************************************************//
    wklyMinWage := yearlyMinWage / 52;

    if month( aCalcFullClaim.Accident_Date ) < 12 then
       accidentYear := year( aCalcFullClaim.Accident_Date ) + 2
    else
       accidentYear := year( aCalcFullClaim.Accident_Date ) + 3;

    nc_index_amt := wklyMinWage;

    for nc_cnt := accidentYear to aCalcFullClaim.Indexation_year do
       begin
       nc_index_amt := nc_index_amt * valueNCINDEXF( nc_cnt )
       end;


       // Just for testing
    if (aCalcFullClaim.Recurrence = 'Y') and (year(aCalcFullClaim.RecurrenceDate) = 2026) then
      nc_index_amt := wklyMinWage;


    aCalcFullClaim.Minimum_wage := nc_index_amt * 52;
    //*********************************************************************//

    try
       calc_ben(aCalcFullClaim, fWorking);
    Finally
      ReturnMessage := aCalcFullClaim.ReturnMessage;
      ReturnCode := aCalcFullClaim.ReturnCode;
    end;

    if ReturnCode then
    begin
      minWageCalculation(aCalcFullClaim, aCalcFullMinWageClaim, aCalcPartClaim, aDeathBenefitCalc);
    end;

     //if gross earnings less then min then we pay at 100%; factor back up
    if aCalcFullClaim.Annual_Gross_A <= ( aCalcFullMinWageClaim.Minimum_wage + 0.00005 ) then
    begin
      //set flags
      yearlyWageLessThenMin := true;
      aCalcFullClaim.Pay_At_100_Flag := true;
      aCalcPartClaim.Pay_At_100_Flag := true;
    end;

    //set some fields in full and part claim now that min calculation is done
    aCalcFullClaim.Min_Wage_Annual_Net_A := aCalcFullMinWageClaim.Min_Wage_Annual_Net_A;
    aCalcFullClaim.Tax_Coll_Ben_Only := aCalcFullClaim.Coll_Ben_Tax_Net;
    aCalcFullClaim.Min_Wage_Total_Deds := aCalcFullMinWageClaim.Total_Deds;

    //get sheltered amounts
    aCalcFullClaim.Weekly_Shelter_Ben_Amount_90 := getFullShelteredAmount( aCalcFullClaim );
    aCalcFullClaim.Weekly_Shelter_Ben_Amount := getMinShelteredAmount( aCalcFullMinWageClaim );

    aCalcPartClaim.Minimum_wage := aCalcFullMinWageClaim.Minimum_wage;
    aCalcPartClaim.Min_Wage_Annual_Net_A := aCalcFullMinWageClaim.Min_Wage_Annual_Net_A;
    aCalcPartClaim.Tax_Coll_Ben_Only := aCalcFullClaim.Coll_Ben_Tax_Net;
    aCalcPartClaim.Min_Wage_Total_Deds := aCalcFullMinWageClaim.Total_Deds;

    if ReturnCode Then
       begin
       try
          calc_ben( aCalcpartClaim, fWorking );
       finally
          ReturnMessage := aCalcFullClaim.ReturnMessage;
          ReturnCode := aCalcFullClaim.ReturnCode;

          if aCalcPartClaim.Annual_Gross_A <= ( aCalcFullMinWageClaim.Minimum_wage + 0.00005 ) then
             begin
             //set flags
             yearlyWageLessThenMinPartial := true;
             aCalcPartClaim.Pay_At_100_Flag_Partial := true;
             aCalcFullClaim.Pay_At_100_Flag_Partial := true;
             end;

          //set some fields in full and part claim now that min calculation is done
          aCalcPartClaim.Minimum_wage := aCalcFullMinWageClaim.Minimum_wage;
          aCalcPartClaim.Min_Wage_Annual_Net_A := aCalcFullMinWageClaim.Min_Wage_Annual_Net_A;
          aCalcPartClaim.Tax_Coll_Ben_Only := aCalcFullClaim.Coll_Ben_Tax_Net;
          aCalcPartClaim.Min_Wage_Total_Deds := aCalcFullMinWageClaim.Total_Deds;
          aCalcPartClaim.Weekly_Shelter_Ben_Amount := aCalcFullClaim.Weekly_Shelter_Ben_Amount;
          aCalcPartClaim.Weekly_Shelter_Ben_Amount_90 := aCalcFullClaim.Weekly_Shelter_Ben_Amount_90;
          //********************************************************************
       end; // end of try Finally

       if ReturnMessage = '' Then
          begin
          ReturnMessage := aCalcpartClaim.ReturnMessage;
          end;

       if aCalcFullClaim.ReturnCode Then
          begin
          aCalcFullClaim.Post_Injury_Earn := savePost_Injury_Earn;
          end;
       end; //if ReturnCode

    //check to see if their actual weekly rate is less then the min wage weekly rate
    //going to go after their Annual_Net + CollateralBenefits; this is their weekly max benefit for FULL
    //
    if (aCalcFullClaim.Weekly_90_S < aCalcFullMinWageClaim.Weekly_90_S)  and
       (not yearlyWageLessThenMin)                                       then
       begin
       CopyMinWageClaim( aCalcFullClaim, aCalcFullMinWageClaim );
       end;

    //do calc for a partial claim as well
    if ReturnCode then
       begin
       minWagePartCalculation(aCalcFullClaim, aCalcPartClaim, aCalcFullMinWageClaim, aCalcPartMinWageClaim, aDeathBenefitCalc);
       end;

    //check partial wage against min as well
    if (aCalcPartClaim.Weekly_90_S < aCalcPartMinWageClaim.Weekly_90_S) and
       (not yearlyWageLessThenMinPartial)                               then
       begin
       CopyMinWageClaim( aCalcPartClaim, aCalcPartMinWageClaim );
       aCalcPartClaim.Minimum_Wage_Flag_Partial := true;
       end;

    if ( Not ReturnCode ) OR ( ReturnMessage <> '' ) Then
       begin
       // set on opening for the first time
       //if not ( self.ActiveControl.Name = edWkly_Sal_A.Name ) then
       //  WagelossMainForm.ShowInfoLine2( CalcFullClaim.ReturnMessage )
       //else
       //  ResetInfoLine2;
       end;
    end
  else  // 2005 and below rebalc
     begin
     copyNCCLAIM( aCalcFullClaim, aCalcPartClaim );
     savePost_Injury_Earn := aCalcFullClaim.Post_Injury_Earn;
     aCalcFullClaim.Post_Injury_Earn := 0.0;

     try
        calc_ben(aCalcFullClaim, fWorking);
     finally
        ReturnMessage := aCalcFullClaim.ReturnMessage;
        ReturnCode := aCalcFullClaim.ReturnCode;
     end;

     if ReturnCode Then
        begin
        try
           calc_ben(aCalcpartClaim, fWorking);
           aCalcPartClaim.Weekly_Net := aCalcPartClaim.Weekly_Net + aCalcPartClaim.Post_Injury_Earn_Net;
        finally
           ReturnMessage := aCalcFullClaim.ReturnMessage;
           ReturnCode := aCalcFullClaim.ReturnCode;
        end;

        if ReturnMessage = '' Then
           begin
           ReturnMessage := aCalcpartClaim.ReturnMessage;
           end;

        if aCalcFullClaim.ReturnCode Then
           begin
           aCalcFullClaim.Post_Injury_Earn := savePost_Injury_Earn;
           end;
        end; //ReturnCode

    if (Not ReturnCode) OR (ReturnMessage <> '') Then
       begin
       // set on opening for the first time
       //if not ( self.ActiveControl.Name = edWkly_Sal_A.Name ) then
       //   WagelossMainForm.ShowInfoLine2( CalcFullClaim.ReturnMessage )
       //else
       //   ResetInfoLine2;
       end;
    end;
  result := true;
end;

function getMinimumWage (var recurrence: shortString; recurrenceDate, accidentDate: TDatetime; aDeathBenefitCalc: boolean): currency;
var
  lngReturn : Integer;
  testDate : String;
begin
  Result := 0;

  try
    if recurrence = 'Y' Then
       begin
       testDate := DateToStr(recurrenceDate);
       end
    else
       begin
       testDate := DateToStr(accidentDate);
       end;

    //appLog('testDate				                : ' + testDate );
    //
    // if we are performing a death benefit calc then set the min wage to 0
    //
    if Not aDeathBenefitCalc Then
       begin
       dm1.usp_Get_Minimum_Wage.Parameters.ParamByName( '@accidentDate' ).Value := testDate;
       dm1.usp_Get_Minimum_Wage.Open;
       lngReturn := dm1.usp_Get_Minimum_Wage.Parameters.ParamByName( '@RETURN_VALUE' ).Value;
       if lngReturn = 0 Then
          Begin
          if Not dm1.usp_Get_Minimum_Wage.Eof Then
             Begin
             Result := dm1.usp_Get_Minimum_Wage.FieldByName( 'minWage' ).Value;
             end;
          dm1.usp_Get_Minimum_Wage.Close;
          end;
       end
    else
       begin
       Result := 0;
       end;
  except
     on E:Exception do
        Begin
        Result := 0;
        dm1.usp_Get_Minimum_Wage.Close;
        MessageDlg( '*Retrieve of Minimum Wage Failed. Please notify help desk at 4573', mtError, [mbOK], 0 );
        End;
  end;
end;

Function valueNCINDEXF( y: integer ): double;
Var
  iii: integer;
Begin
  // Get values in the Indexation Factors Table
  indexNCINDEXF := -1;
  For iii := low( arrayNCINDEXF ) To high( arrayNCINDEXF ) Do
  Begin
    If ( arrayNCINDEXF[iii].Indexation_Year = y ) Then
    Begin
      indexNCINDEXF:=iii;
      result := arrayNCINDEXF[iii].Indexing_Factor;
      exit;
    End
  End;
  If ( indexNCINDEXF < 0 ) Then
  Begin
    result:=0.0;
    exit;
  End;

  result := 0.0;
End;

procedure minWageCalculation(var aCalcFullClaim, aCalcFullMinWageClaim, aCalcPartClaim: recNCCLAIM; aDeathBenefitCalc: boolean);
var
  nc_index_amt: currency;
  nc_cnt, accidentYear: integer;
  wklyMinWage, yrlyMinWage: currency;
  fFullMinWage: recConst;
begin
  //first copy info to minWage record
  CopyNCCLAIM( aCalcFullClaim, aCalcFullMinWageClaim );

  //get the yearly min wage and divide by 52 to weekly rate
  yrlyMinWage := getMinimumWage(aCalcFullClaim.Recurrence, aCalcFullClaim.RecurrenceDate, aCalcFullClaim.Accident_Date, aDeathBenefitCalc );
  wklyMinWage := yrlyMinWage / 52;

  if month( aCalcFullMinWageClaim.Accident_Date ) < 12 then
    accidentYear := year( aCalcFullMinWageClaim.Accident_Date ) + 2
  else
    accidentYear := year( aCalcFullMinWageClaim.Accident_Date ) + 3;

  nc_index_amt := wklyMinWage;

  for nc_cnt := accidentYear to aCalcFullMinWageClaim.Indexation_year do
  begin
    nc_index_amt := nc_index_amt * valueNCINDEXF( nc_cnt )
  end;

         // Just for testing
  if (aCalcFullClaim.Recurrence = 'Y') and (year(aCalcFullClaim.RecurrenceDate) = 2026) then
    nc_index_amt := wklyMinWage;

  //put the weekly and yearly minimum wage into CalcFullMinWageClaim
  aCalcFullMinWageClaim.Wkly_Sal_A := nc_index_amt;
  aCalcFullMinWageClaim.Minimum_wage := nc_index_amt * 52 ;
  aCalcFullClaim.Minimum_wage := nc_index_amt * 52;
  aCalcPartClaim.Minimum_wage := nc_index_amt * 52;

  //send to calculator
  calc_ben( aCalcFullMinWageClaim, fFullMinWage );

  aCalcFullMinWageClaim.Min_Wage_Annual_Net_A := aCalcFullMinWageClaim.Annual_Net;
end;

function getFullShelteredAmount(var aCalcFullClaim: recNCCLAIM):currency;
var
  totalDeds, annualAmount, weeklyAmount : currency;
begin
  totalDeds := PdoxRound( ( aCalcFullClaim.Total_Deds * 0.75 ), 2 );
  annualAmount := totalDeds - aCalcFullClaim.Total_Deds_S;
  weeklyAmount := PdoxRound( annualAmount / 52, 2 );
  Result := PDoxRound( weeklyAmount * 0.90, 2 );
end;

function getMinShelteredAmount(var aCalcFullMinWageClaim: recNCCLAIM): currency;
var
  totalDeds, annualAmount: currency;
begin
  totalDeds := PdoxRound( ( aCalcFullMinWageClaim.Total_Deds * 0.75 ), 2 );
  annualAmount := totalDeds - aCalcFullMinWageClaim.Total_Deds_S;
  Result := PDoxRound( annualAmount / 52, 2 );
end;

procedure CopyMinWageClaim( var aCalcFullClaim, aCalcFullMinWageClaim: recNCCLAIM );
begin
  //copy relevant fields...may have to copy more or less; also set min wage flag to true
  aCalcFullClaim.Annual_90_S := aCalcFullMinWageClaim.Annual_90_S; //factor this back up to 100%
  aCalcFullClaim.Annual_90 := aCalcFullMinWageClaim.Annual_Net; //this is since they are paid at 100% not 90%
  aCalcFullClaim.Annual_Gross := aCalcFullMinWageClaim.Annual_Gross;
  aCalcFullClaim.Weekly_Net := aCalcFullMinWageClaim.Weekly_Net;
  aCalcFullClaim.Weekly_Net_A := aCalcFullMinWageClaim.Weekly_Net_A;
  aCalcFullClaim.Weekly_90 := aCalcFullMinWageClaim.Weekly_90;
  aCalcFullClaim.Weekly_90_S := aCalcFullMinWageClaim.Weekly_90_S;
  aCalcFullClaim.Inc_Tax_Fed := aCalcFullMinWageClaim.Inc_Tax_Fed;
  aCalcFullClaim.Inc_Tax_Man := aCalcFullMinWageClaim.Inc_Tax_Man;
  aCalcFullClaim.CPP_Prem := aCalcFullMinWageClaim.CPP_Prem;
  aCalcFullClaim.CPP2_Prem := aCalcFullMinWageClaim.CPP2_Prem;
  aCalcFullClaim.EI_Prem := aCalcFullMinWageClaim.EI_Prem;
  aCalcFullClaim.Total_Deds := aCalcFullMinWageClaim.Total_Deds;
  aCalcFullClaim.Minimum_wage := aCalcFullMinWageClaim.Minimum_wage;
  aCalcFullClaim.Minimum_wage_Flag := true;
  aCalcFullClaim.Wkly_Clmt_Anty_Con_Amt := aCalcFullMinWageClaim.Wkly_Clmt_Anty_Con_Amt;
  aCalcFullClaim.Post_Injury_Earn_Net := aCalcFullMinWageClaim.Post_Injury_Earn_Net;
  //added for PF4 screen
  aCalcFullClaim.Annual_80 := aCalcFullMinWageClaim.Annual_80_S;  // Yes this is correct for 2006 claims
  aCalcFullClaim.Annual_80_S := aCalcFullMinWageClaim.Annual_80_S;
  aCalcFullClaim.Weekly_80 := aCalcFullMinWageClaim.Weekly_80_S; // Yes this is correct for 2006 claims
  aCalcFullClaim.Weekly_80_S := aCalcFullMinWageClaim.Weekly_80_S;
end;

procedure minWagePartCalculation( var aCalcFullClaim, aCalcPartClaim, aCalcFullMinWageClaim, aCalcPartMinWageClaim: recNCCLAIM; aDeathBenefitCalc: boolean );
var
  nc_index_amt: currency;
  nc_cnt, accidentYear: integer;
  wklyMinWage, yrlyMinWage: currency;
  fPartMinWage: recConst;
begin
  //first copy info to minWage record
  CopyNCCLAIM( aCalcPartClaim, aCalcPartMinWageClaim );

  //get the yearly min wage and divide by 52 to weekly rate
  yrlyMinWage := getMinimumWage(aCalcFullClaim.Recurrence, aCalcFullClaim.RecurrenceDate, aCalcFullClaim.Accident_Date, aDeathBenefitCalc );
  wklyMinWage := yrlyMinWage / 52;

  if month( aCalcFullMinWageClaim.Accident_Date ) < 12 then
    accidentYear := year( aCalcFullMinWageClaim.Accident_Date ) + 2
  else
    accidentYear := year( aCalcFullMinWageClaim.Accident_Date ) + 3;

  nc_index_amt := wklyMinWage;

  for nc_cnt := accidentYear to aCalcPartMinWageClaim.Indexation_Year do
  begin
    nc_index_amt := nc_index_amt * valueNCINDEXF( nc_cnt )
  end;

       // Just for testing
  if (aCalcFullClaim.Recurrence = 'Y') and (year(aCalcFullClaim.RecurrenceDate) = 2026) then
    nc_index_amt := wklyMinWage;

  //put the weekly and yearly minimum wage into CalcFullMinWageClaim
  aCalcPartMinWageClaim.Wkly_Sal_A := nc_index_amt;
  aCalcPartMinWageClaim.Minimum_wage := nc_index_amt * 52;

  //send to calculator
  calc_ben( aCalcPartMinWageClaim, fPartMinWage );

  aCalcPartMinWageClaim.Min_Wage_Annual_Net_A := aCalcPartMinWageClaim.Annual_Net;
end;


function getApprovedPendingWeeks(var claimNo: shortString):currency;
var
  approvedPendingWeeks: currency;
Begin
  approvedPendingWeeks := 0;
    try
      with dm1.qryGeneralEmerge do
      begin
        if Active then
          Close;
        SQL.Clear;
        SQL.Add( 'SELECT weeksPaidQty ' );
        SQL.Add( 'FROM PaymentItem ' );
        SQL.Add( 'WHERE claimNo = ' + claimNo );
        SQL.Add( ' AND ( ( statusType LIKE  ''Approved%'' ) OR ( statusType LIKE ''Pending%'' ) )' );
        Open;
        try
          First;
          while not Eof do
          begin
            try
              approvedPendingWeeks := approvedPendingWeeks + FieldByName( 'weeksPaidQty').AsCurrency;
          finally
            Next;
          end; //finally
        end; //try
        finally
          Close;
        end; //try
      end;
      except
        ;
    end;

    result := approvedPendingWeeks;
end;

function StrIsReal(AString: string): Boolean;
var
  I: Extended;
  Code: Integer;
begin 
  Val(AString, I, Code);
  Result := Code = 0;
end;

(******************************************************************************)
(*                                                                            *)
(*     Recalculate Benefit levels                                             *)
(*                                                                            *)
(******************************************************************************)
procedure SetUpAndRecalcBen(var fSRClaim : recWLREBDTL; isActualShelterDeductEnabled : Boolean; actualShelterDeduct : currency);
var
    fClaim, fPartialClaim: recNCCLAIM;
begin
  try
  //if fSRClaim.Claim_No = '06025638' then
   // PrintRecord(fSRClaim);
  //workDate := fSRClaim.Accident_Date;
  //if ((fSRClaim.indexationYear <> 0) and (month(workDate) = 6)) then
  //   workDate := EncodeDate(year(workDate), month(workDate) + 1, day(workDate));

  //if ((year(workDate) <> fSRClaim.Tax_Year) and ((month(workDate) = 6) or (month(workDate) = 12))) then
  //begin
  //  DecodeDate(workDate, workYear, workMonth, workDay);
  //  workMonth := workMonth - 6;
  //  if (workMonth) = 0 then workMonth := 12;
  //  if ((workMonth = 4) OR (workMonth = 6) OR (workMonth = 9) OR (workMonth = 11))
  //    AND (workDay = 31) then
  //    workDay := 30;
  //  if (workMonth) = 6 then workMonth := 5;
  //  workDate := EncodeDate(workYear, workMonth, workDay);
  //end;

  fSRClaim.Weeks_Worked := 52 - fSRClaim.Accum_Wks_Yr_PdCst;

  if fSRClaim.Weeks_Worked < 0 then
     fSRClaim.Weeks_Worked := 0;

  fSRClaim.Annual_Gross_A := fSRClaim.Wkly_Sal * fSRClaim.Weeks_Worked;
  fSRClaim.Wkly_Sal_A := fSRClaim.Annual_Gross_A / 52;

  if isActualShelterDeductEnabled then
  begin
    fSRClaim.Nbr_Act_Shelter_Deduct := actualShelterDeduct;
  end;

  ClearNCCLAIM(fClaim);
  //fClaim.Claim_No := fSRClaim.Claim_No;
  //fClaim.Claim_Suffix := fSRClaim.Claim_Suffix;
  fClaim.Tax_Year := fSRClaim.Tax_Year;

  fClaim.Marital_Status := fSRClaim.Marital_Status;
  fClaim.Spouse_Working := fSRClaim.Spouse_Working;
  fClaim.ClaimSpouseForTaxPurposes := fSRClaim.ClaimSpouseForTaxPurposes;
  fClaim.No_Of_Dependnts := fSRClaim.Nbr_Of_Dependants;
  fClaim.No_Infirm := fSRClaim.Nbr_Of_Infirm_Deps;
  fClaim.EI_Exempt := fSRClaim.Uic_Exempt;
  fClaim.Wkly_Sal_A := fSRClaim.Wkly_Sal;
  fClaim.Self_Employed := fSRClaim.Self_Employed;
  fClaim.Recurrence := fSRClaim.Recurrence;
  fClaim.CPP_Exempt := fSRClaim.CPP_Exempt;
  fClaim.Tax_Exempt := fSRClaim.Tax_Exempt;
  fClaim.Child_Care_Exp := fSRClaim.Child_Care_Exp;
  fClaim.Spousal_Support := fSRClaim.Spousal_Support;
  fClaim.Child_Support := fSRClaim.Child_Support;
  //fClaim.Accident_Date := workDate;
  fClaim.Accident_Date := fSRClaim.Accident_Date;
  //applog('Work Date Used: ' + FormatDateTime('c', workDate ));
  fClaim.Max_Adjustment := fSRClaim.Max_Adjustment;
  fClaim.RecurrenceDate := fSRClaim.Recurrence_Date;
  fClaim.Youthful_Worker := fSRClaim.Youthful_Worker;
  fClaim.Wkly_Sal := fSRClaim.Wkly_Sal;
  fClaim.Indexation_Year := fSRClaim.indexationYear;
  fClaim.Collateral_Ben_Tax := fSRClaim.collateralTaxableAmt;
  fClaim.Collateral_Ben_Non_Tax := fSRClaim.collateralNonTaxableAmt;

  uglobal.RecalcBen(fClaim, fPartialClaim, false);

  fSRClaim.Wkly_Net := fClaim.Weekly_Net;
  fSRClaim.Wkly_90 := fClaim.Weekly_90;
  fSRClaim.Wkly_90_S := fClaim.Weekly_90_S;
  fSRClaim.Wkly_Tax_S := fClaim.Weekly_90 - fClaim.Weekly_90_S;

  if  fSRClaim.Wkly_Tax_S < 0.00 then
     fSRClaim.Wkly_Tax_S := 0.00;

  if isActualShelterDeductEnabled then
     begin
     fSRClaim.Tax_Shelter_Deduct := fSRClaim.Wkly_Tax_S * fSRClaim.Nbr_Act_Shelter_Deduct
     end
  else
     begin
     if ((year(fSRClaim.Accident_Date) < 2006)) then
        begin
        fSRClaim.Tax_Shelter_Deduct := fSRClaim.Wkly_Tax_S * fSRClaim.Accum_Wks_Yr_90Net
        end
     else
        begin
        fSRClaim.Tax_Shelter_Deduct := fSRClaim.Wkly_Tax_S * (fSRClaim.Accum_Wks_Yr_90Net + fSRClaim.Accum_Wks_Yr_90Net_Post)
        end
     end;

  fSRClaim.Wkly_80 := fClaim.Weekly_80;
  fSRClaim.Annual_Gross := fClaim.Annual_Gross;
  fSRClaim.Annual_Net := fClaim.Annual_Net;

  if fSRClaim.Wkly_Net = fSRClaim.Wkly_90 then
     fSRClaim.Annual_Net := fClaim.Annual_90;

  fSRClaim.Annual_90 := fClaim.Annual_90;
  fSRClaim.Annual_90_S := fClaim.Annual_90_S;
  fSRClaim.Annual_80 := fClaim.Annual_80;
  fSRClaim.Inc_Tax_Fed := fClaim.Inc_Tax_Fed;
  fSRClaim.Inc_Tax_Prov := fClaim.Inc_Tax_Man;
  fSRClaim.Cpp_Prem := fClaim.CPP_Prem;
  fSRClaim.Cpp2_Prem := fClaim.CPP2_Prem;
  fSRClaim.Uic_Prem := fClaim.EI_Prem;
  fSRClaim.Total_Deds := fClaim.Total_Deds;
  fSRClaim.Total_Deds_P_A := (fSRClaim.Total_Deds * fSRClaim.Weeks_Worked) / 52;
  fSRClaim.Tax_Exemption := fClaim.Tax_Exemption;
  //  message "Second Run of TAX CALCULATIONS"
  ClearNCCLAIM(fClaim);
  //fClaim.Claim_No := fSRClaim.Claim_No;
  //fClaim.Claim_Suffix := fSRClaim.Claim_Suffix;
  fClaim.Tax_Year := fSRClaim.Tax_Year;
  fClaim.Marital_Status := fSRClaim.Marital_Status;
  fClaim.Spouse_Working := fSRClaim.Spouse_Working;
  fClaim.No_Of_Dependnts := fSRClaim.Nbr_Of_Dependants;
  fClaim.No_Infirm := fSRClaim.Nbr_Of_Infirm_Deps;
  fClaim.EI_Exempt := fSRClaim.Uic_Exempt;
  fClaim.CPP_Exempt := fSRClaim.CPP_Exempt;
  fClaim.Tax_Exempt := fSRClaim.Tax_Exempt;
  fClaim.Wkly_Sal_A := fSRClaim.Wkly_Sal_A;
  //fClaim.Accident_Date := workDate;
  fClaim.Accident_Date := fSRClaim.Accident_Date;
  fClaim.Self_Employed := fSRClaim.Self_Employed;
  fClaim.Recurrence := fSRClaim.Recurrence;
  fClaim.RecurrenceDate := fSRClaim.Recurrence_Date;
  fClaim.Youthful_Worker := fSRClaim.Youthful_Worker;
  fClaim.Max_Adjustment := fSRClaim.Max_Adjustment;
  fClaim.Wkly_Sal := fSRClaim.Wkly_Sal;
  fClaim.Indexation_Year := fSRClaim.indexationYear;

  uglobal.RecalcBen(fClaim, fPartialClaim, false);

  fSRClaim.Annual_Gross_A := fClaim.Annual_Gross;
  fSRClaim.Annual_Net_A := fClaim.Annual_Net;
  fSRClaim.Inc_Tax_Fed_A := fClaim.Inc_Tax_Fed;
  fSRClaim.Inc_Tax_Prov_A := fClaim.Inc_Tax_Man;
  fSRClaim.Cpp_Prem_A := fClaim.Cpp_Prem;
  fSRClaim.Cpp2_Prem_A := fClaim.Cpp2_Prem;
  fSRClaim.Uic_Prem_A := fClaim.EI_Prem;
  fSRClaim.Total_Deds_A := fClaim.Total_Deds;
  fSRClaim.Tax_Exemption_A := fClaim.Tax_Exemption;
  fSRClaim.Tax_Shelter_Bnft := fSRClaim.Total_Deds_P_A - fClaim.Total_Deds_A;

  if fSRClaim.Tax_Shelter_Bnft < 0 then
     fSRClaim.Tax_Shelter_Bnft := 0;

  fSRClaim.Rebate_Amount := fSRClaim.Tax_Shelter_Deduct - fSRClaim.Tax_Shelter_Bnft;

  fSRClaim.workerShetlerAnnuityContribAmt :=
      fSRClaim.Accum_Wks_Yr_90Net_Post / fSRClaim.Accum_Wks_Yr_PdCst *
      fSRClaim.Rebate_Amount * fSRClaim.workerAnnuityContributionPercent / 100;
  if fSRClaim.workerShetlerAnnuityContribAmt < 0 then
    fSRClaim.workerShetlerAnnuityContribAmt := 0;

    fSRClaim.wcbShelterAnnuityContribAmt :=
      fSRClaim.Accum_Wks_Yr_90Net_Post / fSRClaim.Accum_Wks_Yr_PdCst *
      fSRClaim.Rebate_Amount * fSRClaim.wcbAnnuityContributionPercent / 100;
  if fSRClaim.wcbShelterAnnuityContribAmt < 0 then
    fSRClaim.wcbShelterAnnuityContribAmt := 0;

  fSRClaim.Rebate_Amount := fSRClaim.Rebate_Amount - fSRClaim.workerShetlerAnnuityContribAmt;

  if fSRClaim.Rebate_Amount < 0 then
     fSRClaim.Rebate_Amount := 0;
  //PrintRecord(fSRClaim);
  except
    On e:exception do
    begin
      MessageDlg('Error doing calculation for claim ' + fSRClaim.claim_no + #10#10 + E.message,
      mtError,[mbOk], 0);
    end;
  end;
end;

procedure PrintRecord(var fSRClaim : recWLREBDTL);
begin
  appLog('Printing Shelter Record....  ');
	appLog('Claim_No 				                  : ' + fSRClaim.Claim_No);
	appLog('Claim_Suffix 				              : ' + fSRClaim.Claim_Suffix);
	appLog('Clmt_Name_Initials 			          : ' + fSRClaim.Clmt_Name_Initials);
	appLog('Tax_Year 				                  : ' + format('%d', [ fSRClaim.Tax_Year ] ));
	appLog('Marital_Status 				            : ' + fSRClaim.Marital_Status);
	appLog('Spouse_Working 				            : ' + fSRClaim.Spouse_Working);
	appLog('Nbr_Of_Dependants 			          : ' + format('%d', [ fSRClaim.Nbr_Of_Dependants ] ));
	appLog('Nbr_Of_Infirm_Deps 			          : ' + format('%d', [ fSRClaim.Nbr_Of_Infirm_Deps ] ));
	appLog('Uic_Exempt 				                : ' + fSRClaim.Uic_Exempt);
	appLog('Accum_Wks_Yr_PdCst 			          : ' + format('%.2n', [ fSRClaim.Accum_Wks_Yr_PdCst ] ));
	appLog('Accum_Wks_Yr_90Net 			          : ' + format('%.2n', [ fSRClaim.Accum_Wks_Yr_90Net ] ));
	appLog('Wkly_Sal 				                  : ' + format('%.2n', [ fSRClaim.Wkly_Sal ] ));
	appLog('Wkly_Net 				                  : ' + format('%.2n', [ fSRClaim.Wkly_Net ] ));
	appLog('Wkly_90 				                  : ' + format('%.2n', [ fSRClaim.Wkly_90 ] ));
	appLog('Wkly_90_S 				                : ' + format('%.2n', [ fSRClaim.Wkly_90_S ] ));
	appLog('Wkly_80 				                  : ' + format('%.2n', [ fSRClaim.Wkly_80 ] ));
	appLog('Annual_Gross 				              : ' + format('%.2n', [ fSRClaim.Annual_Gross ] ));
	appLog('Annual_Net 				                : ' + format('%.2n', [ fSRClaim.Annual_Net ] ));
	appLog('Annual_90 				                : ' + format('%.2n', [ fSRClaim.Annual_90 ] ));
	appLog('Annual_90_S 				              : ' + format('%.2n', [ fSRClaim.Annual_90_S ] ));
	appLog('Annual_80 				                : ' + format('%.2n', [ fSRClaim.Annual_80 ] ));
	appLog('Tax_Exemption 				            : ' + format('%.2n', [ fSRClaim.Tax_Exemption ] ));
	appLog('Inc_Tax_Fed 				              : ' + format('%.2n', [ fSRClaim.Inc_Tax_Fed ] ));
	appLog('Inc_Tax_Prov 				              : ' + format('%.2n', [ fSRClaim.Inc_Tax_Prov ] ));
	appLog('Cpp_Prem 				                  : ' + format('%.2n', [ fSRClaim.Cpp_Prem ] ));
  appLog('Cpp2_Prem 				                  : ' + format('%.2n', [ fSRClaim.Cpp2_Prem ] ));
	appLog('Uic_Prem 				                  : ' + format('%.2n', [ fSRClaim.Uic_Prem ] ));
	appLog('Total_Deds 				                : ' + format('%.2n', [ fSRClaim.Total_Deds ] ));
	appLog('Wkly_Sal_A 				                : ' + format('%.2n', [ fSRClaim.Wkly_Sal_A ] ));
	appLog('Annual_Gross_A 				            : ' + format('%.2n', [ fSRClaim.Annual_Gross_A ] ));
	appLog('Annual_Net_A 				              : ' + format('%.2n', [ fSRClaim.Annual_Net_A ] ));
	appLog('Tax_Exemption_A 			            : ' + format('%.2n', [ fSRClaim.Tax_Exemption_A ] ));
	appLog('Inc_Tax_Fed_A 				            : ' + format('%.2n', [ fSRClaim.Inc_Tax_Fed_A ] ));
	appLog('Inc_Tax_Prov_A 				            : ' + format('%.2n', [ fSRClaim.Inc_Tax_Prov_A ] ));
	appLog('Cpp_Prem_A 				                : ' + format('%.2n', [ fSRClaim.Cpp_Prem_A ] ));
  appLog('Cpp2_Prem_A 				                : ' + format('%.2n', [ fSRClaim.Cpp2_Prem_A ] ));
	appLog('Uic_Prem_A 				                : ' + format('%.2n', [ fSRClaim.Uic_Prem_A ] ));
	appLog('Tax_Shelter_Bnft 			            : ' + format('%.2n', [ fSRClaim.Tax_Shelter_Bnft ] ));
	appLog('Tax_Shelter_Deduct 			          : ' + format('%.2n', [ fSRClaim.Tax_Shelter_Deduct ] ));
	appLog('Rebate_Amount 				            : ' + format('%.2n', [ fSRClaim.Rebate_Amount ] ));
	appLog('Weeks_Worked 				              : ' + format('%.2n', [ fSRClaim.Weeks_Worked ] ));
	appLog('Wkly_Tax_S 				                : ' + format('%.2n', [ fSRClaim.Wkly_Tax_S ] ));
	appLog('Total_Deds_A 				              : ' + format('%.2n', [ fSRClaim.Total_Deds_A ] ));
	appLog('Total_Tax_S 				              : ' + format('%.2n', [ fSRClaim.Total_Tax_S ] ));
	appLog('Total_Deds_P_A 				            : ' + format('%.2n', [ fSRClaim.Total_Deds_P_A ] ));
	appLog('Shelter_Rebate_Year 			        : ' + format('%d', [ fSRClaim.Shelter_Rebate_Year ] ));
  appLog('Prime_Firm_No 				            : ' + fSRClaim.Prime_Firm_No);
	appLog('Accident_Date				              : ' + FormatDateTime('c', fSRClaim.Accident_Date ));
  appLog('Self_Employed				              : ' + fSRClaim.Self_Employed);
  appLog('Recurrence				                : ' + fSRClaim.Recurrence);
  appLog('Child_Care_Exp                    : ' + format('%.2n', [ fSRClaim.Child_Care_Exp ] ));
  appLog('Spousal_Support				            : ' + format('%.2n', [ fSRClaim.Spousal_Support ] ));
  appLog('Child_Support				              : ' + format('%.2n', [ fSRClaim.Child_Support ] ));
  appLog('CPP_Exempt				                : ' + fSRClaim.CPP_Exempt);
  appLog('Tax_Exempt				                : ' + fSRClaim.Tax_Exempt);
  appLog('Max_Adjustment				            : ' + format('%.2n', [ fSRClaim.Max_Adjustment ] ));
	appLog('Nbr_Act_Shelter_Deduct		        : ' + format('%.2n', [ fSRClaim.Nbr_Act_Shelter_Deduct ] ));
	appLog('Recurrence_Date				            : ' + FormatDateTime('c', fSRClaim.Recurrence_Date ));
	appLog('Youthful_Worker				            : ' + fSRClaim.Youthful_Worker);
	appLog('Accum_Wks_Yr_90Net_Post		        : ' + format('%.2n', [ fSRClaim.Accum_Wks_Yr_90Net_Post ] ));
	appLog('workerAnnuityContributionPercent  : ' + format('%.2n', [ fSRClaim.workerAnnuityContributionPercent ] ));
	appLog('wcbAnnuityContributionPercent		  : ' + format('%.2n', [ fSRClaim.wcbAnnuityContributionPercent ] ));
	appLog('workerShetlerAnnuityContribAmt		: ' + format('%.2n', [ fSRClaim.workerShetlerAnnuityContribAmt ] ));
	appLog('wcbShelterAnnuityContribAmt		    : ' + format('%.2n', [ fSRClaim.wcbShelterAnnuityContribAmt ] ));
	appLog('paidFromDate				              : ' + FormatDateTime('c', fSRClaim.paidFromDate ));
	appLog('paidToDate				                : ' + FormatDateTime('c', fSRClaim.paidToDate ));
	appLog('employerPaidFlag			            : ' + fSRClaim.employerPaidFlag);
	appLog('processDateTime				            : ' + FormatDateTime('c', fSRClaim.processDateTime ));
	appLog('indexationYear 				            : ' + format('%d', [ fSRClaim.indexationYear ] ));
  appLog('PostInjuryEarnings			          : ' + format('%.2n', [ fSRClaim.PostInjuryEarnings ] ));
	appLog('reportType				                : ' + fSRClaim.reportType);
	appLog('collateralTaxableAmt			        : ' + format('%.2n', [ fSRClaim.collateralTaxableAmt ] ));
	appLog('collateralNonTaxableAmt			      : ' + format('%.2n', [ fSRClaim.collateralNonTaxableAmt ] ));
	appLog('sumWeeksPaidQty				            : ' + format('%.2n', [ fSRClaim.sumWeeksPaidQty ] ));
	appLog('sumWeeksPaidPost104EffDate		    : ' + format('%.2n', [ fSRClaim.sumWeeksPaidPost104EffDate ] ));
	appLog('paidOver52WeeksFlag			          : ' + fSRClaim.paidOver52WeeksFlag);
	appLog('rejectionReasonDesc			          : ' + fSRClaim.rejectionReasonDesc);
	appLog('doNotBatchProcessFlag			        : ' + fSRClaim.doNotBatchProcessFlag);
  appLog('End Printing Shelter Record....  ');
end;

function logActivity(var aClaimNumber, aLogType: String; aComponent : String): boolean;
var
  msg, userId : String;
  bReturn: boolean;
begin
  bReturn := True;
  userId := Utils.getWinUserName();

  if ( aLogType = LOG_TYPE_SELECT) then
    begin
      msg := 'The claim ' +  aClaimNumber + ' has been loaded by ' + userId + '.';
    end;

  if ( aLogType = LOG_TYPE_UPDATE) then
    begin
      msg := 'The claim ' +  aClaimNumber + ' has been updated by ' + userId + '.';
    end;

  if ( aLogType = LOG_TYPE_PAYMENT) then
    begin
      msg := 'A payment claim ' +  aClaimNumber + ' has been created by ' + userId + '.';
    end;

  try
    with dm1 do
    begin
      if qryLog.active then
        qryLog.close;
      qryLog.sql.clear;
      qryLog.sql.add('INSERT INTO dbo.tblActivityLog ' );
      qryLog.sql.add('(applicationName, componentName, userId, priority, [message], loggedDatetime) ' );
      qryLog.sql.add('VALUES( ' );
      qryLog.sql.add(SQLString( 'Wageloss' ) );
      qryLog.sql.add(SQLString( aComponent ) );
      qryLog.sql.add(SQLString( userId ) );
      qryLog.sql.add(SQLString( 'INFO' ) );
      qryLog.sql.add(SQLString( msg ) );
      qryLog.sql.add('GetDate()' + ')' );
      qryLog.ExecSQL;
      qryLog.close;
    end;
  except
    on E:Exception do
      begin
      MessageDlg('Log Update Failed. ' + Chr(10) + Chr(13) +  E.Message +
                   Chr(10) + Chr(13) +  'Please notify help desk at 4573.', mtError, [mbOK], 0 );
      bReturn := false;
      end;
  end;

  Result := bReturn;
  
end;

function getNextKey(aSequenceName: String; aIncreaseValue, aReservationId: Integer): Integer;
var
	newKey : integer;
begin
	newKey := -1;

  try
    With dm1.uspReserveKeysFromSequence do
       begin
       Parameters.ParamByName( '@sequenceName' ).Value := aSequenceName;
       Parameters.ParamByName( '@keyCount' ).Value := aIncreaseValue;
       Parameters.ParamByName( '@reservationId' ).Value := aReservationId;
       ExecProc;
       newKey := Parameters.ParamByName( '@RETURN_VALUE' ).Value;
       end;
  except
    on e:Exception do
       begin
       raise exception.create('Cannot generate the next key. Detail message: ' + e.message );
       end;
  end;

	result := newKey;
end;

function doReviewClaim104(var accidentDate, week104EffectiveDate  : TDateTime; claimNo : Shortstring; durationWeeks : currency): boolean;
var
  annuityEntitlementWeeks : currency;
begin
  annuityEntitlementWeeks :=  getAnnuityEntitlementWeeks(accidentDate, claimNo, durationWeeks);

  if ( week104EffectiveDate < 1 )and
     ( annuityEntitlementWeeks > 95.99 ) and
     ( annuityEntitlementWeeks <= 104 ) then
    result := true
  else
    result := false;
end;

function getAnnuityEntitlementWeeks(var accidentDate : TDateTime; claimNo : Shortstring; durationWeeks : currency): currency;
var
  annuityEntitlementWeeks : currency;
begin
  if ( getYearFromAccidentDate(accidentDate) >= 2006 ) then
  begin
    try
      with dm1 do
      begin
        if qryGeneralEmerge.active then
          qryGeneralEmerge.close;
        qryGeneralEmerge.sql.clear;
        qryGeneralEmerge.sql.add( 'SELECT ISNULL(annuityEntitlementWeeks, 0) as annuityEntitlmentWeeks ' );
        qryGeneralEmerge.sql.add( 'FROM ClaimPaymentSummary ' );
        qryGeneralEmerge.sql.add( 'WHERE claimNo = ' +  claimNo );
        qryGeneralEmerge.open;
        qryGeneralEmerge.first;
        annuityEntitlementWeeks := qryGeneralEmerge.FieldByName( 'annuityEntitlmentWeeks' ).AsCurrency;
        qryGeneralEmerge.close;
      end;
    except
      on e:Exception do
      begin
        raise exception.create('Cannot get annuity entitlement weeks from database. Detail message: ' + e.message );
      end;
    end;
  end
  else
    annuityEntitlementWeeks := durationWeeks;
  result := annuityEntitlementWeeks;
end;

function getYearFromAccidentDate(var accidentDate : TDateTime): Word;
var
   iYear, iMonth, iDay:Word;
begin
  DecodeDate( accidentDate, iYear, iMonth, iDay );
  result := iYear;
end;


procedure GetRemitChequeMessages(var tb: array of recNCCHQMSG);
var
   i:Integer;
begin
  try
     with dm1 do
        begin
        if qryRemittanceMessage.active then
           qryRemittanceMessage.close;

        qryRemittanceMessage.Parameters.ParamByName('currentDate1').Value := Now;
        qryRemittanceMessage.Parameters.ParamByName('currentDate2').Value := Now;
        qryRemittanceMessage.Open;
        qryRemittanceMessage.First;
        i := Low(tb);
        while (not qryRemittanceMessage.Eof) and (i <= High(RemittanceChequeMessages)) do
           begin
           tb[i].remittenceMessageId := qryRemittanceMessageremittanceMessageId.AsInteger;
           tb[i].legacyMesageCode := qryRemittanceMessagelegacyMessageCode.AsString;

           qryRemittanceMessage.Next;
           i := i + 1;
           end;


        qryRemittanceMessage.close;
        end;
  except
     on e:Exception do
        begin
        raise exception.create('Cannot load Remittance Cheque Message Table from database. Detail message: ' + e.message );
        end;
  end;

end;

procedure getEffectiveAccidentDate(Accident_Date, Recurrence_Date:TDateTime; Indexation_Year:Integer;
                                   Recurrence_Date_Status:String;
                                   var eAccident_Date:TDateTime;
                                   var eAcc_Year, eAcc_Month, eTax_Year:Integer);
var
   iAcc_Year, iAcc_Month, iAcc_Day:Word;
begin
   if Trim(Recurrence_Date_Status) = 'Y' then
      begin
      eAccident_Date := Recurrence_Date;
      DecodeDate(Recurrence_Date, iAcc_Year, iAcc_Month, iAcc_Day);
      end
   else
      begin
      eAccident_Date := Accident_Date;
      DecodeDate(Accident_Date, iAcc_Year, iAcc_Month, iAcc_Day);
      end;

   eAcc_Year := iAcc_Year;
   eAcc_Month := iAcc_Month;
   eTax_Year := Max(eAcc_Year, Indexation_Year);
end;

function getMaxAdjustment(Accident_Date, Recurrence_Date:TDateTime; Indexation_Year:Integer;Recurrence_Date_Status, Self_Employed_Status:String):Currency;
var
   i, eTax_Year, eAccident_Year, eAccident_Month : Integer;
   iAccident_Year, iAccident_Month, iAccident_Day : Word;
   iRecurrence_Year, iRecurrence_Month, iRecurrence_Day : Word;
   iAccident_Date, eAccident_Date : TDateTime;
   New_Max_Adjustment : Currency;
begin
  DecodeDate(Accident_Date, iAccident_Year, iAccident_Month, iAccident_Day);

  if ((iAccident_Year > 2005) And (iAccident_Year < 2022)) And
     (Trim(Self_Employed_Status) <> 'Y')                    then
     begin
     New_Max_Adjustment := 0; // Bill 59 regular worker
     end
  else
     begin
     getEffectiveAccidentDate(Accident_Date, Recurrence_Date, Indexation_Year, Recurrence_Date_Status,
                              eAccident_Date, eAccident_Year, eAccident_Month, eTax_Year);
     if ((iAccident_Year > 2005) And (iAccident_Year < 2022)) And
        (Trim(Self_Employed_Status) = 'Y')                    then
        begin
        New_Max_Adjustment := getSelfEmployedMaxAdjustment(eTax_Year, eAccident_Year, eAccident_Month, eAccident_Date);
        end
     else if (iAccident_Year < 2006) OR (iAccident_Year > 2021) then
        begin
        New_Max_Adjustment := LoadMaxAdjustment(eTax_Year, eAccident_Year, eAccident_Month, eAccident_Date, Accident_Date);
        end;
     end;

  result := New_Max_Adjustment;
end;

function getMinAdjustment(Accident_Date, Recurrence_Date:TDateTime; Indexation_Year:Integer;Recurrence_Date_Status, Self_Employed_Status:String):Currency;
var
   i, eTax_Year, eAccident_Year, eAccident_Month, iAccident_Day : Integer;
   iRecurrence_Year, iRecurrence_Month, iRecurrence_Day : Word;
   eAccident_Date : TDateTime;
   New_Min_Adjustment : Currency;
begin
  if Trim(Self_Employed_Status) <> 'Y' then
     begin
     New_Min_Adjustment := 0;
     end
  else
     begin
     getEffectiveAccidentDate(Accident_Date, Recurrence_Date, Indexation_Year, Recurrence_Date_Status,
                              eAccident_Date, eAccident_Year, eAccident_Month, eTax_Year);

     New_Min_Adjustment := getSelfEmployedMinAdjustment(eTax_Year, eAccident_Year, eAccident_Month, eAccident_Date);
     end;


  result := New_Min_Adjustment;
end;

function LoadMaxAdjustment(eTax_Year:Integer; eAccident_Year:Integer; eAccident_Month:Integer; eAccident_Date, iAccident_Date:TDateTime):Currency;
var
   i, iTax_Year, iAccident_Year : Integer;
   Acc_Year, Acc_Month, Acc_Day : Word;
   New_Max_Adjustment : Currency;
Begin
  if ((eTax_Year - eAccident_Year) < 2) Then
     iTax_Year := eAccident_Year
  else
     iTax_Year := eTax_Year;

  // Get values from MAX table
  if (year(iAccident_Date) < 2006) then
     begin
     for i := low(arrayNCANNMAX) to high(arrayNCANNMAX) do
        begin
        if (arrayNCANNMAX[i].Accident_Year > 1900) and
           (arrayNCANNMAX[i].Accident_Year = eAccident_Year) and
           (arrayNCANNMAX[i].Tax_Year = iTax_Year) then
           begin
           break;
           end;
        end;

     if (eAccident_Month = 12 ) Then
        New_Max_Adjustment := arrayNCANNMAX[i].Annual_Maximum_Dec
     else
        New_Max_Adjustment := arrayNCANNMAX[i].Annual_Maximum;
     end
  else if (year(iAccident_Date) > 2021) then
     begin
     for i := low(arrayNCANNMAXB18) to high(arrayNCANNMAXB18) do
        begin
        if (arrayNCANNMAXB18[i].Accident_Year > 1900) and
           (arrayNCANNMAXB18[i].Accident_Year = eAccident_Year) and
           (arrayNCANNMAXB18[i].Tax_Year = iTax_Year) then
           begin
           break;
           end;
        end;

     if (eAccident_Month = 12 ) Then
        New_Max_Adjustment := arrayNCANNMAXB18[i].Annual_Maximum_Dec
     else
        New_Max_Adjustment := arrayNCANNMAXB18[i].Annual_Maximum;
     end;

  Result := New_Max_Adjustment;
End;

function getNewIndexedAmount(Accident_Date:TDateTime; Indexation_Year, NewIndexation_Year:integer; Max_Adjustment:Currency):Currency;
var
   nc_index_amt:Currency;
   i, Start_Index_Year, End_Index_Year:integer;
begin
  //
  // If the claim has been indexed then perform the indexation to get the proper indexed max
  //
  nc_index_amt := Max_Adjustment;
  End_Index_Year := NewIndexation_Year;
  Start_Index_Year := Max(Year(Accident_Date), Indexation_Year);

  if NewIndexation_Year > Indexation_Year then
     begin
     if Month(Accident_Date) < 12 then
        begin
        if (Start_Index_Year < (Year(Accident_Date) + 2)) then
           Start_Index_Year := (Year(Accident_Date) + 2)
        else
           Start_Index_Year := Start_Index_Year + 1;
        end
     else
        begin
        if (Start_Index_Year < (Year(Accident_Date) + 3)) then
           Start_Index_Year := (Year(Accident_Date) + 3)
        else
           Start_Index_Year := Start_Index_Year + 1;
        end;

     for i := Start_Index_Year to End_Index_Year do
        begin
        nc_index_amt := pdoxRound(nc_index_amt * uGlobal.valueNCINDEXF(i),2)
        end;
     end
  else
     begin
     Start_Index_Year := Indexation_Year;
     if Month(Accident_Date) < 12 then
        begin
        if (NewIndexation_Year < (Year(Accident_Date) + 2)) then
           End_Index_Year := (Year(Accident_Date) + 2)
        else
           End_Index_Year := NewIndexation_Year + 1;
        end
     else
        begin
        if (NewIndexation_Year < (Year(Accident_Date) + 3)) then
           End_Index_Year := (Year(Accident_Date) + 3)
        else
           End_Index_Year := NewIndexation_Year + 1;
        end;

     for i := Start_Index_Year downto End_Index_Year do
        begin
        nc_index_amt := pdoxRound(nc_index_amt * (1/uGlobal.valueNCINDEXF(i)),2)
        end;
     end;


  result := nc_index_amt;
end;


function getSelfEmployedMaxAdjustment(iTaxYear, iAccidentYear, iAccidentMonth:Integer; AccidentDate:TDateTime): Currency;
var
  lngReturn, i, nc_Index_Year: Integer;
  AnnualMax, nc_index_amt:Currency;
begin
  result := 0;

  try
     dm1.usp_Get_Self_Employed_Max.Parameters.ParamByName( '@accidentDate' ).Value := AccidentDate;
     dm1.usp_Get_Self_Employed_Max.Open;
     lngReturn := dm1.usp_Get_Self_Employed_Max.Parameters.ParamByName( '@RETURN_VALUE' ).Value;

     if lngReturn = 0 Then
        begin
        if Not dm1.usp_Get_Self_Employed_Max.Eof Then
           begin
           AnnualMax := dm1.usp_Get_Self_Employed_Max.FieldByName( 'maxSelfEmployed' ).Value;
           end;

        dm1.usp_Get_Self_Employed_Max.Close;
        end;

     AnnualMax := getNewIndexedAmount(AccidentDate, iAccidentYear, iTaxYear, AnnualMax);

     result := AnnualMax;
  except
     on e:Exception do
        begin
        result := 0;
        dm1.usp_Get_Self_Employed_Max.Close;
        MessageDlg( '*Retrieve of Self Employed Max Adjustment failed. Please notify help desk at 4573', mtError, [mbOK], 0 );
        end;
  end;
end;


function getSelfEmployedMinAdjustment(iTaxYear, iAccidentYear, iAccident_Month:integer; iAccident_Date:TDateTime): Currency;
var
  lngReturn, i: Integer;
  AnnualMin, nc_index_amt:currency;
begin
  result := 0;

  try
     dm1.usp_Get_Self_Employed_Max.Parameters.ParamByName( '@accidentDate' ).Value := iAccident_Date;
     dm1.usp_Get_Self_Employed_Max.Open;
     lngReturn := dm1.usp_Get_Self_Employed_Max.Parameters.ParamByName( '@RETURN_VALUE' ).Value;

     if lngReturn = 0 Then
        begin
        if Not dm1.usp_Get_Self_Employed_Max.Eof Then
           begin
           AnnualMin := dm1.usp_Get_Self_Employed_Max.FieldByName( 'minSelfEmployed' ).Value;
           end;
        dm1.usp_Get_Self_Employed_Max.Close;
        end;


     AnnualMin := getNewIndexedAmount(iAccident_Date, iAccidentYear, iTaxYear, AnnualMin);
     result := AnnualMin;

  except
     on e:Exception do
        begin
        applog('TWagelossBenefitCalcForm.getSelfEmployedMinAdjustment - Exception - Message: ' + e.Message);
        result := 0;
        dm1.usp_Get_Self_Employed_Max.Close;
        MessageDlg( '*Retrieve of Self Employed Min Adjustment failed. Please notify help desk at 4573', mtError, [mbOK], 0 );
        end;
  end;
end;

function isSelfEmployedAdjInRange(adjAmount : Currency; CalcFullClaim:recNCCLAIM;
                                  isIndexation:Boolean; edMax_Adjustments:TEdit;
                                  Recurrence_Status, Self_Employed_Status:String;
                                  eIndexationYear:integer;eRecurrenceDate:TDateTime): String;
var
  lngReturn, iTax_Year, i: Integer;
  iAccident_Year, iAccident_Month, iAccident_Day: Word;
  nMax, nMin, index_amt_max, index_amt_min : Currency;
begin
  result := '';

  try
     nMax := getMaxAdjustment(CalcFullClaim.Accident_Date, eRecurrenceDate, eIndexationYear, Recurrence_Status, Self_Employed_Status);
     nMin := getMinAdjustment(CalcFullClaim.Accident_Date, eRecurrenceDate, eIndexationYear, Recurrence_Status, Self_Employed_Status);

     if nMax > 0 then
        begin
        if (adjAmount >= nMin) AND (adjAmount <= nMax) then
           begin
           // all good
           end
        else
           begin
           Result := Format('*Max Adj amount must be >= $ %.2n and <= $ %.2n',
                            [nMin,nMax]);
           //***
           if WagelossMainForm.isRunManualTest then
              if not isIndexation then
                 edMax_Adjustments.Text := format('%.2n',[nMin]);
              //***
           end
        end
     else
        begin
        if (adjAmount < nMin) then
           begin
           Result := Format('*Max Adj amount must be >= Min: $ %.2n',
                            [nMin]);
           //***
           if WagelossMainForm.isRunManualTest then
              if not isIndexation then
                 edMax_Adjustments.Text := format( '%.2n',[nMin] )
           //***
           end
        end;
  except
     on e:Exception do
        begin
        applog('TWagelossBenefitCalcForm.isSelfEmployedAdjInRange - Exception - Message: ' + e.Message);
        Result := 'Error';
        dm1.usp_Get_Self_Employed_Max.Close;
        MessageDlg( '*Retrieve of Self Employed Adjustment Amounts failed. Please notify help desk at 4573', mtError, [mbOK], 0 );
        end;
  end;
end;


end.
