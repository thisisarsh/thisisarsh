
@echo off
rem *****************************************************************
rem * Overpayments data from Main Frame file A75A.MW0201.OPFILE     *                                                               *
rem *  Execute copy of Overpayments file into Wageloss database     *
rem *                                                               *
rem *  Changed to run from Sysadmiral  June 2001                    *
rem *                                                               *
rem *   Step 1 ISQL to clear out data in Wageloss database          *
rem *      Step 1 is in OPDELETE.sql                                *
rem *   Step 2 Check if file from mainframe is there                *
rem *   Step 3 Bulkcopy data into Wageloss database                 *
rem *   STEP 4 Delete the file used for the Bulkcopy                *
rem *                                                               *
rem *****************************************************************


rem * RLloyd, July 4/07 - As part of following the the 'SQL Batch Job Standards.doc' specification, this file will no longer be used.  
rem * The steps in this file have been replaced by Tidal jobs WLME008, WLME010, & WLME012.  It would be best to remove this file 
rem * completely, but if that is not done, at least this will be commented out.

echo *** You should not be running Overpay2.BAT; it has been replaced by Tidal jobs WLME008, WLME010, & WLME012. ***

rem set DBSERVER=%1
rem set DBNAME=%2
rem set TBLNAME=%3
rem set INOUT=%4
rem set DBSERVER1=%5
rem set IOFILENAME=%6
rem set ERROR_FILE=%7
rem set ADDOPTIONS=%9
rem set BCPGENERICBAT=%8


rem echo STEP 2 Check file exists

rem if not exist %IOFILENAME% goto :Fail2


rem echo STEP 3 Bulkcopy data file

rem call %BCPGENERICBAT% %DBSERVER% %DBNAME% %TBLNAME% %INOUT% %DBSERVER1% %IOFILENAME% %ERROR_FILE% %ADDOPTIONS% 

rem if errorlevel 1 goto :Fail3


rem echo STEP 4 Delete data file

rem del %IOFILENAME%

rem if errorlevel 1 goto :Fail4


rem goto :Done



rem :Fail2
rem   echo *** Error Step 2, %IOFILENAME% file does not exist
rem   goto :Fail

rem :Fail3
rem   echo *** Error Step 3, call to %BCPGENERICBAT%
rem   goto :Fail

rem :Fail4
rem   echo *** Error Step 4, cannot delete %IOFILENAME%
rem   goto :Fail

rem :Fail
rem    OCSEXIT 1

rem :Done
