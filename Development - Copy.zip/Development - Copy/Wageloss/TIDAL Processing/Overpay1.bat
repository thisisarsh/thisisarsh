
@echo off
rem *****************************************************************
rem *  Execute import of overpayments data into Wageloss database   *
rem *                                                               *
rem *  Changed to run from Sysadmiral  September 2000               *
rem *                                                               *
rem *   Step 1 Delete records from wageloss database                *
rem *      Step 2 and 3 are in overpay2.bat                         *
rem *   Step 2 Check for opfile extracted from mainframe            *
rem *   Step 3 Bulkcopy data into wageloss database                 *
rem *                                                               *
rem *****************************************************************

rem RLloyd, June 25/07 - Change for NR61115 - this batch file will not be called.  
rem Instead, TIDAL scheduler will call ISQL_GENERICNew.bat, passing the opdelete.sql script path as a 
rem parameter.  Therefore all statements are commented out.  Ideally, this batch file should be removed, 
rem but if this is not the case, at least it won't do anything if run.

echo *** You should not be running Overpay1.BAT; it has been replaced by Tidal job WLME005. ***



rem echo STEP 1 ISQL
rem ***  STEP 1  Run SQL script
rem * /E trusted security, /b batch abort on error, /l 60 login timeout
rem * comment out next line to run in test, comment out one after for PROD

rem isql -E -b -l 60 -d wageloss_db -S WCBAP12 -i \\wcbsm2\apps\sqloper\operproc\wageloss\opdelete.sql
rem -o \\wcbfp1\vol1\apps\sqloper\operout\output.txt

rem isql -E -b -l 60 -d wageloss_db -S WCBAP2 -i \\wcbtsm1\apps\bss\datadown\wageloss\opdelete.sql 

rem -o \\wcbfp1\dev1\dev\apps\bss\datadown\output2.txt

rem if errorlevel 1 goto :Fail

rem goto :Done

rem :Fail
rem    OCSEXIT 1

rem :Done